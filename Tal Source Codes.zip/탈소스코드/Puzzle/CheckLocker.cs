using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CheckLocker : MonoBehaviour
{
    public GameObject[] nums;
    private int solveCount;

    private Action _succedCallback;
    private Action _failedCallback;

    public GameObject body;

    private void OnEnable()
    {
        nums[0].GetComponentInChildren<Button>().Select();
    }

    public void Play(Action succedCallback, Action failedCallback)
    {
        _succedCallback = succedCallback;
        _failedCallback = failedCallback;
    }

    public void SolveButtonClick()
    {
        solveCount = 0;

        for(int i = 0; i < nums.Length; i++)
        {
            if(nums[i].GetComponent<Locker>()._isSolve)
            {
                solveCount++;
            }
        }

        if(solveCount >= 4)
        {
            _succedCallback?.Invoke();
        }
        else
        {
            _failedCallback?.Invoke();
        }
        body.SetActive(false);
    }

}
