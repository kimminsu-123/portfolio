using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PuzzleSet : MonoBehaviour
{
    Action succedCallBack;
    Action failedCallBack;

    public GameObject body;
    public GameObject _locker;

    public void Show(Action _succedCallBack, Action _failedCallBack)
    {
        body.SetActive(true);
        _locker.GetComponent<CheckLocker>().Play(_succedCallBack, _failedCallBack);
    }
}
