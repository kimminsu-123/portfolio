using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class Locker : MonoBehaviour
{
    private int keypad;
    public int solvekey;
    public bool _isSolve = false;

    public TMPro.TMP_Text _textMeshPro;

    private void Start()
    {
        keypad = 0;
        _textMeshPro.text = keypad.ToString();
    }

    private void OnEnable()
    {
        JudgeisSolve();
    }

    public void CountUp()
    {
        if (keypad++ >= 9)
        {
            keypad = 0;
        }

        JudgeisSolve();
        
        _textMeshPro.text = keypad.ToString();
    }

    public void CountDown()
    {
        if (keypad-- <= 0)
        {
            keypad = 9;
        }

        JudgeisSolve();

        _textMeshPro.text = keypad.ToString();
    }

    public void JudgeisSolve()
    {
        if (keypad == solvekey)
        {
            _isSolve = true;
        }
        else
        {
            _isSolve = false;
        }
    }
}
