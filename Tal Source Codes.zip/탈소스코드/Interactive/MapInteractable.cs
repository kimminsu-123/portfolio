using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class MapInteractable : Interactable
{
    [SerializeField] private UnityEvent onEnd;
    [SerializeField] private Sprite image;

    private Action<bool> _callback;

    protected override void Execute(GameObject interactor, Action<bool> callback)
    {
        _callback = callback;
        UIManager.Instance.ViewMap.Show(image, OnEndCommunication);
    }

    private void OnEndCommunication()
    {
        onEnd?.Invoke();
        _callback?.Invoke(true);
    }
}
