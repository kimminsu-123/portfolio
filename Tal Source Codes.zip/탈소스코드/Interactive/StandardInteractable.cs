using System;
using UnityEngine;
using UnityEngine.Events;

public class StandardInteractable : Interactable
{
    [SerializeField] private UnityEvent action;

    protected override void Execute(GameObject interactor, Action<bool> callback)
    {
        action?.Invoke();
        callback?.Invoke(true);
    }
}