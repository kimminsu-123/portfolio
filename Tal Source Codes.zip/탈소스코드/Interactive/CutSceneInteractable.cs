using System;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Playables;

public class CutSceneInteractable : Interactable
{
    [SerializeField] private PlayableDirector director;
    [SerializeField] private PlayableAsset timeline;

    [SerializeField] private UnityEvent onEndCutScene;

    private Action<bool> _callback;
    
    protected override void Execute(GameObject interactor, Action<bool> callback)
    {
        _callback = callback;
        // CutSceneManager.Play(timeline, OnEndCutScene)
    }

    private void OnEndCutScene()
    {
        onEndCutScene?.Invoke();
        _callback?.Invoke(true);   
    }
}