using System;
using Scipts.Scriptable_Objects;
using UnityEngine;
using UnityEngine.Events;

public class GenerateItemInteractable : Interactable
{
    [SerializeField] private InventorySO inventory;
    [SerializeField] private ItemDataSO[] generateItems;

    [SerializeField] private UnityEvent onSuccess;
    [SerializeField] private UnityEvent onFailed;

    protected override void Execute(GameObject interactor, Action<bool> callback)
    {
        if (inventory.RemainSize < generateItems.Length)
        {
            onFailed?.Invoke();
            callback?.Invoke(false);
            return;
        }
        
        for (int i = 0; i < generateItems.Length; i++)
        {
            inventory.AddItem(generateItems[i]);
        }
        onSuccess?.Invoke();
        callback?.Invoke(true);
    }
}