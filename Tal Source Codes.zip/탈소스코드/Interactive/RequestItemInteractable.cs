using System;
using System.Collections.Generic;
using Scipts.Scriptable_Objects;
using UnityEngine;
using UnityEngine.Events;

public class RequestItemInteractable : Interactable
{
    [SerializeField] private InventorySO inventory;
    [SerializeField] private ItemDataSO[] requestItems;

    [SerializeField] private UnityEvent onSuccess;
    [SerializeField] private UnityEvent onFailed;
    
    protected override void Execute(GameObject interactor, Action<bool> callback)
    {
        for (int i = 0; i < requestItems.Length; i++)
        {
            bool haveItem = inventory.HaveItem(requestItems[i]);
            if (!haveItem)
            {
                onFailed?.Invoke();
                callback?.Invoke(false);
                return;
            }
        }

        for (int i = 0; i < requestItems.Length; i++)
        {
            inventory.RemoveItem(requestItems[i]);
        }
        onSuccess?.Invoke();
        callback?.Invoke(true);
    }
}