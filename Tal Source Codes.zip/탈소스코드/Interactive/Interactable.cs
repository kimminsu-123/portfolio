using System;
using UnityEngine;

public abstract class Interactable : MonoBehaviour
{
    [SerializeField] private Interactable subInteractable;

    private void Start()
    {
        
    }

    public void Interact(GameObject interactor, Action<bool> callback)
    {
        Execute(interactor, (doNext) =>
        {
            if (doNext && subInteractable != null)
            {
                subInteractable.Interact(interactor, callback);
            }
            else
            {
                callback?.Invoke(doNext);
            }
        });
    }
    
    protected abstract void Execute(GameObject interactor, Action<bool> callback);
}