using UnityEngine;
using UnityEngine.Events;

public class RegionInteractable : MonoBehaviour
{
    public bool disabledAfterInteract = true;

    [Header("Interact Config")]
    public LayerMask targetLayerMask;
    public UnityEvent onEnterRegion;
    public Interactable subInteractable;

    [Header("Region Config")] 
    public Vector2 size;
    public Vector2 offset;
    
    private BoxCollider2D _detectCollider;

    private void Awake()
    {
        _detectCollider = gameObject.AddComponent<BoxCollider2D>();
    }

    private void OnEnable()
    {
        _detectCollider.isTrigger = true;
        _detectCollider.size = size;
        _detectCollider.offset = offset;
    }

    private void OnTriggerEnter2D(Collider2D col)
    {
        bool isTarget = (targetLayerMask & (1 << col.gameObject.layer)) > 0;
        if (!isTarget)
        {
            return;
        }
        
        PlayerController controller = col.GetComponentInParent<PlayerController>();
        controller.SetStateInteracting();

        if (subInteractable != null)
        {
            subInteractable.Interact(col.gameObject, _ => controller.ChangeState(State.Normal));
        }
        else
        {
            controller.ChangeState(State.Normal);
        }

        onEnterRegion?.Invoke();

        if (disabledAfterInteract)
        {
            gameObject.SetActive(false);
        }
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireCube(transform.position + (Vector3)offset, size);
    }
}