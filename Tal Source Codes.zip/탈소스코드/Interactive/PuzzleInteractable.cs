using System;
using UnityEngine;
using UnityEngine.Events;

public class PuzzleInteractable : Interactable
{
    // Puzzle 데이터를 들고 있으면 될 듯?
    // 성공 콜백, 실패 콜백
    [SerializeField] private UnityEvent successCallback;
    [SerializeField] private UnityEvent failedCallback;

    private Action<bool> _callback;

    protected override void Execute(GameObject interactor, Action<bool> callback)
    {
        _callback = callback;
        Debug.Log("asd");
        UIManager.Instance.PuzzleSet.Show(OnSucceed, OnFailed);
    }
    
    private void OnSucceed()
    {
        successCallback?.Invoke();
        _callback?.Invoke(true);
    }

    private void OnFailed()
    {
        failedCallback?.Invoke();
        _callback?.Invoke(false);
    }
}