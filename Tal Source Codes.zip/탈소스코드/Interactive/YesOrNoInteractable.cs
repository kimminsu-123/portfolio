using System;
using UnityEngine;
using UnityEngine.Events;

public class YesOrNoInteractable : Interactable
{
    [SerializeField] private YesOrNoSO dialogSo;
    [SerializeField] private UnityEvent yesCallbacks;
    [SerializeField] private UnityEvent noCallbacks;

    private Action<bool> _callback;

    protected override void Execute(GameObject interactor, Action<bool> callback)
    {
        _callback = callback;
        UIManager.Instance.YesOrNoDialog.Show(dialogSo, DoYes, DoNo);
    }

    public void Execute()
    {
        var controller = FindObjectOfType<PlayerController>();
        controller.SetStateInteracting();
        Interact(controller.gameObject, controller.OnEndInteract);
    }

    private void DoYes()
    {
        yesCallbacks?.Invoke();
        _callback?.Invoke(true);
    }

    private void DoNo()
    {
        noCallbacks?.Invoke();
        _callback?.Invoke(false);
    }
}