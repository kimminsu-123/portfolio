using System;
using UnityEngine;
using UnityEngine.Events;

public class CommunicationInteractable : Interactable
{
    [SerializeField] private TextData data;
    [SerializeField] private UnityEvent onEnd;
    
    private Action<bool> _callback;
    
    protected override void Execute(GameObject interactor, Action<bool> callback)
    {
        _callback = callback;
        UIManager.Instance.CommunicationDialog.Show(data, OnEndCommunication);
    }

    public void Execute()
    {
        var controller = FindObjectOfType<PlayerController>();
        controller.SetStateInteracting();
        Interact(controller.gameObject, controller.OnEndInteract);
    }

    private void OnEndCommunication()
    {
        onEnd?.Invoke();
        _callback?.Invoke(true);
    }
}