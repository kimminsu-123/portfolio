public interface IItem
{
}