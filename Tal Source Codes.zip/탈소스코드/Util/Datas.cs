using System;
using UnityEngine;

[Serializable]
public class SpeechData
{
    public string name;
    [TextArea] public string text;
    public AudioClip sound;
    public Sprite icon;
}

public static class SoundNames
{
    public static readonly string SFX_ClickButton = "ClickButton";
    public static readonly string SFX_Kung = "Kung";
    public static readonly string SFX_Locker = "Locker";
    public static readonly string SFX_MonsterAttack = "MonsterAttack";
    public static readonly string SFX_OpenDoor = "OpenDoor";
    public static readonly string SFX_PlayerDeath = "PlayerDeath";
    public static readonly string SFX_SkipTalk = "SkipTalk";
    public static readonly string SFX_StepFloor = "StepFloor";
    public static readonly string SFX_StepRoad = "StepRoad";
    public static readonly string SFX_Bucket = "Bucket";

    public static readonly string BGM_Main = "BGM_Main";
    public static readonly string BGM_DarkMonster = "BGM_DarkMonster";
}