using System;
using UnityEngine;

[RequireComponent(typeof(AudioSource))]
public class AnimationEventStepSounds : MonoBehaviour
{
    private AudioSource _source;

    private void Start()
    {
        _source = GetComponent<AudioSource>();
    }

    public void PlayStepSound()
    {
        var clip = SoundManager.Instance.FindSfx(SoundNames.SFX_StepFloor);
        if (clip != null)
        {
            _source.PlayOneShot(clip); 
        }
    }
}