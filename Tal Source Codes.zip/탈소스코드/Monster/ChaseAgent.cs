using System;
using SAP2D;
using UnityEngine;

[RequireComponent(typeof(SAP2DAgent))]
public class ChaseAgent : MonoBehaviour
{
    private enum State
    {
        Patrol,
        Chase
    }

    public bool useFlip = true;
    public Transform[] patrolPoints;
    public LayerMask targetLayer;
    
    public ChasingArea chasingArea;
    public Stage stage;

    private bool _targetInStage = false;
    private State _currentState = State.Patrol;
    private SAP2DAgent _agent;
    private int _currentPatrolIndex;
    private SpriteRenderer _cachedSpriteRen;
    
    private void Awake()
    {
        _agent = GetComponent<SAP2DAgent>();
        _cachedSpriteRen = GetComponent<SpriteRenderer>();
    }

    private void OnEnable()
    {
        _targetInStage = false;
        _currentPatrolIndex = 0;
        if (patrolPoints.Length > 0)
        {
            _currentState = State.Patrol;
            _agent.Target = patrolPoints[_currentPatrolIndex];
            _agent.CanMove = true;
            _agent.CanSearch = true;   
        }
        else
        {
            if (_agent.Target != null)
            {
                Wait();
            }
        }

        if (chasingArea != null)
        {
            chasingArea.onEnter.AddListener(OnEnterArea);
            chasingArea.onExit.AddListener(OnExitArea);   
        }
        
        stage.onEnter.AddListener(OnEnterStage);
        stage.onExit.AddListener(OnExitStage);
    }

    public void Wait()
    {
        _agent.CanMove = false;
        _agent.CanSearch = false;
    }

    public void Release()
    {
        _agent.CanMove = true;
        _agent.CanSearch = true;
    }

    private void Update()
    {
        if (useFlip)
        {
            Flip();
        }
        
        if (_currentState == State.Patrol)
        {
            Patrol();   
        }
    }

    private void Flip()
    {
        Transform target = _agent.Target;
        if (target == null)
        {
            return;
        }

        Vector2 direction = (target.position - transform.position).normalized;
        if (direction.x > 0f)
        {
            _cachedSpriteRen.flipX = false;
        }
        else if (direction.x < 0f)
        {
            _cachedSpriteRen.flipX = true;
        }
    }
    
    private void Patrol()
    {
        if (_agent.Target == null)
        {
            return;
        }
        Vector2 currentPos = transform.position;
        if (Vector3.Distance(currentPos, _agent.Target.position) <= _agent.GetNextPointDistance)
        {
            _currentPatrolIndex = (_currentPatrolIndex + 1) % patrolPoints.Length;
            _agent.Target = patrolPoints[_currentPatrolIndex];
        }
    }

    private void OnEnterStage(Collider2D target)
    {
        bool isTarget = (targetLayer.value & (1 << target.gameObject.layer)) > 0;
        if (!isTarget)
        {
            return;
        }

        _targetInStage = true;
    }
    
    private void OnExitStage(Collider2D target)
    {
        bool isTarget = (targetLayer.value & (1 << target.gameObject.layer)) > 0;
        if (!isTarget)
        {
            return;
        }

        _targetInStage = false;
        if (_currentState == State.Chase && patrolPoints.Length > 0)
        {
            _currentPatrolIndex = 0;
            _currentState = State.Patrol;
            _agent.Target = patrolPoints[_currentPatrolIndex];
        }
    }
    
    private void OnEnterArea(Collider2D target)
    {
        bool isTarget = (targetLayer.value & (1 << target.gameObject.layer)) > 0;

        if (!isTarget || !_targetInStage)
        {
            return;
        }
        
        _currentState = State.Chase;
        _agent.Target = target.transform;    
    }

    private void OnExitArea(Collider2D target)
    {
        bool isTarget = (targetLayer.value & (1 << target.gameObject.layer)) > 0;

        if (!isTarget)
        {
            return;
        }

        if (_currentState == State.Chase && patrolPoints.Length > 0)
        {
            _currentPatrolIndex = 0;
            _currentState = State.Patrol;
            _agent.Target = patrolPoints[_currentPatrolIndex];    
        }
    }
}