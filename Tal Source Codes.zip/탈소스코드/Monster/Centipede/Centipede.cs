using System;
using System.Collections.Generic;
using SAP2D;
using UnityEngine;

public class Centipede : MonoBehaviour
{
    public CentipedeParts nextParts;

    private SAP2DAgent _agent;
    private Vector3 _prevPosition;

    private void Awake()
    {
        _agent = GetComponent<SAP2DAgent>();
    }

    private void Start()
    {
        _agent.onNextPoint.AddListener(OnNextPoint);
        _prevPosition = transform.position;
    }

    private void OnNextPoint()
    {
        _prevPosition = transform.position;
        nextParts.SetPoint(_prevPosition);
    }
}