using System;
using UnityEngine;

public class Follower : MonoBehaviour
{
    public Transform follower;

    public bool initialize = true;
    public float distance;
    public Direction initDirection;

    private void Start()
    {
        if (!initialize)
        {
            return;
        }

        Vector3 dir = Vector3.zero;
        switch (initDirection)
        {
            case Direction.Up:
                dir = -Vector3.up * distance;
                break;
            case Direction.Down:
                dir = -Vector3.down * distance;
                break;
            case Direction.Left:
                dir = -Vector3.left * distance;
                break;
            case Direction.Right:
                dir = -Vector3.right * distance;
                break;
        }

        transform.position = follower.position + dir;
    }

    private void Update()
    {
        transform.position =
            follower.position + Vector3.ClampMagnitude(transform.position - follower.position,  Mathf.Sqrt(distance * 2));
    }
}