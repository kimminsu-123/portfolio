using System;
using System.Collections.Generic;
using Unity.Mathematics;
using Unity.VisualScripting.Dependencies.NCalc;
using UnityEngine;

public class CentipedeParts : MonoBehaviour
{
    public float followSpeed = 2f;
    public CentipedeParts nextParts;
    
    private Vector3 _point;
    private Vector3 _prevPoint;
    private float _t;

    private void Start()
    {
        _t = 0f;
    }

    public void SetPoint(Vector3 point)
    {
        _prevPoint = _point;
        _point = point;
        _t = 0f;
        
        Vector2 direction = (point - transform.position).normalized;
        var angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg; 
        transform.rotation = Quaternion.Euler(Vector3.forward * (angle + 90f));
        
        if (nextParts != null)
        {
            nextParts.SetPoint(_prevPoint);
        }
    }

    private void Update()
    {
        if (_t >= 1f)
        {
            return;
        }

        _t += Time.deltaTime * followSpeed;
        transform.position = Vector3.Lerp(_prevPoint, _point, _t);
    }
}