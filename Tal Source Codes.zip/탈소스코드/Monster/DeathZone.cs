using System;
using UnityEngine;

public class DeathZone : MonoBehaviour
{
    public LayerMask targetLayer;
    
    private Collider2D _cachedCol;

    private void Awake()
    {
        _cachedCol = GetComponent<Collider2D>();
    }

    private void Start()
    {
        _cachedCol.isTrigger = true;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        bool isTarget = (targetLayer & (1 << other.gameObject.layer)) > 0;
        if (isTarget)
        {
            other.GetComponentInParent<PlayerController>().Die();   
        }
    }
}