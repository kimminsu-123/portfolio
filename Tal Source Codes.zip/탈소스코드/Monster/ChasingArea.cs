using System;
using System.Security.Cryptography;
using UnityEngine;
using UnityEngine.Events;

public class ChasingArea : MonoBehaviour
{
    public Vector2 size;
    public Vector2 offset;

    public UnityEvent<Collider2D> onEnter;
    public UnityEvent<Collider2D> onExit;

    private BoxCollider2D _cachedCollider;
    
    private void Awake()
    {
        _cachedCollider = gameObject.AddComponent<BoxCollider2D>();
    }

    private void Start()
    {
        _cachedCollider.offset = offset;
        _cachedCollider.size = size;
        _cachedCollider.isTrigger = true;
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireCube(transform.position + (Vector3)offset, size * (Vector2)transform.lossyScale);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        onEnter?.Invoke(other);
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        onExit?.Invoke(other);
    }
}