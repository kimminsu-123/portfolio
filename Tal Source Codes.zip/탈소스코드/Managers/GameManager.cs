using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : SingletonMonoBehavior<GameManager>
{
    public void LoadGame()
    {
        SceneManager.LoadScene("Scenes/InGame Demo");//("InGame Scene");
    }

    public void LoadMain()
    {
        SceneManager.LoadScene("Main Scene");
    }
    
    public void ExitGame()
    {
#if UNITY_EDITOR
        EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }
}
