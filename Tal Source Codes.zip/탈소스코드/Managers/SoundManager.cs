using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

[System.Serializable]
public class Sound
{
    public string name;
    public AudioClip clip;
}

public class SoundManager : SingletonMonoBehavior<SoundManager>
{
    [SerializeField] private Sound[] sfx = null;
    [SerializeField] private Sound[] bgm = null;

    [SerializeField] private AudioSource bgmPlayer = null;
    [SerializeField] private AudioSource[] sfxPlayer = null;


    private void Start()
    {
        sfxPlayer[0].volume = 0.1f;
    }

    public void PlayBGM(string bgmName)
    {
        Sound found = bgm.FirstOrDefault(x => x.name.Equals(bgmName));
        if (found == null)
        {
            return;
        }

        bgmPlayer.clip = found.clip;
        bgmPlayer.Play();
    }
    public void StopBGM()
    {
        bgmPlayer.Stop();
    }

    public AudioClip FindSfx(string name)
    {
        return sfx.FirstOrDefault(x => x.name.Equals(name))?.clip;
    }

    public void PlayOneShot(string sfxName)
    {
        if (sfx.Length <= 0)
            return;

        Sound found = sfx.FirstOrDefault(x => x.name.Equals(sfxName));
        if (found == null)
        {
            return;
        }

        sfxPlayer[0].PlayOneShot(found.clip);
    }

    public void PlaySFX(string sfxName)
    {
        if (sfx.Length <= 0)
            return;

        Sound found = sfx.FirstOrDefault(x => x.name.Equals(sfxName));
        if (found == null)
        {
            return;
        }

        AudioSource notUsingPlayer = sfxPlayer.FirstOrDefault(x => !x.isPlaying);
        if (notUsingPlayer == null)
        {
            return;
        }
        notUsingPlayer.clip = found.clip;
        notUsingPlayer.Play();
    }
}