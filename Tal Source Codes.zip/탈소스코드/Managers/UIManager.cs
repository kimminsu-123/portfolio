using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UIManager : SingletonMonoBehavior<UIManager>
{
    public YesOrNoDialog YesOrNoDialog => _yesOrNoDialog;
    public CommunicationDialog CommunicationDialog => _communicationDialog;

    private YesOrNoDialog _yesOrNoDialog;
    private CommunicationDialog _communicationDialog;

    public GameOverUI GameOverUI => _gameOverUI;

    private GameOverUI _gameOverUI;

    public ViewMap ViewMap => _viewMap;
    private ViewMap _viewMap;

    public PuzzleSet PuzzleSet => _puzzleSet;
    private PuzzleSet _puzzleSet;

    protected override void OnAwake()
    {
        _yesOrNoDialog = GetComponentInChildren<YesOrNoDialog>(true);
        _communicationDialog = GetComponentInChildren<CommunicationDialog>(true);
        _gameOverUI = GetComponentInChildren<GameOverUI>(true);
        _viewMap = GetComponentInChildren<ViewMap>(true);
        _puzzleSet = GetComponentInChildren<PuzzleSet>(true);
    }
}