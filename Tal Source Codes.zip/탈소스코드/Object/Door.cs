using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum DoorState
{
    Open,
    Close,
    Lock,
}

public class Door : MonoBehaviour
{
    public DoorState state;
    public Sprite doorOpen;
    public Sprite doorClose;

    public void Open()
    {
        if(state == DoorState.Lock)
        {
            return;
        }

        if (state == DoorState.Open)
        {
            return;
        }

        state = DoorState.Open;
        GetComponent<SpriteRenderer>().sprite = doorOpen;
        GetComponent<Collider2D>().enabled = false;
        SoundManager.Instance.PlayOneShot(SoundNames.SFX_OpenDoor);
    }

    public void Unlock()
    {
        if(state != DoorState.Lock)
        {
            return;
        }

        state = DoorState.Close;

        Open();
    }

    public void Close()
    {
        if(state != DoorState.Open)
        {
            return;
        }

        state = DoorState.Close;
        GetComponent<SpriteRenderer>().sprite = doorClose;
        GetComponent<Collider2D>().enabled = true;
        SoundManager.Instance.PlayOneShot(SoundNames.SFX_OpenDoor);
    }
}
