using Object;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Oni : MonoBehaviour
{
    public FadeLight startFade;
    public float fadeValue;

    public void OnEnable()
    {
        startFade.Fade(fadeValue);
    }
}
