using System;
using DG.Tweening;
using UnityEngine;
using UnityEngine.Events;

namespace Object
{
    public class MovePoints : MonoBehaviour
    {
        public Transform[] points;
        public UnityEvent onArriveLastPoint;
        public float moveDuration = 1f;
        
        private int _currentIndex;

        private void Start()
        {
            _currentIndex = -1;
        }

        public void MoveNext()
        {
            _currentIndex++;
            if (_currentIndex >= points.Length)
            {
                return;
            }

            if (_currentIndex == points.Length - 1)
            {
                transform.DOMove(points[_currentIndex].position, moveDuration)
                    .SetEase(Ease.Unset)
                    .OnComplete(() => onArriveLastPoint?.Invoke())
                    .Play();   
            }
            else
            {
                transform.DOMove(points[_currentIndex].position, moveDuration)
                    .SetEase(Ease.Unset)
                    .Play();
            }
        }
    }
}