using System;
using DG.Tweening;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Rendering.Universal;

namespace Object
{
    public class FadeLight : MonoBehaviour
    {
        public Light2D targetLight;
        public UnityEvent onCompleteFade;
        public float duration = 1f;

        private bool _isFading;

        private void OnEnable()
        {
            _isFading = false;
        }

        public void Fade(float intensity)
        {
            if (_isFading)
            {
                return;
            }

            _isFading = true;
            DOTween.To(
                    () => targetLight.intensity,
                    (v) => targetLight.intensity = v,
                    intensity,
                    duration)
                .OnComplete(() =>
                {
                    _isFading = false;
                    onCompleteFade?.Invoke();
                })
                .Play();
        }
    }
}