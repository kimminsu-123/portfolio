using System;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Rendering;

public class YesOrNoTest : MonoBehaviour
{
    public Interactable target;
    
    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            target.Interact(gameObject, b =>
            {
                Debug.Log($"Interaction Finish {b}");
            });
        }
    }

    public void Debugging(int a)
    {
        Debug.Log(a);
    }
}