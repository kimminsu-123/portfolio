using System;
using System.Linq;
using Scipts.Scriptable_Objects;
using UnityEngine;

public class SOTest : MonoBehaviour
{
    public InventorySO InventorySo;
    public ItemDataSO ItemDataSo1;
    public ItemDataSO ItemDataSo2;
    public ItemDataSO ItemDataSo3;

    public void Update()
    {
        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            var r = InventorySo.AddItem(ItemDataSo1) ? $"Success Add {ItemDataSo1.Id}" : $"Failed Add {ItemDataSo1.Id}";
            Debug.Log(r);
            PrintInventory();
        }

        if (Input.GetKeyDown(KeyCode.Alpha2))
        {
            var r = InventorySo.AddItem(ItemDataSo2) ? $"Success Add {ItemDataSo2.Id}" : $"Failed Add {ItemDataSo2.Id}";
            Debug.Log(r);
            PrintInventory();
        }

        if (Input.GetKeyDown(KeyCode.Alpha3))
        {
            var r = InventorySo.AddItem(ItemDataSo3) ? $"Success Add {ItemDataSo3.Id}" : $"Failed Add {ItemDataSo3.Id}";
            Debug.Log(r);
            PrintInventory();
        }

        if (Input.GetKeyDown(KeyCode.Q))
        {
            var r = InventorySo.RemoveItem(ItemDataSo1)
                ? $"Success Remove {ItemDataSo1.Id}"
                : $"Failed Remove {ItemDataSo1.Id}";
            Debug.Log(r);
            PrintInventory();
        }

        if (Input.GetKeyDown(KeyCode.W))
        {
            var r = InventorySo.RemoveItem(ItemDataSo2)
                ? $"Success Remove {ItemDataSo2.Id}"
                : $"Failed Remove {ItemDataSo2.Id}";
            Debug.Log(r);
            PrintInventory();
        }

        if (Input.GetKeyDown(KeyCode.E))
        {
            var r = InventorySo.RemoveItem(ItemDataSo3)
                ? $"Success Remove {ItemDataSo3.Id}"
                : $"Failed Remove {ItemDataSo3.Id}";
            Debug.Log(r);
            PrintInventory();
        }
    }

    private void PrintInventory()
    {
        Debug.Log($"{string.Join(", ", InventorySo.GetItems.Select(x => x.Id))}");
    }
}