using System;
using UnityEngine;
using UnityEngine.Rendering;

public class OverlapTilemapTest : MonoBehaviour
{
    private void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            var mousePos = Input.mousePosition;
            var worldPos = Camera.main.ScreenToWorldPoint(mousePos);
            
            Debug.Log(worldPos);

            var cols = Physics2D.OverlapCircleAll(worldPos, 1f);
            Debug.Log(cols.Length);
        }
    }
}