using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class GameOverUI : MonoBehaviour
{
    [SerializeField] private Image profileImage;
    [SerializeField] private TMP_Text talkText;

    public void Die()
    {
        gameObject.SetActive(true);

        StartCoroutine(FadeImage());
    }

    private IEnumerator FadeImage()
    {
        float fadeCount = 0;

        while(fadeCount <= 1)
        {
            profileImage.color = new Color(0,0,0,fadeCount);
            fadeCount += Time.deltaTime;
            yield return null;
        }

        fadeCount = 0;

        while (fadeCount <= 1)
        {
            talkText.color = new Color(1, 1, 1, fadeCount);
            fadeCount += Time.deltaTime;
            yield return null;
        }

        yield return new WaitForSeconds(0.25f);
        GameManager.Instance.LoadMain();
        yield return new WaitForSeconds(0.25f);
        gameObject.SetActive(false);
    }
}
