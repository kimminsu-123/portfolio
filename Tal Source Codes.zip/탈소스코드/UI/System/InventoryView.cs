using Scipts.Scriptable_Objects;
using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class InventoryView : MonoBehaviour
{
    [SerializeField] private Sprite defaultItemIcon;
    [SerializeField] private InventorySO inventorySo;
    [SerializeField] private Image[] itemSlots;
    
    private void Start()
    {
        inventorySo.Initialize();
        inventorySo.RegisterEventOnChanged(UpdateView);
    }

    public void UpdateView()
    {
        int index = 0;
        List<ItemDataSO> items = inventorySo.GetItems;
        for(index = 0; index < items.Count; index++)
        {
            itemSlots[index].sprite = items[index].Icon;
        }

        for(; index < itemSlots.Length; index++)
        {
            itemSlots[index].sprite = defaultItemIcon;
        }
    }
    
    private void OnDestroy()
    {
        inventorySo.UnregisterEventOnChanged(UpdateView);
    }
}
/*

public class PlayerUI : MonoBehaviour
{
    private Image[] Masks;
    private Image[] item;

    [SerializeField]
    private InventorySO maskInven;
    [SerializeField]
    private InventorySO ItemInven;

    private void Start()
    {
        maskInven.RegisterEventOnChanged(UpdateMaskView);
        ItemInven.RegisterEventOnChanged(UpdateInventoryView);
    }
    private void UpdateInventoryView()
    {
        int i = 0;
        foreach(var a in ItemInven.GetItems)
        {
            item[i++].sprite = a.Icon;
        }
    }

    private void UpdateMaskView()
    {
        int i = 0;
        foreach (var a in maskInven.GetItems)
        {
            item[i++].sprite = a.Icon;
        }
    }

    public void SetInventory(ItemDataSO data)
    {

    }

    private void OnDestroy()
    {
        maskInven.UnregisterEventOnChanged(UpdateMaskView);
        ItemInven.UnregisterEventOnChanged(UpdateInventoryView);
    }
}*/
