using System;
using System.Collections;
using System.Collections.Generic;
using System.Net.Mime;
using Unity.VisualScripting;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class CommunicationDialog : MonoBehaviour
{
    private class DialogData
    {
        public TextData TextData;
        public Action Action;

        public DialogData(TextData data, Action callback)
        {
            TextData = data;
            Action = callback;
        }
    }
    
    [SerializeField] private Image profileImage;
    [SerializeField] private TMP_Text talkText;
    [SerializeField] private float typingInterval = 0.02f;

    private TextData _data;
    private Action _callback;
    private Coroutine _typingCoroutineInstance;
    private WaitForSeconds _typingCoroutineInterval;

    private Queue<DialogData> _queue;

    private int dialogNum;
    private bool isTyping;

    private void Start()
    {
        _queue = new Queue<DialogData>();
    }

    private void Update()
    {
        if (!isTyping)
            return;

        if (Input.GetKeyDown(KeyCode.Space))
        {
            SoundManager.Instance.PlayOneShot(SoundNames.SFX_SkipTalk);
            if (++dialogNum < _data.textData.Length)
            {
                if (_typingCoroutineInstance != null)
                {
                    StopCoroutine(_typingCoroutineInstance);
                }
                _typingCoroutineInstance = StartCoroutine(Typing());
            }
            else
            {
                StopAllCoroutines();
                
                if (_queue.Count > 0)
                {
                    _callback?.Invoke();

                    var data = _queue.Dequeue();
                    _data = data.TextData;
                    _callback = data.Action;
                    dialogNum = 0;
                    isTyping = true;

                    StartCoroutine(Typing());
                }
                else
                {
                    gameObject.SetActive(false);
                    _callback?.Invoke();
                }
            }
        }
    }

    public void Show(TextData data, Action callback)
    {
        if (gameObject.activeSelf)
        {
            _queue.Enqueue(new DialogData(data, callback));
            return;
        }
        gameObject.SetActive(true);

        _typingCoroutineInterval = new WaitForSeconds(typingInterval);

        _data = data;
        _callback = callback;
        dialogNum = 0;
        isTyping = true;

        StartCoroutine(Typing());
    }

    private IEnumerator Typing()
    {
        SpeechData data = _data.textData[dialogNum];
        profileImage.sprite = data.icon;
        talkText.text = "";

        if (data.sound != null)
        {
            // 사운드 재생
        }
        
        for (int index = 0; index < data.text.Length; index++)
        {
            yield return _typingCoroutineInterval;
            talkText.text += data.text[index];
        }
    }
}