using System;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class YesOrNoDialog : MonoBehaviour
{
    [SerializeField] private GameObject dialog;
    [SerializeField] private TMP_Text contents;
    [SerializeField] private Button yesButton;
    [SerializeField] private Button noButton;

    private TMP_Text _yesButtonText;
    private TMP_Text _noButtonText;

    private void Awake()
    {
        _yesButtonText = yesButton.GetComponentInChildren<TMP_Text>(true);
        _noButtonText = noButton.GetComponentInChildren<TMP_Text>(true);
    }

    public void Show(YesOrNoSO data, UnityAction yesCallback, UnityAction noCallback)
    {
        contents.text = data.Message;
        _yesButtonText.text = data.YesText;
        _noButtonText.text = data.NoText;
        
        yesButton.onClick.AddListener(Hide);
        yesButton.onClick.AddListener(yesCallback);
        noButton.onClick.AddListener(Hide);
        noButton.onClick.AddListener(noCallback);
        
        dialog.gameObject.SetActive(true);
        
        yesButton.Select();
    }

    public void Hide()
    {
        yesButton.onClick.RemoveAllListeners();
        noButton.onClick.RemoveAllListeners();
        dialog.gameObject.SetActive(false);
    }
}