using System;
using UnityEngine;
using UnityEngine.UI;

public class MainCanvas : MonoBehaviour
{
    public Button playGameButton;
    public Button exitGameButton;

    private void Start()
    {
        playGameButton.onClick.AddListener(GameManager.Instance.LoadGame);
        exitGameButton.onClick.AddListener(GameManager.Instance.ExitGame);
    }
}