using System;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using UnityEngine;

public class PingPongAnimation : MonoBehaviour
{
    public float range = 1f;
    public float duration = 1f;
    public Direction direction;

    private Vector2 _startPos;
    private Tweener _tweener;
    private RectTransform _cachedRectTr;

    private void Awake()
    {
        _cachedRectTr = GetComponent<RectTransform>();
    }

    private void OnEnable()
    {
        _startPos = _cachedRectTr.localPosition;
        
        Vector2 dir = _startPos;
        
        switch (direction)
        {
            case Direction.Up:
                dir += Vector2.up * range;
                break;
            case Direction.Down:
                dir += Vector2.down * range;
                break;
            case Direction.Left:
                dir += Vector2.left * range;
                break;
            case Direction.Right:
                dir += Vector2.right * range;
                break;
        }
        
        _tweener = transform.DOLocalMove(dir, duration)
            .SetLoops(-1, LoopType.Yoyo)
            .SetEase(Ease.Unset)
            .Play();
    }

    private void OnDisable()
    {
        _cachedRectTr.localPosition = _startPos;
        _tweener?.Kill();
    }
}
