using System;
using System.Collections;
using System.Collections.Generic;
using System.Net.Mime;
using System.Runtime.CompilerServices;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;

public class ViewMap : MonoBehaviour
{
    public Image image;
    private Action _callback;

    private void Update()
    {
        if (!gameObject.activeSelf)
            return;

        if(Input.GetKeyDown(KeyCode.Space))
        {
            gameObject.SetActive(false);
        }
    }

    public void Show(Sprite image, Action callback)
    {
        this.image.sprite = image;
        _callback = callback;

        gameObject.SetActive(true);
    }

    private void OnDisable()
    {
        _callback?.Invoke();
    }
}
