using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ButtonClickSound : MonoBehaviour
{
    private Button _button;
    
    public void Awake()
    {
        _button = GetComponent<Button>();
    }

    public void OnEnable()
    {
        _button.onClick.AddListener(PlayOneshot);
    }

    public void PlayOneshot()
    {
        SoundManager.Instance.PlayOneShot(SoundNames.SFX_ClickButton);
    }
}
