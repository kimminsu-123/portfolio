using UnityEngine;

[CreateAssetMenu(fileName = "TextData",menuName = "Scriptable Objects/TextData", order = int.MaxValue)]
public class TextData : ScriptableObject
{
    public SpeechData[] textData;
}