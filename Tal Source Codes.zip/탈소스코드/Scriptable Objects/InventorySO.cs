using System.Collections.Generic;
using System.Linq;
using Scipts.Scriptable_Objects;
using UnityEngine;
using UnityEngine.Events;

[CreateAssetMenu(fileName = "Inventory", menuName = "Assets/S.O/Inventory", order = 0)]
public class InventorySO : ScriptableObject
{
    [SerializeField] private uint inventorySize;
    [SerializeField] private UnityEvent onInventoryChanged;

    public uint InventorySize => inventorySize;
    public uint RemainSize => InventorySize - (uint)_items.Count;

    private Dictionary<uint, ItemDataSO> _items;

    public void Initialize()
    {
        _items = new Dictionary<uint, ItemDataSO>();
    }

    public void RegisterEventOnChanged(UnityAction callback)
    {
        onInventoryChanged.AddListener(callback);
    }

    public void UnregisterEventOnChanged(UnityAction callback)
    {
        onInventoryChanged.RemoveListener(callback);
    }

    public bool AddItem(ItemDataSO item)
    {
        if (_items.Count >= inventorySize)
        {
            return false;
        }

        if (_items.ContainsKey(item.Id))
        {
            return false;
        }
        
        _items.Add(item.Id, item);
        onInventoryChanged?.Invoke();
        
        return true;    
    }

    public bool RemoveItem(ItemDataSO item)
    {
        if (_items.Count <= 0)
        {
            return false;
        }

        if (!_items.ContainsKey(item.Id))
        {
            return false;
        }

        _items.Remove(item.Id);
        onInventoryChanged?.Invoke();
        
        return true;
    }

    public bool HaveItem(ItemDataSO item) => _items.ContainsKey(item.Id);
    public List<ItemDataSO> GetItems => _items.Values.ToList();
}