using UnityEngine;

namespace Scipts.Scriptable_Objects
{
    [CreateAssetMenu(fileName = "ItemData", menuName = "Assets/S.O/ItemData", order = 0)]
    public class ItemDataSO : ScriptableObject
    {
        [SerializeField] private uint id;
        [SerializeField] private Sprite icon;
        [SerializeField] private string description;
        
        public uint Id => id;
        public Sprite Icon => icon;
        public string Description => description;
    }
}