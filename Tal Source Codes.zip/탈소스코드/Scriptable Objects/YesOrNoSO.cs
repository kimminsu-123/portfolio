using UnityEngine;

[CreateAssetMenu(fileName = "YesOrNo Contents", menuName = "Assets/S.O/YesOrNo", order = 0)]
public class YesOrNoSO : ScriptableObject
{
    [TextArea]
    [SerializeField] private string message;
    [SerializeField] private string yesText;
    [SerializeField] private string noText;

    public string Message => message;
    public string YesText => yesText;
    public string NoText => noText; 
}