using System.Text;
using System.Windows.Forms;

namespace RankingServer
{
    public partial class FormMain : Form
    {
        private class ClearData : IComparable<ClearData>
        {
            public string Name;
            public long Ticks;

            public ClearData()
            {
                Name = string.Empty;
                Ticks = long.MaxValue;
            }

            public int CompareTo(ClearData? other)
            {
                if (other == null) return -1;

                return Ticks.CompareTo(other.Ticks);
            }
        }

        public const int NAME_LEN = 128;
        private UDPReceiver _receiver;

        private List<ClearData> _stageClearRanks;
        private List<ClearData> _waveClearRanks;
        private int _port;

        public FormMain()
        {
            InitializeComponent();

            _stageClearRanks = new List<ClearData>(6);
            _waveClearRanks = new List<ClearData>(6);
        }

        private void ReadFile()
        {
            string path = @".\serverinfo.ini";

            if (!File.Exists(path))
            {
                SetErrorText("���� ������ �������� �ʽ��ϴ�.");
                _port = -1;
                return;
            }

            try
            {
                string port = File.ReadLines(path).First();

                _port = int.Parse(port);
            }
            catch (Exception ex)
            {
                SetErrorText($"���� �д� �� ���� : {ex.Message}");
                _port = -1;
            }
        }

        private void SetErrorText(string txt)
        {
            Invoke(new MethodInvoker(delegate ()
            {
                Label_Error.Text = txt;
            }));
        }

        private void AddStageList(string name, long ticks)
        {
            Invoke(new MethodInvoker(delegate ()
            {
                _stageClearRanks.Add(new ClearData()
                {
                    Name = name,
                    Ticks = ticks
                });
                _stageClearRanks = _stageClearRanks.OrderBy(x => x.Ticks).Take(5).ToList();

                Grid_StageMode.Rows.Clear();
                for (int i = 0; i < _stageClearRanks.Count; i++)
                {
                    ClearData data = _stageClearRanks[i];

                    if (data == null)
                    {
                        Grid_StageMode.Rows.Add($"{i + 1}", string.Empty, string.Empty);
                    }
                    else
                    {
                        TimeSpan timeSpan = TimeSpan.FromTicks(data.Ticks);

                        Grid_StageMode.Rows.Add($"{i + 1}", $"{data.Name}", $"{timeSpan.Minutes:00}:{timeSpan.Seconds:00}");
                    }
                }
            }));
        }

        private void AddWaveList(string name, long ticks)
        {
            Invoke(new MethodInvoker(delegate ()
            {
                _waveClearRanks.Add(new ClearData()
                {
                    Name = name,
                    Ticks = ticks
                });
                _waveClearRanks = _waveClearRanks.OrderBy(x => x.Ticks).Take(5).ToList();

                Grid_WaveMode.Rows.Clear();
                for (int i = 0; i < _waveClearRanks.Count; i++)
                {
                    ClearData data = _waveClearRanks[i];

                    if (data == null)
                    {
                        Grid_WaveMode.Rows.Add($"{i + 1}", string.Empty, string.Empty);
                    }
                    else
                    {
                        TimeSpan timeSpan = TimeSpan.FromTicks(data.Ticks);

                        Grid_WaveMode.Rows.Add($"{i + 1}", $"{data.Name}", $"{timeSpan.Minutes:00}:{timeSpan.Seconds:00}");
                    }
                }
            }));
        }

        private void StartServer()
        {
            try
            {
                _receiver = new UDPReceiver(_port);
                _receiver.OnReceive += OnReceive;
                _receiver.Start();

                Label_Error.Text = "������ ���������� ���� �Ǿ����ϴ�.";
            }
            catch (Exception ex)
            {
                Label_Error.Text = $"{_port} - {ex.Message}";
            }
        }

        private void OnReceive(byte[] buffer)
        {
            if (buffer != null && buffer.Length != 0)
            {
                int offset = 0;
                offset += Deserialize(buffer, offset, out int type);
                offset += Deserialize(buffer, offset, out string name);
                offset += Deserialize(buffer, offset, out long ticks);

                if (type == 0)
                {
                    AddStageList(name, ticks);
                }
                else
                {
                    AddWaveList(name, ticks);
                }
            }
        }

        private int Deserialize(byte[] buffer, int offset, out int value)
        {
            value = 0;

            try
            {
                byte[] bytes = new byte[sizeof(int)];
                Array.Copy(buffer, offset, bytes, 0, bytes.Length);

                value = BitConverter.ToInt32(bytes, 0);
            }
            catch (Exception ex)
            {
                SetErrorText(ex.Message);
            }

            return sizeof(int);
        }

        private int Deserialize(byte[] buffer, int offset, out string value)
        {
            value = string.Empty;

            try
            {
                byte[] bytes = new byte[NAME_LEN];
                Array.Copy(buffer, offset, bytes, 0, bytes.Length);

                if (BitConverter.IsLittleEndian)
                {
                    Array.Reverse(bytes);
                }

                value = Encoding.UTF8.GetString(bytes, 0, bytes.Length).Trim('\0');
            }
            catch (Exception ex)
            {
                SetErrorText(ex.Message);
            }

            return NAME_LEN;
        }

        private int Deserialize(byte[] buffer, int offset, out long value)
        {
            value = 0;
            try
            {
                byte[] bytes = new byte[sizeof(long)];
                Array.Copy(buffer, offset, bytes, 0, bytes.Length);

                value = BitConverter.ToInt64(bytes, 0);
            }
            catch (Exception ex)
            {
                SetErrorText(ex.Message);
            }

            return sizeof(long);
        }

        private void FormMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            _receiver?.Dispose();
        }

        private void FormMain_Load(object sender, EventArgs e)
        {
            ReadFile();
            if (_port > 0)
            {
                StartServer();
            }
        }

        private void Grid_WaveMode_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
