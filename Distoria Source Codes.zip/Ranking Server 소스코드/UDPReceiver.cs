﻿using System.Net;
using System.Net.Sockets;

namespace RankingServer
{
    public class UDPReceiver : IDisposable
    {
        public const int BUFFER_SIZE = 512;

        public delegate void OnReceiveCallback(byte[] buffer);

        public OnReceiveCallback OnReceive;

        private Socket _socket;
        private IPEndPoint _ipEndPoint;
        private CancellationTokenSource _tokenSource;

        public UDPReceiver(int port)
        {
            _socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            _ipEndPoint = new IPEndPoint(IPAddress.Any, port);
            _tokenSource = new CancellationTokenSource();
        }

        public void Start()
        {
            _socket.Bind(_ipEndPoint);

            ProcessReceive();
        }

        public void Stop()
        {
            _tokenSource?.Cancel();
        }

        private void ProcessReceive()
        {
            if (_tokenSource.IsCancellationRequested)
            {
                return;
            }

            SocketAsyncEventArgs args = new SocketAsyncEventArgs();
            args.SetBuffer(new byte[BUFFER_SIZE], 0, BUFFER_SIZE);
            args.RemoteEndPoint = new IPEndPoint(IPAddress.None, 0);
            args.Completed += OnCompletedReceive;

            lock (_socket)
            {
                _socket.ReceiveFromAsync(args);
            }
        }

        private void OnCompletedReceive(object? sender, SocketAsyncEventArgs e)
        {
            byte[] buffer = e.Buffer;
            if(buffer != null)
            {
                try
                {
                    OnReceive?.Invoke(buffer);
                }
                finally
                {
                    ProcessReceive();
                }
            }
        }

        public void Dispose()
        {
            Stop();

            _socket?.Close();
            _socket?.Dispose();
        }
    }
}
