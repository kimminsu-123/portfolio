using UnityEngine;

namespace ProjectAAA.Utils.Visualizer
{
    public abstract class Visualizer : MonoBehaviour
    {
        public Color gizmosColor = Color.red;
        public bool drawWireframe = false;
    }
}