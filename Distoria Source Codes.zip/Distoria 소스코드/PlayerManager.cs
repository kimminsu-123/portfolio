using System;
using System.Collections;
using KinematicCharacterController;
using ProjectAAA.Core.Action;
using ProjectAAA.Core.Entity;
using ProjectAAA.Core.Managers;
using ProjectAAA.Interaction.Items;
using ProjectAAA.Player;
using ProjectAAA.Player.Actions;
using ProjectAAA.SO;
using ProjectAAA.UI;
using ProjectAAA.UI.MainFight;
using ProjectAAA.Utils;
using ProjectAAA.Utils.DataTable;
using ProjectAAA.WeaponSystem;
using UniRx;
using UnityEngine;
using EventType = ProjectAAA.Core.Managers.EventType;

namespace ProjectAAA.Core.Scene.Manager
{
    public class PlayerManager : SingletonMonoBehavior<PlayerManager>
    {
        public ActionFlagSO dashActionFlag;
        
        public GameObject PlayerGo => playerMotor.gameObject;
        public KinematicCharacterMotor PlayerMotor => playerMotor;
        public LivingEntity PlayerEntity => _playerEntity;
        public WeaponHandler WeaponHandler => _playerWeaponHandler;
        public PlayerController PlayerController => _playerController;
        public IActionable ActionController => _playerActionController;
        public GameObject PlayerUI => playerUI;
        public ItemHandler ItemHandler => _playerItemHandler;
        
        public Camera MainCamera { get; private set; }

        [SerializeField] private KinematicCharacterMotor playerMotor;
        [SerializeField] private GameObject playerUI;
        
        private LivingEntity _playerEntity;
        private WeaponHandler _playerWeaponHandler;
        private PlayerController _playerController;
        private PlayerCamera _playerCamera;
        private IActionable _playerActionController;
        private ItemHandler _playerItemHandler;

        protected override void Initialize()
        {
            MainCamera = Camera.main;
            playerUI.SetActive(false);
            PlayerGo.SetActive(false);
            
            _playerEntity = PlayerGo.GetComponent<LivingEntity>();
            _playerController = PlayerGo.GetComponent<PlayerController>();
            _playerCamera = PlayerGo.GetComponentInChildren<PlayerCamera>(true);
            _playerWeaponHandler = PlayerGo.GetComponent<WeaponHandler>();
            _playerActionController = PlayerGo.GetComponent<IActionable>();
            _playerItemHandler = PlayerGo.GetComponent<ItemHandler>();
            
            EventManager.Instance.AddListener(EventType.OnBeginLoadSceneGroup, DeActivePlayer);
            EventManager.Instance.AddListener(EventType.OnEndLoadSceneGroup, ActivePlayer);
            EventManager.Instance.AddListener(EventType.OnPlayerDeath, OnPlayerDeath);
        }

        private void Start()
        {
            StartCoroutine(BindPlayerToUI());
        }

        private IEnumerator BindPlayerToUI()
        {
            while (!UiManager.Instance.Contains<MainFightUI>())
            {
                yield return Awaitable.NextFrameAsync();
            }
                            
            UiManager.Instance.Get<MainFightUI>().HealthUI.BindEntity(_playerEntity);
            UiManager.Instance.Get<MainFightUI>().DashUI.ClearDash();
            
            PlayerCurrencyManager.Instance.Key.Subscribe(UiManager.Instance.Get<MainFightUI>().CurrencyUI.OnChangeKey);
            PlayerCurrencyManager.Instance.Gold.Subscribe(UiManager.Instance.Get<MainFightUI>().CurrencyUI.OnChangeGold);

            _playerWeaponHandler.CurrentWeapon.Subscribe(weapon =>
            {
                if (weapon != null)
                {
                    int index = _playerWeaponHandler.CurrentWeaponIndex() + 1;

                    UiManager.Instance.Get<MainFightUI>().WeaponPreviewUI.UpdatePreviewIndex(index);
                    UiManager.Instance.Get<MainFightUI>().WeaponPreviewUI.UpdatePreviewImage(weapon.WeaponImage);
                }
            });
            
            _playerWeaponHandler.onChangeAmmo.AddListener(() =>
            {
                WeaponBase weapon = _playerWeaponHandler.CurrentWeapon.Value;

                int ammo = 0;
                int count = 0;

                if (weapon != null) 
                {
                    ammo = Global.InfinityAmmo;
                    if (weapon.AmmoAmount != Global.InfinityAmmo)
                    {
                        ammo = weapon.CurrentAmmo + weapon.CurrentMagazineAmmoCount;
                    }
                    count = weapon.CurrentMagazineAmmoCount;
                }

                UiManager.Instance.Get<MainFightUI>().WeaponPreviewUI.UpdateAmmo(ammo);
                UiManager.Instance.Get<MainFightUI>().WeaponPreviewUI.UpdateClip(count);
            });
        }

        private void OnPlayerDeath(Component sender, object[] args)
        {
            EventManager.Instance.PostNotification(EventType.PlayerClear, this);
        }

        private void ActivePlayer(Component sender, object[] args)
        {
            GameObject spawnPoint = GameObject.FindGameObjectWithTag(Global.SpawnPointTag);
            if (spawnPoint != null)
            {
                PlayerGo.SetActive(true);
                playerUI.SetActive(true);

                playerMotor.transform.parent = spawnPoint.transform;
                playerMotor.SetPositionAndRotation(spawnPoint.transform.position, spawnPoint.transform.rotation, false);
                _playerCamera.SetHorizontalRotation(spawnPoint.transform.rotation.eulerAngles);
                playerMotor.BaseVelocity = Vector3.zero;

                EventManager.Instance.PostNotification(EventType.OnPlayerActive, this);
            }
        }

        public void DeActivePlayer(Component sender, object[] args)
        {
            playerMotor.BaseVelocity = Vector3.zero;
            playerMotor.transform.parent = gameObject.transform;
            playerMotor.SetPositionAndRotation(Vector3.zero, Quaternion.identity, false);
            playerUI.SetActive(false);
            PlayerGo.SetActive(false);
            
            EventManager.Instance.PostNotification(EventType.OnPlayerDeActive, this);
        }
    }
}