using ProjectAAA.Utils;
using UnityEngine;
using UnityEngine.Playables;

namespace ProjectAAA.Timeline
{
    public class LoadSceneAsset :  PlayableAsset
    {
        public SceneReference scene;
        
        public override Playable CreatePlayable(PlayableGraph graph, GameObject owner)
        {
            var playable = ScriptPlayable<LoadSceneBehaviour>.Create(graph);
            var behaviour = playable.GetBehaviour();
            
            behaviour.Scene = scene;

            return playable;
        }
    }
}