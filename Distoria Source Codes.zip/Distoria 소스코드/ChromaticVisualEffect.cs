using System.Linq;
using DG.Tweening;
using ProjectAAA.SO.CameraEffect;
using ProjectAAA.SO.CameraEffect.Visual;
using UnityEngine;
using UnityEngine.Rendering.Universal;

namespace ProjectAAA.CameraEffect
{
    public class ChromaticVisualEffect : CameraEffectBase
    {
        private ChromaticAberration  _chromaticAberration;
        private ChromaticEffectDataSO _chromaticEffectDataSo;
        private Tweener _chromaticTweener;
        
        public override void Initialize()
        {
            base.Initialize();

            if(_volumeProfile.TryGet(out ChromaticAberration value))
            {
                _chromaticAberration = value;
            }
            else
            {
                _volumeProfile.components.Add(ScriptableObject.CreateInstance<ChromaticAberration>());
                
                _chromaticAberration = _volumeProfile.components.OfType<ChromaticAberration>().First();
            }

            _chromaticAberration.intensity.value = 0f;
        }
        
        protected override void Setup(EffectDataSO effectData)
        {
            _chromaticEffectDataSo = effectData as ChromaticEffectDataSO;
        }

        public override void OnRegister(EffectDataSO effectData)
        {
            base.OnRegister(effectData);
            
            float duration = _chromaticEffectDataSo.AnimationCurve.keys.Last().time;

            _chromaticTweener?.Kill();
            _chromaticTweener = DOTween.To(() => 0f, x => _chromaticAberration.intensity.value = x, 1f, duration)
                .SetEase(_chromaticEffectDataSo.AnimationCurve)
                .SetAutoKill(true)
                .OnComplete(() =>
                {
                    _chromaticTweener = DOTween.To(() => 1f, x => _chromaticAberration.intensity.value = x, 0f, duration)
                        .SetEase(_chromaticEffectDataSo.AnimationCurve)
                        .SetAutoKill(true)
                        .Play();
                })
                .Play();
        }
    }
}