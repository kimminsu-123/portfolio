using System.Collections.Generic;
using UnityEngine;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.Core.Entity
{
    [RequireComponent(typeof(Animator))]
    public class AnimatorWrapper : MonoBehaviour
    {
        [SerializeField] private List<Animator> registeredAnimators;
        
        private Animator _cachedAnimator;

        private void Awake()
        {
            _cachedAnimator = GetComponent<Animator>();
        }
        
        public void Rebind(bool notifyListeners = true, float speed = 1f)
        {
            _cachedAnimator.speed = speed;
            _cachedAnimator.Rebind();

            if (!notifyListeners) return;
            
            foreach (var animator in registeredAnimators)
            {
                if (animator != null)
                {
                    animator.speed = speed;
                    animator.Rebind();
                }
            }
        }

        public void SetBool(int id, bool value, bool notifyListeners = true, float speed = 1f)
        {
            _cachedAnimator.speed = speed;
            _cachedAnimator.SetBool(id, value);

            if (!notifyListeners) return;
            
            foreach (var animator in registeredAnimators)
            {
                if (animator != null)
                {
                    animator.speed = speed;
                    animator.SetBool(id, value);
                }
            }
        }

        public void SetFloat(int id, float value, bool notifyListeners = true, float speed = 1f)
        {
            _cachedAnimator.speed = speed;
            _cachedAnimator.SetFloat(id, value);
            
            if (!notifyListeners) return;
            
            foreach (var animator in registeredAnimators)
            {
                if (animator != null)
                {
                    animator.speed = speed;
                    animator.SetFloat(id, value);
                }
            }
        }
        
        public void CrossFade(int id, float normalizedDuration, int layer, float normalizedTimeOffset, float normalizedTime, bool notifyListeners = true, float speed = 1f)
        {
            _cachedAnimator.speed = speed;
            _cachedAnimator.CrossFade(id, normalizedDuration, layer, normalizedTimeOffset, normalizedTime);
            
            if (!notifyListeners) return;
            
            foreach (var animator in registeredAnimators)
            {
                if (animator != null)
                {
                    animator.speed = speed;
                    animator.CrossFade(id, normalizedDuration, layer, normalizedTimeOffset, normalizedTime);
                }
            }
        }
        
        public float GetFloat(int id) => _cachedAnimator.GetFloat(id);
        public bool GetBool(int id) => _cachedAnimator.GetBool(id);
        public int GetInteger(int id) => _cachedAnimator.GetInteger(id);

        public void AddAnimator(Animator animator)
        {
            registeredAnimators.Add(animator);
        }

        public void RemoveAnimator(Animator animator)
        {
            registeredAnimators.Remove(animator);
        }

        public void SetOverrideController(RuntimeAnimatorController overrideController)
        {
            _cachedAnimator.runtimeAnimatorController = overrideController;
        }
    }
}