using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;

namespace ProjectAAA.UI
{
    public class PointerButton : MonoBehaviour, IPointerClickHandler
    {
        public UnityEvent onClick;
        
        public void OnPointerClick(PointerEventData eventData)
        {
            onClick?.Invoke();
        }
    }
}