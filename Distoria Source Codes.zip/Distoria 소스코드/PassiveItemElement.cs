using Cysharp.Threading.Tasks.Triggers;
using ProjectAAA.Core.Managers;
using ProjectAAA.Core.Pool;
using ProjectAAA.Utils.DataTable;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace ProjectAAA.UI
{
    public class PassiveItemElement : PoolObjMonoBehaviour, IPointerEnterHandler, IPointerExitHandler, IPointerMoveHandler
    {
        [SerializeField] private Image image;

        private string _itemName;
        private ItemGrade _itemGrade;
        private string _itemDescription;

        public void SetImage(Sprite icon)
        {
            image.sprite = icon;
        }

        public void SetName(string itemName)
        {
            _itemName = itemName;
        }

        public void SetGrade(ItemGrade grade)
        {
            _itemGrade = grade;
        }

        public void SetDescription(string description)
        {
            _itemDescription = description;
        }

        public void OnPointerEnter(PointerEventData eventData)
        {
            UiManager.Instance.Get<PassiveItemDetail>().SetIcon(image.sprite);
            UiManager.Instance.Get<PassiveItemDetail>().SetName(_itemName);
            UiManager.Instance.Get<PassiveItemDetail>().SetGrade(_itemGrade);
            UiManager.Instance.Get<PassiveItemDetail>().SetDescription(_itemDescription);
            UiManager.Instance.Get<PassiveItemDetail>().Show();
        }

        public void OnPointerExit(PointerEventData eventData)
        {
            UiManager.Instance.Get<PassiveItemDetail>().Hide();
        }

        public void OnPointerMove(PointerEventData eventData)
        {
            UiManager.Instance.Get<PassiveItemDetail>().Move(eventData.position);
        }
    }
}