using ProjectAAA.SO.Pool;
using UnityEngine;

namespace ProjectAAA.Core.Pool
{
    public class PoolObjContainer : MonoBehaviour
    {
        [SerializeField] protected ObjectPoolSO[] objPoolSo;

        protected virtual void Start()
        {
            Initialize();
        }

        protected virtual void Initialize()
        {
            for (int i = 0; i < objPoolSo.Length; i++)
            {
                objPoolSo[i].SetupPool(transform);
            }
        }

        protected virtual void OnDestroy()
        {
            for (int i = 0; i < objPoolSo.Length; i++)
            {
                objPoolSo[i].Clear();
            }
        }
    }
}