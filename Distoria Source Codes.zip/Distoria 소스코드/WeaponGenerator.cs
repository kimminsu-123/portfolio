using System.Collections.Generic;
using ProjectAAA.Core.Pool;
using ProjectAAA.SO.Pool;
using ProjectAAA.Utils;
using UnityEngine;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.WeaponSystem
{
    public class WeaponGenerator : Generator<int, WeaponBase>
    {
        protected override bool InitOnStart => false;
        protected override bool GetKey(ObjectPoolSO pool, ref int key)
        {
            WeaponBase weapon = pool.Get<WeaponBase>(transform);
            if (weapon == null) return false;

            key = weapon.WeaponId;
            pool.ReturnQueue(weapon);

            return true;
        }
    }
}