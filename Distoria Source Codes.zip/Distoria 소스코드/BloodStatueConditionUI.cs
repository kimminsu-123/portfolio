using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace ProjectAAA.UI.Statue
{
    public struct BloodConditionData
    {
        public float CurrentHp { get; }
        public float RequireHp { get; }

        public BloodConditionData(float hp, float requireHp)
        {
            CurrentHp = hp;
            RequireHp = requireHp;
        }
    }
    
    public class BloodStatueConditionUI : StatueConditionUI
    {
        protected override Type RegisterType => typeof(BloodStatueConditionUI);

        [SerializeField] private TMP_Text currentHealthText;
        [SerializeField] private TMP_Text requireHealthText;
        [SerializeField] private Image fillImage;

        public void Setup(BloodConditionData data)
        {
            BlockImage.gameObject.SetActive(data.CurrentHp <= data.RequireHp);

            currentHealthText.text = $"{data.CurrentHp:F0}";
            requireHealthText.text = $"{data.RequireHp:F0}";
            
            if(Mathf.Approximately(0f, data.RequireHp))
            {
                fillImage.fillAmount = 1f;
            }
            else
            {
                fillImage.fillAmount = data.CurrentHp / data.RequireHp;
            }
        }
    }
}