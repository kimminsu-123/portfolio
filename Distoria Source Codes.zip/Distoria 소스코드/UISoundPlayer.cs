using ProjectAAA.Core.Managers;
using ProjectAAA.SO;
using UnityEngine;
using UnityEngine.EventSystems;

namespace ProjectAAA.UI
{
    public class UISoundPlayer : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler, IPointerDownHandler, IPointerUpHandler, IPointerClickHandler
    {
        public FMODEventInfoSO onPointerEnterSoundInfo;
        public FMODEventInfoSO onPointerExitSoundInfo;
        public FMODEventInfoSO onPointerDownSoundInfo;
        public FMODEventInfoSO onPointerUpSoundInfo;
        public FMODEventInfoSO onPointerClickSoundInfo;
        
        public void OnPointerEnter(PointerEventData eventData)
        {
            SoundManager.Instance.PlaySFX(onPointerEnterSoundInfo, Vector3.zero);
        }

        public void OnPointerExit(PointerEventData eventData)
        {
            SoundManager.Instance.PlaySFX(onPointerExitSoundInfo, Vector3.zero);
        }

        public void OnPointerDown(PointerEventData eventData)
        {
            SoundManager.Instance.PlaySFX(onPointerDownSoundInfo, Vector3.zero);
        }

        public void OnPointerUp(PointerEventData eventData)
        {
            SoundManager.Instance.PlaySFX(onPointerUpSoundInfo, Vector3.zero);
        }

        public void OnPointerClick(PointerEventData eventData)
        {
            SoundManager.Instance.PlaySFX(onPointerClickSoundInfo, Vector3.zero);
        }
    }
}