using ProjectAAA.Utils;
using ProjectAAA.Utils.DataTable;
using UnityEngine;

namespace ProjectAAA.Interaction
{
    public interface Iitem : ISaveDataElement
    {
        public void Use(GameObject target);
        public void OnReset();
    }
}