using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using NaughtyAttributes;
using ProjectAAA.Core.Managers;
using ProjectAAA.Core.OptimizedSensor;
using UnityEngine;

namespace ProjectAAA.Utils
{
    public class Magnetic : MonoBehaviour
    {
        [SerializeField] private Transform rootTr;
        [SerializeField] private AnimationCurve speedCurve;
        [SerializeField] private LayerMask targetLayer;
        [SerializeField, Range(0f, 1f)] private float ratio = 0.5f;
        [SerializeField] private bool isRunning;
        [SerializeField] private float radius = 4f;
        
        private Transform _target;
        private Rigidbody _rootRg;
        
        private float _theta;
        private Vector3 _startPosition;
        private OptimizedOverlapSphereSensorData _sensorData;
        
        // Debug 용
        [SerializeField, Header("디버그 세팅")] private bool useDebug;
        [SerializeField, ShowIf("useDebug")] private int stepCount = 100;
        [SerializeField, ShowIf("useDebug")] private Transform debugTarget;
        [SerializeField, ShowIf("useDebug")] private Color gizmosColor = Color.red;

        private void Awake()
        {
            if (rootTr == null)
            {
                rootTr = transform.parent;
            }
            _rootRg = rootTr.GetComponent<Rigidbody>();
        }

        private void Start()
        {
            _sensorData = new OptimizedOverlapSphereSensorData(1, 1);
        }

        private void OnDisable()
        {
            Stop();
        }

        private void Reset()
        {
            gameObject.layer = Global.MagnetLayerIndex;
            rootTr = transform.root;
        }

        public void Run()
        {
            isRunning = true;
        }

        public void Stop()
        {
            isRunning = false;
            
            if (_rootRg != null)
            {
                _rootRg.isKinematic = false;
            }
            
            _target = null;
            _theta = 0f;
        }

        private void Update()
        {
            if (isRunning && _target != null)
            {
                if (Vector3.Distance(rootTr.position, _target.position) < 0.05f)
                {
                    Stop();
                    return;
                }
                
                Vector3 p2 = CalcControlPoint(_startPosition, _target.position);
                rootTr.position = Bezier.Lerp(_startPosition, p2, _target.position, speedCurve.Evaluate(_theta));

                _theta += Time.deltaTime;
            }
        }

        private void FixedUpdate()
        {
            if (!isRunning || _target != null)
            {
                return;
            }

            if (_sensorData.Status == SensorStatus.Running)
            {
                return;
            }

            Detect();
        }

        private async UniTaskVoid Detect()
        {
            _sensorData.SetModel(new OptimizedOverlapSphereSensorModel()
            {
                Origin = rootTr.position,
                Radius = radius,
                LayerMask = targetLayer,
            });
            
            PhysicsManager.Instance.AddOverlapSphereSensor(_sensorData);

            await _sensorData.Handle.Task;

            Collider col = _sensorData.Results[0].collider;
            if (col != null)
            {
                if (col.TryGetComponent(out MagnetCollector collector))
                {
                    _target = collector.Center;
            
                    if (_rootRg != null)
                    {
                        _rootRg.isKinematic = true;
                    }

                    _theta = 0f;
                    _startPosition = rootTr.position;    
                }
            }
        }
        
        private Vector3 CalcControlPoint(Vector3 from, Vector3 to)
        {
            Vector3 toVec = to;
            toVec.y = from.y;

            Vector3 ret = Vector3.Lerp(from, toVec, ratio);

            return ret;
        }

        private void OnDrawGizmos()
        {
            Gizmos.color = Color.red;
            Gizmos.DrawWireSphere(transform.position, radius);
            
            if (useDebug && debugTarget != null)
            {
                Vector3 p2 = CalcControlPoint(transform.position, debugTarget.position);
                Gizmos.DrawSphere(p2, 0.2f);
                
                Gizmos.color = Color.blue;
                Gizmos.DrawLine(transform.position, p2);
                Gizmos.DrawLine(p2, debugTarget.position);
                
                Gizmos.color = gizmosColor;
                List<Vector3> points = new List<Vector3>();
                for (int i = 0; i <= stepCount; i++)
                {
                    points.Add(Bezier.Lerp(transform.position, p2, debugTarget.position, i / (float)stepCount));
                }

                for (var index = 0; index < points.Count - 1; index++)
                {
                    Gizmos.DrawLine(points[index], points[index + 1]);
                }
            }
        }
    }
}