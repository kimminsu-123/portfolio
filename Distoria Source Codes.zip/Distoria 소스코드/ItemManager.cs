using ProjectAAA.Interaction.Items;
using ProjectAAA.SO;
using ProjectAAA.SO.Pool;
using ProjectAAA.Utils;
using ProjectAAA.Utils.DataTable;
using UnityEngine;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.Core.Managers
{
    [RequireComponent(typeof(ItemGenerator))]
    public class ItemManager : SingletonMonoBehavior<ItemManager>
    {
        public ItemGenerator Generator { get; private set; }
        
        [Tooltip("0번째부터 기본 등급으로 아이템에 사용할 파티클 오브젝트풀을 넣습니다.")]
        [SerializeField] private ObjectPoolSO[] particlePerGrade;
        [SerializeField] private Color[] colorPerGrade;
        [SerializeField] private Color[] colorPerBuffType;

        protected override void Initialize()
        {
            Generator = GetComponent<ItemGenerator>();
            for (int i = 0; i < particlePerGrade.Length; i++)
            {
                particlePerGrade[i].SetupPool(transform);
            }
        }

        public ParticlePoolObj GetParticleByGrade(ItemGrade grade, Transform parent)
        {
            if (grade == ItemGrade.None)
            {
                return null;
            }
            
            if ((int)grade > particlePerGrade.Length)
            {
                Logger.LogError("ItemManager", $"{grade} 에 할당된 이펙트가 존재하지 않습니다.");
                return null;
            }

            ObjectPoolSO so = particlePerGrade[(int)grade];
            ParticlePoolObj particle = so.Get<ParticlePoolObj>(parent);
            particle.SetOriginPool(so);
            particle.SetPosition(Vector3.zero, Space.Self);
            particle.SetRotation(Quaternion.identity, Space.Self);
            
            return particle;
        }

        public Color GetColorByGrade(ItemGrade grade)
        {
            if ((int) grade > colorPerGrade.Length)
            {
                return Color.white;
            }

            return colorPerGrade[(int) grade];
        }
        
        public Color GetColorByBuffType(EffectType type)
        {
            if ((int) type > colorPerBuffType.Length)
            {
                return Color.white;
            }

            return colorPerBuffType[(int) type - 1];
        }
    }
}