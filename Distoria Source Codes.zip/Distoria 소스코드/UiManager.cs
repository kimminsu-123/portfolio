using System;
using System.Collections.Generic;
using ProjectAAA.UI;
using ProjectAAA.Utils;
using UniRx;
using UnityEngine;
using UnityEngine.EventSystems;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.Core.Managers
{
    public class UiManager : SingletonMonoBehavior<UiManager>
    {
        public ReactiveProperty<GameObject> SelectionProperty
        {
            get
            {
                if (_selectionProperty == null)
                {
                    _selectionProperty = new ReactiveProperty<GameObject>();
                }
                return _selectionProperty;
            }
        }
        
        private readonly Dictionary<Type, UiBase> _uis = new Dictionary<Type, UiBase>();
        
        private ReactiveProperty<GameObject> _selectionProperty;

        private void Update()
        {
            if (EventSystem.current != null)
            {
                SelectionProperty.Value = EventSystem.current.currentSelectedGameObject;
            }
        }

        public T Get<T>() where T : UiBase
        {
            if (!_uis.TryGetValue(typeof(T), out UiBase ui))
            {
                Logger.LogWarning("UIManager Get 실패", $"{typeof(T)} 등록되어있지 않습니다");
                return null;
            }
            return ui as T;
        }

        public bool Contains<T>() where T : UiBase
        {
            return _uis.ContainsKey(typeof(T));
        }

        public void Register(Type type, UiBase ui) 
        {
            if (!_uis.TryAdd(type, ui))
            {
                Logger.LogWarning("UIManager 등록 실패", $"{type} 이미 등록되었습니다");
            }
        }

        public void UnRegister(Type type) 
        {
            if (!_uis.Remove(type))
            {
                Logger.LogWarning("UIManager 삭제 실패", $"{type} 등록되지 않은 UI 입니다");
            }
        }
    }
}