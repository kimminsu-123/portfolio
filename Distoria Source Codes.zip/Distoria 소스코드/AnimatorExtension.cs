using System;
using System.Linq;
using UnityEngine;

namespace ProjectAAA.Utils
{
    public static class AnimatorExtension
    {
        public static async Awaitable CrossFade(this Animator animator, string name, float fadeTime, Action callback)
        {
            AnimationClip[] clipInfo = animator.runtimeAnimatorController.animationClips;
            AnimationClip clip = clipInfo.FirstOrDefault(x => x.name.Equals(name));
            if (clip == null)
            {
                callback?.Invoke();
                return;
            }
            
            animator.CrossFade(name, fadeTime);
            
            await Awaitable.WaitForSecondsAsync(clip.length);
            
            callback?.Invoke();
        }
    }
}