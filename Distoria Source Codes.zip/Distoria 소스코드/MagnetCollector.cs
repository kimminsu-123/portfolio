using UnityEngine;

namespace ProjectAAA.Utils
{
    public class MagnetCollector : MonoBehaviour
    {
        [field: SerializeField] public Transform Center { get; private set; }
    }
}