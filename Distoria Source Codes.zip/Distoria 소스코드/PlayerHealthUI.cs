using System;
using ProjectAAA.Core.Entity;
using ProjectAAA.Core.Managers;
using ProjectAAA.SO.CameraEffect;
using ProjectAAA.UI;
using ProjectAAA.Utils;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using EventType = ProjectAAA.Core.Managers.EventType;
using Logger = ProjectAAA.Utils.Logger;

public class PlayerHealthUI : MonoBehaviour
{
    [SerializeField] private EffectDataSO hitEffect;
    private LivingEntity _livingEntity;

    private void Awake()
    {
        _livingEntity = GetComponent<LivingEntity>();
    }

    private void OnEnable()
    {
        _livingEntity.onTakeDamage.AddListener(HpUpdate);
    }
    
    private void HpUpdate(HitInfo info)
    {
        CameraEffectManager.Instance.Register(hitEffect);
    }
}