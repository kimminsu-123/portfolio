using System;
using ProjectAAA.Core.Managers;
using UnityEngine;
using EventType = ProjectAAA.Core.Managers.EventType;

namespace ProjectAAA.Utils
{
    [Serializable]
    public class EventData
    {
        public EventType eventType;
        public Component sender;
        public string[] parameters;
    }
    
    public class EventNotifier : MonoBehaviour
    {
        public EventData[] data;

        public void Notify()
        {
            foreach (var d in data)
            {
                Logger.Log("EventNotifier", $"{d.eventType} {d.sender} {string.Join(", ", d.parameters)}", Color.green);
            
                EventManager.Instance.PostNotification(d.eventType, d.sender, Array.ConvertAll(d.parameters, input => (object) input));    
            }
        }
    }
}