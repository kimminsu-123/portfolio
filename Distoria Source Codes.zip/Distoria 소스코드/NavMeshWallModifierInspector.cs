using Unity.AI.Navigation;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace ProjectAAA.Mob
{
    [CanEditMultipleObjects]
    [CustomEditor(typeof(NavMeshWallModifier))]
    public class NavMeshWallModifierInspector : UnityEditor.Editor
    {
        private BoxCollider _collider;
        private NavMeshModifierVolume _volume;
        private GameObject _wallObj;
        private bool _initialized = false;

        public override void OnInspectorGUI()
        {
            if (!_initialized)
            {
                Initialize();
            }
            
            serializedObject.Update();
            
            if(_wallObj == null)
            {
                var go = AssetDatabase.LoadAssetAtPath<GameObject>(
                    @"Assets/02_Progs/02_Prefab/Core/Level/BlockedWall.prefab");

                if (go)
                {
                    _wallObj = (GameObject)PrefabUtility.InstantiatePrefab(go);

                    Undo.RegisterCreatedObjectUndo(_wallObj, "Create BlockedWall");

                    var parent = (target as NavMeshWallModifier).transform;
                    _wallObj.transform.SetParent(parent);
                    _wallObj.transform.localPosition = Vector3.zero;
                    _wallObj.transform.localRotation = Quaternion.identity;
                    _wallObj.name = "BlockedWall";

                    EditorUtility.SetDirty(parent.gameObject);
                    EditorSceneManager.MarkSceneDirty(parent.gameObject.scene);
                }
            }
            
            _volume.area = 1;
            _volume.center = _collider.center;
            _volume.size = _collider.size;

            Vector3 size = _collider.size;
            size.x *= _collider.transform.localScale.x;
            size.y *= _collider.transform.localScale.y;
            size.z *= _collider.transform.localScale.z;
            if (size.x > size.z)
            {
                _wallObj.transform.localRotation = Quaternion.identity;
                size.x /= _collider.transform.localScale.x;
                size.y /= _collider.transform.localScale.y;
                size.z /= _collider.transform.localScale.z;
            }
            else
            {
                (size.x, size.z) = (size.z, size.x);
                _wallObj.transform.localRotation = Quaternion.Euler(0, 90, 0);
                size.x /= _collider.transform.localScale.z;
                size.y /= _collider.transform.localScale.y;
                size.z /= _collider.transform.localScale.x;
            }
            
            _wallObj.transform.localPosition = _collider.center;
            _wallObj.transform.localScale = size;
            
            serializedObject.ApplyModifiedProperties();
        }

        private void Initialize()
        {
            NavMeshWallModifier modifier = target as NavMeshWallModifier;
            
            _collider = modifier.GetComponent<BoxCollider>();
            _volume = modifier.GetComponent<NavMeshModifierVolume>();
            
            Transform tr = modifier.transform.Find("BlockedWall");
            if (tr != null)
            {
                _wallObj = tr.gameObject;
            }
            
            _initialized = true;
        }
    }
}