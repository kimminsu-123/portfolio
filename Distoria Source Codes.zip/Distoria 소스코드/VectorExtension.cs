using UnityEngine;

namespace ProjectAAA.Utils
{
    public static class VectorExtension
    {
        public static float DistanceIgnoreY(Vector3 a, Vector3 b)
        {
            Vector3 start = a;
            Vector3 end = b;
        
            start.y = 0;
            end.y = 0;
        
            float result = Vector3.Distance(start, end);

            return result;
        }
    }
}
