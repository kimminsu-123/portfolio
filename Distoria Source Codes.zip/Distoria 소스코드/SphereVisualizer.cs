using UnityEngine;

namespace ProjectAAA.Utils.Visualizer
{
    public class SphereVisualizer : Visualizer
    {
        public Vector3 center;
        public float radius;
        
        private void OnDrawGizmos()
        {
            Gizmos.color = gizmosColor;
            Gizmos.matrix = transform.localToWorldMatrix;
            if(drawWireframe) Gizmos.DrawWireSphere(center, radius);
            else Gizmos.DrawSphere(center, radius);
        }
    }
}