using DG.Tweening;
using Grabbit;
using NaughtyAttributes;
using UnityEngine;

namespace ProjectAAA.Interaction
{
    public class SlidingDoor : TriggerInteractable
    {
        private enum Status
        {
            Closed,
            Opening,
            Opened,
        }

        public LayerMask targetLayer;
        public Transform model;
        public Vector3 direction;
        public float length;
        public float duration;

        [ShowNonSerializedField] private Status _currentStatus;

        private Collider _collider;
        private Tweener _tweener;
        
        protected override void Initialize()
        {
            _collider = GetComponent<Collider>();
            _collider.isTrigger = true;
            
            _currentStatus = Status.Closed;
            
            onTriggerEnter.AddListener(target =>
            {
                int mask = targetLayer.value & (1 << target.gameObject.layer);
                if (mask > 0)
                {
                    BeginSlide();
                }
            });   
        }

        public void BeginSlide()
        {
            if (_currentStatus != Status.Closed) return;
            if (_tweener != null) return;
            
            _currentStatus = Status.Opening;

            Vector3 endPos = model.transform.localPosition + direction.normalized * length;
            _tweener = model.DOLocalMove(endPos, duration)
                            .OnComplete(EndSlide)
                            .SetAutoKill(true)
                            .Play();
        }

        public void EndSlide()
        {
            _currentStatus = Status.Opened;

            _collider.enabled = false;
            
            _tweener = null;
        }

        private void OnDrawGizmosSelected()
        {
            if (model != null)
            {
                Gizmos.color = Color.red;

                Vector3 to = direction.normalized * length;
                Gizmos.DrawLine(model.position, model.position + to);
            }
        }
    }
}