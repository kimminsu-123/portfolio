using ProjectAAA.Core.Entity;
using ProjectAAA.Core.Managers;
using ProjectAAA.Core.Scene.Manager;
using ProjectAAA.UI.Statue;
using ProjectAAA.Utils;
using ProjectAAA.Utils.DataTable;
using UnityEngine;

namespace ProjectAAA.Interactables.Statue
{
    public class BloodStoneStatue : StoneStatue
    {
        protected override StatueConditionUI ConditionUI => UiManager.Instance.Get<BloodStatueConditionUI>();
        protected override IPredicate AcceptCondition => _acceptCondition;
        protected override IPredicate DenyCondition => null;

        [Header("피의 석상 관련 속성")] 
        [SerializeField, Range(0f, 1f)] private float ratio = 0.2f;
        [SerializeField] private int rewardGroupId;
        [SerializeField] private GameObject rewardSpawnPoint;
        
        private IPredicate _acceptCondition;

        private void Start()
        {
            _acceptCondition = new FuncPredicate(CheckHealth);
        }

        protected override void OnInteract()
        {
            BloodStatueConditionUI blood = ConditionUI as BloodStatueConditionUI;

            blood?.Setup(new BloodConditionData(PlayerManager.Instance.PlayerEntity.CurrentHealth,
                PlayerManager.Instance.PlayerEntity.MaxHealth * ratio));
        }

        private bool CheckHealth()
        {
            LivingEntity entity = PlayerManager.Instance.PlayerEntity;

            float curRatio = entity.CurrentHealth / entity.MaxHealth;
            
            return curRatio > ratio;
        }

        protected override void OnAccept()
        {
            RewardData rewardData = RewardManager.Instance.GetRandomizedReward(rewardGroupId);
            if (rewardData != null)
            {
                LivingEntity entity = PlayerManager.Instance.PlayerEntity;
                entity.TakeDamageDirect(entity.MaxHealth * ratio);

                RewardManager.Instance.SpawnReward(rewardData, rewardSpawnPoint);
            }
        }

        protected override void OnDeny()
        {
        }
    }
}