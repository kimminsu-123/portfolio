using System.Collections.Generic;
using System.Diagnostics;
using ProjectAAA.Core.Timer;
using ProjectAAA.Utils;
using UnityEngine;
using UnityEngine.Rendering;

namespace ProjectAAA.Core.Managers
{
    public class DebugVisualizerManager : SingletonMonoBehavior<DebugVisualizerManager>
    {
        private class VisualSettings : DisposeBase
        {
            public Mesh Mesh;
            public Matrix4x4 Matrix;
            public Material Material;
            public CooldownTimer Timer;

            protected override void DisposeManagedResources()
            {
                Mesh = null;
                Material = null;
                
                Timer?.Dispose();
                Timer = null;
            }
        }

        private List<VisualSettings> _visualSettings;
        
        private Mesh _cachedSphereMesh;
        private Mesh _cachedCubeMesh;
        private Mesh _cachedCapsuleMesh;
        private Mesh _cachedCylinderMesh;
        private Shader _cachedShader;

        protected override void Initialize()
        {
            _visualSettings = new List<VisualSettings>();
            
            MeshFilter sphereFilter = GameObject.CreatePrimitive(PrimitiveType.Sphere).GetComponent<MeshFilter>();
            MeshFilter cubeFilter = GameObject.CreatePrimitive(PrimitiveType.Cube).GetComponent<MeshFilter>();
            MeshFilter capsuleFilter = GameObject.CreatePrimitive(PrimitiveType.Capsule).GetComponent<MeshFilter>();
            MeshFilter cylinderFilter = GameObject.CreatePrimitive(PrimitiveType.Cylinder).GetComponent<MeshFilter>();
            
            _cachedSphereMesh = sphereFilter.mesh;
            _cachedCubeMesh = cubeFilter.mesh;
            _cachedCapsuleMesh = capsuleFilter.mesh;
            _cachedCylinderMesh = cylinderFilter.mesh;
            _cachedShader = Shader.Find("Universal Render Pipeline/Unlit");

            Destroy(sphereFilter.gameObject);
            Destroy(cubeFilter.gameObject);
            Destroy(capsuleFilter.gameObject);
            Destroy(cylinderFilter.gameObject);
        }

        private void Update()
        {
            for (int i = _visualSettings.Count - 1; i >= 0; i--)
            {
                CooldownTimer timer = _visualSettings[i].Timer;

                if (!timer.IsRunning)
                {
                    _visualSettings.RemoveAt(i);
                }
                else
                {
                    Mesh mesh = _visualSettings[i].Mesh;
                    Matrix4x4 matrix = _visualSettings[i].Matrix;
                    Material material = _visualSettings[i].Material;
                    
                    Graphics.DrawMesh(mesh, matrix, material, 0);
                }
                
                timer.Tick(Time.deltaTime);
            }
        }

        private Material CreateMaterial(Color color)
        {
            Material material = new Material(_cachedShader);
            material.SetFloat("_Surface", 1);
            material.SetFloat("_Blend", 0);
            material.SetInt("_SrcBlend", (int)BlendMode.SrcAlpha);
            material.SetInt("_DstBlend", (int)BlendMode.OneMinusSrcAlpha);
            material.SetInt("_ZWrite", 0);
            material.EnableKeyword("_SURFACE_TYPE_TRANSPARENT");
            material.EnableKeyword("_ALPHAPREMULTIPLY_ON");
            material.SetColor("_BaseColor", color);
            material.SetShaderPassEnabled("ShadowCaster", false);
            material.renderQueue = (int)RenderQueue.Transparent;

            return material;
        }

        [Conditional("UNITY_EDITOR")]
        public void DrawSphere(Vector3 position, Quaternion rotation, float radius, float duration = 0f)
        {
            DrawSphere(position, rotation, radius, new Color(1f, 0f, 0f, 0.5f), duration);
        }
        
        [Conditional("UNITY_EDITOR")]
        public void DrawCube(Vector3 position, Quaternion rotation, Vector3 size, float duration = 0f)
        {
            DrawCube(position, rotation, size, new Color(1f, 0f, 0f, 0.5f), duration);
        }
        
        [Conditional("UNITY_EDITOR")]
        public void DrawCapsule(Vector3 position, Quaternion rotation, float radius, float height, float duration = 0f)
        {
            DrawCapsule(position, rotation, radius, height, new Color(1f, 0f, 0f, 0.5f), duration);
        }
        
        [Conditional("UNITY_EDITOR")]
        public void DrawCylinder(Vector3 position, Quaternion rotation, float radius, float height, float duration = 0f)
        {
            DrawCylinder(position, rotation, radius, height, new Color(1f, 0f, 0f, 0.5f), duration);
        }
        
        [Conditional("UNITY_EDITOR")]
        public void DrawSphere(Vector3 position, Quaternion rotation, float radius, Color color, float duration = 0f)
        {
            VisualSettings setting = new VisualSettings
            {
                Mesh = _cachedSphereMesh,
                Matrix = Matrix4x4.TRS(position, rotation, Vector3.one * (radius * 2f)),
                Material = CreateMaterial(color),
                Timer = new CooldownTimer(duration)
            };
            
            setting.Timer.Start();
            
            _visualSettings.Add(setting);
        }
        
        [Conditional("UNITY_EDITOR")]
        public void DrawCube(Vector3 position, Quaternion rotation, Vector3 size, Color color, float duration = 0f)
        {
            VisualSettings setting = new VisualSettings
            {
                Mesh = _cachedCubeMesh,
                Matrix = Matrix4x4.TRS(position, rotation, size),
                Material = CreateMaterial(color),
                Timer = new CooldownTimer(duration)
            };
            
            setting.Timer.Start();
            
            _visualSettings.Add(setting);
        }
        
        [Conditional("UNITY_EDITOR")]
        public void DrawCapsule(Vector3 position, Quaternion rotation, float radius, float height, Color color, float duration = 0f)
        {
            VisualSettings setting = new VisualSettings
            {
                Mesh = _cachedCapsuleMesh,
                Matrix = Matrix4x4.TRS(position, rotation, Vector3.right * (radius * 2f) + Vector3.forward * (radius * 2f) + Vector3.up * (height * 0.5f)),
                Material = CreateMaterial(color),
                Timer = new CooldownTimer(duration)
            };
            
            setting.Timer.Start();
            
            _visualSettings.Add(setting);
        }
        
        [Conditional("UNITY_EDITOR")]
        public void DrawCylinder(Vector3 position, Quaternion rotation, float radius, float height, Color color, float duration = 0f)
        {
            VisualSettings setting = new VisualSettings
            {
                Mesh = _cachedCylinderMesh,
                Matrix = Matrix4x4.TRS(position, rotation, Vector3.right * (radius * 2f) + Vector3.forward * (radius * 2f) + Vector3.up * (height * 0.5f)),
                Material = CreateMaterial(color),
                Timer = new CooldownTimer(duration)
            };
            
            setting.Timer.Start();
            
            _visualSettings.Add(setting);
        }
    }
}