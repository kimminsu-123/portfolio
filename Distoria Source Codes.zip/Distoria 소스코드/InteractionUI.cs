using System;
using UnityEngine;
using UnityEngine.UI;

namespace ProjectAAA.UI
{
    public class InteractionUI : UiBase
    {
        public float MaxFillAmount { get; set; }
        protected override Type RegisterType => typeof(InteractionUI);

        [SerializeField] private Image fillImage;
        private float _accumTime;

        private void OnDisable()
        {
            Clear();
        }

        private void Start()
        {
            Clear();
        }

        public override void Show()
        {
            gameObject.SetActive(true);
        }
        
        public override void Hide()
        {
            Clear();
            gameObject.SetActive(false);
        }

        public void Clear()
        {
            _accumTime = 0f;
            fillImage.fillAmount = 0f;
        }

        public void Fill(float deltaTime)
        {
            if (gameObject.activeSelf)
            {
                _accumTime += deltaTime / MaxFillAmount;
                fillImage.fillAmount = Mathf.Clamp(_accumTime, 0f, 1f);   
            }
        }
    }
}