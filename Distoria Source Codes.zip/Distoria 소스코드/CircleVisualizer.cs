using System;
using UnityEngine;

#if UNITY_EDITOR
using UnityEditor;
#endif

namespace ProjectAAA.Utils.Visualizer
{
    public class CircleVisualizer : Visualizer
    {
        public Vector3 center;
        public float radius;
        public float height;
    }
#if UNITY_EDITOR
    [CustomEditor(typeof(CircleVisualizer))]
    public class DrawCircleVisualizer : Editor
    {
        private void OnSceneGUI()
        {
            CircleVisualizer inst = (CircleVisualizer) target;

            Handles.color = inst.gizmosColor;
            Handles.matrix = inst.transform.localToWorldMatrix;
            if (inst.drawWireframe) Handles.DrawWireDisc(inst.center, Vector3.up, inst.radius);
            else Handles.DrawSolidDisc(inst.center, Vector3.up, inst.radius);

            if (inst.height != 0f)
            {
                Vector3 upCenter = inst.center + Vector3.up * inst.height;

                for (int i = 0; i < 4; i++)
                {
                    Vector3 right = Quaternion.Euler(Vector3.up * (90f * i)) * Vector3.right * inst.radius + inst.center;
                    Vector3 upRight = Vector3.up * inst.height + right; 
                    Handles.DrawLine(right, upRight);
                }
                
                if (inst.drawWireframe)
                {
                    Handles.DrawWireDisc(upCenter, Vector3.up, inst.radius);
                }
                else
                {
                    Handles.DrawSolidDisc(upCenter, Vector3.up, inst.radius);
                }
            }
        }
    }
#endif
}