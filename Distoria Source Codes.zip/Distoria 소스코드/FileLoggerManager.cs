using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading;
using ProjectAAA.Utils;
using UnityEngine;

namespace ProjectAAA.Core.Managers
{
    public class FileLoggerManager : SingletonMonoBehavior<FileLoggerManager>
    {
        private struct Log
        {
            public DateTime Time;
            public string Condition;
            public string StackTrace;

            public override string ToString()
            {
                return $"[{Time:yyyyMMdd-hh:mm:ss}] {Condition}\n{StackTrace}";
            }
        }

        private const int ThreadInterval = 500;

        private static readonly string logRootPath = $@"{Application.dataPath}\Logs";
        private static readonly string errorPath = $@"{logRootPath}\Error";
        private static readonly string assertPath = $@"{logRootPath}\Assert";
        private static readonly string warningPath = $@"{logRootPath}\Warning";
        private static readonly string logPath = $@"{logRootPath}\Log";
        private static readonly string exceptionPath = $@"{logRootPath}\Exception";
        private static readonly string fileName = $@"{DateTime.Now:yyyyMMdd}.txt";
        
        private ConcurrentDictionary<LogType, List<Log>> _logDict;

        private object _listLock;
        private CancellationTokenSource _tokenSource;
        private Thread _worker;

        protected override void Initialize()
        {
            CreateDirectories();
            
            Application.logMessageReceivedThreaded += CaptureLogs;
            
            _logDict = new ConcurrentDictionary<LogType, List<Log>>();
            _logDict.TryAdd(LogType.Error, new List<Log>(100));
            _logDict.TryAdd(LogType.Assert, new List<Log>(100));
            _logDict.TryAdd(LogType.Warning, new List<Log>(100));
            _logDict.TryAdd(LogType.Log, new List<Log>(100));
            _logDict.TryAdd(LogType.Exception, new List<Log>(100));
            
            _listLock = new object();
            _tokenSource = new CancellationTokenSource();
            _worker = new Thread(ProcessWriteToFile);
            _worker.IsBackground = true;
            _worker.Start();
        }

        private void CreateDirectories()
        {
            if (!Directory.Exists(logRootPath))
            {
                Directory.CreateDirectory(logRootPath);
            }
            
            if (!Directory.Exists(errorPath))
            {
                Directory.CreateDirectory(errorPath);
            }
            
            if (!Directory.Exists(assertPath))
            {
                Directory.CreateDirectory(assertPath);
            }
            
            if (!Directory.Exists(warningPath))
            {
                Directory.CreateDirectory(warningPath);
            }
            
            if (!Directory.Exists(logPath))
            {
                Directory.CreateDirectory(logPath);
            }
            
            if (!Directory.Exists(exceptionPath))
            {
                Directory.CreateDirectory(exceptionPath);
            }
        }

        public void CaptureLogs(string condition, string stackTrace, LogType type)
        {
            if (_logDict.TryGetValue(type, out List<Log> list))
            {
                Log log = new Log {Time = DateTime.Now, Condition = condition, StackTrace = stackTrace};

                lock (_listLock)
                {
                    list.Add(log);
                }
            }
        }

        private void ProcessWriteToFile()
        {
            while (true)
            {
                Thread.Sleep(ThreadInterval);

                if (_tokenSource.IsCancellationRequested)
                {
                    break;
                }

                WriteErrorLogs();
                WriteAssertLogs();
                WriteWarningLogs();
                WriteLogs();
                WriteExceptionLogs();
            }
        }

        private void WriteErrorLogs()
        {
            if (_logDict.TryGetValue(LogType.Error, out List<Log> list))
            {
                lock (_listLock)
                {
                    if (list.Count <= 0)
                    {
                        return;
                    }

                    StringBuilder sb = new StringBuilder();
                    foreach (Log log in list)
                    {
                        sb.AppendLine(log.ToString());
                        sb.AppendLine();
                    }

                    try
                    {
                        string path = Path.Combine(errorPath, fileName);
                        if (!File.Exists(path))
                        {
                            File.Create(path);
                        }
                        else
                        {
                            long size = new FileInfo(path).Length;
                            
                            // 5MB 를 넘어가면 파일 초기화
                            if (size > 5 * 1024 * 1024)
                            {
                                File.WriteAllText(path, string.Empty);
                            }
                        }
                    
                        using (StreamWriter streamWriter = new StreamWriter(path, true, Encoding.UTF8))
                        {
                            streamWriter.Write(sb.ToString());
                            streamWriter.Flush();
                        }
                    
                        list.Clear();
                    }
                    catch (IOException)
                    {
                        // ignore
                    }
                }
            }
        }

        private void WriteAssertLogs()
        {
            if (_logDict.TryGetValue(LogType.Assert, out List<Log> list))
            {
                lock (_listLock)
                {
                    if (list.Count <= 0)
                    {
                        return;
                    }

                    StringBuilder sb = new StringBuilder();
                    foreach (Log log in list)
                    {
                        sb.AppendLine(log.ToString());
                        sb.AppendLine();
                    }

                    try
                    {
                        string path = Path.Combine(assertPath, fileName);
                        if (!File.Exists(path))
                        {
                            File.Create(path);
                        }
                        else
                        {
                            long size = new FileInfo(path).Length;
                            
                            // 5MB 를 넘어가면 파일 초기화
                            if (size > 5 * 1024 * 1024)
                            {
                                File.WriteAllText(path, string.Empty);
                            }
                        }
                    
                        using (StreamWriter streamWriter = new StreamWriter(path, true, Encoding.UTF8))
                        {
                            streamWriter.Write(sb.ToString());
                            streamWriter.Flush();
                        }

                        list.Clear();
                    }
                    catch (IOException)
                    {
                        // ignore
                    }
                }
            }
        }

        private void WriteWarningLogs()
        {
            if (_logDict.TryGetValue(LogType.Warning, out List<Log> list))
            {
                lock (_listLock)
                {
                    if (list.Count <= 0)
                    {
                        return;
                    }

                    StringBuilder sb = new StringBuilder();
                    foreach (Log log in list)
                    {
                        sb.AppendLine(log.ToString());
                        sb.AppendLine();
                    }
                    
                    try
                    {
                        string path = Path.Combine(warningPath, fileName);
                        if (!File.Exists(path))
                        {
                            File.Create(path);
                        }
                        else
                        {
                            long size = new FileInfo(path).Length;
                            
                            // 5MB 를 넘어가면 파일 초기화
                            if (size > 5 * 1024 * 1024)
                            {
                                File.WriteAllText(path, string.Empty);
                            }
                        }
                    
                        using (StreamWriter streamWriter = new StreamWriter(path, true, Encoding.UTF8))
                        {
                            streamWriter.Write(sb.ToString());
                            streamWriter.Flush();
                        }
                    
                        list.Clear();
                    }
                    catch (IOException)
                    {
                        // ignore
                    }     
                }
            }
        }

        private void WriteLogs()
        {
            if (_logDict.TryGetValue(LogType.Log, out List<Log> list))
            {
                lock (_listLock)
                {
                    if (list.Count <= 0)
                    {
                        return;
                    }

                    StringBuilder sb = new StringBuilder();
                    foreach (Log log in list)
                    {
                        sb.AppendLine(log.ToString());
                        sb.AppendLine();
                    }

                    try
                    {
                        string path = Path.Combine(logPath, fileName);
                        if (!File.Exists(path))
                        {
                            File.Create(path);
                        }
                        else
                        {
                            long size = new FileInfo(path).Length;
                            
                            // 5MB 를 넘어가면 파일 초기화
                            if (size > 5 * 1024 * 1024)
                            {
                                File.WriteAllText(path, string.Empty);
                            }
                        }

                        using (StreamWriter streamWriter = new StreamWriter(path, true, Encoding.UTF8))
                        {
                            streamWriter.Write(sb.ToString());
                            streamWriter.Flush();
                        }

                        list.Clear();
                    }
                    catch (IOException)
                    {
                        // ignore
                    }                    
                }
            }
        }

        private void WriteExceptionLogs()
        {
            if (_logDict.TryGetValue(LogType.Exception, out List<Log> list))
            {
                lock (_listLock)
                {
                    if (list.Count <= 0)
                    {
                        return;
                    }

                    StringBuilder sb = new StringBuilder();
                    foreach (Log log in list)
                    {
                        sb.AppendLine(log.ToString());
                        sb.AppendLine();
                    }

                    try
                    {
                        string path = Path.Combine(exceptionPath, fileName);
                        if (!File.Exists(path))
                        {
                            File.Create(path);
                        }
                        else
                        {
                            long size = new FileInfo(path).Length;
                            
                            // 5MB 를 넘어가면 파일 초기화
                            if (size > 5 * 1024 * 1024)
                            {
                                File.WriteAllText(path, string.Empty);
                            }
                        }
                    
                        using (StreamWriter streamWriter = new StreamWriter(path, true, Encoding.UTF8))
                        {
                            streamWriter.Write(sb.ToString());
                            streamWriter.Flush();
                        }
                    
                        list.Clear();
                    }
                    catch (IOException)
                    {
                        // ignore
                    }       
                }
            }
        }

        protected override void OnDestroy()
        {
            base.OnDestroy();
            
            Application.logMessageReceivedThreaded -= CaptureLogs;

            _tokenSource?.Cancel();
            _worker?.Join();
            
            WriteErrorLogs();
            WriteAssertLogs();
            WriteWarningLogs();
            WriteLogs();
            WriteExceptionLogs();
        }
    }
} 