using System.Text.RegularExpressions;
using ProjectAAA.SO.Pool;
using ProjectAAA.Utils;
using Unity.AI.Navigation;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEditorInternal;
using UnityEngine;
using UnityEngine.AI;

namespace ProjectAAA.Mob
{
    [CanEditMultipleObjects]
    [CustomEditor(typeof(MonsterArea))]
    public class MonsterAreaInspector : UnityEditor.Editor
    {
        private SerializedProperty _clearAreaSoundInfoProperty;
        private SerializedProperty _endAreaEffectPoolProperty;
        private SerializedProperty _onBeginAreaProperty;
        private SerializedProperty _onEndAreaProperty;
        private SerializedProperty _spawnModeProperty;
        private SerializedProperty _areaTypeProperty;
        private SerializedProperty _gizmosColorProperty;
        private SerializedProperty _sphereRadiusProperty;
        private SerializedProperty _cubeSizeProperty;
        private SerializedProperty _monsterPoolListProperty;
        
        private SerializedProperty _randomMonsterSpawnSettingsListProperty;
        private SerializedProperty _spawnIntervalProperty;
        private SerializedProperty _spawnCountProperty;
        private SerializedProperty _isSubjectProperty;

        private ReorderableList _monsterPoolReorderableList;
        private ReorderableList _randomMonsterSpawnSettingsReorderableList;

        private bool _initialized = false;
        private bool _isBatchMode = false;
        private int _selectedIndex = -1;
        private int _prevSpawnMode = -1;

        private void OnDisable()
        {
            SceneView.duringSceneGui -= Batch;
        }

        private void Initialize()
        {
            SceneView.duringSceneGui += Batch;
            
            _isBatchMode = false;
            _selectedIndex = -1;
            _prevSpawnMode = -1;

            FindProperties();
            ResetMonsterList();
            
            _monsterPoolReorderableList = new ReorderableList(serializedObject, _monsterPoolListProperty, false, true, false, false);
            _monsterPoolReorderableList.drawHeaderCallback += (rect) => EditorGUI.LabelField(rect, "몬스터 리스트");
            _monsterPoolReorderableList.drawElementCallback += (rect, index, active, focused) =>
            {
                SerializedProperty element = _monsterPoolListProperty.GetArrayElementAtIndex(index);

                GUI.Label(rect, element.objectReferenceValue.name, EditorStyles.boldLabel);
            };
            _monsterPoolReorderableList.onSelectCallback += (list) => { _selectedIndex = list.index; };

            _randomMonsterSpawnSettingsReorderableList = new ReorderableList(serializedObject, _randomMonsterSpawnSettingsListProperty, false, true, true, true);
            _randomMonsterSpawnSettingsReorderableList.drawHeaderCallback += (rect) => EditorGUI.LabelField(rect, "랜던 스폰할 몬스터 세팅들");
            _randomMonsterSpawnSettingsReorderableList.elementHeight = EditorGUIUtility.singleLineHeight * 2f + 4;
            _randomMonsterSpawnSettingsReorderableList.drawElementCallback += (rect, index, active, focused) =>
            {
                SerializedProperty element = _randomMonsterSpawnSettingsReorderableList.serializedProperty.GetArrayElementAtIndex(index);
                SerializedProperty poolProperty = element.FindPropertyRelative("monsterPool");
                SerializedProperty spawnCountProperty = element.FindPropertyRelative("spawnCount");

                float lineHeight = EditorGUIUtility.singleLineHeight;
                float spacing = 2f;

                Rect poolRect = new Rect(rect.x, rect.y, rect.width, lineHeight);
                Rect countRect = new Rect(rect.x, rect.y + lineHeight + spacing, rect.width, lineHeight);

                EditorGUI.PropertyField(poolRect, poolProperty);
                EditorGUI.PropertyField(countRect, spawnCountProperty);
            };
            _randomMonsterSpawnSettingsReorderableList.onAddCallback += list =>
            {
                if (_selectedIndex < 0 || _selectedIndex >= _monsterPoolListProperty.arraySize)
                {
                    EditorUtility.DisplayDialog("오류", "몬스터를 선택해주세요", "확인");
                    return;
                }
                
                list.serializedProperty.InsertArrayElementAtIndex(list.count);
                SerializedProperty element = list.serializedProperty.GetArrayElementAtIndex(list.count - 1);
                SerializedProperty poolProperty = element.FindPropertyRelative("monsterPool");
                SerializedProperty spawnCountProperty = element.FindPropertyRelative("spawnCount");
                
                SerializedProperty poolElement = _monsterPoolReorderableList.serializedProperty.GetArrayElementAtIndex(_selectedIndex);
                ObjectPoolSO selectedSo = poolElement.objectReferenceValue as ObjectPoolSO;
                
                poolProperty.objectReferenceValue = selectedSo;
                spawnCountProperty.intValue = 0;
            };
            
            _initialized = true;
        }

        private void Reset()
        {
            Initialize();
        }

        public override void OnInspectorGUI()
        {
            FindProperties();
            
            if (!_initialized)
            {
                Initialize();
            }

            if (_isSubjectProperty.boolValue)
            {
                EditorGUILayout.LabelField($"MonsterStage 에 의존적이지 않고 Collider 와 함께 동작합니다.");
            }
            
            _monsterPoolReorderableList.DoLayoutList();
            if (GUILayout.Button("Reset Monster List"))
            {
                ResetMonsterList();
            }
            EditorGUILayout.Space(20f);
            
            DrawProperties();
            UpdateSpawnMode();
            UpdateMonsterAreaMode();
            
            serializedObject.ApplyModifiedProperties();
        }

        private void FindProperties()
        {
            _clearAreaSoundInfoProperty = serializedObject.FindProperty("clearAreaSoundInfo");
            _endAreaEffectPoolProperty = serializedObject.FindProperty("endAreaEffectPool");
            _onBeginAreaProperty = serializedObject.FindProperty("onBeginArea");
            _onEndAreaProperty = serializedObject.FindProperty("onEndArea");
            _spawnModeProperty = serializedObject.FindProperty("spawnMode");
            _areaTypeProperty = serializedObject.FindProperty("areaType");
            _gizmosColorProperty = serializedObject.FindProperty("gizmosColor");
            _sphereRadiusProperty = serializedObject.FindProperty("sphereRadius");
            _cubeSizeProperty = serializedObject.FindProperty("cubeSize");
            _monsterPoolListProperty = serializedObject.FindProperty("monsterPoolList");
            _randomMonsterSpawnSettingsListProperty = serializedObject.FindProperty("randomMonsterSpawnSettings");
            _spawnIntervalProperty = serializedObject.FindProperty("spawnInterval");
            _spawnCountProperty = serializedObject.FindProperty("spawnCount");
            _isSubjectProperty = serializedObject.FindProperty("isSubject");
        }

        private void DrawProperties()
        {
            serializedObject.Update();

            EditorGUILayout.PropertyField(_clearAreaSoundInfoProperty);
            EditorGUILayout.PropertyField(_endAreaEffectPoolProperty);
            EditorGUILayout.PropertyField(_onBeginAreaProperty);
            EditorGUILayout.PropertyField(_onEndAreaProperty);
            EditorGUILayout.PropertyField(_spawnModeProperty);

            if (_spawnModeProperty.enumValueIndex == (int) SpawnMode.RandomizeOnRuntime)
            {
                EditorGUILayout.PropertyField(_areaTypeProperty);
                EditorGUILayout.PropertyField(_gizmosColorProperty);
                if (_areaTypeProperty.enumValueIndex == (int)AreaType.Sphere)
                {
                    EditorGUILayout.PropertyField(_sphereRadiusProperty);
                }
                else
                {
                    EditorGUILayout.PropertyField(_cubeSizeProperty);
                }

                _randomMonsterSpawnSettingsReorderableList.DoLayoutList();
                EditorGUILayout.PropertyField(_spawnIntervalProperty);
                EditorGUILayout.PropertyField(_spawnCountProperty);
            }
            else
            {
                DrawBatchMode();
            }

            DrawUpdateSpawnPointArea();
            DrawCreateWallButton();
        }

        private void UpdateMonsterAreaMode()
        {
            MonsterArea area = target as MonsterArea;
            if (area == null) return;
            
            area.gameObject.layer = _isSubjectProperty.boolValue ? Global.InteractionLayerIndex : Global.DefaultLayerIndex;

            bool isNew = false;
            
            if (_isSubjectProperty.boolValue)
            {
                isNew = area.gameObject.TryGetOrAddComponent(out BoxCollider col);
                isNew |= area.gameObject.TryGetOrAddComponent(out Rigidbody rid);
                
                col.isTrigger = true;
                
                rid.isKinematic = true;
                rid.useGravity = false;
                rid.freezeRotation = true;
                
            }
            else
            {
                if (area.TryGetComponent(out BoxCollider col))
                {
                    isNew = true;
                        
                    DestroyImmediate(col);
                }
                
                if (area.TryGetComponent(out Rigidbody rid))
                {
                    isNew = true;
                    
                    DestroyImmediate(rid);
                }
            }

            if (isNew)
            {
                EditorUtility.SetDirty(area.gameObject);
                EditorSceneManager.MarkSceneDirty(area.gameObject.scene);
            }
        }

        private void UpdateSpawnMode()
        {
            if (_prevSpawnMode != _spawnModeProperty.enumValueIndex)
            {
                SpawnMode mode = (SpawnMode) _spawnModeProperty.enumValueIndex;
                switch (mode)
                {
                    case SpawnMode.Manual:
                        _randomMonsterSpawnSettingsListProperty.ClearArray();
                        _spawnIntervalProperty.floatValue = 0f;
                        break;
                    case SpawnMode.RandomizeOnRuntime:
                        MonsterSpawnPoint[] points = (target as MonsterArea).GetComponentsInChildren<MonsterSpawnPoint>(true);
                        for (int idx = 0; idx < points.Length; idx++)
                        {
                            DestroyImmediate(points[idx].gameObject);
                        }
                        _isBatchMode = false;
                        break;
                }
                _prevSpawnMode = _spawnModeProperty.enumValueIndex;
            }
        }
        
        private void ResetMonsterList()
        {
            serializedObject.Update();
            
            _monsterPoolListProperty.ClearArray();

            Regex re = new Regex(@"^Assets/02_Progs/03_ScriptableObjects/Object Pool/Monster/Pool_Monster_");
            
            string[] guids = AssetDatabase.FindAssets("t:ObjectPoolSO", new[] { "Assets/02_Progs/03_ScriptableObjects/Object Pool/Monster" });
            for (var i = 0; i < guids.Length; i++)
            {
                string path = AssetDatabase.GUIDToAssetPath(guids[i]);
                if (re.IsMatch(path))
                {
                    ObjectPoolSO so = AssetDatabase.LoadAssetAtPath<ObjectPoolSO>(path);

                    int index = _monsterPoolListProperty.arraySize;
                    _monsterPoolListProperty.InsertArrayElementAtIndex(index);
                    _monsterPoolListProperty.GetArrayElementAtIndex(index).objectReferenceValue = so;
                }
            }    
            
            serializedObject.ApplyModifiedProperties();
        }
        
        private void DrawBatchMode()
        {
            string title = _isBatchMode ? "배치 모드 비활성화" : "배치 모드 활성화";
            
            Color orgColor = GUI.backgroundColor;
            if (_isBatchMode)
            {
                GUI.backgroundColor = Color.green;
            }
            
            if (GUILayout.Button(title))
            {
                _isBatchMode = !_isBatchMode;
            }
            
            GUI.backgroundColor = orgColor;
        }
        
        private void DrawUpdateSpawnPointArea()
        {
            Color orgColor = GUI.backgroundColor;
            
            if (GUILayout.Button("Area 에 할당된 SpawnPoint 업데이트 하기"))
            {
                MonsterArea monsterArea = target as MonsterArea;

                MonsterSpawnPoint[] points = monsterArea.gameObject.GetComponentsInChildren<MonsterSpawnPoint>(true);
                for (int i = 0; i < points.Length; i++)
                {
                    points[i].area = monsterArea;
                }
                
                EditorUtility.SetDirty(monsterArea.gameObject);
                EditorSceneManager.MarkSceneDirty(monsterArea.gameObject.scene);
            }
            
            GUI.backgroundColor = orgColor;
        }
        
        private void Batch(SceneView view)
        {
            if (!_isBatchMode) return;
            if (_selectedIndex < 0 || _selectedIndex >= _monsterPoolListProperty.arraySize)
            {
                if (_monsterPoolListProperty.arraySize <= 0) return;
                
                _monsterPoolReorderableList.Select(0);
                _selectedIndex = 0;
            }
            
            SerializedProperty element = _monsterPoolReorderableList.serializedProperty.GetArrayElementAtIndex(_selectedIndex);
            ObjectPoolSO selectedSo = element.objectReferenceValue as ObjectPoolSO;
            MonsterArea monsterArea = target as MonsterArea;
            
            Event e = Event.current;
            if (e.type == EventType.MouseDown && e.button == 0 && !e.alt)
            {
                if (e.type == EventType.Layout)
                {
                    HandleUtility.AddDefaultControl(GUIUtility.GetControlID(FocusType.Passive));
                }
                Selection.activeObject = monsterArea.gameObject;
                
                Ray ray = HandleUtility.GUIPointToWorldRay(e.mousePosition);
                if (Physics.Raycast(ray, out RaycastHit hit))
                {
                    if (!NavMesh.SamplePosition(hit.point, out NavMeshHit navHit, 1.0f, NavMesh.AllAreas))
                    {
                        EditorUtility.DisplayDialog("오류", "해당 위치에는 Navmesh가 구워져 있지 않습니다", "확인");
                        return;
                    }
                    
                    string spawnerName = $"Spawner_{selectedSo.name.Substring(selectedSo.name.IndexOf("_") + 1)}";
                    GameObject go = new GameObject(spawnerName)
                    {
                        transform =
                        {
                            position = navHit.position,
                            rotation = monsterArea.transform.rotation,
                            parent = monsterArea.transform
                        }
                    };
                    MonsterSpawnPoint point = go.AddComponent<MonsterSpawnPoint>();
                    point.monsterPool = selectedSo;
                    point.area = monsterArea;

                    Undo.RegisterCreatedObjectUndo(go, spawnerName);
                }
                
                e.Use();
            }
        }

        private void DrawCreateWallButton()
        {
            if (GUILayout.Button("벽 생성"))
            {
                MonsterArea area = target as MonsterArea;

                if (area != null)
                {
                    GameObject wall = new GameObject("Wall");
                    wall.transform.SetParent(area.transform);
                    wall.AddComponent<NavMeshWallModifier>();
                    
                    wall.layer = Global.WallLayerIndex;
                }
            }
        }
    }
}