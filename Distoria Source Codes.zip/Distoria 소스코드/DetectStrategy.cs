using System;
using ProjectAAA.Utils;
using UnityEngine;
using Collider = UnityEngine.Collider;

namespace ProjectAAA.Core.Detector
{
    [Obsolete(error:true,message:"안쓰는 거임 ㅋ")]
    public abstract class DetectStrategy : DisposeBase
    {
        protected Transform CachedTr { get; private set; }
        protected Vector3 CachedCenter { get; private set; }
        protected int DetectCount { get; private set; }
        protected LayerMask DetectLayerMask { get; private set; }

        protected DetectStrategy(Transform baseTr, Vector3 center, int detectCount, LayerMask detectLayerMask)
        {
            CachedTr = baseTr;
            CachedCenter = center;
            DetectCount = detectCount;
            DetectLayerMask = detectLayerMask;
        }
        
        public abstract Collider[] Execute();

        protected override void DisposeNotManagedResources()
        {
            CachedTr = null;
        }
    }
    
    [Obsolete(error:true,message:"안쓰는 거임 ㅋ")]
    public class SphereDetectStrategy : DetectStrategy
    {
        private readonly float _radius;

        private Collider[] _detects;

        public SphereDetectStrategy(float radius, Transform baseTr, Vector3 center, int detectCount, LayerMask detectLayerMask) : base(baseTr, center, detectCount, detectLayerMask)
        {
            _radius = radius;
            _detects = new Collider[DetectCount];
        }

        public override Collider[] Execute()
        {
            int cnt = Physics.OverlapSphereNonAlloc(CachedTr.position + CachedCenter, _radius, _detects, DetectLayerMask);
            
            return cnt > 0 ? _detects : null;
        }

        protected override void DisposeNotManagedResources()
        {
            base.DisposeNotManagedResources();
            _detects = null;
        }
    }
    
    [Obsolete(error:true,message:"안쓰는 거임 ㅋ")]
    public class SectorDetectStrategy : DetectStrategy
    {
        private readonly float _height;
        private readonly float _angle;
        private readonly float _radius;

        private Collider[] _detects;

        public SectorDetectStrategy(float height, float angle, float radius, Transform baseTr, Vector3 center, int detectCount, LayerMask detectLayerMask) : base(baseTr, center, detectCount, detectLayerMask)
        {
            _height = height;
            _angle = angle;
            _radius = radius;
            _detects = new Collider[DetectCount];
        }

        public override Collider[] Execute()
        {
            int cnt = Physics.OverlapSphereNonAlloc(CachedTr.position + CachedCenter, _radius + _height, _detects, DetectLayerMask);
            
            int ret = 0;
            for (int i = 0; i < cnt; i++)
            {
                if (IsInside(_detects[i])) 
                {
                    ret++;
                }
                else
                {
                    _detects[i] = null;
                }
            }
            
            return ret > 0 ? _detects : null;
        }

        private bool IsInside(Collider other)
        {
            Vector3 dir = other.transform.position - CachedTr.position;
            
            float angle = Vector3.SignedAngle(CachedTr.forward, dir.normalized, CachedTr.up);

            bool ret = true;

            ret &= angle <= _angle * 0.5f;
            if (_height > 0f)
            {
                ret &= dir.magnitude <= _radius;
                ret &= dir.y <= _height * 0.5f;
            }
            else
            {
                dir.y = 0f;
                ret &= dir.magnitude <= _radius;
            }

            return ret;
        }

        protected override void DisposeNotManagedResources()
        {
            base.DisposeNotManagedResources();
            _detects = null;
        }
    }
}