using System.Collections.Generic;
using Newtonsoft.Json;
using ProjectAAA.Utils.DataTable;
using UnityEngine;

namespace ProjectAAA.SO
{
    [CreateAssetMenu(fileName = "RangeDataTableSO", menuName = "Scriptable Objects/DataTable/RangeDataTableSO")]
    public class RangeDataTableSO : DataTableSO
    {
        private Dictionary<int, RangeData> _rangeData = new();
        
        protected override void FromJson(string json)
        {
            List<RangeData> list = JsonConvert.DeserializeObject<List<RangeData>>(json);
            
            Utils.Logger.Assert(list != null, "Range", "영역 데이터가 비어있습니다.");
            
            _rangeData = new Dictionary<int, RangeData>(list.Count);
            foreach (RangeData data in list)
            {
                _rangeData.TryAdd(data.Code, data);
            }
        }

        public RangeData Get(int code)
        {
            if (!_rangeData.ContainsKey(code))
            {
                Utils.Logger.LogError("RangeDataTableSO", $"{code} 데이터가 존재하지 않습니다.");
                return null;
            }
            
            return _rangeData[code];
        }
    }
}