using System;
using Amazon.S3.Model;
using ProjectAAA.SO.Pool;
using UnityEngine;

namespace ProjectAAA.Core.Pool
{
    public class PoolObjMonoBehaviour : MonoBehaviour, IPoolObj
    {
        private enum Status
        {
            Gotten,
            Released
        }
        
        private ObjectPoolSO _source;
        private Status _status;

        public void SetOriginPool(ObjectPoolSO source)
        {
            _source = source;
        }

        public void SelfReturn()
        {
            if (_source != null)
            {
                _source.ReturnQueue(this);
            }
        }

        public void SetPosition(Vector3 pos, Space space = Space.World)
        {
            if (space == Space.World)
            {
                transform.position = pos;
            }
            else
            {
                transform.localPosition = pos;
            }
        }

        public void SetRotation(Quaternion rot, Space space = Space.World)
        {
            if (space == Space.World)
            {
                transform.rotation = rot;
            }
            else
            {
                transform.localRotation = rot;
            }
        }

        public void SetScale(Vector3 scale)
        {
            transform.localScale = scale;
        }

        public void SetParent(Transform p)
        {
            transform.SetParent(p);
        }

        public void Active()
        {
            gameObject.SetActive(true);
        }

        public void Inactive()
        {
            gameObject.SetActive(false);
        }

        public virtual void OnGet()
        {
            _status = Status.Gotten;
        }

        public virtual void OnRelease()
        {
            _status = Status.Released;
        }
    }
}