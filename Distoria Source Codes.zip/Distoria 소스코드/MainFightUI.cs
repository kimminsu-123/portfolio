using System;

namespace ProjectAAA.UI.MainFight
{
    public class MainFightUI : UiBase
    {
        protected override Type RegisterType => typeof(MainFightUI);
        
        public HealthUI HealthUI { get; private set; }
        public DashUI DashUI { get; private set; }
        public CurrencyUI CurrencyUI { get; private set; }
        public WeaponPreviewUI WeaponPreviewUI { get; private set; }
        public ItemCollectUI ItemCollectUI { get; private set; }
        public BuffCollectUI BuffCollectUI { get; private set; }
        public QuestCollectUI QuestCollectUI { get; private set; }

        protected override void OnAwake()
        {
            HealthUI = GetComponentInChildren<HealthUI>(true);
            DashUI = GetComponentInChildren<DashUI>(true);
            CurrencyUI = GetComponentInChildren<CurrencyUI>(true);
            WeaponPreviewUI = GetComponentInChildren<WeaponPreviewUI>(true);
            ItemCollectUI = GetComponentInChildren<ItemCollectUI>(true);
            BuffCollectUI = GetComponentInChildren<BuffCollectUI>(true);
            QuestCollectUI = GetComponentInChildren<QuestCollectUI>(true);
        }
    }
}