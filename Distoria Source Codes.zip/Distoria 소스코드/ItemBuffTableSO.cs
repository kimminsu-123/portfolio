using System.Collections.Generic;
using FMOD;
using Newtonsoft.Json;
using ProjectAAA.Utils;
using ProjectAAA.Utils.DataTable;
using UnityEngine;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.SO
{
    [CreateAssetMenu(fileName = "ItemBuffTableSO", menuName = "Scriptable Objects/DataTable/ItemBuffTableSO")]
    public class ItemBuffTableSO : DataTableSO
    {
        private Dictionary<int, ItemBuffDataGroup> _buffGroups;
        
        protected override void FromJson(string json)
        {
            List<ItemBuffData> deserialized = JsonConvert.DeserializeObject<List<ItemBuffData>>(json);
            
            Logger.Assert(deserialized != null, "ItemBuffTable", "아이템 테이블이 비어있습니다.");

            _buffGroups = new Dictionary<int, ItemBuffDataGroup>();
            foreach (ItemBuffData itemBuff in deserialized)
            {
                int key = itemBuff.EffectId;
                if (!_buffGroups.ContainsKey(key))
                {
                    _buffGroups.Add(key, new ItemBuffDataGroup());
                }
                
                _buffGroups[key].AddBuff(itemBuff);
            }
        }

        public ItemBuffDataGroup GetGroup(int buffId) => _buffGroups.GetValueOrDefault(buffId);
    }
}