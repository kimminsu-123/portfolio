using Cysharp.Threading.Tasks;
using ProjectAAA.Utils;

namespace ProjectAAA.WeaponSystem
{
    public class BulletPenetration : BulletHitAbility
    {
        public override bool IsDone => _currentCount <= 0;

        private readonly int _maxCount;

        private int _currentCount;
        
        public BulletPenetration(BulletHitHandler handler, int maxCount) : base(handler)
        {
            _maxCount = maxCount;
            _currentCount = maxCount;
        }

        public override void Init()
        {
            _currentCount = _maxCount;
            
            Next?.Init();
        }

        public override async UniTask OnHitOther(HitInfo info)
        {
            if (IsDone)
            {
                if (Next != null)
                {
                    await Next.OnHitOther(info);
                }
                return;
            }

            if (info.Target.layer == Global.MonsterHurtBoxLayerIndex)
            {
                Handler.Shoot(info.Point);
                
                _currentCount--;
            }
            else
            {
                _currentCount = -1;

                if (Next != null)
                {
                    await Next.OnHit(info);
                    await Next.OnHitOther(info);   
                }
            }
        }
    }
}