using System.Collections.Generic;
using Newtonsoft.Json;
using ProjectAAA.Utils.DataTable;
using UnityEngine;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.SO
{
    [CreateAssetMenu(fileName = "MagazineTableSO", menuName = "Scriptable Objects/DataTable/MagazineTableSO", order = 0)]
    public class MagazineTableSO : DataTableSO
    {
        public IEnumerable<MagazineData> Magazines => _magazineData.Values;
        
        private Dictionary<int, MagazineData> _magazineData;
        
        protected override void FromJson(string json)
        {
            List<MagazineData> list = JsonConvert.DeserializeObject<List<MagazineData>>(json);

            Logger.Assert(list != null, "MagazineTable", "탄창 데이터 테이블이 비어있습니다.");
            
            _magazineData = new Dictionary<int, MagazineData>(list.Count);
            foreach (MagazineData data in list)
            {
                _magazineData.TryAdd(data.MagazineId, data);
            }
        }

        public MagazineData Get(int magazineId)
        {
            if (!_magazineData.ContainsKey(magazineId))
            {
                Logger.LogError("MagazineTableSO", $"{magazineId} 데이터가 존재하지 않습니다.");
                return null;
            }
            
            return _magazineData[magazineId];
        }
    }
}