using UnityEngine;

namespace ProjectAAA.SO.ShaderEffect
{
    [CreateAssetMenu(fileName = "MonsterShaderModifierDataSO", menuName = "Scriptable Objects/ShaderEffect/MonsterShaderModifierDataSO")]
    public class MonsterShaderModifierDataSO : ScriptableObject
    {
        public static readonly int DebuffColorPropertyID = Shader.PropertyToID("_DebuffColor");
        public static readonly int HitColorPropertyID = Shader.PropertyToID("_HitColor");
        public static readonly int HitTimePropertyID = Shader.PropertyToID("_Hit_Time");
        public static readonly int DebuffTimePropertyID = Shader.PropertyToID("_Debuff_Time");
        public static readonly int CriticalTimePropertyID = Shader.PropertyToID("_Critical_Time");
        public static readonly int DesolvePropertyID = Shader.PropertyToID("_Desolve");
        
        [Header("피격 관련 설정")]
        [SerializeField] private Color normalHitColor = Color.HSVToRGB(1f, 1f, 1f, true);
        [SerializeField] private float hitFadeTime = 0.5f;
        [SerializeField] private AnimationCurve hitFadeCurve;

        [Header("디버프 관련 설정")]
        [SerializeField] private Color debuffPoisonColor = Color.HSVToRGB(1f, 1f, 1f, true);
        [SerializeField] private Color debuffBurnColor = Color.HSVToRGB(1f, 1f, 1f, true);
        [SerializeField] private Color debuffCorrosionColor = Color.HSVToRGB(1f, 1f, 1f, true);
        [SerializeField] private Color debuffWoundColor = Color.HSVToRGB(1f, 1f, 1f, true);
        
        [SerializeField] private int debuffPoisonMaxStack = 5;
        [SerializeField] private int debuffBurnMaxStack = 10;
        [SerializeField] private int debuffCorrosionMaxStack = 10;
        [SerializeField] private int debuffWoundMaxStack = 10;
        [SerializeField] private float debuffFadeTime = 0.3f;
        [SerializeField] private AnimationCurve debuffFadeCurve;
        
        [Header("크리티컬 관련 설정")]
        [SerializeField] private Color criticalHitColor = Color.HSVToRGB(1f, 1f, 1f, true);
        [SerializeField] private float criticalFadeTime = 0.5f;
        [SerializeField] private AnimationCurve criticalFadeCurve;
        
        [Header("죽었을 때 Desolve 관련 설정")]
        [SerializeField] private float deathDesolveFadeDealy = 3f;
        [SerializeField] private float deathDesolveFadeTime = 0.5f;
        [SerializeField] private AnimationCurve deathDesolveFadeCurve;
        
        public float HitFadeTime => hitFadeTime;
        public AnimationCurve HitFadeCurve => hitFadeCurve;

        public Color NormalHitColor => normalHitColor;
        public Color CriticalHitColor => criticalHitColor;
        public Color DebuffPoisonColor => debuffPoisonColor;
        public Color DebuffBurnColor => debuffBurnColor;
        public Color DebuffCorrosionColor => debuffCorrosionColor;
        public Color DebuffWoundColor => debuffWoundColor;
        public float DebuffFadeTime => debuffFadeTime;
        public int DebuffPoisonMaxStack => debuffPoisonMaxStack;
        public int DebuffBurnMaxStack => debuffBurnMaxStack;
        public int DebuffCorrosionMaxStack => debuffCorrosionMaxStack;
        public int DebuffWoundMaxStack => debuffWoundMaxStack;
        public AnimationCurve DebuffFadeCurve => debuffFadeCurve;
        
        public float CriticalFadeTime => criticalFadeTime;
        public AnimationCurve CriticalFadeCurve => criticalFadeCurve;
        
        public float DeathDesolveFadeDealy => deathDesolveFadeDealy;
        public float DeathDesolveFadeTime => deathDesolveFadeTime;
        public AnimationCurve DeathDesolveFadeCurve => deathDesolveFadeCurve;
    }
}