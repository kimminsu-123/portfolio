using System;
using ProjectAAA.Utils;
using UnityEngine;
using UnityEngine.Events;

namespace ProjectAAA.Core.Entity
{
    public class HurtBox : MonoBehaviour, IDamageable
    {
        [HideInInspector] public HurtBox centerHurtBox;
        [HideInInspector] public Transform rootTr;
        public int RootHash => rootTr.GetHashCode(); 
        
        public UnityEvent<HitInfo> onTakeDamage;
        public bool isCriticalZone;
        public bool isCenter;

        public Collider CachedCollider { get; private set; }

        private void Awake()
        {
            CachedCollider = GetComponent<Collider>();
        }

        public virtual void TakeDamage(HitInfo hitInfo)
        {
            hitInfo.IsCritical = isCriticalZone;
            hitInfo.Target = gameObject;
            onTakeDamage?.Invoke(hitInfo);
        }
    }
}