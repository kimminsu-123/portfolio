using System;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.VirtualTexturing;

namespace ProjectAAA.EditorSelection
{
    public static class EditorSelectionSettings
    {
        private const string PREFS_PREFIX = "EditorSelectionOverlay";
        public static bool EnableSelection => EditorPrefs.GetBool($"{PREFS_PREFIX}enableSelectionToggle", false);

        public static Color HoverColor => new Color(
            EditorPrefs.GetFloat($"{PREFS_PREFIX}hoverColor_R", 1f),
            EditorPrefs.GetFloat($"{PREFS_PREFIX}hoverColor_G", 1f),
            EditorPrefs.GetFloat($"{PREFS_PREFIX}hoverColor_B", 0f),
            EditorPrefs.GetFloat($"{PREFS_PREFIX}hoverColor_A", 1f)
        );

        public static Color SelectionColor => new Color(
            EditorPrefs.GetFloat($"{PREFS_PREFIX}selectionColor_R", 1f),
            EditorPrefs.GetFloat($"{PREFS_PREFIX}selectionColor_G", 0f),
            EditorPrefs.GetFloat($"{PREFS_PREFIX}selectionColor_B", 0f),
            EditorPrefs.GetFloat($"{PREFS_PREFIX}selectionColor_A", 1f)
        );

        public static void SaveEnableSelection(bool enable)
        {
            EditorPrefs.SetBool($"{PREFS_PREFIX}enableSelectionToggle", enable);
        }

        public static void SaveHoverColor(Color color)
        {
            EditorPrefs.SetFloat($"{PREFS_PREFIX}hoverColor_R", color.r);
            EditorPrefs.SetFloat($"{PREFS_PREFIX}hoverColor_G", color.g);
            EditorPrefs.SetFloat($"{PREFS_PREFIX}hoverColor_B", color.b);
            EditorPrefs.SetFloat($"{PREFS_PREFIX}hoverColor_A", color.a);
        }

        public static void SaveSelectionColor(Color color)
        {
            EditorPrefs.SetFloat($"{PREFS_PREFIX}selectionColor_R", color.r);
            EditorPrefs.SetFloat($"{PREFS_PREFIX}selectionColor_G", color.g);
            EditorPrefs.SetFloat($"{PREFS_PREFIX}selectionColor_B", color.b);
            EditorPrefs.SetFloat($"{PREFS_PREFIX}selectionColor_A", color.a);
        }
    }

    public static class EditorSelectionHighlighter
    {
        private static GameObject _hoveredGameObject;
        private static Transform[] _selectedTransforms;
        private static bool _isFocus;

        private static GUIStyle _helpLabelStyle;
        private static GUIStyle _labelStyle;
        private static Material _hoveredMaterial;
        private static Material _selectedMaterial;

        [InitializeOnLoadMethod]
        public static void Initialize()
        {
            _isFocus = EditorApplication.isFocused;

            RegisterEvents();
        }

        private static void RegisterEvents()
        {
            SceneView.beforeSceneGui += OnSceneGUIBefore;
            SceneView.duringSceneGui += OnSceneGUI;
            EditorApplication.focusChanged += isFocus => _isFocus = isFocus;
            Selection.selectionChanged += OnSelectionChanged;
        }

        private static void SetupMaterials()
        {
            _hoveredMaterial = new Material(Shader.Find("Universal Render Pipeline/Unlit"));
            _hoveredMaterial.SetFloat("_Surface", 1);
            _hoveredMaterial.SetFloat("_Blend", 0);
            _hoveredMaterial.SetInt("_SrcBlend", (int)BlendMode.SrcAlpha);
            _hoveredMaterial.SetInt("_DstBlend", (int)BlendMode.OneMinusSrcAlpha);
            _hoveredMaterial.SetInt("_ZWrite", 0);
            _hoveredMaterial.EnableKeyword("_SURFACE_TYPE_TRANSPARENT");
            _hoveredMaterial.EnableKeyword("_ALPHAPREMULTIPLY_ON");
            _hoveredMaterial.SetColor("_BaseColor", EditorSelectionSettings.HoverColor);
            _hoveredMaterial.SetShaderPassEnabled("ShadowCaster", false);
            _hoveredMaterial.renderQueue = (int)RenderQueue.Transparent;

            _selectedMaterial = new Material(Shader.Find("Universal Render Pipeline/Unlit"));
            _selectedMaterial.SetFloat("_Surface", 1);
            _selectedMaterial.SetFloat("_Blend", 0);
            _selectedMaterial.SetInt("_SrcBlend", (int)BlendMode.SrcAlpha);
            _selectedMaterial.SetInt("_DstBlend", (int)BlendMode.OneMinusSrcAlpha);
            _selectedMaterial.SetInt("_ZWrite", 0);
            _selectedMaterial.EnableKeyword("_SURFACE_TYPE_TRANSPARENT");
            _selectedMaterial.EnableKeyword("_ALPHAPREMULTIPLY_ON");
            _selectedMaterial.SetColor("_BaseColor", EditorSelectionSettings.SelectionColor);
            _selectedMaterial.SetShaderPassEnabled("ShadowCaster", false);
            _selectedMaterial.renderQueue = (int)RenderQueue.Transparent;
        }

        private static void OnSceneGUIBefore(SceneView obj)
        {
            if (!EditorSelectionSettings.EnableSelection || !_isFocus) return;

            SetupMaterials();

            if (_hoveredGameObject != null)
            {
                HighlightGameObject(_hoveredGameObject, _hoveredMaterial, false);
            }

            if (_selectedTransforms != null)
            {
                foreach (Transform selected in _selectedTransforms)
                {
                    if (selected == null) continue;

                    HighlightGameObject(selected.gameObject, _selectedMaterial, true);
                }
            }
        }

        private static void OnSceneGUI(SceneView view)
        {
            if (!EditorSelectionSettings.EnableSelection || !_isFocus)
            {
                _hoveredGameObject = null;
                _selectedTransforms = null;
                SceneView.RepaintAll();
                return;
            }

            Event current = Event.current;
            HandleUtility.AddControl(GUIUtility.GetControlID(FocusType.Passive), float.PositiveInfinity);

            if (current.type == EventType.MouseMove)
            {
                GameObject newObj = HandleUtility.PickGameObject(current.mousePosition, true);
                if (newObj != _hoveredGameObject)
                {
                    _hoveredGameObject = newObj;
                    view.Repaint();
                }
            }

            DrawLabels();
        }

        private static void HighlightGameObject(GameObject target, Material material, bool ignoreHover)
        {
            try
            {
                if (target == null) return;
                if (ignoreHover && target == _hoveredGameObject) return;

                SceneView sceneView = SceneView.lastActiveSceneView;
                if (sceneView == null) return;

                Camera sceneCamera = sceneView.camera;
                if (sceneCamera == null) return;

                Vector3 direction = sceneCamera.transform.position - target.transform.position;
                Vector3 offset = direction.normalized * 0.001f;
                Matrix4x4 translatedMatrix = Matrix4x4.TRS(
                    target.transform.position + offset,
                    target.transform.rotation,
                    target.transform.lossyScale
                );

                MeshFilter meshFilter = target.GetComponent<MeshFilter>();
                if (meshFilter != null && meshFilter.sharedMesh != null)
                {
                    Graphics.DrawMesh(meshFilter.sharedMesh, translatedMatrix, material, 0, sceneCamera);
                }
                else
                {
                    SkinnedMeshRenderer skinnedMeshRen = target.GetComponent<SkinnedMeshRenderer>();
                    if (skinnedMeshRen != null && skinnedMeshRen.sharedMesh != null)
                    {
                        Graphics.DrawMesh(skinnedMeshRen.sharedMesh, translatedMatrix, material, 0, sceneCamera);
                    }
                }

                for (int i = 0; i < target.transform.childCount; i++)
                {
                    HighlightGameObject(target.transform.GetChild(i).gameObject, material, ignoreHover);
                }
            }
            catch (Exception)
            {
                // ignore
            }
        }

        private static void OnSelectionChanged()
        {
            _selectedTransforms = Selection.transforms;
            SceneView.RepaintAll();
        }

        private static void SettingStyles()
        {
            _helpLabelStyle = new GUIStyle(EditorStyles.largeLabel);
            _helpLabelStyle.fontStyle = FontStyle.BoldAndItalic;
            _helpLabelStyle.normal.textColor = Color.yellow;
            _helpLabelStyle.wordWrap = true;

            _labelStyle = new GUIStyle(EditorStyles.label);
            _labelStyle.normal.textColor = Color.red;
            _labelStyle.wordWrap = true;
        }

        private static void DrawLabels()
        {
            SettingStyles();

            try
            {
                Handles.BeginGUI();
                GUILayout.BeginVertical(EditorStyles.helpBox, GUILayout.ExpandWidth(false));
                GUILayout.Label($"프리팹에 경우 최상위 오브젝트와 하위오브젝트가 모두 선택됩니다. 하위 오브젝트를 선택하고 싶다면 최상위 오브젝트 선택 후 다시 선택하시면 됩니다.",
                    _helpLabelStyle);
                GUILayout.Label($"Hovered Object: {_hoveredGameObject?.name}", _labelStyle);
                if (_selectedTransforms != null)
                {
                    string[] names = _selectedTransforms.Select(x => x.name).ToArray();
                    GUILayout.Label($"Selected Objects: {string.Join(", ", names)}", _labelStyle);
                }

                GUILayout.EndVertical();
                Handles.EndGUI();
            }
            catch (Exception)
            {
                // ignore
            }
        }
    }
}