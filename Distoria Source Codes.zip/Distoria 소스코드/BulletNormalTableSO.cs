using System.Collections.Generic;
using Newtonsoft.Json;
using ProjectAAA.Utils.DataTable;
using ProjectAAA.WeaponSystem;
using UnityEngine;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.SO
{
    [CreateAssetMenu(fileName = "BulletNormalTableSO", menuName = "Scriptable Objects/DataTable/BulletNormalTableSO", order = 0)]
    public class BulletNormalTableSO : DataTableSO
    {
        private Dictionary<int, BulletNormalData> _bulletData;
        
        protected override void FromJson(string json)
        {
            List<BulletNormalData> list = JsonConvert.DeserializeObject<List<BulletNormalData>>(json);

            Logger.Assert(list != null, "BulletNormalTable", "탄알 (일반형) 데이터 테이블이 비어있습니다.");
            
            _bulletData = new Dictionary<int, BulletNormalData>(list.Count);
            foreach (BulletNormalData data in list)
            {
                _bulletData.TryAdd(data.BulletID, data);
            }
        }

        public BulletNormalData Get(int bulletId)
        {
            if (!_bulletData.ContainsKey(bulletId))
            {
                Logger.LogError("BulletNormalTableSO", $"{bulletId} 데이터가 존재하지 않습니다.");
                return null;
            }
            
            return _bulletData[bulletId];
        }
    }
}