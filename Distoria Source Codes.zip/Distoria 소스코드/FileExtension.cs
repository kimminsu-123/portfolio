using System.IO;
using System.Text;
using ProjectAAA.Interaction.Items;
using UnityEngine;

namespace ProjectAAA.Utils
{
    public static class FileExtensions
    {
        public static async Awaitable<string> ReadLineAsync(this BinaryReader br)
        {
            await Awaitable.BackgroundThreadAsync();
            StringBuilder sb = new StringBuilder();

            bool foundEndOfLine = false;
            while (!foundEndOfLine)
            {
                try
                {
                    char ch = br.ReadChar();
                    switch (ch)
                    {
                        case '\r':
                            if (br.PeekChar() == '\n')
                            {
                                br.ReadChar();
                            }
                            foundEndOfLine = true;
                            break;
                        case '\n':
                            foundEndOfLine = true;
                            break;
                        default:
                            sb.Append(ch);
                            break;
                    }
                }
                catch (EndOfStreamException)
                {
                    break;
                }
            }

            await Awaitable.MainThreadAsync();
            
            return sb.ToString();
        }
    }
}