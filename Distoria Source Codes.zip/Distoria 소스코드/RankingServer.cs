using System;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using ProjectAAA.Utils;
using UnityEngine;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.Network
{
    public class RankingServer : Singleton<RankingServer>
    {
        public bool IsValid { get; private set; }
        
        private static readonly string FilePath = $@"{Application.dataPath}\serverinfo.ini";
        private static readonly int NameLen = 128;

        private UdpClient _client;
        private string _serverIp;
        private int _port;
        
        public void Initialize()
        {
            IsValid = File.Exists(FilePath);
            if (IsValid)
            {
                try
                {
                    string[] lines = File.ReadLines(FilePath).ToArray();
                    
                    _serverIp = lines[0];
                    _port = int.Parse(lines[1]);

                    _client = new UdpClient();
                    
                    Logger.Log($"RankingServer", $"파일 정보 및 Client 생성이 완료되었습니다. {_serverIp}:{_port}");
                }
                catch (Exception e)
                {
                    Logger.LogException(e);
                }
            }
            else
            {
                Logger.Log($"RankingServer", $"랭킹 서버에 연결할 수 있는 파일이 존재하지 않습니다.");
            }
        }

        public void Send(GameMode mode, string name, long ticks)
        {
            if (!IsValid || mode == GameMode.None)
            {
                return;
            }
            
            byte[] source = new byte[512];
            int offset = 0;
            
            try
            {
                offset += Serialize(source, offset, (int) mode);
                offset += Serialize(source, offset, name);
                offset += Serialize(source, offset, ticks);

                // 타임아웃 3초
                _client.Client.SendTimeout = 3000;
                _client.Send(source, source.Length, _serverIp, _port);

                Logger.Log($"RankingServer", $"서버로 정상적으로 전송 되었습니다. {mode} {name} {ticks}");
            }
            catch (Exception e)
            {
                Logger.LogException(e);
            }
        }
        
        private static int Serialize(byte[] source, int offset, int value)
        {
            byte[] buffer = BitConverter.GetBytes(value);
            Buffer.BlockCopy(buffer, 0, source, offset, sizeof(int));

            return buffer.Length;
        }

        private static int Serialize(byte[] source, int offset, string value)
        {
            byte[] buffer = Encoding.UTF8.GetBytes(value);
            if (BitConverter.IsLittleEndian)
            {
                Array.Reverse(buffer);
            }

            int len = buffer.Length;
            if(len > NameLen)
            {
                len = NameLen;
            }
            Buffer.BlockCopy(buffer, 0, source, offset, len);

            return NameLen;
        }

        private static int Serialize(byte[] source, int offset, long value)
        {
            byte[] buffer = BitConverter.GetBytes(value);
            Buffer.BlockCopy(buffer, 0, source, offset, sizeof(long));

            return buffer.Length;
        }
    }
}