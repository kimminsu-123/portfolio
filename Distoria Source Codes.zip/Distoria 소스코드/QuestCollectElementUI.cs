using System;
using ProjectAAA.Core.Managers;
using ProjectAAA.SO;
using TMPro;
using UnityEngine;

namespace ProjectAAA.UI.MainFight
{
    [RequireComponent(typeof(Animator))]
    public class QuestCollectElementUI : CollectElementUI<QuestCollectData>
    {
        [SerializeField] private TMP_Text bodyText;
        [SerializeField] private TMP_Text goalText;

        private readonly int _isClear = Animator.StringToHash("IsClear");
        private Animator _animator;

        private void Awake()
        {
            _animator = GetComponent<Animator>();
        }

        protected override void OnSetup(QuestCollectData data)
        {
            _animator.SetBool(_isClear, false);
            
            UpdateUI(data);
        }

        public void UpdateUI(QuestCollectData data)
        {
            bodyText.text = data.BodyMsg;
            goalText.text = data.GoalMsg;
        }

        public void AnimationClear()
        {
            _animator.SetBool(_isClear, true);
        }
    }
}