using System;
using System.Collections.Generic;
using ProjectAAA.Player;
using ProjectAAA.SO.Pool;
using ProjectAAA.Utils.DataTable;
using UnityEngine;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.WeaponSystem
{
    public class MagazineBase
    {
        public int NextMagazineID => _magazineData.NextMagazineId;
        public int MagazineID => _magazineData.MagazineId;
        public int Count => _bulletPoolStack.Count;
        public int Size => _magazineData.MagazineSize + WeaponAlterStat.Instance.MagazineSize;
        public bool IsFull => Size == Count;
        
        private readonly MagazineData _magazineData;
        private readonly BulletGenerator _bulletGenerator;
        private readonly Queue<ObjectPoolSO> _bulletPoolStack;
        
        public MagazineBase(MagazineData data, BulletGenerator bulletGenerator)
        {
            _magazineData = data;
            _bulletGenerator = bulletGenerator;
            _bulletPoolStack = new Queue<ObjectPoolSO>();
        }
        
        public void Fill(int amount)
        {
            if (_bulletPoolStack.Count >= Size) return;

            _bulletPoolStack.Clear();
            switch (_magazineData.MagazineType)
            {
                case MagazineType.None:
                    FillOnlyBasic(amount);
                    break;
                case MagazineType.Area:
                    FillArea(amount);
                    break;
                case MagazineType.Repeat:
                    FillRepeat(amount);
                    break;
            }
        }

        public void Clear()
        {
            _bulletPoolStack.Clear();
        }

        private void FillOnlyBasic(int amount)
        {
            int basic = _magazineData.BasicBulletId;
            for (int i = 1; i <= amount; i++)
            {
                ObjectPoolSO bulletPool = _bulletGenerator.GetPool(basic);
                Push(bulletPool);
            }
        }
        
        private void FillArea(int amount)
        {
            PaddingType minPaddingType = _magazineData.MinPaddingType;
            PaddingType maxPaddingType = _magazineData.MaxPaddingType;

            int minValue = _magazineData.MagazineMin;
            int maxValue = _magazineData.MagazineMax;
            
            CalcPaddingPosition(minPaddingType, minValue, out int left);
            CalcPaddingPosition(maxPaddingType, maxValue, out int right);
            
            if (left > right)
            {
                Logger.LogError("MagazineBase", $"Area Type 에 Padding Min, Max 값이 잘못 설정 되어있습니다. (left > right) : ({left} > {right})");
                return;
            }
            
            int basic = _magazineData.BasicBulletId;
            int special = _magazineData.SpecialBulletId;
            for (int i = 1; i <= amount; i++)
            {
                int id = left <= i && i <= right ? special : basic;
                
                ObjectPoolSO bulletPool = _bulletGenerator.GetPool(id);
                Push(bulletPool);
            }
        }
        
        private void CalcPaddingPosition(PaddingType type, int value, out int ret)
        {
            if (type == PaddingType.Left)
            {
                ret = value;
            }
            else
            {
                ret = Size - value + 1;
            }
        }

        private void FillRepeat(int amount)
        {
            int left = _magazineData.MagazineMin;
            int right = left + _magazineData.MagazineMax - 1;

            if (left > right)
            {
                Logger.LogError("MagazineBase", $"Repeat Type 에 Min, Max 값이 잘못 설정 되어있습니다. (left > right) : ({left} > {right})");
                return;
            }

            int basic = _magazineData.BasicBulletId;
            int special = _magazineData.SpecialBulletId;
            for (int i = 0; i < amount; i++)
            {
                int repeat = i % right + 1;
                int id = left <= repeat && repeat <= right ? special : basic;
                
                ObjectPoolSO bulletPool = _bulletGenerator.GetPool(id);
                Push(bulletPool);
            }
        }
        
        public void Push(ObjectPoolSO bulletPool)
        {
            _bulletPoolStack.Enqueue(bulletPool);
        }

        public BulletBase Pop(Transform shootPos)
        {
            if (_bulletPoolStack.Count <= 0)
            {
                return null;
            }
            
            ObjectPoolSO bulletPool = _bulletPoolStack.Dequeue();

            BulletBase nextBullet = bulletPool.Get<BulletBase>(shootPos);
            nextBullet.SetOriginPool(bulletPool);
            nextBullet.SetParent(null);
            nextBullet.SetScale(Vector3.one);

            return nextBullet;
        }
        
        public BulletBase[] Pop(Transform shootPos, int cnt)
        {
            if (_bulletPoolStack.Count <= 0)
            {
                return null;
            }
            
            ObjectPoolSO bulletPool = _bulletPoolStack.Dequeue();

            BulletBase[] ret = new BulletBase[cnt];
            for (int i = 0; i < cnt; i++)
            {
                BulletBase nextBullet = bulletPool.Get<BulletBase>(shootPos);
                nextBullet.SetOriginPool(bulletPool);
                nextBullet.SetParent(null);
                nextBullet.SetScale(Vector3.one);

                ret[i] = nextBullet;
            }
            return ret;
        }
    }
}