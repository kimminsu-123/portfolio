using ProjectAAA.Core.Entity;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.UI.MainFight
{
    public class HealthUI : MonoBehaviour
    {
        [SerializeField] private TMP_Text healthText;
        [SerializeField] private Image fillImage;
        
        private LivingEntity _bindEntity;

        private void Awake()
        {
            healthText.text = string.Empty;
            fillImage.fillAmount = 1f;
        }

        public void BindEntity(LivingEntity entity)
        {
            if (_bindEntity != null)
            {
                _bindEntity.onUpdate.RemoveListener(OnUpdateHealth);
            }
            
            _bindEntity = entity;
            _bindEntity.onUpdate.AddListener(OnUpdateHealth);
        }

        private void OnUpdateHealth()
        {
            float max = _bindEntity.MaxHealth;
            float cur = _bindEntity.CurrentHealth;
            
            if (max <= 0)
            {
                return;
            }
            
            if (max < cur)
            {
                Logger.LogError("Health UI", $"{max} {cur} MaxHealth 보다 CurrentHealth 가 더 작습니다.");
                return; 
            }

            healthText.text = $"{cur:F0}";
            fillImage.fillAmount = Mathf.Clamp01(cur / max);
        }
    }
}