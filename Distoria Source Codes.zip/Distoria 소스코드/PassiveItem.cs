using System;
using ProjectAAA.Core;
using ProjectAAA.Core.Managers;
using ProjectAAA.Core.Scene.Manager;
using ProjectAAA.UI;
using ProjectAAA.UI.MainFight;
using ProjectAAA.Utils;
using ProjectAAA.Utils.DataTable;
using UnityEngine;

namespace ProjectAAA.Interaction.Items
{
    public class PassiveItem : ItemBase, IInteractable, IItemFloatingModel
    {
        public float InteractDuration => 0.5f;
        public Sprite Icon => DatabaseManager.Instance.IconResources.GetIcon(RewardType.PassiveItem, CachedBuilder.ItemID);
        public string Name => ItemData.ItemName;
        public string Type => ItemData.ItemGrade.ToString();
        public string Desc => ItemData.ItemDescription; 
        public string Effect => Buffs.ToString();
        public Transform ParentTr => _floatingPosition;

        private Transform _floatingPosition;

        private void Start()
        {
            _floatingPosition = transform.FindInChildrenContains("Floating");
        }

        public override void Active()
        {
            base.Active();
            
            CachedBuilder.Model.ChangeLayerAll(Global.OutlineLayerIndex);
        }

        public override void InActive()
        {
            base.InActive();
            
            CachedBuilder.Model.ChangeLayerAll(Global.ItemLayerIndex);
        }

        public void Interact(GameObject target)
        {
            Use(target);
        }

        public override void Use(GameObject target)
        {
            base.Use(target);
            
            if (target.TryGetComponent(out ItemHandler handler))
            {
                handler.InsertItem(this);
                
                UiManager.Instance.Get<MainFightUI>().ItemCollectUI.Add(RewardType.PassiveItem, CachedBuilder.ItemID, ItemData.ItemName);
            }
        }

        public override void OnReset()
        {
            Buffs.ResetAll(CachedTarget);
            
            base.OnReset();
        }

        protected override void PostLoadItem()
        {
            gameObject.SetActive(false);
            transform.parent = PlayerManager.Instance.PlayerGo.transform;
        }

        protected override void OnGetParticle()
        {
            PassiveItemParticlePoolObj particle = CachedParticle as PassiveItemParticlePoolObj;

            if (particle != null)
            {
                particle.SetItemTexture(CachedBuilder.ItemID);
            }
        }
    }
}