using System.Collections.Generic;
using UnityEngine;

namespace ProjectAAA.Utils
{
    public static class TimeHandler
    {
        private static int _curAuthor;
        
        public static void SetTimeScale(int author, float scale)
        {
            if (_curAuthor.Equals(author)) return;

            _curAuthor = author;
            
            Time.timeScale = scale;
            Time.fixedDeltaTime = 0.005f * scale;
        }

        public static void ResetTimeScale(int author)
        {
            if (!_curAuthor.Equals(author)) return;

            _curAuthor = 0;

            Time.timeScale = 1f;
            Time.fixedDeltaTime = 0.005f;
        }
    }
}