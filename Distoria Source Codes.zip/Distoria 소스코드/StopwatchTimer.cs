using System;

namespace ProjectAAA.Core.Timer
{
    public class StopwatchTimer : Timer<float>
    {
        public StopwatchTimer(float initTime) : base(initTime)
        {
        }

        public override void Tick(float delta)
        {
            if (IsRunning && !IsPause)
            {
                CurrentTime += delta;
            }
        }

        public TimeSpan ToTimeSpan() => TimeSpan.FromSeconds(CurrentTime);
    }
}