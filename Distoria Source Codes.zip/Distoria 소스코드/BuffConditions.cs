using System;
using KinematicCharacterController;
using ProjectAAA.Core.Action;
using ProjectAAA.Core.Entity;
using ProjectAAA.Core.Managers;
using ProjectAAA.Core.Scene.Manager;
using ProjectAAA.Player.Actions;
using ProjectAAA.SO;
using ProjectAAA.Utils;
using ProjectAAA.WeaponSystem;
using UniRx;
using UnityEngine;
using EventType = ProjectAAA.Core.Managers.EventType;

namespace ProjectAAA.Interaction.Items
{
    public abstract class ItemBuffConditionBase : IPredicate
    {
        public virtual void Enable() { }
        public virtual void Disable() { }

        public abstract bool Evaluate();
    }
    
    public class ConditionNone : ItemBuffConditionBase
    {
        public override bool Evaluate() => true;
    }
    
    public class ConditionUnderPlayerHealth : ItemBuffConditionBase
    {
        private readonly float _percent;

        private LivingEntity PlayerEntity => PlayerManager.Instance.PlayerEntity;
        
        public ConditionUnderPlayerHealth(float percent)
        {
            _percent = percent;
        }

        public override bool Evaluate()
        {
            float curPercent = PlayerEntity.CurrentHealth / PlayerEntity.MaxHealth;
            
            return curPercent <= (_percent * 0.01f);
        }
    }

    public class ConditionFlyPlayer : ItemBuffConditionBase
    {
        private KinematicCharacterMotor Motor => PlayerManager.Instance.PlayerMotor;
        
        public override bool Evaluate() => !Motor.GroundingStatus.IsStableOnGround;
    }
    
    public class ConditionMovePlayer : ItemBuffConditionBase
    {
        private KinematicCharacterMotor Motor => PlayerManager.Instance.PlayerMotor;
                
        public override bool Evaluate() => Motor.BaseVelocity.sqrMagnitude > 0f;
    }
    
    public class ConditionStopPlayer : ItemBuffConditionBase
    {
        private KinematicCharacterMotor Motor => PlayerManager.Instance.PlayerMotor;
                
        public override bool Evaluate() => Mathf.Approximately(Motor.BaseVelocity.sqrMagnitude, 0f);
    }

    public class ConditionOnPlayerDash : ItemBuffConditionBase
    {
        private ActionFlagSO DashActionFlag => PlayerManager.Instance.dashActionFlag;
        private IActionable PlayerActionController => PlayerManager.Instance.ActionController;
        
        public override bool Evaluate() => PlayerActionController.ContainsAction(DashActionFlag);
    }
    
    public class ConditionInSafeTimePlayer : ItemBuffConditionBase
    {
        private readonly float _safeTime;
        private float _lastTime;
        
        public ConditionInSafeTimePlayer(float time)
        {
            _safeTime = time;
        }

        public override void Enable()
        {
            PlayerManager.Instance.PlayerEntity.onTakeDamage.AddListener(OnTakeDamage);
            
            _lastTime = Time.time;
        }
        
        public override void Disable()
        {
            PlayerManager.Instance.PlayerEntity.onTakeDamage.RemoveListener(OnTakeDamage);
        }

        private void OnTakeDamage(HitInfo info)
        {
            _lastTime = Time.time;
        }

        public override bool Evaluate() => Time.time >= _lastTime + _safeTime;
    }

    public class ConditionOnKillMonster : ItemBuffConditionBase
    {
        private readonly int _count;

        private int _accumCount;
        
        public ConditionOnKillMonster(int count)
        {
            _count = count;             
        }
        
        public override void Enable()
        {
            EventManager.Instance.AddListener(EventType.OnKillMonster, OnKillMonster);
            
            _accumCount = 0;
        }

        private void OnKillMonster(Component sender, object[] args)
        {
            _accumCount++;
        }

        public override void Disable()
        {
            EventManager.Instance.RemoveListener(EventType.OnKillMonster, OnKillMonster);
        }
        
        public override bool Evaluate()
        {
            bool ret = _accumCount >= _count;
            if(ret) _accumCount = 0;
            return ret;
        }
    }

    public class ConditionOnSwapWeapon : ItemBuffConditionBase
    {
        private WeaponHandler PlayerWeaponHandler => PlayerManager.Instance.WeaponHandler;

        private WeaponBase _curWeapon;
        private bool _isSwapped;
        private IDisposable _rxInstance;
        
        public override void Enable()
        {
            _rxInstance?.Dispose();
            _rxInstance = PlayerWeaponHandler.CurrentWeapon.Subscribe(OnChangeWeapon);
            _isSwapped = false;
        }

        public override void Disable()
        {
            _rxInstance?.Dispose();
        }
        
        private void OnChangeWeapon(WeaponBase newWeapon)
        {
            if (_curWeapon != newWeapon)
            {
                _curWeapon = newWeapon;
                _isSwapped = true;   
            }
        }

        public override bool Evaluate()
        {
            bool ret = _isSwapped;

            _isSwapped = false;

            return ret;
        }   
    }
}