using System.IO;
using UnityEngine;
using ProjectAAA.Utils;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.Core
{
    public static class Config
    {
        private const string AWS_BIN_FILE_PATH = @"../config.bin";
        private const string CRYPTO_KEY = @"PROJECT_AAA_CKEY"; // 키는 무조건 16글자 맞춰야함

        public static string AwsPublicAccessKey { get; private set; }
        public static string AwsSecretAccessKey { get; private set; }
        public static string AwsDataTableBucketName { get; private set; }

        public static async Awaitable LoadConfigAws()
        {
            await using FileStream fs = new FileStream(AWS_BIN_FILE_PATH, FileMode.Open);
            
            using BinaryReader br = new BinaryReader(fs);
            string publicKey = await br.ReadLineAsync();
            string secreteKey = await br.ReadLineAsync();
            string bucketName = await br.ReadLineAsync();
            
            AwsPublicAccessKey = Util.AESDecrypt128(CRYPTO_KEY, publicKey);
            AwsSecretAccessKey = Util.AESDecrypt128(CRYPTO_KEY, secreteKey);
            AwsDataTableBucketName = Util.AESDecrypt128(CRYPTO_KEY, bucketName);
            
            Logger.Log("AwsPublicAccessKey", AwsPublicAccessKey, Color.green);
            Logger.Log("AwsSecretAccessKey", AwsSecretAccessKey, Color.green);
            Logger.Log("AwsDataTableBucketName", AwsDataTableBucketName, Color.green);
        }
    }
    
    public class ConfigLoader : MonoBehaviour
    {
        #region ForDebugging
        [SerializeField] private string txt;

        private const string CRYPTO_KEY = @"PROJECT_AAA_CKEY"; // 키는 무조건 16글자 맞춰야함
        
        [ContextMenu("Encrypt")]
        private void Encrypt()
        {
            Logger.Log("Encrypt", Util.AESEncrypt128(CRYPTO_KEY, txt), Color.green);
        }

        [ContextMenu("Decrypt")]
        private void Decrypt()
        {
            Logger.Log("Encrypt", Util.AESDecrypt128(CRYPTO_KEY, txt), Color.green);
        }

        #endregion
        public async Awaitable Load()
        {
            await Config.LoadConfigAws();
        }
    }
}