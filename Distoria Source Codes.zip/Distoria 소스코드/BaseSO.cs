using UnityEngine;

namespace ProjectAAA.SO
{
    public class BaseSO : ScriptableObject
    {
        [SerializeField, TextArea] private string description;
    }
}