using ProjectAAA.Core.Scene.Manager;
using ProjectAAA.Utils;
using UnityEngine;

namespace ProjectAAA.Player.Actions
{
    public class PlayerFireAction : PlayerActionBase
    {
        private bool IsFireKeyDown => PlayerActionController.PlayerInput.GamePlay.Fire.IsPressed();

        public override void OnRegister()
        {
            base.OnRegister();
            
            PlayerManager.Instance.WeaponHandler.Trigger();
        }

        public override void OnUnRegister()
        {
            base.OnUnRegister();
            
            PlayerManager.Instance.WeaponHandler.Release();
        }

        public override bool Validate()
        {
            return IsFireKeyDown;
        }
    }
}