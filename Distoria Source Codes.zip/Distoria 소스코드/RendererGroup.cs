using System;
using System.Collections.Generic;
using System.Linq;
using DG.Tweening;
using UnityEngine;

namespace ProjectAAA.Utils
{
    public class RendererGroup
    {
        private readonly Material[] _materials;

        public RendererGroup(GameObject root)
        {
            Renderer[] renderers = root.GetComponentsInChildren<Renderer>(true);
            
            _materials = renderers.SelectMany(x => x.materials).ToArray();
        }

        public void SetFloat(int id, float value)
        {
            for (int i = 0; i < _materials.Length; i++)
            {
                Material mat = _materials[i];

                if (mat != null && mat.HasFloat(id))
                {
                    mat.SetFloat(id, value);
                }
            }
        }

        public float GetFloat(int id)
        {
            for (int i = 0; i < _materials.Length; i++)
            {
                Material mat = _materials[i];

                if (mat != null && mat.HasFloat(id))
                {
                    return mat.GetFloat(id);
                }
            }

            return 0f;
        }

        public void SetColor(int id, Color value)
        {
            for (int i = 0; i < _materials.Length; i++)
            {
                Material mat = _materials[i];

                if (mat != null && mat.HasColor(id))
                {
                    mat.SetColor(id, value);
                }
            }
        }

        public void DOFade(int id, float from, float to, float duration, AnimationCurve curve, List<Tweener> tweeners, float delay = 0f, TweenCallback callback = null)
        {
            foreach (Tweener tweener in tweeners)
            {
                tweener.Kill();
            }
            tweeners.Clear();
            
            for (int i = 0; i < _materials.Length; i++)
            {
                Material mat = _materials[i];

                if (mat.HasFloat(id))
                {
                    Tweener tweener = DOTween.To(() => from, x => mat.SetFloat(id, x), to, duration).SetAutoKill(true);
                    if (curve != null)
                    {
                        tweener.SetEase(curve);
                    }
                    if (delay > 0f)
                    {
                        tweener.SetDelay(delay);
                    }
                    tweener.Play();
                
                    tweeners.Add(tweener);   
                }
            }

            if (callback != null)
            {
                tweeners[0].OnComplete(callback);
            }
        }
    }
}