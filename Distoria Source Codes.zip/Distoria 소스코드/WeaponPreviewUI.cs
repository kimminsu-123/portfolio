using ProjectAAA.Utils;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace ProjectAAA.UI.MainFight
{
    public class WeaponPreviewUI : MonoBehaviour
    {
        [SerializeField] private TMP_Text clipText;
        [SerializeField] private TMP_Text ammoText;

        [SerializeField] private Image weaponImage;
        [SerializeField] private TMP_Text weaponIdxText;

        private void Awake()
        {
            clipText.text = "0";
            ammoText.text = "0";
            weaponImage.sprite = null;
            weaponIdxText.text = "0";
        }

        /// <summary>
        /// Clip 을 업데이트 하는 함수입니다.
        /// </summary>
        /// <param name="clip">현재 탄창에 있는 탄 수를 나타냅니다.</param>
        public void UpdateClip(int clip)
        {
            clipText.text = $"{clip}";
            
            LayoutRebuilder.ForceRebuildLayoutImmediate(clipText.rectTransform);
        }
        
        /// <summary>
        /// Ammo 를 업데이트 하는 함수입니다.
        /// </summary>
        /// <param name="ammo">현재 탄창에 있는 탄 수 + 재장전 가능한 Ammo 를 나타냅니다. (-1 를 넘길 경우 무한으로 표현합니다.)</param>
        public void UpdateAmmo(int ammo)
        {
            ammoText.text = $"{(ammo == Global.InfinityAmmo ? Global.Message.InfinityChar : ammo)}";
            
            LayoutRebuilder.ForceRebuildLayoutImmediate(ammoText.rectTransform);
        }
        
        /// <summary>
        /// 현재 무기 Icon 을 변경하는 함수입니다.
        /// </summary>
        /// <param name="image">현재 무기의 Sprite 이미지</param>
        public void UpdatePreviewImage(Sprite image)
        {
            weaponImage.sprite = image;
        }
        
        /// <summary>
        /// 현재 무기 인벤토리에 인덱스를 변경하는 함수입니다.
        /// </summary>
        /// <param name="index">현재 무기의 인벤토리 인덱스 + 1 (1 부터 시작합니다.)</param>
        public void UpdatePreviewIndex(int index)
        {
            weaponIdxText.text = $"{index}";
        }
    }
}