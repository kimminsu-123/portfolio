using System;
using System.Collections.Generic;
using System.Linq;
using ProjectAAA.Utils;
using UnityEngine;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.Core.FSM
{
    public class StateMachine : MonoBehaviour
    {
        private StateNode CurrentState { get; set; }
        private Dictionary<Type, StateNode> _nodes = new();
        private HashSet<ITransition> _anyTransitions = new();

        private void Update()
        {
            ITransition transition = GetTransition();
            if (transition != null)
            {
                ChangeState(transition.To);
            }
            
            CurrentState?.State?.UpdateState();
        }

        private void FixedUpdate()
        {
            ITransition transition = GetTransition();
            if (transition != null)
            {
                ChangeState(transition.To);
            }

            CurrentState?.State?.FixedUpdateState();
        }

        public void SetState(IState state)
        {
            CurrentState = _nodes[state.GetType()];
            CurrentState.State?.EnterState();
        }

        public IState GetState() => CurrentState.State;

        public void ChangeState(IState newState)
        {
            if (newState == CurrentState?.State) return;

            IState previousState = CurrentState?.State;
            IState nextState = _nodes[newState.GetType()].State;

            CurrentState = _nodes[newState.GetType()];

            previousState?.ExitState();
            nextState?.EnterState();
        }

        private ITransition GetTransition()
        {
            foreach (ITransition transition in _anyTransitions)
            {
                if (transition.Condition.Evaluate())
                {
                    return transition;
                }
            }

            return CurrentState?.Transitions.FirstOrDefault(transition => transition.Condition.Evaluate());
        }

        public void AddTransition(IState from, IState to, IPredicate condition) =>
            GetOrAddNode(from).AddTransition(GetOrAddNode(to).State, condition);

        public void AddAnyTransition(IState to, IPredicate condition) =>
            _anyTransitions.Add(new Transition(GetOrAddNode(to).State, condition));

        public void RemoveTransition(IState from, IState to)
        {
            if (!_nodes.ContainsKey(from.GetType())) return;

            _nodes[from.GetType()].RemoveTransition(to);
        }

        public void RemoveAnyTransition(IState to) => _anyTransitions.RemoveWhere(x => x.To.Equals(to));

        public void RemoveAllTransitions()
        {
            _nodes = null;
            _nodes = new Dictionary<Type, StateNode>();
        }

        public void RemoveAllAnyTransitions()
        {
            _anyTransitions = null;
            _anyTransitions = new HashSet<ITransition>();
        }

        private StateNode GetOrAddNode(IState state)
        {
            StateNode node = _nodes.GetValueOrDefault(state.GetType());

            if (node == null)
            {
                node = new StateNode(state);
                _nodes.Add(state.GetType(), node);
            }

            return node;
        }
    }
}