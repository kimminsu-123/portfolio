using System;
using UnityEngine;
using UnityEngine.UI;

namespace ProjectAAA.UI.Statue
{
    public abstract class StatueConditionUI : UiBase 
    {
        public RectTransform RectTr => transform as RectTransform;
        protected Image BlockImage => blockImage;
            
        [SerializeField] private Image blockImage;

        private void Start()
        {
            Hide();
        }

        public override void Show()
        {
            gameObject.SetActive(true);
        }
        
        public override void Hide()
        {
            gameObject.SetActive(false);
        }
    }
}