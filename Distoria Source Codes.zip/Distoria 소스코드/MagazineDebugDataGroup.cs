using System.Collections.Generic;
using Newtonsoft.Json;
using ProjectAAA.Utils.DataTable;
using UnityEngine;

namespace ProjectAAA.SO.Debug
{
    [CreateAssetMenu(fileName = "MagazineDebugDataGroup", menuName = "Scriptable Objects/DataTable/Debug/Magazine")]
    public class MagazineDebugDataGroup : DebugDataGroup
    {
        [SerializeField] private List<MagazineData> magazines;

        protected override void FromJson(string json)
        {
            magazines.Clear();
            magazines = JsonConvert.DeserializeObject<List<MagazineData>>(json);
        }

        public override string ToJson()
        {
            return JsonConvert.SerializeObject(magazines);
        }
    }
}