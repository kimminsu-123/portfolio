using System;
using ProjectAAA.Core.Managers;
using ProjectAAA.Core.Scene.Manager;
using ProjectAAA.Player.Actions;
using ProjectAAA.SO;
using ProjectAAA.Utils;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.UI.Statue
{
    public class StatueUI : UiBase
    {
        [SerializeField] private FMODEventInfoSO hideSound;
        private bool EscKeyDown
        {
            get
            {
#if UNITY_EDITOR
                return Input.GetKeyDown(KeyCode.BackQuote) || PlayerManager.Instance.PlayerEntity.IsDead;
#else
                return PlayerActionController.PlayerInput.GamePlay.ESC.WasPressedThisFrame() || PlayerManager.Instance.PlayerEntity.IsDead;
#endif
            }
        }
        
        protected override Type RegisterType => typeof(StatueUI);

        [Header("텍스트 참조")]
        [SerializeField] private TMP_Text titleText;
        [SerializeField] private TMP_Text descriptionText;
        [SerializeField] private TMP_Text effectDescriptionText;

        [Header("긍정 선택지 참조")]
        [SerializeField] private Button acceptButton;
        [SerializeField] private TMP_Text acceptButtonText;
        
        [Header("부정 선택지 참조")]
        [SerializeField] private Button denyButton;
        [SerializeField] private TMP_Text denyButtonText;

        private IPredicate _acceptCondition;
        private IPredicate _denyCondition;
        private StatueConditionUI _cachedConditionUI;

        private void Start()
        {
            AddOnAccept(Hide);
            AddOnDeny(Hide);
            
            Hide();
        }

        private void Update()
        {
            if (EscKeyDown)
            {
                denyButton.onClick?.Invoke();
                SoundManager.Instance.PlaySFX(hideSound, gameObject.transform.position);
            }
            else
            {
                ControlConditionUI();
            }
        }

        private void ControlConditionUI()
        {
            GameObject curSelected = UiManager.Instance.SelectionProperty.Value;

            if (curSelected == null)
            {
                return;
            }
            
            if (_cachedConditionUI == null)
            {
                return;
            }
            
            if (!curSelected.GetHashCode().Equals(acceptButton.gameObject.GetHashCode()))
            {
                _cachedConditionUI.Hide();
                return;
            }
            
            _cachedConditionUI.RectTr.anchoredPosition = Vector2.zero;
            _cachedConditionUI.RectTr.sizeDelta = Vector2.zero;
            _cachedConditionUI.Show();
        }

        public StatueUI SetTitle(string title)
        {
            titleText.text = title;

            return this;
        }
        
        public StatueUI SetDescription(string desc)
        {
            descriptionText.text = desc;

            return this;
        }
        
        public StatueUI SetEffectDescription(string desc)
        {
            effectDescriptionText.text = desc;

            return this;
        }
        
        public StatueUI SetAcceptText(string txt)
        {
            acceptButtonText.text = txt;

            return this;
        }
        
        public StatueUI SetDenyText(string txt)
        {
            denyButtonText.text = txt;

            return this;
        }
        
        public StatueUI AddOnAccept(UnityAction action)
        {
            acceptButton.onClick.AddListener(action);

            return this;
        }

        public StatueUI RemoveOnAccept(UnityAction action)
        {
            acceptButton.onClick.RemoveListener(action);

            return this;
        }
        
        public StatueUI AddOnDeny(UnityAction action)
        {
            denyButton.onClick.AddListener(action);

            return this;
        }

        public StatueUI RemoveOnDeny(UnityAction action)
        {
            denyButton.onClick.RemoveListener(action);

            return this;
        }

        public StatueUI SetAcceptCondition(IPredicate condition)
        {
            _acceptCondition = condition;

            return this;
        }

        public StatueUI SetDenyCondition(IPredicate condition)
        {
            _denyCondition = condition;

            return this;
        }

        public StatueUI SetConditionUI(StatueConditionUI ui)
        {
            _cachedConditionUI = ui;

            return this;
        }
        
        public override void Show()
        {
            CursorHandler.UnLock();
            PlayerManager.Instance.ActionController.BlockAllActions();
            
            acceptButton.interactable = _acceptCondition == null || _acceptCondition.Evaluate();
            denyButton.interactable = _denyCondition == null || _denyCondition.Evaluate();

            if (_cachedConditionUI != null)
            {
                _cachedConditionUI.RectTr.anchoredPosition = Vector2.zero;
                _cachedConditionUI.RectTr.sizeDelta = Vector2.zero;
                _cachedConditionUI.Show();
            }
            acceptButton.Select();
            
            gameObject.SetActive(true);
        }

        public override void Hide()
        {
            gameObject.SetActive(false);
            
            if (_cachedConditionUI != null)
            {
                _cachedConditionUI.Hide();
            }
            
            CursorHandler.Lock();
            PlayerManager.Instance.ActionController.UnBlockAllActions();
        }
    }
}