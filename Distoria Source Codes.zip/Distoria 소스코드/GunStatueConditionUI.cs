using System;
using ProjectAAA.Core.Managers;
using ProjectAAA.Utils.DataTable;
using UnityEngine;
using UnityEngine.UI;

namespace ProjectAAA.UI.Statue
{
    public struct GunConditionData
    {
        public int CurrentWeapoinId { get; }
        public int DefaultWeaponId { get; }
        
        public GunConditionData(int weaponId, int defaultId)
        {
            CurrentWeapoinId = weaponId;
            DefaultWeaponId = defaultId;
        }
    }
    
    public class GunStatueConditionUI : StatueConditionUI
    {
        protected override Type RegisterType => typeof(GunStatueConditionUI);

        [SerializeField] private Image weaponIconImage;

        public void Setup(GunConditionData data)
        {
            BlockImage.gameObject.SetActive(data.CurrentWeapoinId == data.DefaultWeaponId);
            
            weaponIconImage.sprite = DatabaseManager.Instance.IconResources.GetIcon(RewardType.Weapon, data.CurrentWeapoinId);
        }
    }
}