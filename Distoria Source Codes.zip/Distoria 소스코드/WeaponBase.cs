using Newtonsoft.Json;
using ProjectAAA.Core;
using ProjectAAA.Core.Managers;
using ProjectAAA.Core.Pool;
using ProjectAAA.Core.Scene.Manager;
using ProjectAAA.Interaction;
using ProjectAAA.SO;
using ProjectAAA.SO.Pool;
using ProjectAAA.SO.Recoil;
using ProjectAAA.UI;
using ProjectAAA.Utils;
using ProjectAAA.Utils.DataTable;
using UnityEngine;
using UnityEngine.Events;
using Random = UnityEngine.Random;

namespace ProjectAAA.WeaponSystem
{
    [RequireComponent(typeof(Rigidbody))]
    public abstract class WeaponBase : PoolObjMonoBehaviour, IInteractable, Iitem, IItemDropper, IItemFloatingModel
    {
        protected enum Status
        {
            Dropped,
            Picked,
            Using
        }    
        
        private const string SHOOT_POS_NAME = "ShootPos";
        private const string LEFT_HAND_TARGET_NAME = "LeftHandTarget";
        private const string RIGHT_HAND_TARGET_NAME = "RightHandTarget";
        private const string LINKED_LIGHT_GO_NAME = "[Linked Light]";
        
        [Header("공통 세팅 값")]
        [SerializeField] protected int weaponId;
        [SerializeField] protected GameObject model;
        [SerializeField] protected AnimatorOverrideController weaponAnimatorController;
        [SerializeField] protected AnimatorOverrideController playerOverrideController;
        [SerializeField] protected RecoilData recoilData;
        [SerializeField] protected float nearDistance = 1.5f;
        [SerializeField] protected float interactDuration = 1f;
        
        [Header("이펙트")]
        [SerializeField] protected ObjectPoolSO muzzleFlashEffectPool;

        [Header("사운드")]
        [SerializeField] protected FMODEventInfoSO fireSound;
        [SerializeField] protected FMODEventInfoSO pickUpSound;
        [SerializeField] protected FMODEventInfoSO reloadSound;
        
        [Header("콜백")]
        public UnityEvent onBeginFireCallback;
        public UnityEvent onFireCallback;
        public UnityEvent onFireFailedWhenAmmoZeroCallback;
        public UnityEvent onEndFireCallback;
        public UnityEvent onBeginReloadCallback;
        public UnityEvent onEndReloadCallback;
        
        public float InteractDuration => interactDuration;
        public Camera MainCamera => PlayerManager.Instance.MainCamera;
        public int WeaponId => weaponId;
        public Transform LeftHandTarget { get; private set; }
        public Transform RightHandTarget { get; private set; }
        public Collider PickupCollider { get; private set; }
        public Animator ModelAnimator { get; private set; }
        public Transform ShootPos { get; private set; }
        public AnimatorOverrideController PlayerOverrideController => playerOverrideController;
        public RecoilData RecoilData => recoilData;
        public Sprite Icon => WeaponImage;
        public Transform ParentTr => _floatingPosition;

        public abstract MagazineBase CurrentMagazine { get; }
        public abstract string Name { get; }
        public abstract string Type { get; }
        public abstract string Desc { get; }
        public abstract string Effect { get; }
        public abstract float FireInterval { get; }
        public abstract float SwapTime { get; }
        public abstract int AmmoAmount { get; }
        public abstract int CurrentAmmo { get; }
        public abstract float ReloadTime { get; }
        public abstract int CurrentMagazineAmmoCount { get;}
        public abstract int CurrentMagazineSize { get; }
        public abstract string Description { get; }
        public abstract string Summary { get; }
        public abstract Sprite WeaponImage { get; }

        protected Status CurrentStatus
        {
            get => _currentStatus;
            private set
            {
                _currentStatus = value;

                switch (_currentStatus)
                {
                    case Status.Dropped:
                        HandleDropped();
                        break;
                    case Status.Picked:
                        HandlePicked();
                        break;
                    case Status.Using:
                        HandleUsing();
                        break;
                }
            }
        }

        private Transform _floatingPosition;
        private Rigidbody _cachedRg;
        private ParticlePoolObj _fireParticleObj;
        private GameObject _linkedLightRoot;
        private Status _currentStatus = Status.Dropped;

        private void Awake()
        {
            ModelAnimator = model.GetOrAddComponent<Animator>();
            ModelAnimator.runtimeAnimatorController = weaponAnimatorController;
            ModelAnimator.keepAnimatorStateOnDisable = true;
            
            PickupCollider = GetComponent<Collider>();
            _cachedRg = GetComponent<Rigidbody>();

            onFireCallback?.AddListener(OnFire);

            Initialize();
        }

        protected virtual void OnAwake(){}

        public void Initialize()
        {
            ShootPos = transform.FindInChildren(SHOOT_POS_NAME);
            LeftHandTarget = transform.FindInChildren(LEFT_HAND_TARGET_NAME);
            RightHandTarget = transform.FindInChildren(RIGHT_HAND_TARGET_NAME);
            Transform lights = transform.FindInChildren(LINKED_LIGHT_GO_NAME);
            if (lights != null)
            {
                _linkedLightRoot = lights.gameObject;
            }
            _floatingPosition = transform.FindInChildrenContains("Floating");
            
            CurrentStatus = Status.Dropped;
            
            OnInitialize();
        }

        private void OnFire()
        {
            if (_fireParticleObj == null)
            {
                _fireParticleObj = muzzleFlashEffectPool.Get<ParticlePoolObj>(ShootPos);
                _fireParticleObj.gameObject.ChangeLayerAll(Global.WeaponLayerIndex);
                _fireParticleObj.SetOriginPool(muzzleFlashEffectPool);
            }
            
            _fireParticleObj.Play(true, false);

            if (fireSound != null)
            {
                SoundManager.Instance.PlaySFX(fireSound,gameObject.transform.position);
            }
        }

        protected abstract void OnInitialize();
        public abstract void ForceStopReload();
        public abstract void Reload();
        public abstract void Trigger();
        public abstract void FillAmmo(float percent);
        public abstract void Release();
        public override void OnRelease()
        {
            base.OnRelease();
            
            ModelAnimator.gameObject.ChangeLayerAll(Global.DefaultLayerIndex);
        }

        public virtual void Interact(GameObject target)
        {
            CurrentStatus = Status.Picked;

            PlayerManager.Instance.WeaponHandler.AddWeaponToInventory(this);
            Use(target);
        }

        public virtual void OnDropOff()
        {
            transform.localRotation = Quaternion.identity;
            
            CurrentStatus = Status.Dropped;
        }

        public virtual void Use(GameObject target) 
        {
            CurrentStatus = Status.Using;
            PlayerManager.Instance.WeaponHandler.ChangeWeapon(this);
        }
        
        public void OnReset()
        {
            Release();
            Initialize();
            SelfReturn();
        }

        public bool EvaluateNearTarget(HitInfo hitInfo) => Vector3.Distance(MainCamera.transform.position, hitInfo.Point) <= nearDistance;

        public void DropStart(bool useRigidbody)
        {
            PickupCollider.enabled = false;
            _cachedRg.isKinematic = true;
        }

        public void ActiveItem()
        {
            ModelAnimator.gameObject.ChangeLayerAll(Global.OutlineLayerIndex);
            
            PickupCollider.enabled = true;
        }

        public string Save()
        {
            SaveDataElement item = new SaveDataElement
            {
                SaveDataType = SaveElementType.Weapon,
                id = weaponId,
                Ammo = CurrentMagazineAmmoCount,
                RemainAmmo = CurrentAmmo
            };

            return JsonConvert.SerializeObject(item);
        }

        public void Load(string json)
        {
            PlayerManager.Instance.WeaponHandler.Release();
            
            SaveDataElement item = JsonConvert.DeserializeObject<SaveDataElement>(json);
            Interact(PlayerManager.Instance.PlayerGo);
            SetAmmo(item.Ammo, item.RemainAmmo);
        }
        
        public abstract void SetAmmo(int ammo,int remainAmmo);

        private void HandleDropped()
        {
            if (gameObject.activeSelf)
            {
                ModelAnimator.Update(0f);
                ModelAnimator.Rebind();
            }
            ModelAnimator.enabled = false;
                        
            PickupCollider.isTrigger = true;
            PickupCollider.enabled = true;
            _cachedRg.isKinematic = false;

            ModelAnimator.gameObject.ChangeLayerAll(Global.OutlineLayerIndex);

            if (_fireParticleObj != null)
            {
                _fireParticleObj.gameObject.ChangeLayerAll(Global.DefaultLayerIndex);
                _fireParticleObj.SelfReturn();
                _fireParticleObj = null;
            }
            _linkedLightRoot?.SetActive(false);
        }

        private void HandlePicked()
        {
            _linkedLightRoot?.SetActive(false);
        }

        private void HandleUsing()
        {
            if (_fireParticleObj != null)
            {
                _fireParticleObj.Stop(false);
            }
                
            ModelAnimator.gameObject.ChangeLayerAll(Global.WeaponLayerIndex);

            if (pickUpSound != null)
            {
                PlayerManager.Instance.WeaponHandler.PlayHandlingSound(pickUpSound);
            }

            ModelAnimator.enabled = true;
            PickupCollider.enabled = false;
            
            _cachedRg.isKinematic = true;
            _cachedRg.constraints = RigidbodyConstraints.None;
            _linkedLightRoot?.SetActive(true);
        }
    }
}