using System;
using UnityEngine;
using Logger = ProjectAAA.Utils.Logger;
using Random = UnityEngine.Random;

namespace ProjectAAA.SO
{
    [CreateAssetMenu(fileName = "LineSpreadDataSO", menuName = "Scriptable Objects/Spread/LineSpreadDataSO", order = 0)]
    public class LineSpreadDataSO : BaseSpreadDataSO
    {
        public enum LineType
        {
            Horizontal,
            Vertical,
        }
        
        [SerializeField, Tooltip("Spread 가 적용될 방향을 의미")]
        private LineType lineType = LineType.Horizontal;
        [SerializeField, Tooltip("Spread 가 적용될 라인의 길이를 의미")] 
        private float lineLength;
        [SerializeField, Tooltip("UI 노출용으로만 사용되며 선택되지 않은 LineType 의 길이를 의미")] 
        private float otherLineLength = 0.01f;

        public LineType LineTp => lineType;
        public override Vector2 HalfScale
        {
            get
            {
                Vector2 result = Vector2.one * otherLineLength;
                switch (lineType)
                {
                    case LineType.Horizontal:
                        result.x = lineLength + CurrentYValue;
                        break;
                    case LineType.Vertical:
                        result.y = lineLength + CurrentYValue;
                        break;
                }
                return result;
            }
        }

        public override SpreadType Type => SpreadType.Line;

        protected override Vector3 CalcOffset()
        {
            Vector2 offset = Vector2.zero;
            Vector2 halfLineSize = HalfScale;

            switch (lineType)
            {
                case LineType.Horizontal:
                    offset.x = Random.Range(-halfLineSize.x, halfLineSize.x);
                    break;
                case LineType.Vertical:
                    offset.y = Random.Range(-halfLineSize.y, halfLineSize.y);
                    break;
            }
            return offset;
        }
    }
}