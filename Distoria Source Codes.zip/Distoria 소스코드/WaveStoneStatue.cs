using ProjectAAA.Mob;
using ProjectAAA.UI.Statue;
using ProjectAAA.Utils;

namespace ProjectAAA.Interactables.Statue
{
    public class WaveStoneStatue : StoneStatue
    {
        protected override StatueConditionUI ConditionUI => null;
        protected override IPredicate AcceptCondition => null;
        protected override IPredicate DenyCondition => null;
        
        private MonsterStage _monsterStage;

        protected override void Awake()
        {
            base.Awake();
            
            _monsterStage = GetComponentInChildren<MonsterStage>(true);
            
            Logger.Assert(_monsterStage != null, "WaveStoneStatue", "석상 하위에 MonsterStage 가 할당되어있지 않습니다.");
        }
        
        protected override void OnAccept()
        {
            _monsterStage.BeginStage();
            
            InteractionCollider.enabled = false;
        }

        protected override void OnDeny()
        {
        }
    }
}