using System.Collections.Generic;
using ProjectAAA.SO.Pool;
using ProjectAAA.Utils;
using ProjectAAA.WeaponSystem;
using UnityEngine;

namespace ProjectAAA.Core.Managers
{
    public class WeaponManager : SingletonMonoBehavior<WeaponManager>
    {
        private BulletGenerator _bulletGenerator;
        private MagazineGenerator _magazineGenerator;
        private WeaponGenerator _weaponGenerator;

        public BulletGenerator BulletGenerator => _bulletGenerator;
        public MagazineGenerator MagazineGenerator => _magazineGenerator;
        public WeaponGenerator WeaponGenerator => _weaponGenerator;

        protected override void Initialize()
        {
            _bulletGenerator = FindFirstObjectByType<BulletGenerator>();
            _magazineGenerator = FindFirstObjectByType<MagazineGenerator>();
            _weaponGenerator = FindFirstObjectByType<WeaponGenerator>();

            _bulletGenerator.GenerateAll();
            _weaponGenerator.GenerateAll();
        }

        public void ResizeMagazine(int amount)
        {
            ObjectPoolSO[] weapons = _weaponGenerator.GetValues();
            for (int i = 0; i < weapons.Length; i++)
            {
                List<WeaponBase> list = weapons[i].ToList<WeaponBase>();
                foreach (WeaponBase weapon in list)
                {
                    weapon.CurrentMagazine.Fill(weapon.CurrentMagazine.Count + amount);
                }
            }
        }
    }
}