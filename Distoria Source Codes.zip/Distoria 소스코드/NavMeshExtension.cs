using UnityEngine;
using UnityEngine.AI;

public static class NavMeshExtension
{
    public static bool IsAgentStopped(this NavMeshAgent agent)
    {
        return !agent.pathPending
               && agent.remainingDistance <= agent.stoppingDistance
               && (!agent.hasPath || agent.velocity.sqrMagnitude == 0f);
    }
}
