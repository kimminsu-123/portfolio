using ProjectAAA.Core.Entity;
using ProjectAAA.Core.Managers;
using ProjectAAA.Core.Scene.Manager;
using ProjectAAA.UI.Statue;
using ProjectAAA.Utils;
using Unity.AppUI.Core;
using UnityEngine;

namespace ProjectAAA.Interactables.Statue
{
    public class HealStoneStatue : StoneStatue
    {
        protected override StatueConditionUI ConditionUI => UiManager.Instance.Get<HealStatueConditionUI>();
        protected override IPredicate AcceptCondition => _acceptCondition;
        protected override IPredicate DenyCondition => null;

        [SerializeField] private int goldAmount = 200;
        [SerializeField] private float healPercent = 50f;
        
        private IPredicate _acceptCondition;

        private void Start()
        {
            _acceptCondition = new FuncPredicate(CheckGold);
        }

        private bool CheckGold() => PlayerCurrencyManager.Instance.Gold.Value >= goldAmount;
        
        protected override void OnInteract()
        {
            HealStatueConditionUI heal = ConditionUI as HealStatueConditionUI;

            heal?.Setup(new HealConditionData(PlayerCurrencyManager.Instance.Gold.Value, goldAmount));
        }
        
        protected override void OnAccept()
        {
            LivingEntity entity = PlayerManager.Instance.PlayerEntity;
            float healAmount = entity.MaxHealth * (healPercent * 0.01f);
            entity.Heal(healAmount);
            
            PlayerCurrencyManager.Instance.UseGold(goldAmount);
        }

        protected override void OnDeny()
        {
        }
    }
}