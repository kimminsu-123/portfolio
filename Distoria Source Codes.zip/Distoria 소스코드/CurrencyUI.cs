using System;
using TMPro;
using UniRx;
using UnityEngine;
using UnityEngine.UI;

namespace ProjectAAA.UI.MainFight
{
    public class CurrencyUI : MonoBehaviour
    {
        [SerializeField] private TMP_Text keyText;
        [SerializeField] private TMP_Text goldText;

        private void Awake()
        {
            keyText.text = "0";
            goldText.text = "0";
        }

        public void OnChangeKey(int key)
        {
            keyText.text = $"{key}";
            
            LayoutRebuilder.ForceRebuildLayoutImmediate(keyText.rectTransform);
        }
        
        public void OnChangeGold(int gold)
        {
            goldText.text = $"{gold}";
            
            LayoutRebuilder.ForceRebuildLayoutImmediate(goldText.rectTransform);
        }
    }
}