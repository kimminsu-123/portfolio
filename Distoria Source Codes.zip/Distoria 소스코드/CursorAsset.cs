using NaughtyAttributes;
using UnityEngine;
using UnityEngine.Playables;

namespace ProjectAAA.Timeline
{
    public class CursorAsset : PlayableAsset
    {
        public bool unlockOnExit;
        public bool settingCursor;
        [ShowIf("settingCursor")] public Texture2D texture;
        [ShowIf("settingCursor")] public Vector2 hotspot;
        [ShowIf("settingCursor")] public CursorMode cursorMode;
        public CursorLockMode lockMode;
        
        public override Playable CreatePlayable(PlayableGraph graph, GameObject owner)
        {
            var playable = ScriptPlayable<CursorBehaviour>.Create(graph);
            var behaviour = playable.GetBehaviour();

            behaviour.UnlockOnExit = unlockOnExit;
            behaviour.SettingCursor = settingCursor;
            behaviour.Texture = texture;
            behaviour.Hotspot = hotspot;
            behaviour.CursorMode = cursorMode;
            behaviour.LockMode = lockMode;
            
            return playable;
        }
    }
}