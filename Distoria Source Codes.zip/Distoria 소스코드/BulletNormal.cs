using ProjectAAA.Core;
using ProjectAAA.Core.Entity;
using ProjectAAA.Core.Managers;
using ProjectAAA.Player;
using ProjectAAA.SO;
using ProjectAAA.SO.Pool;
using ProjectAAA.Status;
using ProjectAAA.Utils;
using ProjectAAA.Utils.DataTable;
using ProjectAAA.WeaponSystem.BulletAbility;
using UnityEngine;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.WeaponSystem
{
    [RequireComponent(typeof(BulletAbilitySettings))]
    public class BulletNormal : BulletBase
    {
        public override int AbilityID => CurrentBulletNormalData.AbilityID;
        public override float GravityFactor => CurrentBulletNormalData.GravityFactor;

        [Header("사운드")] 
        [SerializeField] private FMODEventInfoSO hitSound;
        
        public Vector3 CamForward { get; private set; }
        public BulletNormalData CurrentBulletNormalData => DatabaseManager.Instance.GetTable<BulletNormalTableSO>().Get(bulletId);

        private BulletHitHandler _hitHandler;
        private Vector2 _damage;

        protected override void OnAwake()
        {
            SetupCollisionType();
        }

        protected override void OnFixedUpdate()
        {
            if (_hitHandler != null)
            {
                _hitHandler.Update(Time.fixedDeltaTime);
            }
        }

        public override void SetupData()
        {
            BulletSize = CurrentBulletNormalData.BulletSize * WeaponAlterStat.Instance.BulletSize;
            BulletLifeTime = CurrentBulletNormalData.BulletLifeTime * WeaponAlterStat.Instance.BulletLifeTime;
            BulletSpeed = CurrentBulletNormalData.BulletSpeed * WeaponAlterStat.Instance.BulletSpeed;
        }

        private void SetupCollisionType()
        {
            switch (CurrentBulletNormalData.BulletType)
            {
                case BulletType.HitScan:
                    _hitHandler = new BulletHitHandler.Builder<BulletHitScanHandler>()
                        .SetBulletBase(this)
                        .SetLayerMask(targetLayerMask)
                        .Build();
                    break;
                case BulletType.SplitCast:
                    _hitHandler = new BulletHitHandler.Builder<BulletHitSplitCastHandler>()
                        .SetBulletBase(this)
                        .SetLayerMask(targetLayerMask)
                        .Build();
                    break;
            }

            _hitHandler.OnHitCallback += OnHit;
            _hitHandler.OnHitOtherCallback += OnHitOther;
            _hitHandler.OnCompletedCallback += _ => SelfReturn();
        }

        private void OnHit(HitInfo info)
        {
            if (CamForward.magnitude > float.Epsilon)
            {
                transform.forward = CamForward;
            }
            transform.position = info.Point;
            
            if (onHitEffectPool != null)
            {
                ParticlePoolObj particle = onHitEffectPool.Get<ParticlePoolObj>(null);
                particle.SetOriginPool(onHitEffectPool);
                particle.SetPosition(info.Point + (info.Normal * 0.1f));
                particle.SetRotation(Quaternion.LookRotation(info.Normal));
                particle.SetScale(Vector3.one);
                if (info.Target != null)
                {
                    particle.SetParent(info.Target.transform);
                }
                particle.Play();

                if (hitSound != null)
                {
                    SoundManager.Instance.PlaySFX(hitSound, info.Point);
                }
            }
        }
        
        private void OnHitOther(HitInfo info)
        {
            if (info.Target.TryGetComponent(out HurtBox hurtBox))
            {
                info.Hitter = gameObject;
                info.Damage = Random.Range(_damage.x, _damage.y);
                if (hurtBox.isCriticalZone)
                {
                    info.Damage *= CriticalMagnification;
                }
                hurtBox.TakeDamage(info);
                
                if (hurtBox.rootTr.TryGetComponent(out StatusMachine statusMachine))
                {
                    statusMachine.ActiveStatus(CurrentBulletNormalData.StatusType, CurrentBulletNormalData.StatusCount);
                }
            }
        }

        private Vector2 CalcDamage()
        {
            float minDmg = CurrentBulletNormalData.BulletMinDamage * WeaponAlterStat.Instance.BulletDamage;
            float maxDmg = CurrentBulletNormalData.BulletMaxDamage * WeaponAlterStat.Instance.BulletDamage;
            
            return new Vector2(minDmg, maxDmg);
        }

        public override void ForceHit(HitInfo info)
        {
            PlayTracerEffect();

            _damage = CalcDamage();
            
            _hitHandler?.Init();
            _hitHandler?.ProcessHit(info);
        }

        public override void Process(Vector3 point, Vector3 camForward)
        {
            CamForward = camForward;

            _damage = CalcDamage();
            
            Vector3 curPos = transform.position;
            Vector3 direction = (point - curPos).normalized;

            transform.forward = direction;
            transform.localScale = Vector3.one * BulletSize;

            PlayTracerEffect();
            
            _hitHandler?.Init();
            _hitHandler?.Shoot(curPos);
            
            PlayTracerLineEffect(curPos, point);
        }

        private void OnDestroy()
        {
            _hitHandler?.Dispose();
        }   
    }
}