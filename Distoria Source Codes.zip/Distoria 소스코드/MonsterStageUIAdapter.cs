using System;
using System.Linq;
using ProjectAAA.Core.Managers;
using ProjectAAA.UI;
using ProjectAAA.Utils;
using UniRx;
using UnityEngine;

namespace ProjectAAA.Mob
{
    [RequireComponent(typeof(MonsterStage))]
    public class MonsterStageUIAdapter : MonoBehaviour
    {
        private StageUI StageUI => UiManager.Instance.Get<StageUI>();
        private MonsterStage _cachedStage;
        private IDisposable _cachedSubscription;
        private int _curWaveIndex = 0;

        private void Awake()
        {
            _cachedStage = GetComponent<MonsterStage>();
        }

        private void OnEnable()
        {
            if (_cachedStage.Mode == StageMode.Burst)
            {
                _cachedStage.onBeginStage.AddListener(OnBeginStage);
                _cachedStage.onEndStage.AddListener(OnEndStage);
            }
            else
            {
                foreach (MonsterArea area in _cachedStage.AreaList)
                {
                    area.onBeginArea.AddListener(OnBeginArea);
                    area.onEndArea.AddListener(OnEndArea);
                }

                StageUI.SetProcess(0, 0);
                StageUI.SetCurrentWaveIndex(0, _cachedStage.AreaList.Count);
            }
            
            foreach (MonsterArea area in _cachedStage.AreaList)
            {
                _cachedSubscription = area.KillCount.Subscribe(OnKillMonster);
            }
        }

        private void OnDisable()
        {
            if (_cachedStage != null)
            {
                if (_cachedStage.Mode == StageMode.Burst)
                {
                    _cachedStage.onBeginStage.RemoveListener(OnBeginStage);
                    _cachedStage.onEndStage.RemoveListener(OnEndStage);
                }
                else
                {
                    foreach (MonsterArea area in _cachedStage.AreaList)
                    {
                        area.onBeginArea.RemoveListener(OnBeginArea);
                        area.onEndArea.RemoveListener(OnEndArea);
                    }
                }   
            }

            _cachedSubscription?.Dispose();
            
            StageUI?.Hide();
        }

        private void OnBeginStage()
        {
            int totalCount = _cachedStage.AreaList.Sum(x => x.Count);

            StageUI.SetProcess(0, totalCount);
            StageUI.SetCurrentWaveIndex(-1, -1);
            StageUI.Show();
        }

        private void OnEndStage()
        {
            StageUI.Hide();
        }

        private void OnBeginArea(int areaIndex)
        {
            _curWaveIndex = areaIndex;
            
            int maxWaveIndex = _cachedStage.AreaList.Count - 1;
            int maxValue = _cachedStage.AreaList[areaIndex].Count;

            StageUI.SetProcess(0, maxValue);

            if (_cachedStage.Mode == StageMode.Wave)
            {
                StageUI.SetCurrentWaveIndex(areaIndex, maxWaveIndex);
            }
            else
            {
                StageUI.SetCurrentWaveIndex(-1, -1);
            }

            // area 에 있는 몬스터의 수가 0이하일 경우 바로 클리어 이므로 UI 표현 안함
            if (maxValue > 0)
            {
                StageUI.Show();
            }
            else
            {
                StageUI.Hide();
            }
        }

        private void OnEndArea(int areaIndex)
        {
            //StageUI.SetProcess(0, 0);
        }

        private void OnKillMonster(int count)
        {
            if (_cachedStage.Mode == StageMode.Burst)
            {
                int curCount = _cachedStage.AreaList.Sum(x => x.KillCount.Value);
                int totalCount = _cachedStage.AreaList.Sum(x => x.Count);

                StageUI.SetProcess(curCount, totalCount);
            }
            else
            {
                int maxValue = _cachedStage.AreaList[_curWaveIndex].Count;

                StageUI.SetProcess(count, maxValue);
            }
        }
    }
}