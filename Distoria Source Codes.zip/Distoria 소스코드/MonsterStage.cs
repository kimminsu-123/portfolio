using System.Collections.Generic;
using System.Linq;
using ProjectAAA.Core.Managers;
using ProjectAAA.Utils;
using UnityEngine;
using UnityEngine.Events;
using EventType = ProjectAAA.Core.Managers.EventType;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.Mob
{
    public class MonsterStage : MonoBehaviour
    {
        private enum Status
        {
            Begin,
            End
        }

        public List<MonsterArea> AreaList => areaList;
        public bool IsClear => areaList.All(x => x.IsClear);
        public int CurrentWaveIndex { get; private set; }
        public StageMode Mode => stageMode;

        public UnityEvent onBeginStage;
        public UnityEvent onEndStage;
        
        [SerializeField] private StageMode stageMode;
        [SerializeField] private StartCondition startCondition;
        [SerializeField] private List<MonsterArea> areaList;
        [SerializeField] private bool isAutoWave = true;

        private Collider _collider;
        private Status _currentStatus = Status.End;
        
        private void Awake()
        {
            EventManager.Instance.AddListener(EventType.OnBeginLoadSceneGroup, OnBeginSceneGroup);
            if (startCondition == StartCondition.OnSceneLoaded)
            {
                EventManager.Instance.AddListener(EventType.OnEndDelayAfterLoadScene, OnSceneLoaded);
            }
        }

        private void Start()
        {
            Initialize();      
        }

        public void Initialize()
        {
            Logger.Log("MonsterStage", $"{name} Initialize", Color.magenta);

            for (int index = 0; index < areaList.Count; index++)
            {
                areaList[index].Initialize(index);
            }
        }

        public void BeginStage()
        {
            Logger.Log("MonsterStage", $"{name} Begin Stage", Color.magenta);

            switch (stageMode)
            {
                case StageMode.Burst:
                {
                    foreach (MonsterArea area in areaList)
                    {
                        area.Begin();
                    }

                    break;
                }
                case StageMode.Wave:
                {
                    if (0 <= CurrentWaveIndex && CurrentWaveIndex < areaList.Count)
                    {
                        areaList[CurrentWaveIndex].Begin();
                        
                        Logger.Log("MonsterStage", $"{name} Do Next Wave!! [Index : {CurrentWaveIndex}]", Color.magenta);   
                    }

                    break;
                }
                case StageMode.SubjectArea:
                    // do nothing
                    break;
            }
            
            _currentStatus = Status.Begin;
        }

        public void EndStage()
        {
            Logger.Log("MonsterStage", $"{name} End Stage", Color.magenta);
            foreach (MonsterArea area in areaList)
            {
                area.End();
            }
            _currentStatus = Status.End;
        }

        private void Update()
        {
            if (_currentStatus == Status.End) return;

            if (areaList[CurrentWaveIndex].IsClear && isAutoWave)
            {
                BeginNextWave();
            }
            
            if (IsClear)
            {
                Logger.Log("MonsterStage", $"{name} Clear", Color.magenta);
                
                EndStage();
            }
        }

        public void BeginNextWave()
        {
            if (stageMode != StageMode.Wave) 
            {
                return;
            }
            
            if (0 > CurrentWaveIndex || CurrentWaveIndex >= areaList.Count - 1) 
            {
                return;
            }

            areaList[CurrentWaveIndex].DisableRewards();
            areaList[++CurrentWaveIndex].Begin();
                        
            Logger.Log("MonsterStage", $"{name} Do Next Wave!! [Index : {CurrentWaveIndex}]", Color.magenta);
        }
        
        private void OnSceneLoaded(Component sender, object[] args)
        {
            BeginStage();
        }

        private void OnTriggerEnter(Collider other)
        {
            if (startCondition == StartCondition.OnTrigger && other.tag.Equals(Global.PlayerTag))
            {
                BeginStage();
            }
        }

        private void OnDestroy()
        {
            EventManager.Instance.RemoveListener(EventType.OnBeginLoadSceneGroup, OnBeginSceneGroup);
            if (startCondition == StartCondition.OnSceneLoaded)
            {
                EventManager.Instance.RemoveListener(EventType.OnEndDelayAfterLoadScene, OnSceneLoaded);
            }
        }
        
        private void OnBeginSceneGroup(Component sender, object[] args)
        {
            if (!IsClear)
            {
                EndStage();
            }
        }
    }
}