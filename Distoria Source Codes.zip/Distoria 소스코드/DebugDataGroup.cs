using UnityEngine;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.SO.Debug
{
    public abstract class DebugDataGroup : BaseSO
    {
        [SerializeField] private string tablePath = @"ex)DataTables/MonsterSkill";
        
        [ContextMenu("Setup Data From DataTable Json")]
        private void Setup()
        {
            TextAsset asset = Resources.Load<TextAsset>(tablePath);
            
            if (asset == null)
            {
                Logger.LogError("데이터 테이블을 찾을 수 없음", $"데이터 테이블을 찾을 수 없습니다. : {tablePath}");
            }
            FromJson(asset.text);
        }
        
        [ContextMenu("Export To Json")]
        private void ExportToJson()
        {
            string json = ToJson();
            
            UnityEngine.Debug.Log(json);
        }

        protected abstract void FromJson(string json);
        public abstract string ToJson();
    }
}