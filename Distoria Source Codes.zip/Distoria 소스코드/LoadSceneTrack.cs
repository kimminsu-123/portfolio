using UnityEngine.Timeline;

namespace ProjectAAA.Timeline
{
    [TrackClipType(typeof(LoadSceneAsset))]
    public class LoadSceneTrack : PlayableTrack
    {
        
    }
}