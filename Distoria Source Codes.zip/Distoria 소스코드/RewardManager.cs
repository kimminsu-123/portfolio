using System.Collections.Generic;
using Newtonsoft.Json;
using ProjectAAA.SO;
using ProjectAAA.Utils;
using ProjectAAA.Utils.DataTable;
using UnityEngine;

namespace ProjectAAA.Core.Managers
{
    public class RewardManager : SingletonMonoBehavior<RewardManager>, ISaveDataContainer
    {
        private RewardDataTableSO RewardDataTable => DatabaseManager.Instance.GetTable<RewardDataTableSO>();
        
        private readonly Dictionary<RewardType, HashSet<int>> _rewardUniqueHistories = new();

        public RewardData GetRandomizedReward(int rewardGroupId)
        {
            List<RewardData> rewards = RewardDataTable.GetRewards(rewardGroupId);
            if (rewards == null || rewards.Count == 0)
            {
                return null;
            }
            
            List<RewardData> filteredRewards = new List<RewardData>();
            foreach (RewardData reward in rewards)
            {
                if (reward.IsUnique && ContainsUniqueHistory(reward))
                {
                    continue;
                }
                filteredRewards.Add(reward);
            }

            return Util.GetRandomizeItem(filteredRewards);
        }

        public void UseDirectByReward(RewardData reward, GameObject go)
        {
            switch (reward.ReferenceType)
            {
                case RewardType.Weapon:
                    WeaponManager.Instance.WeaponGenerator.GetValue(reward.ReferenceID, go.transform).Interact(go);
                    break;
                case RewardType.ConsumableItem:
                case RewardType.PassiveItem:
                    ItemManager.Instance.Generator.GetValue(reward.ReferenceID, go.transform).Reference.Use(go);
                    break;
            }
        }
        
        public void SpawnReward(RewardData rewardData, GameObject go)
        {
            switch (rewardData.ReferenceType)
            {
                case RewardType.Weapon:
                    WeaponManager.Instance.WeaponGenerator.GetValue(rewardData.ReferenceID, go.transform).ActiveItem();
                    break;
                case RewardType.ConsumableItem:
                case RewardType.PassiveItem:
                    ItemManager.Instance.Generator.GetValue(rewardData.ReferenceID, go.transform).Reference.ActiveItem();
                    break;
            }
        }
        
        public void AddUniqueHistory(RewardData data)
        {
            if (data == null)
            {
                return;
            }
            
            if (!data.IsUnique)
            {
                return;
            }
            
            RewardType type = data.ReferenceType;
            int id = data.ReferenceID;
            
            if (!_rewardUniqueHistories.ContainsKey(type))
            {
                _rewardUniqueHistories.Add(type, new HashSet<int>());
            }
            _rewardUniqueHistories[type].Add(id);
        }

        public bool ContainsUniqueHistory(RewardData data)
        {
            bool ret = _rewardUniqueHistories.ContainsKey(data.ReferenceType);
            if (ret)
            {
                ret &= _rewardUniqueHistories[data.ReferenceType].Contains(data.ReferenceID);
            }

            return ret;
        }
        
        public string Save()
        {
            List<SaveDataElement_RewardHistory> rewardUniqueHistories = new List<SaveDataElement_RewardHistory>();
            foreach (KeyValuePair<RewardType, HashSet<int>> history in _rewardUniqueHistories)
            {
                foreach (int referId in history.Value)
                {
                    rewardUniqueHistories.Add(new SaveDataElement_RewardHistory(history.Key, referId));
                }
            }
            return JsonConvert.SerializeObject(rewardUniqueHistories);
        }

        public void Load(string json)
        {
            List<SaveDataElement_RewardHistory> deserialized = JsonConvert.DeserializeObject<List<SaveDataElement_RewardHistory>>(json);
            foreach (SaveDataElement_RewardHistory data in deserialized)
            {
                if (!_rewardUniqueHistories.ContainsKey(data.ReferenceType))
                {
                    _rewardUniqueHistories.Add(data.ReferenceType, new HashSet<int>());
                }
                _rewardUniqueHistories[data.ReferenceType].Add(data.ReferenceId);
            }
        }

        public string FileName => "rewardhistory";

        public void Clear()
        {
            _rewardUniqueHistories.Clear();
        }
    }
}