using ProjectAAA.Core.Managers;
using ProjectAAA.Mob.Normal;
using ProjectAAA.Utils.DataTable;
using UnityEngine;
using EventType = ProjectAAA.Core.Managers.EventType;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.Quests
{
    public class KillMonsterQuest : QuestBase
    {
        public KillMonsterQuest(QuestData data) : base(data)
        {
        }

        private void OnKillMonster(Component sender, object[] args)
        {
            if (CurrentStatus.Value != Status.Started)
            {
                return;
            }
            
            if (QuestData.MonsterId == 0)
            {
                CurrentValue.Value++;
            }
            else
            {
                MonsterBase monster = sender as MonsterBase;
                if (monster == null || QuestData.MonsterId != monster.MonsterId)
                {
                    return;
                }

                if (QuestData.WeakCondition)
                {
                    if (monster.LivingEntity.LastHitInfo.IsCritical)
                    {
                        CurrentValue.Value++;                
                    }
                }
                else
                {
                    CurrentValue.Value++;
                }
            }
        }

        protected override void OnEnable()
        {
            EventManager.Instance.AddListener(EventType.OnKillMonster, OnKillMonster);
        }

        protected override void OnDisable()
        {
            EventManager.Instance.RemoveListener(EventType.OnKillMonster, OnKillMonster);
        }
    }
}