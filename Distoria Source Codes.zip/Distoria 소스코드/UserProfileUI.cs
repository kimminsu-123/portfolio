using System;
using ProjectAAA.Utils;
using TMPro;
using UniRx;
using UnityEngine;
using UnityEngine.UI;

namespace ProjectAAA.UI.Shop
{
    public class UserProfileUI : MonoBehaviour
    {
        [SerializeField] private TMP_Text goldText;
        [SerializeField] private TMP_Text keyText;
        
        private IDisposable _goldSubscription;
        private IDisposable _keySubscription;
        
        public void Enable()
        {
            _goldSubscription = PlayerCurrencyManager.Instance.Gold.Subscribe(UpdateGold);
            _keySubscription = PlayerCurrencyManager.Instance.Key.Subscribe(UpdateKey);
        }

        public void Disable()
        {
            _goldSubscription?.Dispose();
            _keySubscription?.Dispose();
        }

        private void UpdateGold(int gold)
        {
            goldText.text = $"{gold}";
            LayoutRebuilder.ForceRebuildLayoutImmediate(goldText.rectTransform.parent as RectTransform);
        }

        private void UpdateKey(int key)
        {
            keyText.text = $"{key}";
            LayoutRebuilder.ForceRebuildLayoutImmediate(keyText.rectTransform.parent as RectTransform);
        }
    }
}