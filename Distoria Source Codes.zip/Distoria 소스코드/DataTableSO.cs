using System.IO;
using Amazon;
using Amazon.Runtime;
using Amazon.S3;
using Amazon.S3.Model;
using NaughtyAttributes;
using ProjectAAA.Core;
using ProjectAAA.SO.Debug;
using ProjectAAA.Utils;
using UnityEngine;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.SO
{
    public abstract class DataTableSO : BaseSO, IDownload
    {
        public enum LoadType
        {
            Debug,
            Local,
        }
        
        [SerializeField] private LoadType loadType = LoadType.Debug;
        [SerializeField, ShowIf("loadType", LoadType.Debug)] private DebugDataGroup debugDataGroup;
        [SerializeField, ShowIf("loadType", LoadType.Local)] private string tableName;

        private async Awaitable LoadLocalAsync()
        {
            ResourceRequest request =  Resources.LoadAsync<TextAsset>($"DataTables/{tableName}");
            
            await request;

            if (request.asset == null)
            {
                Logger.LogError($"{tableName}", "파일이 존재하지 않습니다.");
                return;
            }
            
            TextAsset json = request.asset as TextAsset;

            if (json == null)
            {
                Logger.LogError($"{tableName}", "파일이 Text 형식이 아닙니다.");
                return;
            }
            
            Logger.Log($"{tableName}", "Local 파일에서 로드합니다.", Color.magenta);
            
            FromJson(json.text);
        }

        /// <summary>
        /// LoadType 에 맞게 데이터 로딩 만약 업데이트 할 필요가 없다면 로컬에 저장된 데이터를 가지고 옴
        /// </summary>
        [ContextMenu("에디터 환경에서 로드하기")]
        public async Awaitable LoadAsync()
        {
            if (loadType == LoadType.Debug)
            {
                if (debugDataGroup == null)
                {
                    Logger.Log($"{name}", "Debug 모드인데 연결된 DebugDataGroup 이 없습니다.", Color.magenta);    
                    return;
                }
                Logger.Log($"{name}", "Debug 모드로 로드합니다.", Color.magenta);

                FromJson(debugDataGroup.ToJson());
            }
            else
            {
                await LoadLocalAsync();
            }
        }

        /// <summary>
        /// 전달 받은 데이터를 상속받은 각 테이블에서 데이터 변환을 하는 함수
        /// </summary>
        /// <param name="json">Json 형태의 Txt 포멧</param>
        protected abstract void FromJson(string json);
    }
}