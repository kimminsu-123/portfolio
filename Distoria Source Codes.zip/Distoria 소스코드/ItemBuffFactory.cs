using ProjectAAA.Utils;
using ProjectAAA.Utils.DataTable;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.Interaction.Items
{
    public static class ItemBuffFactory
    {
        public static ItemBuffComposite GetBuffs(ItemBuffDataGroup group)
        {
            ItemBuffComposite composite = new ItemBuffComposite();
            foreach (ItemBuffData data in group)
            {
                IItemBuff buff = GetBuff(data);
                ItemBuffConditionBase condition = BuffConditionFactory.Instance.GetCondition(data);
                
                composite.AddBuff(data.EffectKey, data.EffectType, buff, condition, data.EffectTime);
            }
            return composite;
        }

        private static IItemBuff GetBuff(ItemBuffData data)
        {
            switch (data.EffectType)
            {
                case EffectType.Heal:
                    return new ItemBuffHeal(data.EffectValue, data.DisplayUI);
                case EffectType.IncreaseMaxHp:
                    return new ItemBuffIncreaseMaxHp(data.EffectValue, data.DisplayUI);
                case EffectType.GetMoney:
                    return new ItemBuffGetMoney((int) data.EffectValue, data.DisplayUI);
                case EffectType.GetKey:
                    return new ItemBuffGetKey((int) data.EffectValue, data.DisplayUI);
                case EffectType.FillCurrentAmmo:
                    return new ItemBuffFillCurrentAmmo(data.EffectValue, data.DisplayUI);
                case EffectType.FillAllAmmo:
                    return new ItemBuffFillAllAmmo(data.EffectValue, data.DisplayUI);
                case EffectType.IncreaseSpreadCount:
                    return new ItemBuffIncreaseSpreadCount((int) data.EffectValue, data.DisplayUI);
                case EffectType.ReduceReloadTime:
                    return new ItemBuffReduceReloadTime(data.EffectValue, data.DisplayUI);
                case EffectType.IncreaseValue1:
                    return new ItemBuffIncreaseValue1(data.EffectValue, data.DisplayUI);
                case EffectType.IncreaseFireRate:
                    return new ItemBuffIncreaseFireRate(data.EffectValue, data.DisplayUI);
                case EffectType.IncreaseCriticalMagnification:
                    return new ItemBuffIncreaseCriticalMagnification(data.EffectValue, data.DisplayUI);
                case EffectType.IncreaseWeaponSwapTime:
                    return new ItemBuffIncreaseWeaponSwapTime(data.EffectValue, data.DisplayUI);
                case EffectType.IncreaseMagazineSize:
                    return new ItemBuffIncreaseMagazineSize((int) data.EffectValue, data.DisplayUI);
                case EffectType.IncreaseBulletDamage:
                    return new ItemBuffIncreaseBulletDamage(data.EffectValue, data.DisplayUI);
                case EffectType.IncreaseBulletSpeed:
                    return new ItemBuffIncreaseBulletSpeed(data.EffectValue, data.DisplayUI);
                case EffectType.IncreaseBulletRange:
                    return new ItemBuffIncreaseBulletRange(data.EffectValue, data.DisplayUI);
                case EffectType.IncreaseBulletSize:
                    return new ItemBuffIncreaseBulletSize(data.EffectValue, data.DisplayUI);
                case EffectType.IncreaseMoveSpeed:
                    return new ItemBuffIncreasePlayerMoveSpeed(data.EffectValue, data.DisplayUI);
                case EffectType.IncreaseDashCooldown:
                    return new ItemBuffIncreasePlayerDashCooldown(data.EffectValue, data.DisplayUI);
                default:
                    Logger.LogError("ItemBuffFactory", $"{data.EffectType} 존재하지 않거나 개발되지 않은 타입입니다.");
                    return null;
            }
        }
    }
}