using UnityEngine;

namespace ProjectAAA.Utils
{
    public static class CursorHandler
    {
        public static int UnlockCount { get; private set; }

        public static void SetCursor(Texture2D texture, Vector2 hotspot, CursorMode mode)
        {
            Cursor.SetCursor(texture, hotspot, mode);
        }
        
        public static void Lock()
        {
            UnlockCount = Mathf.Max(0, UnlockCount - 1);

            if (UnlockCount <= 0)
            {
                Cursor.lockState = CursorLockMode.Locked;
                Cursor.visible = false;
            }
            
            Logger.Log("Cursor", $"Lock! {UnlockCount}", Color.green);
        }

        public static void UnLock()
        {
            UnlockCount++;

            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
            
            Logger.Log("Cursor", $"Un Lock! {UnlockCount}", Color.green);
        }
    }
}