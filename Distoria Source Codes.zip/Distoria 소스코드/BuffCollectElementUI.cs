using System;
using ProjectAAA.Core.Timer;
using TMPro;
using UniRx;
using UnityEngine;
using UnityEngine.UI;

namespace ProjectAAA.UI.MainFight
{
    public class BuffCollectElementUI : CollectElementUI<BuffCollectData>
    {
        [SerializeField] private TMP_Text descriptionText;
        [SerializeField] private Image typeImage;

        private string _referenceDesc;
        private CooldownTimer _referenceTimer;
        private IDisposable _observableTimer;
        
        protected override void OnSetup(BuffCollectData data)
        {
            typeImage.color = data.TypeColor;
            _referenceDesc = data.Description;

            _referenceTimer = data.Timer;
            
            // 타이머가 null 로 들어오거나 Timer 의 시간이 0 인경우 (00:00 으로 뜨는거방지)
            if (_referenceTimer == null || Mathf.Approximately(_referenceTimer.Time, 0f))
            {
                descriptionText.text = $"{_referenceDesc}";
            }
            else
            {
                UpdateUI(); 
                _referenceTimer.OnTickCallback += UpdateUI;
                _referenceTimer.OnCompleteCallback += OnEndProcess;
            }
        }

        private void UpdateUI()
        {
            int min = (int) (_referenceTimer.CurrentTime / 60);
            float sec = _referenceTimer.CurrentTime % 60;
            
            descriptionText.text = $"{_referenceDesc}  {min:00}:{sec:00.0}";
        }

        protected override void OnCompletedShow()
        {
            if (_referenceTimer == null)
            {
                _observableTimer = Observable.Timer(TimeSpan.FromSeconds(1f))
                    .Subscribe(_ =>
                    {
                        NeedHide = true;
                    });
            }
        }

        private void OnEndProcess()
        {
            NeedHide = true;
        }

        protected override void OnBeginHide()
        {
            if (_referenceTimer != null) 
            {
                _referenceTimer.OnTickCallback -= UpdateUI;
                _referenceTimer.OnCompleteCallback -= OnEndProcess;
            }
        }

        public override void OnRelease()
        {
            base.OnRelease();
            
            _observableTimer?.Dispose();
        }
    }
}