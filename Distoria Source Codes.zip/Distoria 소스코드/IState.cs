using System;
using ProjectAAA.Utils;

namespace ProjectAAA.Core.FSM
{
    public interface IState
    {
        public void EnterState();
        public void UpdateState();
        public void FixedUpdateState();
        public void ExitState();
    }
    
    public interface ITransition
    {
        public IState To { get; }
        public IPredicate Condition { get; }
    }
    
    public class Transition : ITransition
    {
        public IState To { get; }
        public IPredicate Condition { get; }

        public Transition(IState to, IPredicate condition)
        {
            To = to;
            Condition = condition;
        }
    }
}