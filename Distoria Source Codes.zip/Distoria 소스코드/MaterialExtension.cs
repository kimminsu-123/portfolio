using UnityEngine;

namespace ProjectAAA.Utils
{
    public static class MaterialExtension
    {
        /// <summary>
        /// 새로운 Material 을 만들어서 복사하는 함수
        /// </summary>
        /// <param name="material"></param>
        /// <returns>새롭게 만들어진 재질의 인스턴스</returns>
        public static Material CopyMaterial(this Material material)
        {
            // 여분의 변수로 받아야 복사된 재질을 적용할 수 있게 됨
            Material instanced = new Material(material);

            return instanced;
        }
    }
}