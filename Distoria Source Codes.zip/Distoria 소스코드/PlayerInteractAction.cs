using Cysharp.Threading.Tasks;
using ProjectAAA.Core.Managers;
using ProjectAAA.Core.OptimizedSensor;
using ProjectAAA.Core.Scene.Manager;
using ProjectAAA.Core.Timer;
using ProjectAAA.Interaction;
using ProjectAAA.UI;
using UnityEngine;

namespace ProjectAAA.Player.Actions
{
    public class PlayerInteractAction : PlayerActionBase
    {
        private bool InteractionKeyDown => PlayerActionController.PlayerInput.GamePlay.Interaction.WasPerformedThisFrame();
        private bool InteractionKeyPressed => PlayerActionController.PlayerInput.GamePlay.Interaction.IsPressed();
        private InteractionUI InteractionUI => UiManager.Instance.Get<InteractionUI>();
        private ItemFloatingUI ItemFloatingUI => UiManager.Instance.Get<ItemFloatingUI>();

        [SerializeField] private float detectDistance;
        [SerializeField] private LayerMask interactionLayerMask;

        private Camera _playerCamera;
        private int _detectHash;
        private int _focusedHash;
        private OptimizedRaycastSensorData _data;

        private IInteractable _detectInteractable;
        private IInteractable _focusedInteractable;
        private CooldownTimer _pressTimer;

        public override void Initialize(GameObject target)
        {
            base.Initialize(target);

            _playerCamera = Camera.main;
            _pressTimer = new CooldownTimer(0f);
            _pressTimer.OnCompleteCallback += OnCompletedPress;

            _data = new OptimizedRaycastSensorData(1, 1);
        }

        public override void OnRegister()
        {
            base.OnRegister();

            _pressTimer.SetTime(_focusedInteractable.InteractDuration);
            _pressTimer.Start();
            
            InteractionUI.Clear();
            InteractionUI.MaxFillAmount = _focusedInteractable.InteractDuration;
        }

        public override void OnUnRegister()
        {
            base.OnUnRegister();

            _detectHash = 0;
            _focusedHash = 0;
            _detectInteractable = null;
            _focusedInteractable = null;

            _pressTimer.Stop();
            
            InteractionUI.Hide();
            ItemFloatingUI.Hide();
        }

        public override void Execute()
        {
            _pressTimer.Tick(Time.deltaTime);
            InteractionUI.Fill(Time.deltaTime);

            if (_focusedHash != _detectHash || !InteractionKeyPressed)
            {                
                ForceUnRegister();
            }
        }

        protected override void OnBlockChanged()
        {
            base.OnBlockChanged();

            if (BlockCount > 0)
            {
                InteractionUI.Hide();
                ItemFloatingUI.Hide();
            }
        }

        public override bool Validate()
        {
            if (InteractionKeyDown)
            {
                DetectTarget();
            }
            else
            {
                DetectFocus();
            }
            
            return InteractionKeyPressed && _detectInteractable != null && _focusedHash == _detectHash;
        }

        private void OnCompletedPress()
        {
            _focusedInteractable.Interact(PlayerController.gameObject);
            
            ForceUnRegister();
        }

        private async UniTask RunSensor()
        {
            if (_data.Status == SensorStatus.Running)
            {
                return;
            }
            
            _data.SetModel(new OptimizedRaycastSensorModel
            {
                Origin = _playerCamera.transform.position,
                Direction = _playerCamera.transform.forward,
                Distance = detectDistance,
                LayerMask = interactionLayerMask
            }); 
            
            PhysicsManager.Instance.AddRaycast(_data);

            await _data.Handle.Task;
        }

        private async UniTask DetectTarget()
        {
            await RunSensor();

            if (BlockCount > 0)
            {
                InteractionUI.Hide();
                ItemFloatingUI.Hide();
                return;
            }
            
            Collider target = _data.Results[0].collider;
            if (target != null)
            {
                _detectHash = target.gameObject.GetHashCode();
                _detectInteractable = target.GetComponent<IInteractable>();
            }
            else
            {
                _detectHash = 0;
                _detectInteractable = null;
            }
        }

        private async UniTask DetectFocus()
        {
            await RunSensor();
            
            if (BlockCount > 0)
            {
                InteractionUI.Hide();
                ItemFloatingUI.Hide();
                return;
            }
            
            Collider target = _data.Results[0].collider;
            
            if (target != null)
            {
                _focusedHash = target.gameObject.GetHashCode();
                _focusedInteractable = target.GetComponent<IInteractable>();

                if (_focusedInteractable != null)
                {
                    InteractionUI.Show();

                    if (_focusedInteractable is IItemFloatingModel floatingModel)
                    {
                        ItemFloatingUI.Setup(floatingModel, target.transform, PlayerManager.Instance.MainCamera.transform);
                        ItemFloatingUI.Show();   
                    }
                    else
                    {
                        ItemFloatingUI.Hide();
                    }
                }
            }
            else
            {
                _focusedHash = 0;
                _focusedInteractable = null;
                
                InteractionUI.Hide();
                ItemFloatingUI.Hide();   
            }
        }
    }
}