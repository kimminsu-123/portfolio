using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;
using ProjectAAA.Utils.DataTable;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace ProjectAAA.Utils
{
    public enum GameMode
    {
        None = -1,
        Stage = 0,
        Wave = 1,
    }
    
    public enum SurfaceType
    {
        Block,
        Wood,
        Dirt,
        Water,
    }
    
    public enum SpawnMode
    {
        Manual,
        RandomizeOnRuntime
    }

    public enum AreaType
    {
        Sphere,
        Cube
    }

    public enum StageMode
    {
        Wave,
        Burst,
        SubjectArea
    }

    public enum StartCondition
    {
        OnSceneLoaded,
        OnTrigger,
        OnOtherCall,
    }
    
    public enum SceneType
    {
        System,
        Lobby,
        Stage
    }
    
    [Serializable]
    public class SceneProfile
    {
        [field: SerializeField] public SceneType Type { get; private set; } = SceneType.System;
        [field: SerializeField] public SceneReference SceneRef { get; private set; }
        [field: SerializeField] public bool IsActive { get; private set; }
        
        public AsyncOperation Operation { get; private set; } = null;

        public AsyncOperation Load(LoadSceneMode mode)
        {
            Operation = SceneManager.LoadSceneAsync(SceneRef.BuildIndex, mode);
            return Operation;
        }
    }

    [Serializable]
    public class ItemBuffDataGroup : IEnumerable
    {
        private class ItemBuffDataEnumerator : IEnumerator
        {
            private readonly List<ItemBuffData> _buffs;
            private int _position;

            public ItemBuffDataEnumerator(List<ItemBuffData> buffs)
            {
                _buffs = buffs;
                _position = -1;
            }

            public object Current
            {
                get
                {
                    try
                    {
                        return _buffs[_position];
                    }
                    catch (IndexOutOfRangeException)
                    {
                        throw new InvalidOperationException();
                    }
                }  
            } 
            public bool MoveNext() => ++_position < _buffs.Count;
            public void Reset() => _position = -1;
        }
        
        private List<ItemBuffData> _buffs = new();

        public int Count => _buffs.Count;
        public IEnumerator GetEnumerator() => new ItemBuffDataEnumerator(_buffs);
        public void AddBuff(ItemBuffData buff) => _buffs.Add(buff);
        public void RemoveBuff(ItemBuffData buff) => _buffs.Remove(buff);
    }
    
    public enum UpdateType
    {
        Update,
        FixedUpdate,
    }

    [Flags]
    public enum AxisFlag
    {
        X = 1,
        Y = 2,
        Z = 4,
        W = 8,

        XY = X | Y,
        XZ = X | Z,
        XW = X | W,
        YZ = Y | Z,
        YW = Y | W,
        ZW = Z | W,

        XYZ = X | Y | Z,
        XYW = X | Y | W,
        YZW = Y | Z | W,

        XYZW = X | Y | Z | W,
    }

    public enum CamGroupType
    {
        Main,
        Shop
    }

    public class FuncPredicate : IPredicate
    {
        private readonly Func<bool> _func;

        public FuncPredicate(Func<bool> func)
        {
            _func = func;
        }

        public bool Evaluate() => _func.Invoke();
    }

    public struct HitInfo
    {
        public GameObject Hitter;
        public GameObject Target;
        public Vector3 Normal;
        public Vector3 Point;
        public float Damage;

        public bool IsCritical;

        public override string ToString()
        {
            return $"[Hitter:{Hitter}], [Target:{Target}], [Normal:{Normal}], [Point:{Point}], [Damage:{Damage}], [IsCritical:{IsCritical}]";
        }
    }
    
    public static class Global
    {
        public class Message
        {
            public const string SettingReturnToLobby = "로비로 돌아가시겠습니까?";
            public const string SettingRestartGame = "재시작 하시겠습니까?";
            public const string SettingExitGame = "게임을 종료하시겠습니까?";
            
            public const string PurchaseMessage = "을 구매하시겠습니까?";
            public const string SoldOutMessage = "품절";
            public const string LackOfMoneyMessage = "구매 불가";
            public const string SellCountMessage = "잔량 :";

            public const string InfinityChar = "∞";

            public const string ResultMessageClear = "스테이지 클리어하였습니다.\n3초 뒤에 재시작합니다.";
            public const string ResultMessageFailed = "스테이지 클리어 실패하였습니다.\n3초 뒤에 로비로 이동합니다.";
        }
        
        public static readonly int InfinityAmmo = -1;

        public static readonly string PlayerTag = "Player";
        public static readonly string SpawnPointTag = "SpawnPoint";
        
        public static readonly LayerMask MonsterLayerMask = LayerMask.GetMask("Monster");
        public static readonly LayerMask MonsterHitBoxLayerMask = LayerMask.GetMask("MonsterHitBox");
        public static readonly LayerMask MonsterHurtBoxLayerMask = LayerMask.GetMask("MonsterHurtBox");
        public static readonly LayerMask MonsterRagdollLayerMask = LayerMask.GetMask("MonsterRagdoll");

        public static readonly LayerMask PlayerLayerMask = LayerMask.GetMask("Player");
        public static readonly LayerMask PlayerHitBoxLayerMask = LayerMask.GetMask("PlayerHitBox");
        public static readonly LayerMask PlayerHurtBoxLayerMask = LayerMask.GetMask("PlayerHurtBox");
        
        public static readonly LayerMask WallLayerMask = LayerMask.GetMask("Wall");
        public static readonly LayerMask EnvironmentLayerMask = LayerMask.GetMask("Environment");
        public static readonly LayerMask GroundLayerMask = LayerMask.GetMask("Ground");

        public static readonly LayerMask PlayerAttackBlockMask = LayerMask.GetMask("MonsterHurtBox", "Wall", "Environment", "Ground");

        public static readonly int DefaultLayerIndex = LayerMask.NameToLayer("Default");
        public static readonly int StencilAffectLayerIndex = LayerMask.NameToLayer("StancilAffect");
        public static readonly int StencilAffectedLayerIndex = LayerMask.NameToLayer("StancilAffected");
        public static readonly int OutlineLayerIndex = LayerMask.NameToLayer("Outline");
        public static readonly int MonsterHurtBoxLayerIndex = LayerMask.NameToLayer("MonsterHurtBox");
        public static readonly int PlayerHurtBoxLayerIndex = LayerMask.NameToLayer("PlayerHurtBox");
        public static readonly int InteractionLayerIndex = LayerMask.NameToLayer("Interactable");
        public static readonly int ItemLayerIndex = LayerMask.NameToLayer("Item");
        public static readonly int WeaponLayerIndex = LayerMask.NameToLayer("Weapon");
        public static readonly int MagnetLayerIndex = LayerMask.NameToLayer("Magnet");
        public static readonly int WallLayerIndex = LayerMask.NameToLayer("Wall");
        public static readonly int EnvironmentLayerIndex = LayerMask.NameToLayer("Environment");
        public static readonly int GroundLayerIndex = LayerMask.NameToLayer("Ground");
        public static readonly int AlwaysOnTopLayerIndex = LayerMask.NameToLayer("AlwaysOnTop");

        public static class PCAnimParamName
        {
            public static readonly int BIsFiring = Animator.StringToHash("IsFiring");
            public static readonly int StNmFire = Animator.StringToHash("Fire");
            public static readonly int StNmReload = Animator.StringToHash("Reload");
            public static readonly int StNmPickup = Animator.StringToHash("Pickup");
            public static readonly int BIsInteractPortal = Animator.StringToHash("IsInteractPortal");
            public static readonly int StNmPortal = Animator.StringToHash("Portal");
        }

        public static class MonsterAnimName
        {
            public static readonly int Chase = Animator.StringToHash("chase");
            public static readonly int Locomotion = Animator.StringToHash("locomotion");

            public static readonly string Move = "Move";

            public static string GetIdleName(int num)
            {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.Append("Idle");
                stringBuilder.Append(num);
                
                return stringBuilder.ToString();
            }
        }
    }
}

namespace ProjectAAA.Utils.DataTable
{
    public enum MonsterType
    {
        Normal = 1,
        Snipping,
        Explosive,
    }

    public enum SkillType
    {
        Melee = 1,
        Ranged,
        Area,
        Jump
    }

    public enum RangeType
    {
        Sphere = 1,
        HalfSphere,
        Sector,
        Box
    }

    public enum FireType
    {
        Automatic = 1,
        SemiAutomatic,
        Charge
    }

    public enum MagazineType
    {
        None = 0,
        Area,
        Repeat
    }

    public enum PaddingType
    {
        None = 0,
        Left,
        Right
    }

    public enum StatusType
    {
        // 아직 작업 안해도됨
        None = 1,
        Freeze,
        Poison,
        Burn,
        Corrosion,
        Wound,
        Execution
    }

    public enum BulletType
    {
        HitScan = 1,
        SplitCast,
        // Projectile,
    }

    public enum WeaponType
    {
        AR = 1,
        SG,
        SR,
        SMG,
        LMG,
        SPC,
    }
    
    public enum RewardType
    {
        Weapon = 1,
        ConsumableItem,
        PassiveItem,
    }

    [Flags]
    public enum BulletAbilityFlag
    {
        None = 0,
        GenerateProjectile = 1,
        Explosion = 2,
        Penetration = 4,
        Ricochet = 8
    }

    public enum AddBulletCondition
    {
        None = 0,
        DestroyByHit = 1,
        DestroyByOverLifeTime = 2,
        DestroyAnyway = 3,
    }

    public enum AddBulletDirection
    {
        None = 0,
        RandomInSphereDirection = 1,
        NearedEnemyDirection = 2,
        UseSpread = 3,
    }

    public enum RicochetType
    {
        None = 0,
        Reflect = 1,
        NearedEnemy = 2,
    }

    public enum ItemType
    {
        Consumable = 1,
        Passive
    }

    public enum SaveElementType
    {
        Item,
        Weapon,
    }

    public enum ItemGrade
    {
        None = 0,
        D,
        C,
        B,
        A,
        S
    }

    public enum EffectType
    {
        Heal = 1,
        IncreaseMaxHp = 2,
        
        GetMoney = 3,
        GetKey = 4,
        
        FillCurrentAmmo = 5,
        FillAllAmmo = 6,
        
        ReduceReloadTime = 7,
        IncreaseSpreadCount = 8,
        IncreaseValue1 = 9,
        IncreaseFireRate = 10,
        IncreaseCriticalMagnification = 11,
        IncreaseWeaponSwapTime = 12,
        
        IncreaseMagazineSize = 13,
        
        IncreaseBulletDamage = 14,
        IncreaseBulletSpeed = 15,
        IncreaseBulletRange = 16,
        IncreaseBulletSize = 17,
        
        IncreaseMoveSpeed = 18,
        IncreaseDashCooldown = 19,

        // ActiveBulletAbility 이부분 (19 ~ 25) 까지는 고려중,
    }

    public enum ItemConditionType
    {
        None = 0,
        UnderPlayerHealthPercent = 1,
        FlyPlayer,
        MovePlayer,
        StopPlayer,
        OnPlayerDash,
        InSafeTimePlayer,
        OnKillMonster,
        OnSwapWeapon,
    }

    public enum QuestType
    {
        KillMonster = 1,
        GiveStatus
    }

    [Serializable]
    public class MonsterStatData
    {
        /// <summary>
        /// EvadeRadius
        /// EvadeHeight
        /// Value1 ( 1 = defenseDurability )
        /// </summary>
        [SerializeField, JsonProperty("MonsterID", Order = 1)]
        private int monsterId;

        [SerializeField, JsonProperty("MType", Order = 2)]
        private MonsterType type = MonsterType.Normal;

        [SerializeField, JsonProperty("Name", Order = 3)]
        private string name;

        [SerializeField, JsonProperty("MoveSpeed", Order = 3)]
        private float moveSpeed;

        [SerializeField, JsonProperty("WanderRadius", Order = 4)]
        private float wanderRadius;

        [SerializeField, JsonProperty("WanderCooltime", Order = 5)]
        private float wanderCooltime;

        [SerializeField, JsonProperty("ChaseRadius", Order = 6)]
        private float chaseRadius;
        
        [SerializeField, JsonProperty("ChaseSpeed", Order = 7)]
        private float chaseSpeed;

        [SerializeField, JsonProperty("Health", Order = 8)]
        private float health;

        [SerializeField, JsonProperty("Defense", Order = 9)]
        private float defense;
        
        [SerializeField, JsonProperty("EvadeRadius", Order = 10)]
        private float evadeRadius;
        
        [SerializeField, JsonProperty("EvadeCooltime", Order = 11)]
        private float evadeCooltime;
        
        [SerializeField, JsonProperty("EvadeDistance", Order = 12)]
        private float evadeDistance;
        
        [SerializeField, JsonProperty("RagdollForce", Order = 13)]
        private float ragdollForce;
        
        [SerializeField, JsonProperty("statusResistance", Order = 14)]
        private int statusResistance; 
        
        [SerializeField, JsonProperty("stoppingDistance", Order = 15)]
        private int stoppingDistance;
        
        
        [JsonIgnore] public int MonsterId => monsterId;
        [JsonIgnore] public MonsterType Type => type;
        [JsonIgnore] public string Name => name;
        [JsonIgnore] public float MoveSpeed => moveSpeed;
        [JsonIgnore] public float WanderRadius => wanderRadius;
        [JsonIgnore] public float WanderCooltime => wanderCooltime;
        [JsonIgnore] public float ChaseRadius => chaseRadius;
        [JsonIgnore] public float ChaseSpeed => chaseSpeed;
        [JsonIgnore] public float Health => health;
        [JsonIgnore] public float Defense => defense;
        [JsonIgnore] public float EvadeRadius => evadeRadius;
        [JsonIgnore] public float EvadeCooltime => evadeCooltime;
        [JsonIgnore] public float EvadeDistance => evadeDistance;
        [JsonIgnore] public float RagdollForce => ragdollForce;
        [JsonIgnore] public int StatusResistance => statusResistance;
        [JsonIgnore] public int StoppingDistance => stoppingDistance;

    }

    [Serializable]
    public class MonsterSkillData
    {
        [SerializeField, JsonProperty("MonsterID", Order = 1)]
        private int monsterId;

        [SerializeField, JsonProperty("Order", Order = 2)]
        private int seq;

        [SerializeField, JsonProperty("SkillType", Order = 3)]
        private SkillType type = SkillType.Melee;

        [SerializeField, JsonProperty("Values1", Order = 4)]
        private float value1;

        [SerializeField, JsonProperty("Values2", Order = 5)]
        private float value2;

        [SerializeField, JsonProperty("RangeCode", Order = 6)]
        private int rangeCode;

        [SerializeField, JsonProperty("Atk", Order = 7)]
        private float attack;

        [SerializeField, JsonProperty("AtkSpeed", Order = 8)]
        private float attackSpeed;

        [SerializeField, JsonProperty("ReadyDuration", Order = 9)]
        private float readyDuration;

        [SerializeField, JsonProperty("RestDuration", Order = 10)]
        private float restDuration;

        [SerializeField, JsonProperty("CoolTime", Order = 11)]
        private float coolTime;
        
        [SerializeField, JsonProperty("JumpHeight", Order = 12)]
        private float jumpHeight;
        
        [SerializeField, JsonProperty("JumpDuration", Order = 13)]
        private float jumpDuration;

        [JsonIgnore] public int MonsterId => monsterId;
        [JsonIgnore] public int Seq => seq;
        [JsonIgnore] public SkillType Type => type;
        [JsonIgnore] public float Value1 => value1;
        [JsonIgnore] public float Value2 => value2;
        [JsonIgnore] public int RangeCode => rangeCode;
        [JsonIgnore] public float Attack => attack;
        [JsonIgnore] public float AttackSpeed => attackSpeed;
        [JsonIgnore] public float ReadyDuration => readyDuration;
        [JsonIgnore] public float RestDuration => restDuration;
        [JsonIgnore] public float CoolTime => coolTime;
        [JsonIgnore] public float JumpHeight => jumpHeight;
        [JsonIgnore] public float JumpDuration => jumpDuration;
    }

    [Serializable]
    public class RangeData
    {
        [SerializeField, JsonProperty("RangeCode", Order = 1)]
        private int code;

        [SerializeField, JsonProperty("RangeType", Order = 2)]
        private RangeType type = RangeType.Sphere;

        [SerializeField, JsonProperty("CenterX", Order = 3)]
        private float centerX;

        [SerializeField, JsonProperty("CenterY", Order = 4)]
        private float centerY;

        [SerializeField, JsonProperty("CenterZ", Order = 5)]
        private float centerZ;

        [SerializeField, JsonProperty("Value1", Order = 6)]
        private float value1;

        [SerializeField, JsonProperty("Value2", Order = 7)]
        private float value2;

        [SerializeField, JsonProperty("Value3", Order = 8)]
        private float value3;

        [JsonIgnore] public int Code => code;
        [JsonIgnore] public RangeType Type => type;
        [JsonIgnore] public float CenterX => centerX;
        [JsonIgnore] public float CenterY => centerY;
        [JsonIgnore] public float CenterZ => centerZ;
        [JsonIgnore] public float Value1 => value1;
        [JsonIgnore] public float Value2 => value2;
        [JsonIgnore] public float Value3 => value3;
    }

    [Serializable]
    public class WeaponNormalData
    {
        [SerializeField, JsonProperty("WeaponID", Order = 1)]
        private int weaponId;

        [SerializeField, JsonProperty("WeaponName", Order = 2)]
        private string weaponName;

        [SerializeField, JsonProperty("MagazineID", Order = 3)]
        private int magazineId;

        [SerializeField, JsonProperty("FireType", Order = 4)]
        private FireType fireType;

        [SerializeField, JsonProperty("AmmoAmount", Order = 5)]
        private int ammoAmount;

        [SerializeField, JsonProperty("ReloadTime", Order = 6)]
        private float reloadTime;

        [SerializeField, JsonProperty("SpreadCount", Order = 7)]
        private int spreadCount;

        [SerializeField, JsonProperty("BurstCount", Order = 8)]
        private int burstCount;

        [SerializeField, JsonProperty("Value1", Order = 9)]
        private float value1;

        [SerializeField, JsonProperty("FireInterval", Order = 10)]
        private float fireInterval;

        [SerializeField, JsonProperty("CriticalMagnification", Order = 11)]
        private float criticalMagnification;

        [SerializeField, JsonProperty("WeaponSwapTime", Order = 12)]
        private float weaponSwapTime;

        [SerializeField, JsonProperty("WeaponType", Order = 13)]
        private WeaponType weaponType;

        [SerializeField, TextArea, JsonProperty("WeaponSummary", Order = 14)]
        private string weaponSummary;
        
        [SerializeField, TextArea, JsonProperty("WeaponDescription", Order = 15)]
        private string weaponDescription;

        [JsonIgnore] public int WeaponId => weaponId;
        [JsonIgnore] public string WeaponName => weaponName;
        [JsonIgnore] public int MagazineId => magazineId;
        [JsonIgnore] public FireType FireType => fireType;
        [JsonIgnore] public int AmmoAmount => ammoAmount;
        [JsonIgnore] public float ReloadTime => reloadTime;
        [JsonIgnore] public int SpreadCount => spreadCount;
        [JsonIgnore] public int BurstCount => burstCount;
        [JsonIgnore] public float Value1 => value1;
        [JsonIgnore] public float FireInterval => fireInterval;
        [JsonIgnore] public float CriticalMagnification => criticalMagnification;
        [JsonIgnore] public float WeaponSwapTime => weaponSwapTime;
        [JsonIgnore] public WeaponType WeaponType => weaponType;
        [JsonIgnore] public string WeaponSummary => weaponSummary;
        [JsonIgnore] public string WeaponDescription => weaponDescription;
    }

    [Serializable]
    public class MagazineData
    {
        [SerializeField, JsonProperty("MagazineID", Order = 1)]
        private int magazineId;

        [SerializeField, JsonProperty("MagazineSize", Order = 2)]
        private int magazineSize;

        [SerializeField, JsonProperty("MagazineType", Order = 3)]
        private MagazineType magazineType = MagazineType.Area;

        [SerializeField, JsonProperty("MinPadding", Order = 4)]
        private PaddingType minPaddingType = PaddingType.None;

        [SerializeField, JsonProperty("MagazineMin", Order = 5)]
        private int magazineMin;

        [SerializeField, JsonProperty("MaxPadding", Order = 6)]
        private PaddingType maxPaddingType = PaddingType.None;

        [SerializeField, JsonProperty("MagazineMax", Order = 7)]
        private int magazineMax;

        [SerializeField, JsonProperty("BasicBulletID", Order = 8)]
        private int basicBulletId;

        [SerializeField, JsonProperty("SpecialBulletID", Order = 9)]
        private int specialBulletId;

        [SerializeField, JsonProperty("NextMagazineID", Order = 10)]
        private int nextMagazineId;

        [JsonIgnore] public int MagazineId => magazineId;
        [JsonIgnore] public int MagazineSize => magazineSize;
        [JsonIgnore] public MagazineType MagazineType => magazineType;
        [JsonIgnore] public PaddingType MinPaddingType => minPaddingType;
        [JsonIgnore] public int MagazineMin => magazineMin;
        [JsonIgnore] public PaddingType MaxPaddingType => maxPaddingType;
        [JsonIgnore] public int MagazineMax => magazineMax;
        [JsonIgnore] public int BasicBulletId => basicBulletId;
        [JsonIgnore] public int SpecialBulletId => specialBulletId;
        [JsonIgnore] public int NextMagazineId => nextMagazineId;
    }

    [Serializable]
    public class BulletNormalData
    {
        [SerializeField, JsonProperty("BulletID", Order = 1)]
        private int bulletID;

        [SerializeField, JsonProperty("BulletType", Order = 2)]
        private BulletType bulletType = BulletType.HitScan;

        [SerializeField, JsonProperty("BulletMinDamage", Order = 3)]
        private float bulletMinDamage;

        [SerializeField, JsonProperty("BulletMaxDamage", Order = 4)]
        private float bulletMaxDamage;

        [SerializeField, JsonProperty("BulletSpeed", Order = 5)]
        private float bulletSpeed;

        [SerializeField, JsonProperty("BulletLifeTime", Order = 6)]
        private float bulletLifeTime;

        [SerializeField, JsonProperty("BulletSize", Order = 7)]
        private float bulletSize;

        [SerializeField, JsonProperty("StatusType", Order = 8)]
        private StatusType statusType = StatusType.None;

        [SerializeField, JsonProperty("StatusCount", Order = 9)]
        private int statusCount;

        [SerializeField, JsonProperty("GravityFactor", Order = 10)]
        private float gravityFactor;

        [SerializeField, JsonProperty("AbilityID", Order = 11)]
        private int abilityID;

        [JsonIgnore] public int BulletID => bulletID;
        [JsonIgnore] public BulletType BulletType => bulletType;
        [JsonIgnore] public float BulletMinDamage => bulletMinDamage;
        [JsonIgnore] public float BulletMaxDamage => bulletMaxDamage;
        [JsonIgnore] public float BulletSpeed => bulletSpeed;
        [JsonIgnore] public float BulletLifeTime => bulletLifeTime;
        [JsonIgnore] public float BulletSize => bulletSize;
        [JsonIgnore] public StatusType StatusType => statusType;
        [JsonIgnore] public int StatusCount => statusCount;
        [JsonIgnore] public float GravityFactor => gravityFactor;
        [JsonIgnore] public int AbilityID => abilityID;
    }

    [Serializable]
    public class BulletAbilityData
    {
        [SerializeField, JsonProperty("AbilityID", Order = 1)]
        private int abilityID;

        [SerializeField, JsonProperty("AbilityFlag", Order = 2)]
        private BulletAbilityFlag abilityFlag;

        [SerializeField, JsonProperty("AddBulletCondition", Order = 3)]
        private AddBulletCondition addBulletCondition;

        [SerializeField, JsonProperty("AddBulletID", Order = 4)]
        private int addBulletId;

        [SerializeField, JsonProperty("AddBulletCount", Order = 5)]
        private int addBulletCount;

        [SerializeField, JsonProperty("AddBulletDirection", Order = 6)]
        private AddBulletDirection addBulletDirection;

        [SerializeField, JsonProperty("AddBulletRadius", Order = 7)]
        private float addBulletRadius;

        [SerializeField, JsonProperty("ExplosionRange", Order = 8)]
        private float explosionRadius;

        [SerializeField, JsonProperty("ExplosionMinDamage", Order = 9)]
        private float explosionMinDamage;

        [SerializeField, JsonProperty("ExplosionMaxDamage", Order = 10)]
        private float explosionMaxDamage;

        [SerializeField, JsonProperty("ExplosionCameraShakeRange", Order = 11)]
        private float explosionCameraShakeRadius;

        [SerializeField, JsonProperty("ExplosionCameraShakeValue", Order = 12)]
        private float explosionCameraShakeValue;

        [SerializeField, JsonProperty("PenetrationMaxCount", Order = 13)]
        private int penetrationMaxCount;

        [SerializeField, JsonProperty("RicochetType", Order = 14)]
        private RicochetType ricochetType;

        [SerializeField, JsonProperty("RicochetCount", Order = 15)]
        private int ricochetCount;

        [SerializeField, JsonProperty("RicochetRange", Order = 16)]
        private float ricochetRadius;

        [JsonIgnore] public int AbilityID => abilityID;
        [JsonIgnore] public BulletAbilityFlag AbilityFlag => abilityFlag;
        [JsonIgnore] public AddBulletCondition AddBulletCondition => addBulletCondition;
        [JsonIgnore] public int AddBulletId => addBulletId;
        [JsonIgnore] public int AddBulletCount => addBulletCount;
        [JsonIgnore] public AddBulletDirection AddBulletDirection => addBulletDirection;
        [JsonIgnore] public float AddBulletRadius => addBulletRadius;
        [JsonIgnore] public float ExplosionRadius => explosionRadius;
        [JsonIgnore] public float ExplosionMinDamage => explosionMinDamage;
        [JsonIgnore] public float ExplosionMaxDamage => explosionMaxDamage;
        [JsonIgnore] public float ExplosionCameraShakeRadius => explosionCameraShakeRadius;
        [JsonIgnore] public float ExplosionCameraShakeValue => explosionCameraShakeValue;
        [JsonIgnore] public int PenetrationMaxCount => penetrationMaxCount;
        [JsonIgnore] public RicochetType RicochetType => ricochetType;
        [JsonIgnore] public int RicochetCount => ricochetCount;
        [JsonIgnore] public float RicochetRadius => ricochetRadius;
    }

    [Serializable]
    public class ChestData
    {
        [SerializeField, JsonProperty("ChestID", Order = 1)]
        private int chestID;

        [SerializeField, JsonProperty("ChestName", Order = 2)]
        private string chestName;

        [SerializeField, JsonProperty("ChestGrade", Order = 3)]
        private int chestGrade;

        [SerializeField, JsonProperty("KeyCost", Order = 4)]
        private int keyCost;

        [SerializeField, JsonProperty("RewardNameID1", Order = 5)]
        private int rewardGroupID1;
        
        [SerializeField, JsonProperty("RewardNameID2", Order = 6)]
        private int rewardGroupID2;
        
        [SerializeField, JsonProperty("RewardNameID3", Order = 7)]
        private int rewardGroupID3;
        
        [JsonIgnore] public int ChestID => chestID;
        [JsonIgnore] public string ChestName => chestName;
        [JsonIgnore] public int ChestGrade => chestGrade;
        [JsonIgnore] public int KeyCost => keyCost;
        [JsonIgnore] public int RewardGroupID1 => rewardGroupID1;
        [JsonIgnore] public int RewardGroupID2 => rewardGroupID2;
        [JsonIgnore] public int RewardGroupID3 => rewardGroupID3;
    }

    [Serializable]
    public class RewardData
    {
        [SerializeField, JsonProperty("GroupID", Order = 1)]
        private int rewardGroupID;

        [SerializeField, JsonProperty("Sequence", Order = 2)]
        private int sequence;

        [SerializeField, JsonProperty("RewardName", Order = 3)]
        private string rewardName;

        [SerializeField, JsonProperty("ReferenceType", Order = 4)]
        private RewardType referenceType;

        [SerializeField, JsonProperty("ReferenceID", Order = 5)]
        private int referenceID;

        [SerializeField, JsonProperty("Value1", Order = 6)]
        private int value1;

        [SerializeField, JsonProperty("RewardQuantity", Order = 7)]
        private int rewardQuantity;

        [SerializeField, JsonProperty("IsUnique", Order = 8)]
        private bool isUnique;

        [SerializeField, JsonProperty("Cost", Order = 9)]
        private int cost;
        
        [SerializeField, JsonProperty("Description", Order = 10)]
        private string description;

        [JsonIgnore] public int RewardGroupID => rewardGroupID;
        [JsonIgnore] public int Sequence => sequence;
        [JsonIgnore] public string RewardName => rewardName;
        [JsonIgnore] public RewardType ReferenceType => referenceType;
        [JsonIgnore] public int ReferenceID => referenceID;
        [JsonIgnore] public int Value1 => value1;
        [JsonIgnore] public int RewardQuantity => rewardQuantity;
        [JsonIgnore] public bool IsUnique => isUnique;
        [JsonIgnore] public int Cost => cost;
        [JsonIgnore] public string Description => description;
    }

    [Serializable]
    public class ItemData
    {
        [SerializeField, JsonProperty("ItemID", Order = 1)]
        private int itemId;

        [SerializeField, JsonProperty("ItemName", Order = 2)]
        private string itemName;

        [SerializeField, JsonProperty("ItemType", Order = 3)]
        private ItemType itemType;

        [SerializeField, JsonProperty("ItemGrade", Order = 4)]
        private ItemGrade itemGrade;

        [SerializeField, JsonProperty("MagnetReaction", Order = 5)]
        private bool magnetReaction;

        [SerializeField, JsonProperty("EffectID", Order = 6)]
        private int effectId;
        
        [SerializeField, TextArea, JsonProperty("ItemDescription", Order = 7)]
        private string itemDescription;

        [JsonIgnore] public int ItemId => itemId;
        [JsonIgnore] public string ItemName => itemName;
        [JsonIgnore] public ItemType ItemType => itemType;
        [JsonIgnore] public ItemGrade ItemGrade => itemGrade;
        [JsonIgnore] public bool MagnetReaction => magnetReaction;
        [JsonIgnore] public int EffectId => effectId;
        [JsonIgnore] public string ItemDescription => itemDescription;
    }

    [Serializable]
    public class ItemBuffData
    {
        [SerializeField, JsonProperty("EffectID", Order = 1)]
        private int effectId;

        [SerializeField, JsonProperty("EffectKey", Order = 2)]
        private int effectKey;

        [SerializeField, JsonProperty("ConditionType", Order = 3)]
        private ItemConditionType conditionType;
        
        [SerializeField, JsonProperty("ConditionValue", Order = 4)]
        private float conditionValue;
        
        [SerializeField, JsonProperty("EffectType", Order = 5)]
        private EffectType effectType;

        [SerializeField, JsonProperty("EffectValue", Order = 6)]
        private float effectValue;
        
        [SerializeField, JsonProperty("EffectTime", Order = 7)]
        private float effectTime;
        
        [SerializeField, JsonProperty("DisplayUI", Order = 8)]
        private bool displayUI = true;

        [JsonIgnore] public int EffectId => effectId;
        [JsonIgnore] public int EffectKey => effectKey;
        [JsonIgnore] public ItemConditionType ConditionType => conditionType;
        [JsonIgnore] public float ConditionValue => conditionValue;
        [JsonIgnore] public EffectType EffectType => effectType;
        [JsonIgnore] public float EffectValue => effectValue;
        [JsonIgnore] public float EffectTime => effectTime;
        [JsonIgnore] public bool DisplayUI => displayUI;
    }
    
    [Serializable]
    public class QuestData
    {
        [SerializeField, JsonProperty("QuestID", Order = 1)]
        private int questId;

        [SerializeField, JsonProperty("QuestType", Order = 2)]
        private QuestType questType;

        [SerializeField, JsonProperty("EffectID", Order = 3)]
        private int effectId;
        
        [SerializeField, JsonProperty("MonsterID", Order = 4)]
        private int monsterId;
        
        [SerializeField, JsonProperty("ItemID_D", Order = 5)]
        private int itemIdDebuff;

        [SerializeField, JsonProperty("WeakCondition", Order = 7)]
        private bool weakCondition;
        
        [SerializeField, JsonProperty("ClearValue", Order = 8)]
        private int clearValue;
        
        [SerializeField, JsonProperty("RewardGroupID", Order = 9)]
        private int rewardGroupId;
        
        [TextArea, SerializeField, JsonProperty("String1", Order = 10)]
        private string string1;
        
        [TextArea, SerializeField, JsonProperty("String2", Order = 11)]
        private string string2;

        [JsonIgnore] public int QuestId => questId;
        [JsonIgnore] public QuestType QuestType => questType;
        [JsonIgnore] public int EffectId => effectId;
        [JsonIgnore] public int MonsterId => monsterId;
        [JsonIgnore] public int ItemIdDebuff => itemIdDebuff;
        [JsonIgnore] public bool WeakCondition => weakCondition;
        [JsonIgnore] public int ClearValue => clearValue;
        [JsonIgnore] public int RewardGroupId => rewardGroupId;
        [JsonIgnore] public string String1 => string1;
        [JsonIgnore] public string String2 => string2;
    }

    [Serializable]
    public class SaveDataElement_PlayerStat
    {
        [JsonProperty("MaxHp", Order = 1)]
        public float MaxHp { get; set; }
        [JsonProperty("CurrentHp",Order = 2)]
        public float CurrentHp { get; set; }
        [JsonProperty("Defense", Order = 3)]
        public float Defense { get; set; }
    }

    [Serializable]
    public class SaveDataElement_PlayerCurrency
    {
        [JsonProperty("Key", Order = 1)]
        public int Key { get; set; }
        [JsonProperty("Gold", Order = 2)]
        public int Gold { get; set; }
    }

    [Serializable]
    public class SaveDataElement
    {
        [field: JsonProperty("SaveDataType", Order = 1)]
        public SaveElementType SaveDataType { get; set; }

        [field: JsonProperty("ID", Order = 2)] public int id { get; set; }

        [field: JsonProperty("ItemType", Order = 3)]
        public ItemType ItemType { get; set; }

        [field: JsonProperty("Ammo", Order = 4)]
        public int Ammo { get; set; }

        [field: JsonProperty("RemainAmmo", Order = 5)]
        public int RemainAmmo { get; set; }
    }
    
    [Serializable]
    public class SaveDataElement_RewardHistory
    {
        public SaveDataElement_RewardHistory(RewardType type, int id)
        {
            rewardType = type;
            referenceId = id;
        }
        
        [SerializeField, JsonProperty("ReferenceType", Order = 1)]
        private RewardType rewardType;

        [SerializeField, JsonProperty("ReferenceId", Order = 2)]
        private int referenceId;
        
        [JsonIgnore]
        public RewardType ReferenceType => rewardType;
        
        [JsonIgnore]
        public int ReferenceId => referenceId;
        
        public override bool Equals(object obj)
        {
            if (obj is SaveDataElement_RewardHistory other)
            {
                return other.ReferenceType == rewardType && other.ReferenceId == referenceId;
            }
            return false;
        }
        public override int GetHashCode() => HashCode.Combine((int)ReferenceType, ReferenceId);
    }

    [Serializable]
    public class GeneralSettings
    {
        [JsonProperty("VSync", Order = 1)]
        public bool VSync { get; set; }
        
        [JsonProperty("TargetFrameRate", Order = 2)]
        public int TargetFrameRate { get; set; }
        
        [JsonProperty("GraphicsQualitySetting", Order = 3)]
        public int GraphicsQualitySetting { get; set; }
        
        [JsonProperty("Antialiasing", Order = 4)]
        public int Antialiasing { get; set; }
        
        [JsonProperty("RenderScale", Order = 5)]
        public float RenderScale { get; set; }
        
        [JsonProperty("TextureQuality", Order = 6)]
        public int TextureQuality { get; set; }
        
        [JsonProperty("ShadowQuality", Order = 7)]
        public int ShadowQuality { get; set; }
        
        [JsonProperty("MotionBlur", Order = 8)]
        public bool MotionBlur { get; set; }
        
        [JsonProperty("MasterSound", Order = 9)]
        public float MasterSoundValue { get; set; }
        
        [JsonProperty("SFXSound", Order = 10)]
        public float SfxSoundValue { get; set; }
        
        [JsonProperty("MusicSound", Order = 11)]
        public float MusicSoundValue { get; set; }
        
        [JsonProperty("MouseSensitive", Order = 12)]
        public float MouseSensitiveValue { get; set; }
        
        [JsonProperty("TargetFrameRateIndex", Order = 13)]
        public int TargetFrameRateIndex { get; set; }
    }
}