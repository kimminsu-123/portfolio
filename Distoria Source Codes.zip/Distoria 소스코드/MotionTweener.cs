using System;
using System.Collections.Generic;
using System.Linq;
using DG.Tweening;
using UnityEngine;
using UnityEngine.Events;

namespace ProjectAAA.Utils.Tweens
{
    public class TransformTweener : DisposeBase
    {
        public delegate void SetterDelegate(float x);
        
        public bool IsCompleted { get; private set; }

        private readonly AnimationCurve _curve;
        private readonly SetterDelegate _setter;
        
        private Tweener _tweener;

        public TransformTweener(AnimationCurve curve, SetterDelegate setter)
        {
            _curve = curve;
            _setter = setter;
        }

        protected override void DisposeManagedResources()
        {
            _tweener?.Kill();
            _tweener = null;
        }

        public void Play()
        {
            float firstTime = _curve.keys.First().time;
            float lastTime = _curve.keys.Last().time;

            _tweener = DOVirtual.Float(firstTime, lastTime, lastTime, x =>
            {
                float evaluated = _curve.Evaluate(x);
                _setter?.Invoke(evaluated);   
            })
            .SetEase(Ease.Linear)
            .OnComplete(OnCompleted);

            IsCompleted = false;
        }

        private void OnCompleted()
        {
            IsCompleted = true;
        }
    }
    
    public class MotionTweener : MonoBehaviour
    {
        [SerializeField] private Transform pivot;
        [SerializeField] private bool playOnStart;
        
        [Tooltip("모션이 시작될 때 호출됩니다.")]
        public UnityEvent onStarted;
        [Tooltip("모션이 중간에 정지될 때 호출됩니다.")]
        public UnityEvent onStopped;
        [Tooltip("모션이 완료될 때 호출됩니다.")]
        public UnityEvent onCompleted;

        [Header("포지션 커브")]
        [SerializeField] private AnimationCurve positionXCurve;
        [SerializeField] private AnimationCurve positionYCurve;
        [SerializeField] private AnimationCurve positionZCurve;
        
        [Header("회전 커브")]
        [SerializeField] private AnimationCurve rotateXCurve;
        [SerializeField] private AnimationCurve rotateYCurve;
        [SerializeField] private AnimationCurve rotateZCurve;

        private List<TransformTweener> _tweeners = new();

        private Vector3 _startPosition;
        private Quaternion _startRotation;

        private void Start()
        {
            if (playOnStart)
            {
                Play();
            }
        }

        private void OnEnable()
        {
            _startPosition = pivot.localPosition;
            _startRotation = pivot.localRotation;
        }

        private void OnDisable()
        {
            pivot.localPosition = Vector3.zero;
            pivot.localRotation = Quaternion.identity;
        }

        public void Play()
        {
            pivot.localPosition = _startPosition;
            pivot.localRotation = _startRotation;
            
            PlayTweeners();
            
            onStarted?.Invoke();
            
            Logger.Log("MotionTweener", "OnStart", Color.blue);
        }

        public void Stop()
        {
            StopTweeners();
            
            onStopped?.Invoke();
            
            Logger.Log("MotionTweener", "OnStop", Color.blue);
        }

        private void Update()
        {
            if (_tweeners.Count > 0 && _tweeners.All(x => x.IsCompleted))
            {
                onCompleted?.Invoke();
                DisposeAll();
                
                Logger.Log("MotionTweener", "OnCompleted", Color.blue);
            }
        }

        private void DisposeAll()
        {
            if (_tweeners.Count > 0)
            {
                _tweeners.ForEach(x => x.Dispose());
                _tweeners.Clear();
            }
        }

        private void PlayTweeners()
        {
            DisposeAll();
            
            _tweeners.Add(new TransformTweener(positionXCurve, f =>
            {
                Vector3 pos = pivot.localPosition;
                pos.x = _startPosition.x + f;
                pivot.localPosition = pos;
            }));
            _tweeners.Add(new TransformTweener(positionYCurve, f =>
            {
                Vector3 pos = pivot.localPosition;
                pos.y = _startPosition.y + f;
                pivot.localPosition = pos;
            }));
            _tweeners.Add(new TransformTweener(positionZCurve, f =>
            {
                Vector3 pos = pivot.localPosition;
                pos.z = _startPosition.z + f;
                pivot.localPosition = pos;
            }));
            _tweeners.Add(new TransformTweener(rotateXCurve, f =>
            {
                Quaternion rot = pivot.localRotation;
                rot.x = _startRotation.x + f;
                pivot.localRotation = rot;
            }));
            _tweeners.Add(new TransformTweener(rotateYCurve, f =>
            {
                Quaternion rot = pivot.localRotation;
                rot.y = _startRotation.y + f;
                pivot.localRotation = rot;
            }));
            _tweeners.Add(new TransformTweener(rotateZCurve, f =>
            {
                Quaternion rot = pivot.localRotation;
                rot.z = _startRotation.z + f;
                pivot.localRotation = rot;
            }));

            foreach (TransformTweener tweener in _tweeners)
            {
                tweener.Play();   
            }
        }

        private void StopTweeners()
        {
            DisposeAll();
        }
    }
}