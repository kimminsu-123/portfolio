using System.Collections.Generic;
using Newtonsoft.Json;
using ProjectAAA.Utils.DataTable;
using UnityEngine;

namespace ProjectAAA.SO.Debug
{
    [CreateAssetMenu(fileName = "WeaponNormalDebugDataGroup", menuName = "Scriptable Objects/DataTable/Debug/WeaponNormal")]
    public class WeaponNormalDebugDataGroup : DebugDataGroup
    {
        [SerializeField] private List<WeaponNormalData> weapons;

        protected override void FromJson(string json)
        {
            weapons.Clear();
            weapons = JsonConvert.DeserializeObject<List<WeaponNormalData>>(json);
        }

        public override string ToJson()
        {
            return JsonConvert.SerializeObject(weapons);
        }
    }
}