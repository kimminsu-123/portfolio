using System;
using System.Collections.Generic;
using ProjectAAA.Core.Managers;
using ProjectAAA.Core.Scene.Manager;
using ProjectAAA.Player.Actions;
using ProjectAAA.Quests;
using ProjectAAA.SO;
using ProjectAAA.UI.Shop;
using ProjectAAA.Utils;
using ProjectAAA.Utils.DataTable;
using UnityEngine;

namespace ProjectAAA.Interaction.Shop
{
    public class ShopEntryData
    {
        public string Title;
        public string Description;
        public readonly List<ProductRow> ProductRows = new();

        public Sprite RevokedItemIcon;
        public string QuestTxt;
        public QuestBase.Status QuestStatus;
    }
    
    public class ShopEntry : MonoBehaviour, IInteractable
    {
        public float InteractDuration => interactDuration;
        
        private bool EscKeyDown
        {
            get
            {
#if UNITY_EDITOR
                return Input.GetKeyDown(KeyCode.BackQuote) || PlayerManager.Instance.PlayerEntity.IsDead;
#else
                return PlayerActionController.PlayerInput.GamePlay.ESC.WasPressedThisFrame() || PlayerManager.Instance.PlayerEntity.IsDead;
#endif
            }
        }
        
        private QuestBase CurrentQuest => QuestManager.Instance.CurrentQuest;

        [SerializeField] private GameObject model;
        [SerializeField] private int[] rewardGroupIds; 
        [SerializeField] private float interactDuration = 0.5f;
        [SerializeField] private string title = "어쩌구의 상점";
        [SerializeField, TextArea] private string description = "가나다라마바사";
        [SerializeField] private FMODEventInfoSO showSound;
        [SerializeField] private FMODEventInfoSO hideSound;
        private bool _isInitialized = false;
        private bool _isOpened = false;
        private Camera _camera;
        
        private readonly ShopEntryData _cachedProducts = new();

        private void Awake()
        {
            _camera = GetComponentInChildren<Camera>(true);
        }

        public void Interact(GameObject go)
        {
            if (go.CompareTag(Global.PlayerTag))
            {
                if (!_isInitialized)
                {
                    Initialize();
                }
                
                SetupQuestRewards();

                _cachedProducts.QuestTxt = string.Empty;
                _cachedProducts.QuestStatus = QuestBase.Status.Created;
                if (CurrentQuest != null)
                {
                    _cachedProducts.QuestTxt = CurrentQuest.ShopMessage;
                    _cachedProducts.QuestStatus = CurrentQuest.CurrentStatus.Value;
                }
                
                model.ChangeLayerAll(Global.WallLayerIndex);
                
                _camera.gameObject.SetActive(true);
                SoundManager.Instance.PlaySFX(showSound, gameObject.transform.position);
                ShopManager.Instance.Enter(go, _cachedProducts, _camera.gameObject.GetHashCode());

                _isOpened = true;
            }
        }
        
        private void Initialize()
        {
            _cachedProducts.Title = title;
            _cachedProducts.Description = description;
            for (int i = 0; i < rewardGroupIds.Length; i++)
            {
                RewardData data = RewardManager.Instance.GetRandomizedReward(rewardGroupIds[i]);
                if (data != null)
                {
                    _cachedProducts.ProductRows.Add(CreateProduct(data));   
                }
                else
                {
                    _cachedProducts.ProductRows.Add(null);
                }
            }
            
            _isInitialized = true;
        }
        
        private void SetupQuestRewards()
        {
            if (CurrentQuest == null)
            {
                return;
            }

            // 만약 퀘스트 아이템 초기화가 이미 되었다면
            if (_cachedProducts.ProductRows.Count >= 12) 
            {
                return;
            }
            
            if (CurrentQuest.CurrentStatus.Value is QuestBase.Status.Clear or QuestBase.Status.Ended)
            {
                _cachedProducts.RevokedItemIcon = null;
                ItemData itemData = DatabaseManager.Instance.GetTable<ItemTableSO>().GetItem(CurrentQuest.DeBuffItemId);
                if (itemData != null)
                {
                    _cachedProducts.RevokedItemIcon = DatabaseManager.Instance.IconResources.GetIcon((RewardType)(itemData.ItemType + 1), itemData.ItemId);
                }
                    
                List<RewardData> rewards = DatabaseManager.Instance.GetTable<RewardDataTableSO>().GetRewards(CurrentQuest.RewardGroupId);

                int cnt = rewards.Count;
                foreach (RewardData reward in rewards)
                {
                    if (!RewardManager.Instance.ContainsUniqueHistory(reward))
                    {
                        _cachedProducts.ProductRows.Add(CreateProduct(reward));   
                    }
                    else
                    {
                        _cachedProducts.ProductRows.Add(null);
                    }
                }

                for (; cnt < 4; cnt++)
                {
                    _cachedProducts.ProductRows.Add(null);
                }
                    
                CurrentQuest.Disable();
            }
        }

        private ProductRow CreateProduct(RewardData reward)
        {
            return new ProductRow
            {
                Reward = reward,
                Icon = DatabaseManager.Instance.IconResources.GetIcon(reward.ReferenceType, reward.ReferenceID),
                Cost = reward.Cost,
                Name = reward.RewardName,
                Description = reward.Description,
                RemainSellCount = reward.RewardQuantity
            };
        }
        
        private void LateUpdate()
        {
            if (_isOpened && EscKeyDown)
            {
                CloseShop();
            }
        }

        private void CloseShop()
        {
            model.ChangeLayerAll(Global.OutlineLayerIndex);
            
            SoundManager.Instance.PlaySFX(hideSound, gameObject.transform.position);
            ShopManager.Instance.Exit();
            _camera.gameObject.SetActive(false);
            _isOpened = false;
        }
    }
}