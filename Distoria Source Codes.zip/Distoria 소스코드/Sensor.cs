using System;
using System.Collections.Generic;
using System.Linq;
using Cysharp.Threading.Tasks;
using Unity.Collections;
using Unity.Jobs;
using Unity.Profiling;
using UnityEngine;
using UnityEngine.Profiling;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.Core.Sensor
{
    public struct JobRaycastConfig
    {
        public Vector3 Origin;
        public Vector3 Direction;
        public float Distance;
    }
    
    public struct JobSphereCastConfig
    {
        public Vector3 Origin;
        public Vector3 Direction;
        public float Distance;
        public float Radius;
    }
    
    public interface IJobOverlapConfig
    {
        public Vector3 Origin { get; set; }
        public Vector3 Direction { get; set; }
    }
    
    public struct JobOverlapSphereConfig : IJobOverlapConfig
    {
        public Vector3 Origin { get; set; }
        public Vector3 Direction { get; set; }
        public float Radius;
    }
    
    public struct JobOverlapBoxConfig : IJobOverlapConfig
    {
        public Vector3 Origin { get; set; }
        public Vector3 Direction { get; set; }
        public Vector3 HalfExtents;
    }
    
    public struct JobOverlapSectorConfig : IJobOverlapConfig
    {
        public Vector3 Origin { get; set; }
        public Vector3 Direction { get; set; }
        public float Radius;
        public float Angle;
    }
    
    public struct JobOverlapHalfSphereConfig : IJobOverlapConfig
    {
        public Vector3 Origin { get; set; }
        public Vector3 Direction { get; set; }
        public float Radius;
    }
    
    public class JobCastWaiter
    {
        private JobHandle _handle;

        private bool HandleCompleted() => _handle.IsCompleted;
        
        public async UniTask<TResult[]> Wait<TCommand, TResult>(JobHandle handle, NativeArray<TResult> results,
            NativeArray<TCommand> commands, bool block) where TCommand : struct where TResult : struct
        {
            if (block)
            {
                await handle;
            }
            else
            {
                await UniTask.WaitUntil(HandleCompleted);
                
                handle.Complete();
            }

            TResult[] ret = new TResult[results.Length];
            NativeArray<TResult>.Copy(results, ret);
            
            results.Dispose();
            commands.Dispose();

            return ret;
        }
        
        public async UniTask WaitNonAlloc<TCommand, TResult>(JobHandle handle, NativeArray<TResult> results,
            NativeArray<TCommand> commands, TResult[] buffer, bool block) where TCommand : struct where TResult : struct
        {
            if (block)
            {
                await handle;
            }
            else
            {                
                await UniTask.WaitUntil(HandleCompleted);

                handle.Complete();
            }

            int minCnt = Mathf.Min(results.Length, buffer.Length);
            NativeArray<TResult>.Copy(results, 0, buffer, 0, minCnt);
            
            results.Dispose();
            commands.Dispose();
        }
    }
    
    public abstract class JobCastSensor<TParam, TResult>
    {
        public bool IsRunning { get; protected set; }
        protected LayerMask DetectLayerMask { get; private set; }
        protected int DetectCount { get; private set; }
        protected JobCastWaiter Waiter { get; private set; }
        
        protected const int MaxCommandsPerJob = 16;
        
        protected JobCastSensor(LayerMask detectLayerMask, int detectCount)
        {
            IsRunning = false;
            DetectLayerMask = detectLayerMask;
            DetectCount = detectCount;
            Waiter = new JobCastWaiter();
        }
        
        public abstract UniTask<TResult[]> Execute(TParam[] configs, bool block = false);
        public abstract UniTask Execute(TParam[] configs, TResult[] buffer, bool block = false);
    }
    
    public class JobRaycastSensor : JobCastSensor<JobRaycastConfig, RaycastHit>
    {
        private readonly QueryParameters _query;
        
        public JobRaycastSensor(LayerMask detectLayerMask, int detectCount) : base(detectLayerMask, detectCount)
        {
            _query = new QueryParameters(detectLayerMask, false, QueryTriggerInteraction.Collide);
        }
        
        public override async UniTask<RaycastHit[]> Execute(JobRaycastConfig[] configs, bool block = false)
        {
            IsRunning = true;
            
            NativeArray<RaycastCommand> commands = new NativeArray<RaycastCommand>(configs.Length, Allocator.TempJob);
            NativeArray<RaycastHit> results = new NativeArray<RaycastHit>(configs.Length * DetectCount, Allocator.TempJob);
            
            for (int i = 0; i < configs.Length; i++)
            {
                Vector3 origin = configs[i].Origin;
                Vector3 direction = configs[i].Direction;
                float distance = configs[i].Distance;
                commands[i] = new RaycastCommand(origin, direction, _query, distance);
            }
            
            int minCommandsPerJob = Mathf.Clamp(configs.Length, 1, MaxCommandsPerJob);
            
            JobHandle handle = RaycastCommand.ScheduleBatch(commands, results, minCommandsPerJob, DetectCount);
            RaycastHit[] hits = await Waiter.Wait(handle, results, commands, block);
            
            IsRunning = false;
            
            return hits;
        }

        public override async UniTask Execute(JobRaycastConfig[] configs, RaycastHit[] buffer, bool block = false)
        {
            IsRunning = true;
            
            NativeArray<RaycastCommand> commands = new NativeArray<RaycastCommand>(configs.Length, Allocator.TempJob);
            NativeArray<RaycastHit> results = new NativeArray<RaycastHit>(configs.Length * DetectCount, Allocator.TempJob);
            
            for (int i = 0; i < configs.Length; i++)
            {
                Vector3 origin = configs[i].Origin;
                Vector3 direction = configs[i].Direction;
                float distance = configs[i].Distance;
                commands[i] = new RaycastCommand(origin, direction, _query, distance);
            }
            
            int minCommandsPerJob = Mathf.Clamp(configs.Length, 1, MaxCommandsPerJob);
            JobHandle handle = RaycastCommand.ScheduleBatch(commands, results, minCommandsPerJob, DetectCount);
            
            await Waiter.WaitNonAlloc(handle, results, commands, buffer, block);
            
            IsRunning = false;
        }
    }
    
    public class JobSphereCastSensor : JobCastSensor<JobSphereCastConfig, RaycastHit>
    {
        private readonly QueryParameters _query;
        
        public JobSphereCastSensor(LayerMask detectLayerMask, int detectCount) : base(detectLayerMask, detectCount)
        {
            _query = new QueryParameters(detectLayerMask, false, QueryTriggerInteraction.Collide);
        }
        
        public override async UniTask<RaycastHit[]> Execute(JobSphereCastConfig[] configs, bool block = false)
        {
            IsRunning = true;

            NativeArray<RaycastHit> results = new NativeArray<RaycastHit>(configs.Length * DetectCount, Allocator.TempJob);
            NativeArray<SpherecastCommand> commands = new NativeArray<SpherecastCommand>(configs.Length, Allocator.TempJob);
            for (int i = 0; i < configs.Length; i++)
            {
                Vector3 origin = configs[i].Origin;
                Vector3 direction = configs[i].Direction;
                float distance = configs[i].Distance;
                float radius = configs[i].Radius;

                commands[i] = new SpherecastCommand(origin, radius, direction, _query, distance);
            }

            int minCommandsPerJob = Mathf.Clamp(configs.Length, 1, MaxCommandsPerJob);
            JobHandle handle = SpherecastCommand.ScheduleBatch(commands, results, minCommandsPerJob, DetectCount);
            
            RaycastHit[] ret = await Waiter.Wait(handle, results, commands, block);
            
            IsRunning = false;
            
            return ret;
        }
        
        public override async UniTask Execute(JobSphereCastConfig[] configs, RaycastHit[] buffer, bool block = false)
        {
            IsRunning = true;

            NativeArray<RaycastHit> results = new NativeArray<RaycastHit>(configs.Length * DetectCount, Allocator.TempJob);
            NativeArray<SpherecastCommand> commands = new NativeArray<SpherecastCommand>(configs.Length, Allocator.TempJob);
            for (int i = 0; i < configs.Length; i++)
            {
                Vector3 origin = configs[i].Origin;
                Vector3 direction = configs[i].Direction;
                float distance = configs[i].Distance;
                float radius = configs[i].Radius;

                commands[i] = new SpherecastCommand(origin, radius, direction, _query, distance);
            }

            int minCommandsPerJob = Mathf.Clamp(configs.Length, 1, MaxCommandsPerJob);
            JobHandle handle = SpherecastCommand.ScheduleBatch(commands, results, minCommandsPerJob, DetectCount);
            
            await Waiter.WaitNonAlloc(handle, results, commands, buffer, block);
            
            IsRunning = false;
        }
    }
    
    public class JobOverlapSphereSensor : JobCastSensor<IJobOverlapConfig, Collider>
    {
        private ColliderHit[] _hits;
        private readonly HashSet<Collider> _colliders;
        private readonly QueryParameters _query;
        
        public JobOverlapSphereSensor(LayerMask detectLayerMask, int detectCount) : base(detectLayerMask, detectCount)
        {
            _hits = new ColliderHit[detectCount];
            _colliders = new HashSet<Collider>(detectCount);
            _query = new QueryParameters(detectLayerMask, false, QueryTriggerInteraction.Collide);
        }
        
        public override async UniTask<Collider[]> Execute(IJobOverlapConfig[] configs, bool block = false)
        {
            IsRunning = true;
            
            if (_hits.Length < configs.Length * DetectCount)
            {
                _hits = null;
                _hits = new ColliderHit[configs.Length * DetectCount];
            }

            JobOverlapSphereConfig[] sphereConfigs = new JobOverlapSphereConfig[configs.Length];
            for (int i = 0; i < configs.Length; i++)
            {
                sphereConfigs[i] = (JobOverlapSphereConfig) configs[i];   
            }

            NativeArray<ColliderHit> results = new NativeArray<ColliderHit>(sphereConfigs.Length * DetectCount, Allocator.TempJob);
            NativeArray<OverlapSphereCommand> commands = new NativeArray<OverlapSphereCommand>(sphereConfigs.Length, Allocator.TempJob);
            for (int i = 0; i < sphereConfigs.Length; i++)
            {
                Vector3 origin = sphereConfigs[i].Origin;
                float radius = sphereConfigs[i].Radius;
                
                commands[i] = new OverlapSphereCommand(origin, radius, _query);
            }

            int minCommandsPerJob = Mathf.Clamp(sphereConfigs.Length, 1, MaxCommandsPerJob);
            JobHandle handle = OverlapSphereCommand.ScheduleBatch(commands, results, minCommandsPerJob, DetectCount);

            await Waiter.WaitNonAlloc(handle, results, commands, _hits, block);
            
            for (int i = 0; i < _hits.Length; i++)
            {
                Collider collider = _hits[i].collider;
                if(collider != null)
                {
                    _colliders.Add(collider);
                }
            }
            
            Collider[] hits = new Collider[_colliders.Count];
            _colliders.CopyTo(hits);
            _colliders.Clear();
            
            IsRunning = false;
            
            return hits;
        }

        public override async UniTask Execute(IJobOverlapConfig[] configs, Collider[] buffer, bool block = false)
        {
            IsRunning = true;
            
            if (_hits.Length < configs.Length * DetectCount)
            {
                _hits = null;
                _hits = new ColliderHit[configs.Length * DetectCount];
            }

            JobOverlapSphereConfig[] sphereConfigs = new JobOverlapSphereConfig[configs.Length];
            for (int i = 0; i < configs.Length; i++)
            {
                sphereConfigs[i] = (JobOverlapSphereConfig) configs[i];   
            }
            
            NativeArray<OverlapSphereCommand> commands = new NativeArray<OverlapSphereCommand>(sphereConfigs.Length, Allocator.TempJob);
            NativeArray<ColliderHit> results = new NativeArray<ColliderHit>(sphereConfigs.Length * DetectCount, Allocator.TempJob);
            for (int i = 0; i < sphereConfigs.Length; i++)
            {
                Vector3 origin = sphereConfigs[i].Origin;
                float radius = sphereConfigs[i].Radius;
                
                commands[i] = new OverlapSphereCommand(origin, radius, _query);
            }
            
            int minCommandsPerJob = Mathf.Clamp(sphereConfigs.Length, 1, MaxCommandsPerJob);
            JobHandle handle = OverlapSphereCommand.ScheduleBatch(commands, results, minCommandsPerJob, DetectCount);

            await Waiter.WaitNonAlloc(handle, results, commands, _hits, block);
            
            for (int i = 0; i < _hits.Length; i++)
            {
                Collider collider = _hits[i].collider;
                if(collider != null)
                {
                    _colliders.Add(collider);
                }
            }

            if (buffer.Length < _colliders.Count)
            {
                Array.Resize(ref buffer, _colliders.Count);
            }
            _colliders.CopyTo(buffer);
            _colliders.Clear();
            
            IsRunning = false;
        }
    }
    
    public class JobOverlapBoxSensor : JobCastSensor<IJobOverlapConfig, Collider>
    {
        private ColliderHit[] _hits;
        private readonly HashSet<Collider> _colliders;
        private readonly QueryParameters _query;
        
        public JobOverlapBoxSensor(LayerMask detectLayerMask, int detectCount) : base(detectLayerMask, detectCount)
        {
            _hits = new ColliderHit[detectCount];
            _colliders = new HashSet<Collider>(detectCount);
            _query = new QueryParameters(detectLayerMask, false, QueryTriggerInteraction.Collide);
        }

        public override async UniTask<Collider[]> Execute(IJobOverlapConfig[] configs, bool block = false)
        {
            IsRunning = true;

            if (_hits.Length < configs.Length * DetectCount)
            {
                _hits = null;
                _hits = new ColliderHit[configs.Length * DetectCount];
            }
            
            JobOverlapBoxConfig[] boxConfigs = new JobOverlapBoxConfig[configs.Length];
            for (int i = 0; i < configs.Length; i++)
            {
                boxConfigs[i] = (JobOverlapBoxConfig)configs[i];
            }
            
            NativeArray<ColliderHit> results = new NativeArray<ColliderHit>(boxConfigs.Length * DetectCount, Allocator.TempJob);
            NativeArray<OverlapBoxCommand> commands = new NativeArray<OverlapBoxCommand>(boxConfigs.Length, Allocator.TempJob);
            for (int i = 0; i < boxConfigs.Length; i++)
            {
                Vector3 origin = boxConfigs[i].Origin;
                Vector3 halfExtents = boxConfigs[i].HalfExtents;

                commands[i] = new OverlapBoxCommand(origin, halfExtents, Quaternion.identity, _query);
            }

            int minCommandsPerJob = Mathf.Clamp(boxConfigs.Length, 1, MaxCommandsPerJob);
            JobHandle handle = OverlapBoxCommand.ScheduleBatch(commands, results, minCommandsPerJob, DetectCount);
            
            await Waiter.WaitNonAlloc(handle, results, commands, _hits, block);
            
            for (int i = 0; i < _hits.Length; i++)
            {
                Collider collider = _hits[i].collider;
                if(collider != null)
                {
                    _colliders.Add(collider);
                }
            }
            
            Collider[] hits = new Collider[_colliders.Count];
            _colliders.CopyTo(hits);
            _colliders.Clear();
            
            IsRunning = false;

            return hits;
        }

        public override async UniTask Execute(IJobOverlapConfig[] configs, Collider[] buffer, bool block = false)
        {
            IsRunning = true;

            if (_hits.Length < configs.Length * DetectCount)
            {
                _hits = null;
                _hits = new ColliderHit[configs.Length * DetectCount];
            }
            
            JobOverlapBoxConfig[] boxConfigs = new JobOverlapBoxConfig[configs.Length];
            for (int i = 0; i < configs.Length; i++)
            {
                boxConfigs[i] = (JobOverlapBoxConfig)configs[i];
            }
            
            NativeArray<ColliderHit> results = new NativeArray<ColliderHit>(boxConfigs.Length * DetectCount, Allocator.TempJob);
            NativeArray<OverlapBoxCommand> commands = new NativeArray<OverlapBoxCommand>(boxConfigs.Length, Allocator.TempJob);
            for (int i = 0; i < boxConfigs.Length; i++)
            {
                Vector3 origin = boxConfigs[i].Origin;
                Vector3 halfExtents = boxConfigs[i].HalfExtents;

                commands[i] = new OverlapBoxCommand(origin, halfExtents, Quaternion.identity, _query);
            }

            int minCommandsPerJob = Mathf.Clamp(boxConfigs.Length, 1, MaxCommandsPerJob);
            JobHandle handle = OverlapBoxCommand.ScheduleBatch(commands, results, minCommandsPerJob, DetectCount);
            
            await Waiter.WaitNonAlloc(handle, results, commands, _hits, block);
            
            for (int i = 0; i < _hits.Length; i++)
            {
                Collider collider = _hits[i].collider;
                if(collider != null)
                {
                    _colliders.Add(collider);
                }
            }
            
            if (buffer.Length < _colliders.Count)
            {
                Array.Resize(ref buffer, _colliders.Count);
            }
            _colliders.CopyTo(buffer);
            _colliders.Clear();
            
            IsRunning = false;
        }
    }
    
    public class JobOverlapSectorSensor : JobCastSensor<IJobOverlapConfig, Collider>
    {
        private ColliderHit[] _hits;
        private readonly HashSet<Collider> _colliders;
        private readonly QueryParameters _query;
        
        public JobOverlapSectorSensor(LayerMask detectLayerMask, int detectCount) : base(detectLayerMask, detectCount)
        {
            _hits = new ColliderHit[detectCount];
            _colliders = new HashSet<Collider>(detectCount);
            _query = new QueryParameters(detectLayerMask, false, QueryTriggerInteraction.Collide);
        }
        
        public override async UniTask<Collider[]> Execute(IJobOverlapConfig[] configs, bool block = false)
        {
            IsRunning = true;

            if (_hits.Length < configs.Length * DetectCount)
            {
                _hits = null;
                _hits = new ColliderHit[configs.Length * DetectCount];
            }

            JobOverlapSectorConfig[] sectorConfigs = new JobOverlapSectorConfig[configs.Length];
            for (int i = 0; i < configs.Length; i++)
            {
                sectorConfigs[i] = (JobOverlapSectorConfig)configs[i];
            }
            
            NativeArray<ColliderHit> results = new NativeArray<ColliderHit>(sectorConfigs.Length * DetectCount, Allocator.TempJob);
            NativeArray<OverlapSphereCommand> commands = new NativeArray<OverlapSphereCommand>(sectorConfigs.Length, Allocator.TempJob);
            for (int i = 0; i < sectorConfigs.Length; i++)
            {
                commands[i] = new OverlapSphereCommand(sectorConfigs[i].Origin, sectorConfigs[i].Radius, _query);
            }
            
            int minCommandsPerJob = Mathf.Clamp(sectorConfigs.Length, 1, MaxCommandsPerJob);
            JobHandle handle = OverlapSphereCommand.ScheduleBatch(commands, results, minCommandsPerJob, DetectCount);

            await Waiter.WaitNonAlloc(handle, results, commands, _hits, block);
            
            for (int i = 0; i < _hits.Length; i++)
            {
                Collider col = _hits[i].collider;
                for (int j = 0; j < sectorConfigs.Length && col != null; j++)
                {
                    JobOverlapSectorConfig cfg = sectorConfigs[j];
                    
                    Vector3 toTarget = col.transform.position - cfg.Origin;
                    float sqrMag = toTarget.sqrMagnitude;
                    float angle = Vector3.Angle(cfg.Direction.normalized, toTarget.normalized);
                    
                    if (sqrMag > cfg.Radius * cfg.Radius) continue;
                    if (angle <= cfg.Angle * 0.5f)
                    {
                        _colliders.Add(col);
                        break;
                    }
                }
            }
            
            Collider[] ret = new Collider[_colliders.Count];
            _colliders.CopyTo(ret);
            _colliders.Clear();
            
            IsRunning = false;
            
            return ret;
        }

        public override async UniTask Execute(IJobOverlapConfig[] configs, Collider[] buffer, bool block = false)
        {
            IsRunning = true;

            if (_hits.Length < configs.Length * DetectCount)
            {
                _hits = null;
                _hits = new ColliderHit[configs.Length * DetectCount];
            }

            JobOverlapSectorConfig[] sectorConfigs = new JobOverlapSectorConfig[configs.Length];
            for (int i = 0; i < configs.Length; i++)
            {
                sectorConfigs[i] = (JobOverlapSectorConfig)configs[i];
            }
            
            NativeArray<ColliderHit> results = new NativeArray<ColliderHit>(sectorConfigs.Length * DetectCount, Allocator.TempJob);
            NativeArray<OverlapSphereCommand> commands = new NativeArray<OverlapSphereCommand>(sectorConfigs.Length, Allocator.TempJob);
            for (int i = 0; i < sectorConfigs.Length; i++)
            {
                commands[i] = new OverlapSphereCommand(sectorConfigs[i].Origin, sectorConfigs[i].Radius, _query);
            }
            
            int minCommandsPerJob = Mathf.Clamp(sectorConfigs.Length, 1, MaxCommandsPerJob);
            JobHandle handle = OverlapSphereCommand.ScheduleBatch(commands, results, minCommandsPerJob, DetectCount);

            await Waiter.WaitNonAlloc(handle, results, commands, _hits, block);
            
            for (int i = 0; i < _hits.Length; i++)
            {
                Collider col = _hits[i].collider;
                for (int j = 0; j < sectorConfigs.Length && col != null; j++)
                {
                    JobOverlapSectorConfig cfg = sectorConfigs[j];
                    
                    Vector3 toTarget = col.transform.position - cfg.Origin;
                    float sqrMag = toTarget.sqrMagnitude;
                    float angle = Vector3.Angle(cfg.Direction.normalized, toTarget.normalized);
                    
                    if (sqrMag > cfg.Radius * cfg.Radius) continue;
                    if (angle <= cfg.Angle * 0.5f)
                    {
                        _colliders.Add(col);
                        break;
                    }
                }
            }

            if (buffer.Length < _colliders.Count)
            {
                Array.Resize(ref buffer, _colliders.Count);
            }
            _colliders.CopyTo(buffer);
            _colliders.Clear();
            
            IsRunning = false;
        }
    }
    
    public class JobOverlapHalfSphereSensor : JobCastSensor<IJobOverlapConfig, Collider>
    {
        private ColliderHit[] _hits;
        private readonly HashSet<Collider> _colliders;
        private readonly QueryParameters _query;
        
        public JobOverlapHalfSphereSensor(LayerMask detectLayerMask, int detectCount) : base(detectLayerMask, detectCount)
        {
            _hits = new ColliderHit[detectCount];
            _colliders = new HashSet<Collider>(detectCount);
            _query = new QueryParameters(detectLayerMask, false, QueryTriggerInteraction.Collide);
        }
        
        public override async UniTask<Collider[]> Execute(IJobOverlapConfig[] configs, bool block = false)
        {
            IsRunning = true;

            if (_hits.Length < configs.Length * DetectCount)
            {
                _hits = null;
                _hits = new ColliderHit[configs.Length * DetectCount];
            }
            
            JobOverlapHalfSphereConfig[] halfSphereConfigs = new JobOverlapHalfSphereConfig[configs.Length];
            for (int i = 0; i < configs.Length; i++)
            {
                halfSphereConfigs[i] = (JobOverlapHalfSphereConfig)configs[i];
            }
            
            NativeArray<ColliderHit> results = new NativeArray<ColliderHit>(halfSphereConfigs.Length * DetectCount, Allocator.TempJob);
            NativeArray<OverlapSphereCommand> commands = new NativeArray<OverlapSphereCommand>(halfSphereConfigs.Length, Allocator.TempJob);
            for (int i = 0; i < halfSphereConfigs.Length; i++)
            {
                commands[i] = new OverlapSphereCommand(halfSphereConfigs[i].Origin, halfSphereConfigs[i].Radius, _query);
            }
            
            int minCommandsPerJob = Mathf.Clamp(halfSphereConfigs.Length, 1, MaxCommandsPerJob);
            JobHandle handle = OverlapSphereCommand.ScheduleBatch(commands, results, minCommandsPerJob, DetectCount);

            await Waiter.WaitNonAlloc(handle, results, commands, _hits, block);
            
            for (int i = 0; i < _hits.Length; i++)
            {
                Collider col = _hits[i].collider;
                for (int j = 0; j < halfSphereConfigs.Length && col !=null; j++)
                {
                    JobOverlapHalfSphereConfig cfg = halfSphereConfigs[j];
                    
                    Vector3 dir = (col.transform.position - cfg.Origin).normalized;
                    if (Vector3.Dot(cfg.Direction.normalized, dir) >= 0f)
                    {
                        _colliders.Add(col);
                    }
                }
            }
            
            Collider[] ret = new Collider[_colliders.Count];
            _colliders.CopyTo(ret);
            _colliders.Clear();
            
            IsRunning = false;
            
            return ret;
        }

        public override async UniTask Execute(IJobOverlapConfig[] configs, Collider[] buffer, bool block = false)
        {
            IsRunning = true;

            if (_hits.Length < configs.Length * DetectCount)
            {
                _hits = null;
                _hits = new ColliderHit[configs.Length * DetectCount];
            }
            
            JobOverlapHalfSphereConfig[] halfSphereConfigs = new JobOverlapHalfSphereConfig[configs.Length];
            for (int i = 0; i < configs.Length; i++)
            {
                halfSphereConfigs[i] = (JobOverlapHalfSphereConfig)configs[i];
            }
            
            NativeArray<ColliderHit> results = new NativeArray<ColliderHit>(halfSphereConfigs.Length * DetectCount, Allocator.TempJob);
            NativeArray<OverlapSphereCommand> commands = new NativeArray<OverlapSphereCommand>(halfSphereConfigs.Length, Allocator.TempJob);
            for (int i = 0; i < halfSphereConfigs.Length; i++)
            {
                commands[i] = new OverlapSphereCommand(halfSphereConfigs[i].Origin, halfSphereConfigs[i].Radius, _query);
            }
            
            int minCommandsPerJob = Mathf.Clamp(halfSphereConfigs.Length, 1, MaxCommandsPerJob);
            JobHandle handle = OverlapSphereCommand.ScheduleBatch(commands, results, minCommandsPerJob, DetectCount);

            await Waiter.WaitNonAlloc(handle, results, commands, _hits, block);
            
            for (int i = 0; i < _hits.Length; i++)
            {
                Collider col = _hits[i].collider;
                for (int j = 0; j < halfSphereConfigs.Length && col !=null; j++)
                {
                    JobOverlapHalfSphereConfig cfg = halfSphereConfigs[j];
                    
                    Vector3 dir = (col.transform.position - cfg.Origin).normalized;
                    if (Vector3.Dot(cfg.Direction.normalized, dir) >= 0f)
                    {
                        _colliders.Add(col);
                    }
                }
            }

            if (buffer.Length < _colliders.Count)
            {
                Array.Resize(ref buffer, _colliders.Count);
            }
            _colliders.CopyTo(buffer);
            _colliders.Clear();
            
            IsRunning = false;
        }
    }
}
