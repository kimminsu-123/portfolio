using System;
using ProjectAAA.Core.Managers;
using ProjectAAA.SO;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace ProjectAAA.UI
{
    [ExecuteInEditMode]
    public class SkipUI : MonoBehaviour, IUIShow
    {
        private enum Status
        {
            Holding,
            Release,
        }

        public bool IsShow { get; private set; }

        public UnityEvent onCompleted;
        public TMP_Text helpText;
        
        [HideInInspector] public float pressDuration;
        [SerializeField] private Image pressImg;

        private Status _currentStatus;
        private float _accumTime;

        private void Awake()
        {
            SoundManager.Instance.SetBusVolume("MUSIC", 0.6f);
        }

        public void Show()
        {
            Release();

            gameObject.SetActive(true);
            IsShow = true;
        }

        public void Hide()
        {
            gameObject.SetActive(false);
            IsShow = false;
        }

        public void Hold()
        {
            _currentStatus = Status.Holding;
        }

        public void Release()
        {
            _accumTime = 0f;
            _currentStatus = Status.Release;
            pressImg.fillAmount = 0f;
        }

        private void Update()
        {
            if (_currentStatus != Status.Holding) return;
         
            _accumTime += Time.deltaTime;
            pressImg.fillAmount = _accumTime / pressDuration;
            
            if (_accumTime >= pressDuration)
            {
                onCompleted?.Invoke();
                Release();
            }
        }
    }
}