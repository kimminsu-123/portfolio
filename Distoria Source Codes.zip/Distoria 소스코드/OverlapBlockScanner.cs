using System;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using FMOD;
using ProjectAAA.Core.Managers;
using ProjectAAA.Core.OptimizedSensor;
using ProjectAAA.Core.Sensor;
using UnityEngine;

namespace ProjectAAA.Core.Scanner
{
    public class OverlapBlockScanner
    {
        public struct OverlapBlockScannerConfig
        {
            public LayerMask RangeLayerMask;
            public int RangeDetectCount;
            public float RangeRadius;
            public Func<Collider, bool> RangeFilter;
            public Func<Collider, Collider> RangeConverter;
            
            public LayerMask BlockLayerMask;
        }
        
        private readonly HashSet<Collider> _rangeHashSet = new();
        private readonly OverlapBlockScannerConfig _config;
        private readonly Collider[] _filteredCols;

        private readonly OptimizedOverlapSphereSensorData _rangeSensorData;
        private readonly OptimizedRaycastSensorData _blockSensorData;

        public OverlapBlockScanner(OverlapBlockScannerConfig config)
        {
            _config = config;
            
            _filteredCols = new Collider[_config.RangeDetectCount];

            _rangeSensorData = new OptimizedOverlapSphereSensorData(1, _config.RangeDetectCount);
            _blockSensorData = new OptimizedRaycastSensorData(_config.RangeDetectCount, _config.RangeDetectCount);
        }
        
        public async UniTask<Collider[]> ScanRange(Vector3 point)
        {
            for (int i = 0; i < _filteredCols.Length; i++)
            {
                _filteredCols[i] = null;
            }
            
            _rangeSensorData.SetModel(new OptimizedOverlapSphereSensorModel()
            {
                Origin = point,
                Radius = _config.RangeRadius,
                LayerMask = _config.RangeLayerMask,
            });
            
            PhysicsManager.Instance.AddOverlapSphereSensor(_rangeSensorData);
            await _rangeSensorData.Handle.Task;

            for (int i = 0; i < _rangeSensorData.Results.Length; i++)
            {
                Collider col = _rangeSensorData.Results[i].collider;
                
                // null 이 나왔다는 것은 이미 마지막 데이터까지 봤다는 것
                if (col == null)
                {
                    break;
                }
                
                if (_config.RangeConverter != null)
                {
                    Collider converted = _config.RangeConverter.Invoke(col);
                    
                    _rangeHashSet.Add(converted);
                }
                
                if (_config.RangeFilter != null)
                {
                    bool ret = _config.RangeFilter.Invoke(col);
                    if (ret)
                    {
                        _rangeHashSet.Add(col);
                    }
                }
            }
            
            int len = Mathf.Min(_filteredCols.Length, _rangeHashSet.Count);
            _rangeHashSet.CopyTo(_filteredCols, 0, len);
            _rangeHashSet.Clear();

            return _filteredCols;
        }
        
        public async UniTask<RaycastHit[]> ScanBlocked(Vector3 point, Collider[] others)
        {
            int count = 0;
            for (int i = 0; i < others.Length; i++)
            {
                if (others[i] == null)
                {
                    break;
                }
                count++;
            }
    
            // 전달 받은 Collider 가 전부 Null 이면 Blocked 를 돌릴 필요 없음
            if (count <= 0)
            {
                return null;
            }
            
            List<OptimizedRaycastSensorModel> models = new List<OptimizedRaycastSensorModel>(count);
            for (int i = 0; i < count; i++)
            {
                Collider other = others[i];
                Vector3 origin = point;
                Vector3 direction = other.transform.position - origin;
                float distance = direction.magnitude;
                
                models.Add(new OptimizedRaycastSensorModel()
                {
                    Origin = point,
                    Direction = direction.normalized,
                    Distance = distance,
                    LayerMask = _config.BlockLayerMask,
                });
            }
            _blockSensorData.SetModelRange(models);
            
            PhysicsManager.Instance.AddRaycast(_blockSensorData);
            await _blockSensorData.Handle.Task;

            return _blockSensorData.Results;
        }
    }
}