using System;
using ProjectAAA.Core.Managers;
using ProjectAAA.Interaction.Shop;
using ProjectAAA.SO;
using ProjectAAA.Utils.DataTable;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.UI.Shop
{
    public class ProductRow
    {
        public RewardData Reward;
        public Sprite Icon;
        public int Cost;
        public string Name;
        public string Description;
        public int RemainSellCount;
    }
    
    public class ShopUI : UiBase
    {
        public UnityEvent<ProductRow> onSuccessPurchase;

        [SerializeField] private FMODEventInfoSO hoverSound;
        [SerializeField] private FMODEventInfoSO buySound;
        [SerializeField] private TMP_Text shopTitleText;
        [SerializeField] private TMP_Text shopDescriptionText;
        
        protected override Type RegisterType => typeof(ShopUI);

        private UserProfileUI _userProfile;
        private ProductSlotUI[] _productSlots;
        private ProductDetailUI _productDetail;
        private DarkShopUI _darkShop;

        protected override void OnAwake()
        {
            _userProfile = GetComponentInChildren<UserProfileUI>(true);
            _productSlots = GetComponentsInChildren<ProductSlotUI>(true);
            _productDetail = GetComponentInChildren<ProductDetailUI>(true);
            _darkShop = GetComponentInChildren<DarkShopUI>(true);
        }

        private void Start()
        {
            Hide();
        }

        private void OnClickSlot(ProductRow productRow)
        {
            SoundManager.Instance.PlaySFX(buySound, gameObject.transform.position);
            onSuccessPurchase?.Invoke(productRow);
            UpdateUI(0);
        }

        private void OnHoverSlot(ProductRow rowData, PointerEventData eventData)
        {
            if (rowData == null)
            {
                return;
            }

            if (_productDetail == null)
            {
                return;
            }
         
            SoundManager.Instance.PlaySFX(hoverSound, gameObject.transform.position);
            _productDetail.Move(eventData.position);
            _productDetail.Setup(rowData);
            _productDetail.gameObject.SetActive(true);
        }

        private void OnMoveInSlot(ProductRow rowData, PointerEventData eventData)
        {
            if (_productDetail == null)
            {
                return;
            }
            
            _productDetail.Move(eventData.position);
        }

        private void OnUnHoverSlot(ProductRow rowData, PointerEventData eventData)
        {
            if (_productDetail == null)
            {
                return;
            }
            
            _productDetail.gameObject.SetActive(false);
        }

        private void SelectAvailableSlot()
        {
            for (int i = 0; i < _productSlots.Length; i++)
            {
                if (_productSlots[i].Select())
                {
                    break;
                }
            }
        }

        public override void Show()
        {
            if (_productDetail != null)
            {
                _productDetail.gameObject.SetActive(false); 
            }
            SelectAvailableSlot();
            
            gameObject.SetActive(true);
        }

        public override void Hide()
        {
            for (int i = 0; i < _productSlots.Length; i++)
            {
                _productSlots[i].onClick.RemoveListener(OnClickSlot);
                _productSlots[i].onPointerEnter.RemoveListener(OnHoverSlot);
                _productSlots[i].onPointerMove.RemoveListener(OnMoveInSlot);
                _productSlots[i].onPointerExit.RemoveListener(OnUnHoverSlot);
            }
            _userProfile.Disable();
            
            gameObject.SetActive(false);
        }

        public void UpdateUI(int v)
        {
            _productDetail.UpdateDetail();
            for (int i = 0; i < _productSlots.Length; i++)
            {
                _productSlots[i].UpdateSlot();
            }

            SelectAvailableSlot();
        }

        public void Setup(ShopEntryData data)
        {
            for (int idx = 0; idx < data.ProductRows.Count; idx++)
            {
                if (data.ProductRows[idx] == null)
                {
                    _productSlots[idx].gameObject.SetActive(false);
                    continue;
                }
                
                _productSlots[idx].gameObject.SetActive(true);
                _productSlots[idx].Setup(data.ProductRows[idx]);
                _productSlots[idx].onClick.AddListener(OnClickSlot);
                _productSlots[idx].onPointerEnter.AddListener(OnHoverSlot);
                _productSlots[idx].onPointerMove.AddListener(OnMoveInSlot);
                _productSlots[idx].onPointerExit.AddListener(OnUnHoverSlot);
            }

            shopTitleText.text = data.Title;
            shopDescriptionText.text = data.Description;
            
            _userProfile.Enable();
            _darkShop.Setup(data.QuestTxt, data.QuestStatus);
        }
    }
}