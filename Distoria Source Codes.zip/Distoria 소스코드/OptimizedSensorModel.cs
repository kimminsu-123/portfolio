using UnityEngine;

namespace ProjectAAA.Core.OptimizedSensor
{
    public struct OptimizedRaycastSensorModel
    {
        public Vector3 Origin { get; set; }
        public Vector3 Direction { get; set; }
        public LayerMask LayerMask { get; set; }
        public float Distance { get; set; }
    }

    public struct OptimizedSphereCastSensorModel
    {
        public Vector3 Origin { get; set; }
        public Vector3 Direction { get; set; }
        public LayerMask LayerMask { get; set; }
        public float Radius { get; set; }
        public float Distance { get; set; }
    }

    public struct OptimizedOverlapSphereSensorModel
    {
        public Vector3 Origin { get; set; }
        public LayerMask LayerMask { get; set; }
        public float Radius { get; set; }
    }
    
    public struct OptimizedOverlapBoxSensorModel
    {
        public Vector3 Origin { get; set; }
        public LayerMask LayerMask { get; set; }
        public Vector3 HalfExtents { get; set; }
        public Quaternion Orientation { get; set; }
    }

    public struct OptimizedOverlapSectorSensorModel
    {
        public Vector3 Origin { get; set; }
        public Vector3 Direction { get; set; }
        public LayerMask LayerMask { get; set; }
        public float Radius { get; set; }
        public float Angle { get; set; }
    }
}