using System.Collections.Generic;
using Newtonsoft.Json;
using ProjectAAA.Utils.DataTable;
using ProjectAAA.WeaponSystem;
using Unity.AppUI.Core;
using UnityEngine;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.SO
{
    [CreateAssetMenu(fileName = "BulletAbilityTableSO", menuName = "Scriptable Objects/DataTable/BulletAbilityTableSO",
        order = 0)]
    public class BulletAbilityTableSO : DataTableSO
    {
        private Dictionary<int, BulletAbilityData> _bulletAbilityData;

        protected override void FromJson(string json)
        {
            List<BulletAbilityData> list = JsonConvert.DeserializeObject<List<BulletAbilityData>>(json);

            Logger.Assert(list != null, "BulletAbilityTable", "탄알 특수능력 데이터 테이블이 비어있습니다.");

            _bulletAbilityData = new Dictionary<int, BulletAbilityData>(list.Count);
            foreach (BulletAbilityData data in list)
            {
                _bulletAbilityData.TryAdd(data.AbilityID, data);
            }
        }

        public BulletHitAbility CreateHitAbility(int abilityId, BulletHitHandler handler)
        {
            BulletHitAbility ret = new BulletHitNone(handler);

            if (_bulletAbilityData.TryGetValue(abilityId, out BulletAbilityData data))
            {
                if ((data.AbilityFlag & BulletAbilityFlag.Penetration) != 0)
                {
                    ret.SetNext(new BulletPenetration(handler, data.PenetrationMaxCount));
                }

                if ((data.AbilityFlag & BulletAbilityFlag.Ricochet) != 0)
                {
                    ret.SetNext(new BulletRicochet(handler, data.RicochetType, data.RicochetCount,
                        data.RicochetRadius));
                }
            }

            return ret;
        }

        public BulletDestroyAbility CreateDestroyAbility(int abilityId, BulletBase bullet)
        {
            BulletDestroyAbility ret = new BulletDestroyNone();

            if (_bulletAbilityData.TryGetValue(abilityId, out BulletAbilityData data))
            {
                if ((data.AbilityFlag & BulletAbilityFlag.GenerateProjectile) != 0)
                {
                    ret.SetNext(new BulletGenerateBullets(bullet, data.AddBulletCondition, data.AddBulletId,
                        data.AddBulletCount, data.AddBulletDirection, data.AddBulletRadius));
                }

                if ((data.AbilityFlag & BulletAbilityFlag.Explosion) != 0)
                {
                    ret.SetNext(new BulletExplosion(bullet,
                        data.AddBulletCondition, data.ExplosionRadius, data.ExplosionMinDamage,
                        data.ExplosionMaxDamage, data.ExplosionCameraShakeRadius, data.ExplosionCameraShakeValue));
                }
            }

            return ret;
        }

        public bool HasAbility(int abilityId)
        {
            if (abilityId == 0) return false;

            bool ret = _bulletAbilityData.TryGetValue(abilityId, out BulletAbilityData bulletAbilityData);
            if (ret)
            {
                ret &= bulletAbilityData.AbilityFlag != BulletAbilityFlag.None;
            }

            return ret;
        }
    }
}