using System;
using System.Collections.Generic;
using Amazon.Runtime.Internal;
using DG.Tweening;
using NaughtyAttributes;
using ProjectAAA.Core.Managers;
using ProjectAAA.Core.Scene.Manager;
using ProjectAAA.Interaction;
using ProjectAAA.Player;
using ProjectAAA.Player.Actions;
using ProjectAAA.SO.Pool;
using ProjectAAA.Utils;
using UnityEngine;
using UnityEngine.InputSystem.HID;
using UnityEngine.UI;
using EventType = ProjectAAA.Core.Managers.EventType;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.UI
{
    public class MinimapUI : UiBase
    {
        public bool IsValid => _cachedRegion != null;
        
        protected override Type RegisterType => typeof(MinimapUI);

        [SerializeField] private ObjectPoolSO radarPool;
        [SerializeField] private ObjectPoolSO targetPointPool;
        [SerializeField] private RectTransform cachedRectTr;
        [SerializeField] private float defaultZoom = 0.832f;
        [SerializeField, MinMaxSlider(0f, 0.99f)] private Vector2 zoomMinMax = new(0f, 0.9f);
        [SerializeField] private AnimationCurve zoomCurve;
        [SerializeField] private float increaseZoomAmount = 0.04f;
        
        private RectTransform _rootRectTr;
        private Image _cachedImage;
        private Dictionary<int, MinimapRadar> _radars;
        private Dictionary<int, MinimapTargetPoint> _targetPoints;
        private MinimapRegion _cachedRegion;
        private Transform _mainTransform;
        private Tweener _zoomTweener;
        
        private static readonly int MinimapTexture = Shader.PropertyToID("_MinimapTexture");
        private static readonly int PlayerPos = Shader.PropertyToID("_PlayerPos");
        private static readonly int Zoom = Shader.PropertyToID("_Zoom");

        private bool IsKeydownZoomIn => PlayerActionController.PlayerInput.GamePlay.MinimapZoomIn.WasPerformedThisFrame();
        private bool IsKeydownZoomOut => PlayerActionController.PlayerInput.GamePlay.MinimapZoomOut.WasPerformedThisFrame();

        protected override void OnAwake()
        {
            _rootRectTr = transform as RectTransform;
            _cachedImage = cachedRectTr.GetComponent<Image>();
            _mainTransform = PlayerManager.Instance.PlayerGo.transform;
            _cachedImage.material = _cachedImage.material.CopyMaterial();
            _cachedImage.material.SetFloat(Zoom, defaultZoom);

            _radars = new AutoConstructedDictionary<int, MinimapRadar>();
            _targetPoints =  new Dictionary<int, MinimapTargetPoint>();
            
            EventManager.Instance.AddListener(EventType.OnBeginLoadSceneGroup, OnBeginScene);
            EventManager.Instance.AddListener(EventType.OnEndLoadSceneGroup, OnEndScene);
            
            gameObject.SetActive(false);
        }

        private void Update()
        {
            if (IsKeydownZoomIn)
            {
                ZoomIn();
            }

            if (IsKeydownZoomOut)
            {
                ZoomOut();
            }
            
            foreach (MinimapRadar radar in _radars.Values)
            {
                if (!radar.gameObject.activeSelf)
                {
                    radar.gameObject.SetActive(true);
                }
                radar.UpdateRadar();
            }
            
            foreach (MinimapTargetPoint targetPoint in _targetPoints.Values)
            {
                if (!targetPoint.gameObject.activeSelf)
                {
                    targetPoint.gameObject.SetActive(true);
                }
                targetPoint.UpdatePosition(_rootRectTr.sizeDelta.y, _cachedRegion.Rect.height, _cachedImage.material.GetFloat(Zoom));
            }
        }

        private void OnBeginScene(Component sender, object[] args)
        {
            if (_radars != null)
            {
                foreach (MinimapRadar radar in _radars.Values)
                {
                    radar.SelfReturn();
                }
                _radars.Clear();    
            }

            if (_targetPoints != null)
            {
                foreach (MinimapTargetPoint targetPoint in _targetPoints.Values)
                {
                    targetPoint.SelfReturn();
                }

                _targetPoints.Clear();
            }
        }
        
        private void OnEndScene(Component sender, object[] args)
        {
            _cachedRegion = FindFirstObjectByType<MinimapRegion>(FindObjectsInactive.Include);
            
            Logger.Log("MinimapUI", $"OnEndScene : {_cachedRegion}");

            gameObject.SetActive(_cachedRegion != null);
            if (_cachedRegion)
            {
                SetMinimapTexture(_cachedRegion.MinimapTexture);
            }
        }
        
        public void AddRadar(Transform dest, MinimapRadarData data)
        {
            int hash = dest.GetHashCode();

            if (!_radars.ContainsKey(hash))
            {
                MinimapRadar radar = radarPool.Get<MinimapRadar>(cachedRectTr);
                radar.SetOriginPool(radarPool);
                radar.onSelfRelease.AddListener(OnEndDuration);
                radar.gameObject.SetActive(false);
                
                _radars.Add(hash, radar);
            }
            
            _radars[hash].Setup(_mainTransform, dest, data);
        }

        public void RemoveRadar(Transform dest)
        {
            int hash = dest.GetHashCode();
            if (_radars.Remove(hash, out MinimapRadar radar))
            {
                radar.SelfReturn();
            }
        }

        public bool HasRadar(Transform dest)
        {
            return _radars.ContainsKey(dest.GetHashCode());
        }
        
        public void AddTargetPoint(Transform dest, MinimapTargetPointData data)
        {
            int hash = dest.GetHashCode();

            if (!_targetPoints.ContainsKey(hash))
            {
                MinimapTargetPoint point = targetPointPool.Get<MinimapTargetPoint>(cachedRectTr);
                point.transform.SetAsFirstSibling();
                point.SetScale(Vector3.one);
                point.SetOriginPool(targetPointPool);
                point.gameObject.SetActive(false);
                
                _targetPoints.Add(hash, point);
            }
            
            _targetPoints[hash].Setup(_mainTransform, dest, data);
        }
        
        public void RemoveTargetPoint(Transform dest)
        {
            int hash = dest.GetHashCode();
            if (_targetPoints.Remove(hash, out MinimapTargetPoint point))
            {
                point.SelfReturn();
            }
        }        

        public bool HasTargetPoint(Transform dest)
        {
            return _targetPoints.ContainsKey(dest.GetHashCode());
        }
        
        public bool IsInMinimapBoundary(Transform from)
        {
            if (_cachedRegion == null) return false;
            
            Vector3 dir = from.position - _mainTransform.position;
            float worldDistance = new Vector2(dir.x, dir.z).magnitude;

            float zoom = _cachedImage.material.GetFloat(Zoom);
            float scale = _rootRectTr.sizeDelta.y / _cachedRegion.Rect.height;
            float uiDistance = worldDistance * (scale * (1f / (1f - zoom)));

            return uiDistance <= _rootRectTr.sizeDelta.y * 0.5f;
        }
        
        private void OnEndDuration(int hash)
        {
            _radars[hash].onSelfRelease.RemoveListener(OnEndDuration);
            _radars.Remove(hash);
        }

        public void SetMinimapTexture(Texture2D texture)
        {
            _cachedImage.material.SetTexture(MinimapTexture, texture);
        }
        
        public void Rotate(Quaternion rotation)
        {
            cachedRectTr.rotation = Quaternion.Euler(0f, 0f, rotation.eulerAngles.y); 
        }

        public void Translate(Vector3 position)
        {
            _cachedImage.material.SetVector(PlayerPos, new Vector4(position.x, position.z));
        }

        public void ZoomIn()
        {
            _zoomTweener?.Kill();
            
            float curValue = _cachedImage.material.GetFloat(Zoom);
            float nextValue = Mathf.Min(curValue + increaseZoomAmount, zoomMinMax.y);
            
            _zoomTweener = _cachedImage.material
                .DOFloat(nextValue, Zoom, 0.3f)
                .SetEase(zoomCurve)
                .SetAutoKill(true)
                .Play();
        }

        public void ZoomOut()
        {
            _zoomTweener?.Kill();
            
            float curValue = _cachedImage.material.GetFloat(Zoom);
            float nextValue = Mathf.Max(curValue - increaseZoomAmount, zoomMinMax.x);

            _cachedImage.material
                .DOFloat(nextValue, Zoom, 0.3f)
                .SetEase(zoomCurve)
                .SetAutoKill(true)
                .Play();
        }
    }
}