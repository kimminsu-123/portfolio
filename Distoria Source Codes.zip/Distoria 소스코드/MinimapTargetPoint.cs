using System;
using NaughtyAttributes;
using ProjectAAA.Core.Pool;
using ProjectAAA.Utils;
using UnityEngine;
using UnityEngine.UI;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.UI
{
    [Serializable]
    public class MinimapTargetPointData
    {
        public Sprite OverrideIcon; 
        public Color ImgColor = Color.white;
        public float ImgSize = 11.392f;
    }
    
    public class MinimapTargetPoint : PoolObjMonoBehaviour
    {
        [SerializeField] private Image image;

        // 회전 및 Height 조절이 필요해보임
        private RectTransform _rootRectTr;
        private Transform _sourceTr;
        private Transform _destTr;
        private MinimapTargetPointData _data;
        private Sprite _defaultSprite;

        private void Awake()
        {
            _rootRectTr = transform as RectTransform;
            
            _defaultSprite = image.sprite;
        }

        public void Setup(Transform src, Transform dst, MinimapTargetPointData data)
        {
            _sourceTr = src;
            _destTr = dst;
            _data = data;

            image.sprite = _data.OverrideIcon != null ? data.OverrideIcon : _defaultSprite;
            image.color = _data.ImgColor;
            image.rectTransform.sizeDelta = Vector2.one * data.ImgSize;
        }
        
        public void UpdatePosition(float rectHeight, float worldHeight, float zoom)
        {
            float angle = _sourceTr.GetAngleY(_destTr);
            _rootRectTr.localRotation = Quaternion.Euler(new  Vector3(0f, 0f, -angle));
            
            Vector3 dir = _destTr.position - _sourceTr.position;
            float worldDistance = new Vector2(dir.x, dir.z).magnitude;
            float scale = rectHeight / worldHeight;
            float uiDistance = worldDistance * (scale * (1f / (1f - zoom)));
            
            Vector2 size = image.rectTransform.sizeDelta;
            size.y = uiDistance;
            _rootRectTr.sizeDelta = size;
        }
    }
}