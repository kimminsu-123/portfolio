using ProjectAAA.Utils;
#if UNITY_EDITOR
using UnityEditor;
#endif
using UnityEngine.Playables;
using UnityEngine.SceneManagement;

namespace ProjectAAA.Timeline
{
    public class LoadSceneBehaviour : PlayableBehaviour
    {
        public SceneReference Scene;

        private bool _isLoaded;

        public override void OnGraphStart(Playable playable)
        {
            _isLoaded = false;
        }

        public override void OnBehaviourPlay(Playable playable, FrameData info)
        {
            #if UNITY_EDITOR
            if (!EditorApplication.isPlaying) return;
            #endif
            if (Scene != null && !_isLoaded)
            {
                SceneManager.LoadScene(Scene.BuildIndex);
            
                _isLoaded = true;    
            }
        }
    }
}