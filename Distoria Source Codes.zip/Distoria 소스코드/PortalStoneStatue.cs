using ProjectAAA.Interaction;
using ProjectAAA.UI.Statue;
using ProjectAAA.Utils;

namespace ProjectAAA.Interactables.Statue
{
    public class PortalStoneStatue : StoneStatue
    {
        protected override StatueConditionUI ConditionUI => null;
        protected override IPredicate AcceptCondition => null;
        protected override IPredicate DenyCondition => null;

        private Portal _cachedPortal;

        protected override void Awake()
        {
            base.Awake();

            _cachedPortal = GetComponentInChildren<Portal>(true);
        }

        protected override void OnAccept()
        {
            _cachedPortal.Interact(CachedGo);
        }

        protected override void OnDeny()
        {
        }
    }
}