using System.Collections.Generic;
using Newtonsoft.Json;
using ProjectAAA.Utils.DataTable;
using UnityEngine;

namespace ProjectAAA.SO.Debug
{    
    [CreateAssetMenu(fileName = "RangeDebugDataGroup", menuName = "Scriptable Objects/DataTable/Debug/Range")]
    public class RangeDebugDataGroup : DebugDataGroup
    {
        [SerializeField] private List<RangeData> ranges;
        
        protected override void FromJson(string json)
        {
            ranges.Clear();
            ranges = JsonConvert.DeserializeObject<List<RangeData>>(json);
        }

        public override string ToJson()
        {
            return JsonConvert.SerializeObject(ranges);
        }
    }
}