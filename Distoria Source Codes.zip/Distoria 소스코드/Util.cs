using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using FMOD.Studio;
using FMODUnity;
using ProjectAAA.Utils.DataTable;
using UnityEngine;
using Random = UnityEngine.Random;

namespace ProjectAAA.Utils
{
    public class RaycastHitComparer : IComparer<RaycastHit>
    {
        public int Compare(RaycastHit x, RaycastHit y)
        {
            return x.distance.CompareTo(y.distance);
        }
    }
    
    public class ColliderDistanceComparer : IComparer<Collider>
    {
        public Vector3 Origin;
        
        public int Compare(Collider x, Collider y)
        {
            if (ReferenceEquals(x, y)) return 0;
            if (y is null) return -1;
            if (x is null) return 1;

            float distX = Vector3.Distance(Origin, x.transform.position);
            float distY = Vector3.Distance(Origin, y.transform.position);

            return distX.CompareTo(distY);
        }
    }
    
    public static class Util
    {
        public static string AESEncrypt128(string key, string txt)
        {
            byte[] plainBytes = Encoding.UTF8.GetBytes(txt);

            RijndaelManaged rijndael = new RijndaelManaged();
            rijndael.Mode = CipherMode.CBC;
            rijndael.Padding = PaddingMode.PKCS7;
            rijndael.KeySize = 128;
            ICryptoTransform encryptor = rijndael.CreateEncryptor(Encoding.UTF8.GetBytes(key), Encoding.UTF8.GetBytes(key));

            using MemoryStream memoryStream = new MemoryStream();
            using CryptoStream cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write);
            cryptoStream.Write(plainBytes, 0, plainBytes.Length);
            cryptoStream.FlushFinalBlock();

            return Convert.ToBase64String(memoryStream.ToArray());
        }

        //복호화
        public static string AESDecrypt128(string key, string txt)
        {
            byte[] encryptBytes = Convert.FromBase64String(txt);

            RijndaelManaged rijndael = new RijndaelManaged();
            rijndael.Mode = CipherMode.CBC;
            rijndael.Padding = PaddingMode.PKCS7;
            rijndael.KeySize = 128;
            ICryptoTransform decryptor = rijndael.CreateDecryptor(Encoding.UTF8.GetBytes(key), Encoding.UTF8.GetBytes(key));

            using MemoryStream memoryStream = new MemoryStream(encryptBytes);
            using CryptoStream cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read);

            byte[] plainBytes = new byte[encryptBytes.Length];
            int plainCount = cryptoStream.Read(plainBytes, 0, plainBytes.Length);
            
            return Encoding.UTF8.GetString(plainBytes, 0, plainCount);
        }

        public static bool ApproximatelyFloats(float a, float b)
        {
            return Math.Abs(a - b) < float.Epsilon;
        }
        
        public static bool ApproximatelyVector3(Vector3 a, Vector3 b)
        {
            bool ret = ApproximatelyFloats(a.x, b.x);
            ret &= ApproximatelyFloats(a.y, b.y);
            ret &= ApproximatelyFloats(a.z, b.z);

            return ret;
        }
        
        public static bool ApproximatelyVector2(Vector2 a, Vector2 b)
        {
            bool ret = ApproximatelyFloats(a.x, b.x);
            ret &= ApproximatelyFloats(a.y, b.y);

            return ret;
        }

        public static bool HasFlag(int source, int target)
        {
            return (source & (1 << target)) > 0;
        }        
        
        public static void SpringDamping(ref Vector3 current, ref Vector3 velocity, Vector3 target, float halfLife,
            float frequency, float timeStep)
        {
            var dampingRatio = -Mathf.Log(0.5f) / (frequency * halfLife);
            var f = 1.0f + 2.0f * timeStep * dampingRatio * frequency;
            var oo = frequency * frequency;
            var hoo = timeStep * oo;
            var hhoo = timeStep * hoo;
            var detInv = 1.0f / (f + hhoo);
            var detX = f * current + timeStep * velocity + hhoo * target;
            var detV = velocity + hoo * (target - current);
            current = detX * detInv;
            velocity = detV * detInv;
        }
        
        public static PARAMETER_ID GetParameterId(EventReference eventReference, string parameterName)
        {
            if (eventReference.IsNull)
            {
                return default;
            }

            var description = RuntimeManager.GetEventDescription(eventReference);
            description.getParameterDescriptionByName(parameterName, out var parameterDescription);
            return parameterDescription.id;
        }

        public static RewardData GetRandomizeItem(List<RewardData> dataList)
        {
            //sort
            List<RewardData> tempList = dataList.OrderBy(entry => entry.Value1).ToList();

            //get pivot
            int totalQuantity = 0;
            foreach (RewardData data in tempList)
            {
                totalQuantity += data.Value1;
            }
            
            //set target value(random)
            int radomVal= Random.Range(0, totalQuantity + 1);
            Logger.Log("Radom pivot", radomVal.ToString());
            
            //get random item
            int pivot = 0;
            
            foreach (RewardData data in tempList)
            {
                pivot += data.Value1;
                if (pivot >= radomVal)
                {
                    return data;
                }
            }
            
            //not in dataList, return-first value.
            return null;
        }
    }
}