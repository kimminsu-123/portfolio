using System.IO;
using UnityEditor;
using UnityEditor.Build.Profile;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace ProjectAAA.Editor
{
    public class AllProfileBuilder
    {
        [MenuItem("Build/Build All Include Cheat Profiles (Debug + Release)")]
        public static void BuildAllYesCheat()
        {
            Debug.ClearDeveloperConsole();
            
            Build("Assets/Settings/Build Profiles/Windows_Release.asset", $"Build/Release", false);
            Build("Assets/Settings/Build Profiles/Windows_Debug.asset", $"Build/Develop", false);
        }
        
        [MenuItem("Build/Clean Build All Include Cheat Profiles (Debug + Release)")]
        public static void CleanBuildAllYesCheat()
        {
            Debug.ClearDeveloperConsole();
            
            Build("Assets/Settings/Build Profiles/Windows_Release.asset", $"Build/Release", true);
            Build("Assets/Settings/Build Profiles/Windows_Debug.asset", $"Build/Develop", true);
        }
        
        [MenuItem("Build/Build All No Cheat Profiles (Debug + Release)")]
        public static void BuildAllNoCheat()
        {
            Debug.ClearDeveloperConsole();
            
            Build("Assets/Settings/Build Profiles/Windows_NoCheat_Release.asset", $"Build/No_Cheat_Release", false);
            Build("Assets/Settings/Build Profiles/Windows_NoCheat_Debug.asset", $"Build/No_Cheat_Develop", false);
        }
        
        [MenuItem("Build/Clean Build All No Cheat Profiles (Debug + Release)")]
        public static void CleanBuildAllNoCheat()
        {
            Debug.ClearDeveloperConsole();
            
            Build("Assets/Settings/Build Profiles/Windows_NoCheat_Release.asset", $"Build/No_Cheat_Release", true);
            Build("Assets/Settings/Build Profiles/Windows_NoCheat_Debug.asset", $"Build/No_Cheat_Develop", true);
        }
        
        [MenuItem("Build/Build All Profiles (Debug + Release) - (Cheat & Non-Cheat)")]
        public static void BuildAll()
        {
            Debug.ClearDeveloperConsole();
            
            Build("Assets/Settings/Build Profiles/Windows_NoCheat_Release.asset", $"Build/No_Cheat_Release", false);
            Build("Assets/Settings/Build Profiles/Windows_NoCheat_Debug.asset", $"Build/No_Cheat_Develop", false);
            Build("Assets/Settings/Build Profiles/Windows_Release.asset", $"Build/Release", false);
            Build("Assets/Settings/Build Profiles/Windows_Debug.asset", $"Build/Develop", false);
        }
        
        [MenuItem("Build/Clean Build All Profiles (Debug + Release) - (Cheat & Non-Cheat)")]
        public static void CleanBuildAll()
        {
            Debug.ClearDeveloperConsole();
            
            Build("Assets/Settings/Build Profiles/Windows_NoCheat_Release.asset", $"Build/No_Cheat_Release", true);
            Build("Assets/Settings/Build Profiles/Windows_NoCheat_Debug.asset", $"Build/No_Cheat_Develop", true);
            Build("Assets/Settings/Build Profiles/Windows_Release.asset", $"Build/Release", true);
            Build("Assets/Settings/Build Profiles/Windows_Debug.asset", $"Build/Develop", true);
        }

        private static void Build(string assetPath, string path, bool isClean)
        {
            BuildProfile profile = AssetDatabase.LoadAssetAtPath<BuildProfile>(assetPath);
            
            if (profile == null)
            {
                Debug.Log($"{assetPath} - Build Failed : Profile is null");
                return;
            }
            
            Debug.Log($"{profile.name} Start Build To {path}, CleanBuild : {isClean}");
            
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory($"./{path}");
            }
            
            BuildPlayerWithProfileOptions options = new BuildPlayerWithProfileOptions
            {
                buildProfile = profile,
                locationPathName = Path.Combine(path, "Distoria.exe"),
            };

            if (isClean)
            {
                options.options = BuildOptions.CleanBuildCache;
            }
            
            BuildReport report = BuildPipeline.BuildPlayer(options);

            if (report.summary.result == BuildResult.Succeeded)
            {
                Debug.Log($"Build Complete - {profile.name} / start to end : {report.summary.buildStartedAt} - {report.summary.buildEndedAt} total Time : {report.summary.totalTime}");
            }
            else
            {
                Debug.Log($"Build Failed - {profile.name} - {report.summary.result}");
            }
        }
    }
}