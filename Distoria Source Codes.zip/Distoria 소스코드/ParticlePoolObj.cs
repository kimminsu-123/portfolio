using ProjectAAA.Core.Pool;
using UnityEngine;

namespace ProjectAAA.Core
{
    public class ParticlePoolObj : PoolObjMonoBehaviour
    {
        protected ParticleSystem[] Particles { get; private set; }
        
        private int _cnt;
        private bool _releaseOnComplete;

        private void Awake()
        {
            Particles = GetComponentsInChildren<ParticleSystem>(true);

            ParticleSystem.MainModule main = Particles[0].main;
            main.stopAction = ParticleSystemStopAction.Callback;
            
            OnAwake();
        }

        protected virtual void OnAwake()
        {
            
        }

        /// <summary>
        /// 파티클을 종료합니다
        /// </summary>
        /// <param name="release">Stop 이 완료된 경우 파티클을 Pool로 되돌릴지 여부</param>
        public void Stop(bool release = true)
        {
            _cnt = 0;
            _releaseOnComplete = release;

            for (int i = 0; i < Particles.Length; i++)
            {
                if (Particles[i].main.startLifetime.constantMax > 50f)
                {
                    Particles[i].Clear();
                }
                Particles[i].Stop();
            }
        }
        
        /// <summary>
        /// 파티클 입자를 클리어 합니다.
        /// </summary>
        /// <param name="release">Stop 이 완료된 경우 파티클을 Pool로 되돌릴지 여부</param>
        public void Clear(bool release = true)
        {
            _cnt = 0;
            _releaseOnComplete = release;

            for (int i = 0; i < Particles.Length; i++)
            {
                Particles[i].Clear();
            }

            OnParticleSystemStopped();
        }

        /// <summary>
        /// 파티클을 실행합니다
        /// </summary>
        /// <param name="cnt">플레이 횟수를 의미 -1은 무한루프를 의미</param>
        /// <param name="restart">재생이 될 때 재시작할지 여부</param>
        /// <param name="releaseOnComplete">파티클이 끝나면 자동으로 Pool 로 되돌아갈지 여부</param>
        public void Play(bool restart = true, bool releaseOnComplete = true, int cnt = 1)
        {
            gameObject.SetActive(true);

            _releaseOnComplete = releaseOnComplete;
            _cnt = cnt;

            for (int i = 0; i < Particles.Length; i++)
            {
                if (restart)
                {
                    Particles[i].Simulate(0f, true, true, false);
                }

                Particles[i].Play();
            }
        }

        private void OnParticleSystemStopped()
        {
            if (_cnt == -1)
            {
                return;
            }
            
            if (--_cnt > 0)
            {
                Play(true, _releaseOnComplete, _cnt);
            }
            else
            {
                if (_releaseOnComplete)
                {
                    SelfReturn();
                }
                else
                {
                    gameObject.SetActive(false);
                }
            }   
        }
    }
}