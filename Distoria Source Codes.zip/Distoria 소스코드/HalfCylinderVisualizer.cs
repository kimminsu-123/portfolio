using System;
using ProjectAAA.Core.Managers;
using ProjectAAA.Mob.Normal;
using ProjectAAA.SO;
using ProjectAAA.Utils.DataTable;
using ProjectAAA.Utils.Visualizer;
using UnityEditor;
using UnityEngine;

[ExecuteAlways]
public class HalfCylinderVisualizer : Visualizer
{
    private MonsterBase _monsterBase;

    public float radius = 3f;
    public float height = 1f;
    
    private void Awake()
    {
        _monsterBase = GetComponent<MonsterBase>();
    }

    private void Update()
    {
        if (_monsterBase != null && _monsterBase.CurrentSkill != null)
        {
            radius = _monsterBase.CurrentSkill.RangeData.Value1;
        }
    }
}

#if UNITY_EDITOR
[CustomEditor(typeof(HalfCylinderVisualizer))]
public class DrawHalfCylinderVisualizer : Editor
{
    private void OnSceneGUI()
    {
        HalfCylinderVisualizer inst = (HalfCylinderVisualizer)target;
        Handles.color = inst.gizmosColor;
        Vector3 center = inst.transform.position + Vector3.up * inst.height;
        Handles.DrawWireArc(center, Vector3.up, -inst.transform.right, 180, inst.radius);
    }
}
#endif

