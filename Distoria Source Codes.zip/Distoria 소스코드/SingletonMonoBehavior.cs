using UnityEngine;

namespace ProjectAAA.Utils
{
    public abstract class SingletonMonoBehavior<T> : MonoBehaviour where T : MonoBehaviour
    {
        private static T _instance;

        public static T Instance
        {
            get
            {
                if (_instance != null)
                {
                    return _instance;
                }

                _instance = FindFirstObjectByType<T>();

                if (_instance != null)
                {
                    return _instance;
                }

                var findGo = GameObject.Find(typeof(T).Name);

                if (findGo != null)
                {
                    _instance = findGo.AddComponent<T>();
                }
                else
                {
                    _instance = CreateSingleton();
                }

                return _instance;
            }
        }

        private static T CreateSingleton()
        {
            var goName = typeof(T).Name;
            var singleton = new GameObject(goName);
            var component = singleton.AddComponent<T>();

            return component;
        }

        private void Awake()
        {
            Initialize();
        }

        protected virtual void OnDestroy()
        {
            if (_instance == null)
            {
                return;
            }

            if (_instance.GetHashCode().Equals(GetHashCode()))
            {
                _instance = null;
            }
        }

        protected virtual void Initialize() { }
    }
}