using System;
using Amazon.Runtime.Internal.Util;

namespace ProjectAAA.Utils
{
    public class DisposeBase : IDisposable
    {
        private bool _disposed;

        protected DisposeBase()
        {
            _disposed = false;
        }
        
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    DisposeManagedResources();
                }
                DisposeNotManagedResources();
                _disposed = true;  
            }
        }

        /// <summary>
        /// 관리 리소스 해제를 담당하는 함수
        /// </summary>
        protected virtual void DisposeManagedResources()
        {
            
        }

        /// <summary>
        /// 비관리 리소스 해제를 담당하는 함수
        /// </summary>
        protected virtual void DisposeNotManagedResources()
        {
            
        }
    }
}