using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using Color = UnityEngine.Color;
using FontStyle = UnityEngine.FontStyle;
using Object = UnityEngine.Object;

namespace ProjectAAA.Editor.FBXImporter
{
    public class FBXSelection : IComparable<FBXSelection>
    {
        public Action<FBXSelection> OnChangedIsInclude;
        public ModelImporter NewModelImporter { get; private set; }
        public List<AnimationClip> Clips { get; private set; }
        public string SrcFilePath { get; private set; }
        public string SrcFileName { get; private set; }
        public string SrcFullPath => $"{SrcFilePath}{SrcFileName}";
        public string SrcAssetPath => SrcFullPath.Substring(SrcFullPath.IndexOf("Assets", StringComparison.Ordinal));

        public string CopiedFilePath { get; private set; }
        public string CopiedFileName { get; private set; }
        public string CopiedFullPath => $"{CopiedFilePath}{CopiedFileName}";
        public string CopiedAssetPath => CopiedFullPath.Substring(CopiedFullPath.IndexOf("Assets", StringComparison.Ordinal));

        public bool IsRootMotion { get; set; }

        public bool IsIncluded
        {
            set
            {
                if (_curIsIncluded != value)
                {
                    _curIsIncluded = value;
                    OnChangedIsInclude?.Invoke(this);
                }
            }
            get => _curIsIncluded;
        }
        
        private bool _curIsIncluded;

        public FBXSelection(string path)
        {
            string[] split = path.Split('\\');
            int lastIndex = split.Length - 1;
            string fileName = split[lastIndex];

            split[lastIndex] = string.Empty;
            
            NewModelImporter = null;
            Clips = new List<AnimationClip>();
            
            SrcFilePath = string.Join('\\', split);
            SrcFileName = fileName;
            CopiedFilePath = string.Empty;
            CopiedFileName = string.Empty;

            IsRootMotion = false;
            IsIncluded = false;
        }

        public bool CopyTo(string destPath, string destName)
        {
            CopiedFilePath = destPath;
            CopiedFileName = destName;
            
            string destination = $"{destPath}{destName}";
            string srcPath = $"{SrcFilePath}{SrcFileName}";
            try
            {
                File.Copy(srcPath, destination, true);
            }
            catch (Exception ex)
            {
                Debug.LogException(ex);
                return false;
            }

            return true;
        }

        public bool ImportCopiedFBX()
        {
            try
            {
                AssetDatabase.ImportAsset(CopiedAssetPath, ImportAssetOptions.Default);

                NewModelImporter = AssetImporter.GetAtPath(CopiedAssetPath) as ModelImporter;
                if (IsRootMotion)
                {
                    NewModelImporter.avatarSetup = ModelImporterAvatarSetup.CreateFromThisModel;
                    SerializedObject so = new SerializedObject(NewModelImporter);
                    so.FindProperty("m_HumanDescription.m_RootMotionBoneName").stringValue = "Root";
                    so.ApplyModifiedProperties();
                    NewModelImporter.SaveAndReimport();
                }
                        
                AssetDatabase.ImportAsset(CopiedAssetPath, ImportAssetOptions.Default);
            }
            catch (Exception ex)
            {
                Debug.LogException(ex);
                return false;
            }

            return true;
        }

        public bool BringAnimationClips()
        {
            Clips.Clear();

            try
            {
                Object[] objs = AssetDatabase.LoadAllAssetRepresentationsAtPath(CopiedAssetPath);
                foreach (Object obj in objs)
                {
                    AnimationClip clip = obj as AnimationClip;
                    if (clip != null)
                    {
                        Clips.Add(clip);
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.LogException(ex);
                return false;
            }

            return true;
        }

        public bool CreateOrOverrideClips()
        {
            try
            {
                foreach (AnimationClip clip in Clips)
                {
                    string createPath = Application.dataPath + $"/Temp/{clip.name}.anim";
                    string createAssetPath = createPath.Substring(createPath.IndexOf("Assets", StringComparison.Ordinal));
                    string destPath = $"{CopiedFilePath}{clip.name}.anim";
                    string destAssetPath = destPath.Substring(destPath.IndexOf("Assets", StringComparison.Ordinal));

                    Debug.Log($"{clip.name} 애니메이션을 추출합니다. - 절대 경로:{destPath}, 프로젝트 경로:{destAssetPath}");

                    if (File.Exists(destPath))
                    {
                        Debug.Log($"{clip.name} 경로에 애니메이션이 존재합니다. 세팅을 덮어씌웁니다. - 절대 경로:{destPath}, 프로젝트 경로:{destAssetPath}");

                        AnimationClip originClip = AssetDatabase.LoadAssetAtPath<AnimationClip>(destAssetPath);
                        AnimationClipSettings originSetting = AnimationUtility.GetAnimationClipSettings(originClip);
                        AnimationClipSettings copySetting = AnimationUtility.GetAnimationClipSettings(clip);
                        originSetting.startTime = copySetting.startTime;
                        originSetting.stopTime = clip.length;
                        originSetting.cycleOffset = copySetting.cycleOffset;
                        originSetting.orientationOffsetY = copySetting.orientationOffsetY;
                        originSetting.additiveReferencePoseTime = copySetting.additiveReferencePoseTime;
                        originSetting.level = copySetting.level;
                        
                        AnimationUtility.SetAnimationClipSettings(clip, originSetting);
                    }

                    AssetDatabase.CreateAsset(Object.Instantiate(clip), createAssetPath);
                    AssetDatabase.ImportAsset(createAssetPath);
                    AssetDatabase.SaveAssets();
                    AssetDatabase.Refresh();
                    
                    File.Copy(createPath, destPath, true);
                    AssetDatabase.DeleteAsset(createAssetPath);

                    Debug.Log($"{clip.name} 경로에 애니메이션 추출을 완료했습니다. - 절대 경로:{destPath}, 프로젝트 경로:{destAssetPath}");
                }
            }
            catch (Exception ex)
            {
                Debug.LogException(ex);
                return false;
            }

            return true;
        }

        public void ClearCopiedFBX()
        {
            try
            {
                File.Delete(CopiedFullPath);
                File.Delete(CopiedFullPath + ".meta");
            }
            catch (Exception ex)
            {
                Debug.LogException(ex);
            }
        }
        
        public int CompareTo(FBXSelection other)
        {
            if (ReferenceEquals(this, other)) return 0;
            if (ReferenceEquals(null, other)) return 1;
            return string.Compare(SrcFilePath, other.SrcFilePath, StringComparison.Ordinal);
        }
    }
    
    public class FBXImporterWindow : EditorWindow
    {
        private Vector2 _mainMenuScrollPos;
        private Vector2 _srcPathsScrollPos;
        private Vector2 _srcSelectPathsScrollPos;
        private string _errorMsg;
        private GUIStyle _titleStyle;
        private GUIStyle _categoryStyle;
        private GUIStyle _errorMsgStyle;
        
        private readonly List<FBXSelection> _sourceFBXSelections = new();
        private readonly List<FBXSelection> _selectedList = new();
        
        private static bool _initialized;
        private static string _prevSrcPath;
        private static string _currentSrcPath;
        private static string _prevDstPath;
        private static string _currentDstPath;

        [MenuItem("Window/FBXImporter")]
        private static void OpenWindow()
        {
            FBXImporterWindow window = GetWindow<FBXImporterWindow>();
            window.titleContent.text = "FBX Importer";
            window.Show();
            window.Focus();

            _initialized = false;
        }

        private void Initialize()
        {
            _titleStyle = new()
            {
                fontStyle = FontStyle.Bold,
                fontSize = 15,
                normal = new GUIStyleState
                {
                    textColor = Color.yellow
                }
            };

            _categoryStyle = new()
            {
                fontStyle = FontStyle.Bold,
                fontSize = 13,
                normal = new GUIStyleState
                {
                    textColor = Color.magenta
                }
            };
            
            _errorMsgStyle = new()
            {
                fontStyle = FontStyle.Bold,
                fontSize = 17,
                normal = new GUIStyleState
                {
                    textColor = Color.red
                }
            };

            _errorMsg = string.Empty;
            _sourceFBXSelections.Clear();
            _selectedList.Clear();
            
            _mainMenuScrollPos = Vector2.zero;
            _srcPathsScrollPos = Vector2.zero;
            _srcSelectPathsScrollPos = Vector2.zero;
            
            _currentSrcPath = Application.dataPath;
            _currentDstPath = Application.dataPath;

            _prevSrcPath = string.Empty;
            _prevDstPath = string.Empty;

            _initialized = true;
        }
        
        private void OnGUI()
        {
            if (!_initialized)
            {
                Initialize();
            }
            
            GUILayout.BeginVertical();
            DrawTopMenu();

            _mainMenuScrollPos = GUILayout.BeginScrollView(_mainMenuScrollPos, GUI.skin.window);
            DrawSelectPath();
            DrawSourceFBXs();
            GUILayout.EndScrollView();
            
            GUILayout.EndVertical();
        }

        private void DrawTopMenu()
        {
            GUILayout.BeginHorizontal();
            if(GUILayout.Button("초기화"))
            {
                Initialize();
            }
            
            if(GUILayout.Button("추출하기"))
            {
                ImportAnimationClips();
            }
            GUILayout.EndHorizontal();
            
            GUILayout.Label(_errorMsg, _errorMsgStyle);
        }

        private void OnChangedSrcPath()
        {
            _sourceFBXSelections.Clear();
            _selectedList.Clear();
            
            if (string.IsNullOrEmpty(_currentSrcPath))
            {
                _errorMsg = $"원본 경로가 설정되지 않았습니다.";
                return;
            }
            
            if (!Directory.Exists(_currentSrcPath))
            {
                _errorMsg = $"설정한 원본 경로에 폴더가 존재하지 않습니다.";
                return;
            }
            
            string[] filePaths = Directory.GetFiles(_currentSrcPath, "*.fbx", SearchOption.AllDirectories)
                                            .OrderBy(x => x)
                                            .ToArray();
            if (filePaths.Length <= 0)
            {
                _errorMsg = $"설정한 경로에 FBX 가 존재하지 않습니다.";
                return;
            }
            
            for (int i = 0; i < filePaths.Length; i++)
            {
                FBXSelection selection = new FBXSelection(filePaths[i]);
                selection.OnChangedIsInclude = OnChangeIsInclude;
                
                _sourceFBXSelections.Add(selection);
            }
            
            _sourceFBXSelections.Sort();
        }

        private void OnChangeIsInclude(FBXSelection selection)
        {
            if (selection.IsIncluded)
            {
                _selectedList.Add(selection);
            }
            else
            {
                _selectedList.Remove(selection);
            }
        }

        private void OnChangedDstPath()
        {
            if (string.IsNullOrEmpty(_currentDstPath))
            {
                _errorMsg = $"추출 경로가 설정되지 않았습니다.";
                return;
            }

            int st = _currentDstPath.IndexOf("Assets", StringComparison.Ordinal);
            if (st < 0)
            {
                _errorMsg = $"추출 경로가 프로젝트 내부 경로가 아닙니다.";
                return;
            }

            if (!Directory.Exists(_currentDstPath))
            {
                _errorMsg = $"설정한 추출 경로에 폴더가 존재하지 않습니다.";
                return;
            }
        }

        private void DrawSelectPath()
        {
            GUILayout.BeginVertical(GUI.skin.window, GUILayout.MinHeight(40));
            GUILayout.BeginHorizontal();
            GUILayout.Label("원본 경로", GUILayout.ExpandWidth(false));
            _currentSrcPath = GUILayout.TextField(_currentSrcPath, GUILayout.ExpandWidth(true));
            if (GUILayout.Button("...", GUILayout.ExpandWidth(false)))
            {
                _currentSrcPath = EditorUtility.OpenFolderPanel("FBX가 위치한 폴더 경로", "", "");
            }
            GUILayout.EndHorizontal();
            
            GUILayout.BeginHorizontal();
            GUILayout.Label("추출 경로", GUILayout.ExpandWidth(false));
            _currentDstPath = GUILayout.TextField(_currentDstPath, GUILayout.ExpandWidth(true));
            if (GUILayout.Button("...", GUILayout.ExpandWidth(false)))
            {
                _currentDstPath = EditorUtility.OpenFolderPanel("애니메이션을 위치할 폴더 경로", "", "");
            }
            GUILayout.EndHorizontal();
            GUILayout.EndVertical();

            if (!_currentSrcPath.Equals(_prevSrcPath))
            {
                OnChangedSrcPath();
                _prevSrcPath = _currentSrcPath;
            }
            
            if (!_currentDstPath.Equals(_prevDstPath))
            {
                OnChangedDstPath();
                _prevDstPath = _currentDstPath;
            }
        }
        
        private void DrawSourceFBXs()
        {
            HashSet<string> catalog = new HashSet<string>();
            
            GUILayout.Space(30);
            GUILayout.Label("경로에 존재하는 FBX 파일 목록", _titleStyle);
            _srcPathsScrollPos = GUILayout.BeginScrollView(_srcPathsScrollPos, GUI.skin.window, GUILayout.MaxHeight(200));
            foreach (FBXSelection selection in _sourceFBXSelections)
            {
                if (!catalog.Contains(selection.SrcFilePath))
                {
                    GUILayout.Box("", GUILayout.ExpandWidth(true), GUILayout.Height(5f));
                    GUILayout.Label(selection.SrcFilePath, _categoryStyle);
                    catalog.Add(selection.SrcFilePath);
                }
                
                GUILayout.BeginHorizontal();
                GUILayout.Label(selection.SrcFileName, GUILayout.ExpandWidth(true));
                selection.IsIncluded = GUILayout.Toggle(selection.IsIncluded, "포함 여부", GUILayout.Width(100));
                selection.IsRootMotion = GUILayout.Toggle(selection.IsRootMotion, "루트 모션 여부", GUILayout.Width(100));
                GUILayout.EndHorizontal();
            }
            GUILayout.EndScrollView();
            
            GUILayout.Space(10);
            
            GUILayout.Label("추출을 진행할 FBX 목록", _titleStyle);
            _srcSelectPathsScrollPos = GUILayout.BeginScrollView(_srcSelectPathsScrollPos, GUI.skin.window, GUILayout.MaxHeight(200));
            foreach (FBXSelection selection in _selectedList)
            {
                GUILayout.Label($"{selection.SrcFilePath}{selection.SrcFileName}", _categoryStyle);
            }
            GUILayout.EndScrollView();
        }
        
        private void ImportAnimationClips()
        {
            if (_selectedList.Count <= 0)
            {
                EditorUtility.DisplayDialog("오류", "추출할 FBX 가 선택되지 않았습니다.", "확인");
                return;
            }
            
            if (!EditorUtility.DisplayDialog("추출", "선택한 FBX 파일에서 Animation Clip 을 추출하시겠습니까?", "확인", "취소"))
            {
                return;
            }

            if (string.IsNullOrEmpty(_currentDstPath))
            {
                EditorUtility.DisplayDialog("오류", "추출본을 내보낼 경로가 지정되지 않았습니다.", "확인");
            }

            CopyAndImportFBXs();
            ExtractClipsFromFBXs();
        }

        private void CopyAndImportFBXs()
        {
            foreach (FBXSelection selected in _selectedList)
            {
                string destPath = $"{_currentDstPath}/";
                string destName = $"{selected.SrcFileName}";
                
                if (!selected.CopyTo(destPath, destName))
                {
                    Debug.LogError($"{selected.SrcFileName} 파일 복사에 실패하였습니다.");
                    continue;    
                }

                if (!selected.ImportCopiedFBX())
                {
                    Debug.LogError($"{selected.CopiedFileName} FBX 파일 임포트에 실패하였습니다.");
                }
            }
        }
        
        private void ExtractClipsFromFBXs()
        {
            foreach (FBXSelection selected in _selectedList)
            {
                if (!selected.BringAnimationClips())
                {
                    Debug.LogError($"{selected.SrcFileName} 에 애니메이션 클립을 가져오지 못했습니다.");
                    continue;
                }
                
                if (!selected.CreateOrOverrideClips())
                {
                    Debug.LogError($"{selected.SrcFileName} 의 애니메이션 추출이 실패하였습니다.");
                }

                selected.ClearCopiedFBX();
            }
            
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
        }
    }
}