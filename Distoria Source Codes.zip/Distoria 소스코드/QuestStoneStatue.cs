using ProjectAAA.Core.Managers;
using ProjectAAA.UI.Statue;
using ProjectAAA.Utils;
using ProjectAAA.Utils.DataTable;

namespace ProjectAAA.Interactables.Statue
{
    public class QuestStoneStatue : StoneStatue
    {
        protected override StatueConditionUI ConditionUI => null;
        protected override IPredicate AcceptCondition => null;
        protected override IPredicate DenyCondition => null;

        protected override void OnInteract()
        {
            string desc = QuestManager.Instance.GetCurrentDesc();

            StatueUI.SetEffectDescription(desc);
        }

        protected override void OnAccept()
        {
            QuestManager.Instance.SetCurrent();
            QuestManager.Instance.Next();
        }

        protected override void OnDeny()
        {
            QuestManager.Instance.Next();
        }
    }
}