using System;
using System.Linq;
using Cysharp.Threading.Tasks;
using ProjectAAA.Core;
using ProjectAAA.Core.Managers;
using ProjectAAA.Core.Scanner;
using ProjectAAA.SO;
using ProjectAAA.SO.Pool;
using ProjectAAA.Utils;
using ProjectAAA.Utils.DataTable;
using UnityEngine;
using Random = UnityEngine.Random;

namespace ProjectAAA.WeaponSystem
{
    public class BulletGenerateBullets : BulletDestroyAbility
    {
        private ObjectPoolSO BulletPool => WeaponManager.Instance.BulletGenerator.GetPool(_addBulletId);

        private readonly int _addBulletId;
        private readonly int _count;
        private readonly AddBulletDirection _directionType;
        private readonly float _radius;

        private readonly OverlapBlockScanner _scanner;

        private BulletDestroyType _currentDestroyType;
        
        public BulletGenerateBullets(BulletBase bullet, AddBulletCondition condition,
            int addBulletId, int addBulletCount, AddBulletDirection addBulletDirection, float radius) : base(bullet, condition)
        {
            _addBulletId = addBulletId;
            _count = addBulletCount;
            _directionType = addBulletDirection;
            _radius = radius;
            
            OverlapBlockScanner.OverlapBlockScannerConfig config = new OverlapBlockScanner.OverlapBlockScannerConfig
            {
                RangeLayerMask = Global.MonsterHurtBoxLayerMask,
                RangeRadius = radius,
                RangeDetectCount = Mathf.RoundToInt(radius),
                RangeFilter = CheckCenter,

                BlockLayerMask = Global.PlayerAttackBlockMask,
            };
            _scanner = new OverlapBlockScanner(config);
        }

        public override async UniTask OnDestroy(BulletDestroyType destroyType)
        {
            _currentDestroyType = destroyType;
            
            if (CheckCondition(destroyType))
            {
                PlayEffect();
                
                switch (_directionType)
                {
                    case AddBulletDirection.RandomInSphereDirection:
                        HandleRandomInSphereDirection(Bullet.transform.position);   
                        break;
                    case AddBulletDirection.NearedEnemyDirection:
                        await HandleNearedEnemyDirection();
                        break;
                    case AddBulletDirection.UseSpread:
                        HandleUseSpread();
                        break;
                }    
            }
            await base.OnDestroy(destroyType);
        }

        private void PlayEffect()
        {
            ObjectPoolSO pool = Bullet.AbilitySettings.AddBulletEffectPool;
            FMODEventInfoSO clip = Bullet.AbilitySettings.AddBulletSound;

            if (pool != null)
            {
                ParticlePoolObj particle = pool.Get<ParticlePoolObj>(null);
                particle.SetOriginPool(pool);
                particle.SetPosition(Bullet.transform.position);
                particle.SetScale(Vector3.one * (_radius * 2f));
                particle.Play();
            }
            
            if (clip != null)
            {
                SoundManager.Instance.PlaySFX(clip, Bullet.transform.position);
            }
        }

        private void GenerateBullet(Vector3 position, Vector3 point)
        {   
            Vector3 direction = (point - position).normalized;
            
            BulletBase bullet = BulletPool.Get<BulletBase>(null);
            bullet.SetOriginPool(BulletPool);
            bullet.SetPosition(position);
            bullet.SetScale(Vector3.one);
            bullet.CriticalMagnification = Bullet.CriticalMagnification;
            
            bullet.SetupData();
            if (_currentDestroyType == BulletDestroyType.Hit && _directionType == AddBulletDirection.UseSpread)
            {
                bullet.ForceHit(Bullet.CurrentHitInfo);
            }
            else
            {
                bullet.Process(point, direction);
            }
        }

        private void HandleRandomInSphereDirection(Vector3 curPos)
        {
            for (int i = 0; i < _count; i++)
            {
                Vector3 randPos = curPos + Random.insideUnitSphere;
                
                GenerateBullet(curPos, randPos);    
            }
        }
        
        private async UniTask HandleNearedEnemyDirection()
        {
            Vector3 position = Bullet.transform.position;
            Collider[] ret = await _scanner.ScanRange(position);

            bool hasScan = false;
            for (int i = 0; i < ret.Length && !hasScan; i++)
            {
                hasScan |= ret[i] != null;
            }
            
            if (hasScan)
            {
                Collider[] copied = ret.Where(x => x != null)
                    .OrderBy(x => Vector3.Distance(position, x.transform.position))
                    .ToArray();
            
                RaycastHit[] hits = await _scanner.ScanBlocked(position, ret);

                if (hits != null)
                {
                    hasScan = false;
                    int len = Mathf.Min(hits.Length, copied.Length);
                    for (int i = 0; i < len && !hasScan; i++)
                    {
                        hasScan |= hits[i].collider == copied[i];
                    }
                
                    if (hasScan)
                    {
                        int accum = 0;
                        for (int i = 0; i < _count; i++)
                        {
                            if (accum < len && hits[i].collider && hits[i].transform != Bullet.transform)
                            {
                                GenerateBullet(position, hits[accum++].transform.position);
                            }
                            else
                            {
                                Vector3 curPos = position;
                                Vector3 randPos = curPos + Random.insideUnitSphere;
                
                                GenerateBullet(position, randPos);    
                            }
                        }
                    }
                    else
                    {
                        HandleRandomInSphereDirection(position);
                    }
                }
                else
                {
                    HandleRandomInSphereDirection(position);
                }
            }
            else
            {
                HandleRandomInSphereDirection(position);
            }
        
            DebugVisualizerManager.Instance.DrawSphere(position, Quaternion.identity, _radius, new Color(0.5f, 1f, 1f, 0.1f), 0.4f);
        }

        private void HandleUseSpread()
        {
            Vector3 position = Bullet.transform.position;
            BaseSpreadDataSO spreadData = Bullet.AbilitySettings.AddBulletSpreadData;
            for (int i = 0; i < _count; i++)
            {
                if (spreadData == null)
                {
                    Vector3 point = Bullet.transform.forward + position;
                    GenerateBullet(position, point);
                }
                else
                {
                    Vector3 randomPos = spreadData.GetRandomPoint(AxisFlag.Z);
                    Vector3 direction = (Vector3.forward + randomPos).normalized;
                    direction = Bullet.transform.TransformDirection(direction);

                    Vector3 point = position + direction;
            
                    GenerateBullet(position, point);   
                }
            }
        }
    }
}