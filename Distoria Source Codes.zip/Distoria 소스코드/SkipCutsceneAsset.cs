using NaughtyAttributes;
using UnityEngine;
using UnityEngine.Playables;

namespace ProjectAAA.Timeline
{
    public enum SkipType
    {
        Down, 
        Press
    }
    
    public class SkipCutsceneAsset : PlayableAsset
    {
        public KeyCode skipKeyCode = KeyCode.Space;
        public SkipType skipType = SkipType.Down;
        public string skipHelpText;
        [ShowIf("skipType", SkipType.Press)] public float pressDuration = 1f;
        
        [HideInInspector] public double skipTime;

        public override Playable CreatePlayable(PlayableGraph graph, GameObject owner)
        {
            var playable = ScriptPlayable<SkipCutsceneBehaviour>.Create(graph);
            var behaviour = playable.GetBehaviour();
            var ownerDirector = owner.GetComponent<PlayableDirector>();

            behaviour.SkipKeyCode = skipKeyCode;
            behaviour.SkipType = skipType;
            behaviour.SkipHelpText = skipHelpText;
            behaviour.PressDuration = pressDuration;
            behaviour.OwnerDirector = ownerDirector;
            behaviour.SkipTime = skipTime;

            return playable;
        }
    }
}