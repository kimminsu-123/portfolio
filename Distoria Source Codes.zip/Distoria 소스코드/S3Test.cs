using System;
using System.IO;
using System.Threading.Tasks;
using Amazon;
using Amazon.Runtime;
using Amazon.S3;
using Amazon.S3.Model;
using ProjectAAA.Core;
using UnityEngine;
using Logger = ProjectAAA.Utils.Logger;

public class S3Test : MonoBehaviour
{
	public void Test()
	{
		AWSCredentials credentials = new BasicAWSCredentials(Config.AwsPublicAccessKey, Config.AwsSecretAccessKey);
		AmazonS3Client client = new AmazonS3Client(credentials, RegionEndpoint.USEast2);

		Task<GetObjectResponse> ret = client.GetObjectAsync(Config.AwsDataTableBucketName, "datatable/discord_backup_codes.txt");
		ret.Wait();
        
		using var stream = new StreamReader(ret.Result.ResponseStream);
		Logger.Log("Read From S3", stream.ReadToEnd());
	}
}
