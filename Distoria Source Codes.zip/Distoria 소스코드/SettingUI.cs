using System;
using System.Collections.Generic;
using ProjectAAA.Core.Managers;
using ProjectAAA.Core.Scene.Manager;
using ProjectAAA.SO;
using ProjectAAA.Utils;
using TMPro;
using UnityEngine;
using UnityEngine.Playables;
using UnityEngine.UI;
using EventType = ProjectAAA.Core.Managers.EventType;

namespace ProjectAAA.UI
{
    public class SettingUI : UiBase
    {
        protected override Type RegisterType => typeof(SettingUI);
        
        [SerializeField] private PlayableDirector creditTimeline;
        [SerializeField] private FMODEventInfoSO bgmSoundInfo;
        
        [SerializeField] private List<int> frameRatePreset;

        [SerializeField] private GameObject graphicsSettings;
        [SerializeField] private GameObject soundSettings;
        [SerializeField] private GameObject inputSettings;

        [SerializeField] private Toggle settingToggle;
        [SerializeField] private Toggle leaveToLobbyToggle;
        [SerializeField] private Toggle creditToggle;
        [SerializeField] private Toggle exitGameToggle;

        [SerializeField] private TMP_Dropdown settingDropdown;

        //그래픽
        [SerializeField] private Toggle asyncToggle;

        [SerializeField] private TMP_Dropdown targetFrameRate;
        [SerializeField] private Slider targetFrameRateSlider;
        [SerializeField] private TMP_InputField targetFrameRateInput;

        [SerializeField] private TMP_Dropdown graphicsQualityDropdown;

        [SerializeField] private TMP_Dropdown antialiasDropdown;
        [SerializeField] private Slider renderScaleSlider;
        [SerializeField] private TMP_InputField renderScaleInput;
        [SerializeField] private TMP_Dropdown textureQualityDropdown;
        [SerializeField] private TMP_Dropdown shadowQualityDropdown;
        [SerializeField] private Toggle motionBlurToggle;

        //소리
        [SerializeField] private Slider masterVolumeSlider; //
        [SerializeField] private Slider sfxVolumeSlider; //
        [SerializeField] private Slider musicVolumeSlider; //

        //조작
        [SerializeField] private Slider mouseSensitiveSlider; //
        [SerializeField] private TMP_InputField mouseSensitiveInput; //

        private NoticeUI _noticeUI;

        protected override void OnAwake()
        {
            SetFrameRateOptions();

            settingDropdown.onValueChanged.AddListener(OnSelectDropdownSetting);

            asyncToggle.onValueChanged.AddListener(OnClickVSyncSetting);

            targetFrameRate.onValueChanged.AddListener(OnSelectTargetFrameRate);
            targetFrameRateSlider.onValueChanged.AddListener(OnChangeTargetFrameRateSlider);
            targetFrameRateInput.onEndEdit.AddListener(OnEndEditTargetFrameRateInput);

            graphicsQualityDropdown.onValueChanged.AddListener(OnSelectGraphicQuality);

            antialiasDropdown.onValueChanged.AddListener(OnSelectAntialias);

            renderScaleSlider.onValueChanged.AddListener(OnChangeRenderScaleSlider);
            renderScaleInput.onEndEdit.AddListener(OnEndEditRenderScaleInput);

            textureQualityDropdown.onValueChanged.AddListener(OnSelectTextureQuality);
            shadowQualityDropdown.onValueChanged.AddListener(OnSelectShadowQuality);
            motionBlurToggle.onValueChanged.AddListener(OnClickMotionBlur);

            settingToggle.onValueChanged.AddListener(OnClickSettingToggle);
            leaveToLobbyToggle.onValueChanged.AddListener(OnClickLeaveToLobby);
            creditToggle.onValueChanged.AddListener(OnClickCredit);
            exitGameToggle.onValueChanged.AddListener(OnClickExitGame);

            masterVolumeSlider.onValueChanged.AddListener(OnChangeMasterVolume);
            sfxVolumeSlider.onValueChanged.AddListener(OnChangeSfxVolume);
            musicVolumeSlider.onValueChanged.AddListener(OnChangeMusicVolume);

            mouseSensitiveSlider.onValueChanged.AddListener(OnChangeMouseSensitive);
            mouseSensitiveInput.onEndEdit.AddListener(OnEndEditMouseSensitiveInput);

            _noticeUI = GetComponentInChildren<NoticeUI>(true);

            OnClickVSyncSetting(GeneralSettingManager.Instance.UseVSync.Value);
            Hide();
        }

        private void Start()
        {
            creditTimeline.stopped += OnEndCredit;
            creditTimeline.gameObject.SetActive(false);
        }

        private void SetFrameRateOptions()
        {
            int min = int.MaxValue, max = 0;
            for (var index = 0; index < frameRatePreset.Count; index++)
            {
                int frameRate = frameRatePreset[index];

                if (frameRate <= 0)
                {
                    targetFrameRate.options.Add(new TMP_Dropdown.OptionData("사용자 지정"));
                }
                else
                {
                    min = Mathf.Min(min, frameRate);
                    max = Mathf.Max(min, frameRate);

                    if (Mathf.CeilToInt((float)Screen.currentResolution.refreshRateRatio.value) >= frameRate)
                    {
                        targetFrameRate.options.Add(new TMP_Dropdown.OptionData($"{frameRate}"));
                    }
                }
            }

            targetFrameRateSlider.minValue = min;
            targetFrameRateSlider.maxValue = max;
        }


        private void OnSelectDropdownSetting(int arg0)
        {
            switch (arg0)
            {
                case 0:
                    graphicsSettings.SetActive(true);
                    soundSettings.SetActive(false);
                    inputSettings.SetActive(false);
                    break;
                case 1:
                    graphicsSettings.SetActive(false);
                    soundSettings.SetActive(true);
                    inputSettings.SetActive(false);
                    break;
                case 2:
                    graphicsSettings.SetActive(false);
                    soundSettings.SetActive(false);
                    inputSettings.SetActive(true);
                    break;
                default:
                    graphicsSettings.SetActive(true);
                    soundSettings.SetActive(false);
                    inputSettings.SetActive(false);
                    break;
            }
        }

        private void OnClickVSyncSetting(bool isOn)
        {
            GeneralSettingManager.Instance.UseVSync.Value = isOn;

            targetFrameRate.gameObject.SetActive(!isOn);
        }

        private void OnSelectTargetFrameRate(int index)
        {
            GeneralSettingManager.Instance.CurrentTargetFrameRateIndex.Value = index;

            if (index <= 0)
            {
                // 사용자 지정으로 한 경우
                targetFrameRateSlider.gameObject.SetActive(true);
            }
            else
            {
                // 프리셋을 선택한 경우
                int frame = frameRatePreset[index];
                GeneralSettingManager.Instance.CurrentTargetFrameRate.Value = frame;

                targetFrameRateSlider.gameObject.SetActive(false);
            }

            targetFrameRateSlider.SetValueWithoutNotify(GeneralSettingManager.Instance.CurrentTargetFrameRate.Value);
            targetFrameRateInput.SetTextWithoutNotify(
                $"{GeneralSettingManager.Instance.CurrentTargetFrameRate.Value:F0}");
        }

        private void OnChangeTargetFrameRateSlider(float v)
        {
            GeneralSettingManager.Instance.CurrentTargetFrameRate.Value = (int)v;

            targetFrameRate.SetValueWithoutNotify(0);
            targetFrameRateInput.SetTextWithoutNotify($"{v:F0}");
        }

        private void OnEndEditTargetFrameRateInput(string v)
        {
            if (int.TryParse(v, out int result))
            {
                targetFrameRateSlider.value =
                    Mathf.Clamp(result, targetFrameRateSlider.minValue, targetFrameRateSlider.maxValue);
            }
        }

        private void OnSelectGraphicQuality(int index)
        {
            GeneralSettingManager.Instance.CurrentGraphicsQualitySetting.Value = index;

            UpdateGraphicSettings();
        }

        private void OnSelectAntialias(int index)
        {
            if (graphicsQualityDropdown.value != 3)
            {
                graphicsQualityDropdown.value = 3;
            }

            GeneralSettingManager.Instance.CurrentAntialiasing.Value = index;
            antialiasDropdown.SetValueWithoutNotify(index);
        }

        private void OnChangeRenderScaleSlider(float v)
        {
            if (graphicsQualityDropdown.value != 3)
            {
                graphicsQualityDropdown.value = 3;
            }

            float value = (float)Math.Round(v, 1);

            GeneralSettingManager.Instance.CurrentRenderScale.Value = value;

            renderScaleSlider.SetValueWithoutNotify(value);
            renderScaleInput.SetTextWithoutNotify($"{value:F1}");
        }

        private void OnEndEditRenderScaleInput(string v)
        {
            if (float.TryParse(v, out float result))
            {
                float value = (float)Math.Round(result, 1);

                renderScaleSlider.value = Mathf.Clamp(value, renderScaleSlider.minValue, renderScaleSlider.maxValue);
            }
        }

        private void OnSelectTextureQuality(int index)
        {
            if (graphicsQualityDropdown.value != 3)
            {
                graphicsQualityDropdown.value = 3;
            }

            GeneralSettingManager.Instance.CurrentTextureQuality.Value = index;

            textureQualityDropdown.SetValueWithoutNotify(index);
        }

        private void OnSelectShadowQuality(int index)
        {
            if (graphicsQualityDropdown.value != 3)
            {
                graphicsQualityDropdown.value = 3;
            }

            GeneralSettingManager.Instance.CurrentShadowQuality.Value = index + 1;

            shadowQualityDropdown.SetValueWithoutNotify(index);
        }

        private void OnClickMotionBlur(bool active)
        {
            GeneralSettingManager.Instance.UseMotionBlur.Value = active;
        }

        private void OnChangeMusicVolume(float value)
        {
            GeneralSettingManager.Instance.CurrentMusicVolume.Value = value;
        }

        private void OnChangeSfxVolume(float value)
        {
            GeneralSettingManager.Instance.CurrentSfxVolume.Value = value;
        }

        private void OnChangeMasterVolume(float value)
        {
            GeneralSettingManager.Instance.CurrentMasterVolume.Value = value;
        }

        private void OnChangeMouseSensitive(float value)
        {
            GeneralSettingManager.Instance.CurrentMouseSensitive.Value = value;
            mouseSensitiveInput.SetTextWithoutNotify($"{value:F2}");
        }

        private void OnEndEditMouseSensitiveInput(string value)
        {
            if (float.TryParse(value, out float result))
            {
                mouseSensitiveSlider.value =
                    Mathf.Clamp(result, mouseSensitiveSlider.minValue, mouseSensitiveSlider.maxValue);
            }
        }

        private void OnClickSettingToggle(bool isOn)
        {
            settingToggle.GetComponent<ToggleAnimation>().SetSelectAnim(true);

            if (isOn && _noticeUI.gameObject.activeSelf)
            {
                _noticeUI.ForceRevert();
            }
        }

        private void OnClickLeaveToLobby(bool isOn)
        {
            settingToggle.GetComponent<ToggleAnimation>().SetSelectAnim(false);
            if (isOn)
            {
                _noticeUI.Show(Global.Message.SettingReturnToLobby, () =>
                {
                    GameManager.Instance.LeaveToLobby();
                    EventManager.Instance.PostNotification(EventType.PlayerClear, this);
                }, () =>
                {
                    leaveToLobbyToggle.GetComponent<ToggleAnimation>().SetSelectAnim(false);
                    settingToggle.GetComponent<ToggleAnimation>().SetSelectAnim(true);
                });
            }
        }

        private void OnClickCredit(bool isOn)
        {
            settingToggle.GetComponent<ToggleAnimation>().SetSelectAnim(false);
            if (isOn)
            {
                creditTimeline.gameObject.SetActive(true);
                
                PlayerManager.Instance.ActionController.BlockAllActions();
                creditTimeline.Play();
                SoundManager.Instance.PlayBGM(bgmSoundInfo);
            }
        }

        private void OnEndCredit(PlayableDirector director)
        {
            creditTimeline.gameObject.SetActive(false);
            PlayerManager.Instance.ActionController.UnBlockAllActions();
            SoundManager.Instance.StopBGM();
            GameManager.Instance.LeaveToLobby();
        }
        
        private void OnClickExitGame(bool isOn)
        {
            settingToggle.GetComponent<ToggleAnimation>().SetSelectAnim(false);
            if (isOn)
            {
                _noticeUI.Show(Global.Message.SettingExitGame, () => { GameManager.Instance.ExitGame(); }, () =>
                {
                    exitGameToggle.GetComponent<ToggleAnimation>().SetSelectAnim(false);
                    settingToggle.GetComponent<ToggleAnimation>().SetSelectAnim(true);
                });
            }
        }

        private void UpdateGraphicSettings()
        {
                asyncToggle.SetIsOnWithoutNotify(GeneralSettingManager.Instance.UseVSync.Value);
                targetFrameRate.SetValueWithoutNotify(GeneralSettingManager.Instance.CurrentTargetFrameRateIndex.Value);
                graphicsQualityDropdown.SetValueWithoutNotify(GeneralSettingManager.Instance.CurrentGraphicsQualitySetting.Value);
                antialiasDropdown.SetValueWithoutNotify(GeneralSettingManager.Instance.CurrentAntialiasing.Value);
                renderScaleSlider.SetValueWithoutNotify(GeneralSettingManager.Instance.CurrentRenderScale.Value);
                renderScaleInput.SetTextWithoutNotify($"{GeneralSettingManager.Instance.CurrentRenderScale.Value}");
                textureQualityDropdown.SetValueWithoutNotify(GeneralSettingManager.Instance.CurrentTextureQuality.Value);
                shadowQualityDropdown.SetValueWithoutNotify(GeneralSettingManager.Instance.CurrentShadowQuality.Value - 1);
                motionBlurToggle.SetIsOnWithoutNotify(GeneralSettingManager.Instance.UseMotionBlur.Value);
                masterVolumeSlider.SetValueWithoutNotify(GeneralSettingManager.Instance.CurrentMasterVolume.Value);
                musicVolumeSlider.SetValueWithoutNotify(GeneralSettingManager.Instance.CurrentMusicVolume.Value);
                sfxVolumeSlider.SetValueWithoutNotify(GeneralSettingManager.Instance.CurrentSfxVolume.Value);
                mouseSensitiveSlider.SetValueWithoutNotify(GeneralSettingManager.Instance.CurrentMouseSensitive.Value);
                mouseSensitiveInput.SetTextWithoutNotify($"{GeneralSettingManager.Instance.CurrentMouseSensitive.Value:F2}");
            
        }

        public override void Show()
        {
            gameObject.SetActive(true);

            settingToggle.isOn = true;
            settingToggle.GetComponent<ToggleAnimation>().SetSelectAnim(true);

            UpdateGraphicSettings();

            targetFrameRate.onValueChanged.Invoke(GeneralSettingManager.Instance.CurrentTargetFrameRateIndex.Value);

            settingDropdown.value = 2;
            settingDropdown.onValueChanged.Invoke(2);
        }

        public override void Hide()
        {
            gameObject.SetActive(false);
        }
    }
}