using System;
using UnityEngine;
using Random = UnityEngine.Random;

namespace ProjectAAA.Interactables
{
    public class Moro : MonoBehaviour
    {
        [SerializeField] private Animator animator;
        [SerializeField] private Vector2Int idleLoopCountMinMax = new (2, 3);
        [SerializeField] private Transform smokeParent;
        [SerializeField] private ParticleSystem smokeParticle;

        private readonly int _animationIndex = Animator.StringToHash("AnimationIndex");
        private readonly int[] _nextIdlesIdx = { 0, 1, 2 };
        
        private int _nextIdlePick;
        private int _accumCount;

        private void Start()
        {
            _nextIdlePick = 0;
            _accumCount = GetRandomizedLoopCount();
            
            ShuffleNextIdles();
            
            animator.SetInteger(_animationIndex, -1);
        }

        private void Update()
        {
            smokeParticle.transform.position = smokeParent.position;
            smokeParticle.transform.rotation = smokeParent.rotation;
        }

        private int GetRandomizedLoopCount() => Random.Range(idleLoopCountMinMax.x, idleLoopCountMinMax.y + 1);
        private void ShuffleNextIdles()
        {
            for (int i = 0; i < 20; i++)
            {
                int f = Random.Range(0, _nextIdlesIdx.Length);
                int s = Random.Range(0, _nextIdlesIdx.Length);
                
                (_nextIdlesIdx[f], _nextIdlesIdx[s]) = (_nextIdlesIdx[s], _nextIdlesIdx[f]);
            }
        }

        public void ReachedIdleLoop()
        {
            _accumCount--;
            if (_accumCount <= 0)
            {
                animator.SetInteger(_animationIndex, _nextIdlesIdx[_nextIdlePick]);
            }
        }

        public void EndAlterIdle()
        {
            animator.SetInteger(_animationIndex, -1);
            
            _nextIdlePick++;
            if (_nextIdlePick >= _nextIdlesIdx.Length - 1)
            {
                _nextIdlePick = 0;
                
                ShuffleNextIdles();
            }
            
            _accumCount = GetRandomizedLoopCount();
        }
    }
}