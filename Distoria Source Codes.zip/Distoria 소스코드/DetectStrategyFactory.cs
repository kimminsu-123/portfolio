using System;
using ProjectAAA.Core.Managers;
using ProjectAAA.SO;
using ProjectAAA.Utils;
using ProjectAAA.Utils.DataTable;
using UnityEngine;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.Core.Detector
{
    [Obsolete(error:true,message:"안쓰는 거임 ㅋ")]
    public class DetectStrategyFactory : Singleton<DetectStrategyFactory>
    {
        private RangeDataTableSO RangeTable => DatabaseManager.Instance.GetTable<RangeDataTableSO>();

        public DetectStrategy Generate(int rangeCode, Transform transform, int detectCount, LayerMask layerMask)
        {
            RangeData rangeData = RangeTable.Get(rangeCode);
            if (rangeData == null)
            {
                Logger.LogError($"{rangeCode} DetectStrategyFactory", $"{rangeCode} : 테이블에 존재하지 않는 코드입니다.");
                return null;
            }

            Vector3 center = new Vector3(rangeData.CenterX, rangeData.CenterY, rangeData.CenterZ);
            switch (rangeData.Type)
            {
                case RangeType.Sphere:
                    return new SphereDetectStrategy(rangeData.Value1, transform, center, detectCount, layerMask);
                case RangeType.HalfSphere:
                    return null;
                case RangeType.Box:
                    return new SectorDetectStrategy(rangeData.Value1, rangeData.Value2, rangeData.Value3, transform,
                        center, detectCount, layerMask);
                default:
                    return null;
            }
        }
    }
}