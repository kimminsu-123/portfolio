using System.Collections.Generic;
using System.Linq;
using ProjectAAA.Core.Pool;
using ProjectAAA.SO.Pool;
using ProjectAAA.WeaponSystem;
using UnityEngine;
using UnityEngine.EventSystems;

namespace ProjectAAA.Utils
{
    public abstract class Generator<TKey, TValue> : PoolObjContainer where TValue : PoolObjMonoBehaviour
    {
        protected abstract bool InitOnStart { get; }

        private readonly Dictionary<TKey, ObjectPoolSO> _dictionary = new();

        protected override void Start()
        {
            if (InitOnStart)
            {
                GenerateAll();
            }
        }
        
        public void GenerateAll()
        {
            foreach (ObjectPoolSO so in objPoolSo)
            {
                so.SetupPool(transform);

                TKey key = default;
                if (GetKey(so, ref key))
                {
                    _dictionary.TryAdd(key, so);
                }
                else
                {
                    Logger.LogError("Generator", $"GetKeyValue 가 정상적으로 동작하지 않았습니다. {typeof(TKey)} {typeof(TValue)}");
                }
            }
        }

        public TValue GetValue(TKey key, Transform parent)
        {
            ObjectPoolSO so = _dictionary[key];
            TValue value = so.Get<TValue>(parent);
            value.SetOriginPool(so);
            
            return value;
        }

        public ObjectPoolSO[] GetValues() => _dictionary.Select(x => x.Value).ToArray();
        public ObjectPoolSO GetPool(TKey key) => _dictionary[key];
        public bool Contains(TKey key) => _dictionary.ContainsKey(key);
        
        protected abstract bool GetKey(ObjectPoolSO pool, ref TKey key);

        protected override void OnDestroy()
        {
            base.OnDestroy();
            
            _dictionary.Clear();
        }
        
        // 치트키용 함수
        public List<ObjectPoolSO> GetPools()
        {
            return objPoolSo.ToList();
        }
    }
}