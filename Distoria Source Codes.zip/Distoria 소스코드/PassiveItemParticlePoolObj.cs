using System.Linq;
using ProjectAAA.Core.Managers;
using ProjectAAA.Utils.DataTable;
using UnityEngine;

namespace ProjectAAA.Core
{
    public class PassiveItemParticlePoolObj : ParticlePoolObj
    {
        [SerializeField] private ParticleSystem textureParticle;
        
        private Renderer _iconParticleRenderer;
        
        protected override void OnAwake()
        {
            _iconParticleRenderer = textureParticle.GetComponent<Renderer>();
        }

        public void SetItemTexture(int passiveItemCode)
        {
            Texture2D texture = DatabaseManager.Instance.IconResources.GetTexture(RewardType.PassiveItem, passiveItemCode);
            
            _iconParticleRenderer.material.SetTexture("_Texture2D", texture);
        }
    }
}