using ProjectAAA.Utils;
using UnityEngine;
using UnityEngine.Playables;

namespace ProjectAAA.Timeline
{
    public class CursorBehaviour : PlayableBehaviour
    {
        public bool UnlockOnExit;
        public bool SettingCursor;
        public Texture2D Texture;
        public Vector2 Hotspot;
        public CursorMode CursorMode;
        public CursorLockMode LockMode;

        public override void OnBehaviourPlay(Playable playable, FrameData info)
        {
            if (SettingCursor)
            {
                CursorHandler.SetCursor(Texture, Hotspot, CursorMode);
            }

            if (LockMode == CursorLockMode.None)
            {
                CursorHandler.UnLock();
            }
            else
            {
                CursorHandler.Lock();
            }
        }

        public override void OnBehaviourPause(Playable playable, FrameData info)
        {
            if (UnlockOnExit)
            {
                CursorHandler.UnLock();
            }
        }
    }
}