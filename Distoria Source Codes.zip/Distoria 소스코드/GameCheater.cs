using System;
using System.Collections.Generic;
using System.Linq;
using ProjectAAA.Core.Entity;
using ProjectAAA.Core.Managers;
using ProjectAAA.Core.Scene.Manager;
using ProjectAAA.Interaction.Items;
using ProjectAAA.Mob;
using ProjectAAA.Player;
using ProjectAAA.Player.Actions;
using ProjectAAA.SO;
using ProjectAAA.SO.Pool;
using ProjectAAA.UI;
using ProjectAAA.Utils;
using ProjectAAA.WeaponSystem;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement;
using EventType = ProjectAAA.Core.Managers.EventType;
using Logger = ProjectAAA.Utils.Logger;

public class GameCheater : SingletonMonoBehavior<GameCheater>
{
    public InventoryDataBaseSO weaponInven;
    public InventoryDataBaseSO itemInven;
    
    private Vector2 _weaponScrollPos;
    private Vector2 _consumableScrollPos;
    private Vector2 _buffItemScrollPos;
    
    private bool _showAlterStatDebug = false;
    private bool _invincible = false;

    private void Update()
    {
        #if ENABLE_CHEAT
        if (Input.GetKeyDown(KeyCode.F5))
        {
            _showAlterStatDebug = !_showAlterStatDebug;

            if (_showAlterStatDebug)
            {                
                CursorHandler.UnLock();
            }
            else
            {                
                CursorHandler.Lock();
            }
        }
        #else 
            _showAlterStatDebug = false;
        #endif
    }

    private void OnGUI()
    {
        if (!_showAlterStatDebug) return;

        GUIStyle contentsStyle = new GUIStyle
        {
            normal =
            {
                textColor = Color.yellow
            },
            fontSize = 30
        };

        GUIStyle tooltipStyle = new GUIStyle
        {
            normal =
            {
                textColor = Color.green,
            },
            fontSize = 25
        };
        
        GUILayout.BeginHorizontal();
        {
            Color prevColor1 = GUI.color;
            GUI.color = new Color(0, 0, 0, 0.7f);
            GUI.Box(new Rect(0, 0, Screen.width, Screen.height), GUIContent.none);
            GUI.color = prevColor1;
            
            GUILayout.Label("치트키 메뉴", tooltipStyle);
            GUILayout.BeginArea(new Rect(0, 50, 500, 1000));
            {
                GUILayout.Label("무기 스폰", tooltipStyle);
                _weaponScrollPos =
                    GUILayout.BeginScrollView(_weaponScrollPos, GUILayout.Width(400), GUILayout.Height(200));
                {
                    List<ObjectPoolSO> weapons = WeaponManager.Instance.WeaponGenerator.GetPools();
                    List<WeaponBase> weaponList = new List<WeaponBase>();

                    for (int i = 0; i < weapons.Count; i++)
                    { 
                        weaponList.Add(weapons[i].Prefab.GetComponent<WeaponBase>());
                    }

                    for (int i = 0; i < weaponList.Count; i++)
                    {
                        if (GUILayout.Button(weaponList[i].Name))
                        {
                            var weapon = WeaponManager.Instance.WeaponGenerator.GetValue(weaponList[i].WeaponId, PlayerManager.Instance.PlayerGo.transform);
                            weapon.SetParent(null);
                            weapon.SetPosition(PlayerManager.Instance.PlayerGo.transform.position +
                                             PlayerManager.Instance.PlayerGo.transform.up * 1f);
                        }
                    }
                }
                GUILayout.EndScrollView();
                GUILayout.Label("소모성 아이템 스폰", tooltipStyle);
                _consumableScrollPos = GUILayout.BeginScrollView(_consumableScrollPos, GUILayout.Width(400), GUILayout.Height(200));
                {
                    List<ObjectPoolSO> items = ItemManager.Instance.Generator.GetPools();
                    List<ItemBuilder> itemList = new List<ItemBuilder>();

                    for (int i = 0; i < items.Count; i++)
                    {
                        itemList.Add(items[i].Prefab.GetComponent<ItemBuilder>());
                    }

                    for (int i = 0; i < itemList.Count; i++)
                    {
                        if (GUILayout.Button(DatabaseManager.Instance.GetTable<ItemTableSO>().GetItem(itemList[i].ItemID).ItemName))
                        {
                            var item = ItemManager.Instance.Generator.GetValue(itemList[i].ItemID, PlayerManager.Instance.PlayerGo.transform);
                            item.SetParent(null);
                            item.Reference.DropStart(true);
                            item.SetPosition(PlayerManager.Instance.PlayerGo.transform.position +
                                                    PlayerManager.Instance.PlayerGo.transform.up * 1f);
                            item.Reference.ActiveItem();
                        }
                    }
                }
                GUILayout.EndScrollView();

                GUILayout.Label("재화", tooltipStyle);
                if (GUILayout.Button("열쇠 습득 + 1"))
                {
                    PlayerCurrencyManager.Instance.Key.Value += 1;
                }
                if (GUILayout.Button("골드 습득 + 100"))
                {
                    PlayerCurrencyManager.Instance.Gold.Value += 100;
                }

                GUILayout.Label("게임 플레이", tooltipStyle);
                
                GUILayout.Label("마우스 감도", tooltipStyle);
                GeneralSettingManager.Instance.CurrentMouseSensitive.Value = GUILayout.HorizontalSlider(GeneralSettingManager.Instance.CurrentMouseSensitive.Value, 0.01f, 1f, GUILayout.Width(400));
                
                if (GUILayout.Button("플레이어 데미지 부여"))
                {
                    var entity = FindFirstObjectByType<PlayerActionController>().GetComponent<LivingEntity>();
                    entity.GetComponentInChildren<HurtBox>(true).TakeDamage(new HitInfo()
                    {
                        Damage = 25f,
                        Hitter = gameObject,
                        Normal = Vector3.one,
                        Point = Vector3.zero,
                    });
                }
                if (GUILayout.Button("플레이어 회복 10"))
                {
                    var entity = FindFirstObjectByType<PlayerActionController>().GetComponent<LivingEntity>();
                    entity.Heal(10);
                }
                if (GUILayout.Button("무적"))
                {
                    _invincible = !_invincible;
                    if (_invincible)
                    {
                        FindFirstObjectByType<PlayerActionController>().GetComponentInChildren<LivingEntity>().Setup(200, float.MaxValue);
                    }
                    else
                    {
                        FindFirstObjectByType<PlayerActionController>().GetComponentInChildren<LivingEntity>().Setup(200, 0);
                    }
                }
                if (GUILayout.Button("게임 재시작"))
                {
                    RestartGameRoutine();
                }
                
                if (GUILayout.Button("퀘스트 클리어"))
                {
                    QuestManager.Instance.ClearCurrentQuest();
                }
            }
            GUILayout.EndArea();
            
            GUILayout.BeginArea(new Rect(500, 25, 500, 1000));
            {
                GUILayout.Label($"ReloadTime : {WeaponAlterStat.Instance.ReloadTime}", contentsStyle);
                GUILayout.Label($"Value1 : {WeaponAlterStat.Instance.Value1}", contentsStyle);
                GUILayout.Label($"FireInterval : {WeaponAlterStat.Instance.FireInterval}", contentsStyle);
                GUILayout.Label($"SwapTime : {WeaponAlterStat.Instance.SwapTime}", contentsStyle);
                GUILayout.Label($"MagazineSize : {WeaponAlterStat.Instance.MagazineSize}", contentsStyle);
                GUILayout.Label($"SpreadCount : {WeaponAlterStat.Instance.SpreadCount}", contentsStyle);
                GUILayout.Label($"CriticalMagnification : {WeaponAlterStat.Instance.CriticalMagnification}", contentsStyle);
                GUILayout.Label($"BulletDamage : {WeaponAlterStat.Instance.BulletDamage}", contentsStyle);
                GUILayout.Label($"BulletSpeed : {WeaponAlterStat.Instance.BulletSpeed}", contentsStyle);
                GUILayout.Label($"BulletLifeTime : {WeaponAlterStat.Instance.BulletLifeTime}", contentsStyle);
                GUILayout.Label($"BulletSize : {WeaponAlterStat.Instance.BulletSize}", contentsStyle);
                GUILayout.Label($"PlayerMoveSpeedFactor : {PlayerAlterStat.Instance.MoveSpeedFactor}", contentsStyle);
                GUILayout.Label($"PlayerDashCooldownFactor : {PlayerAlterStat.Instance.DashCooldownFactor}", contentsStyle);
            }
            GUILayout.EndArea();

            DisplayMonsterStageInfo();
        }
        GUILayout.EndHorizontal();
    }

    private void DisplayMonsterStageInfo()
    {
        GUIStyle contentsStyle = new GUIStyle
        {
            normal =
            {
                textColor = Color.yellow
            },
            fontSize = 30
        };

        GUILayout.BeginArea(new Rect(1000, 25, 900, 1000));
        
        MonsterStage stage = FindFirstObjectByType<MonsterStage>(FindObjectsInactive.Include);
        if (stage != null)
        {
            List<MonsterArea> areaList = stage.AreaList;
            foreach (MonsterArea area in areaList)
            {
                GUILayout.Label($"{area.name} [KillCount: {area.KillCount} / TotalCount: {area.Count}] - IsClear : {area.IsClear}", contentsStyle);
            }
        }
        else
        {
            GUILayout.Label($"Monster Stage 가 존재하지 않습니다.", contentsStyle);
        }
        GUILayout.EndArea();
    }

    private void RestartGameRoutine()
    {
        weaponInven.ResetInventory();
        itemInven.ResetInventory();
        PlayerActionController.PlayerInput.Disable();

        ClearDontDestroyOnLoadObjects();

        SceneManager.LoadScene(0);
    }

    // DontDestroyOnLoad 오브젝트 초기화용
    private void ClearDontDestroyOnLoadObjects()
    {
        var objects = FindObjectsByType<GameObject>(FindObjectsInactive.Include, FindObjectsSortMode.None);
        foreach (var obj in objects)
        {
            if (string.IsNullOrEmpty(obj.scene.name))
            {
                Destroy(obj);
            }
        }
    }
}