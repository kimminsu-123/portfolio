using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ProjectAAA.Core.Entity;
using ProjectAAA.Core.Managers;
using ProjectAAA.Core.Timer;
using ProjectAAA.Player;
using ProjectAAA.Utils;
using ProjectAAA.Utils.DataTable;
using ProjectAAA.WeaponSystem;
using Unity.Mathematics;
using UnityEngine;

namespace ProjectAAA.Interaction.Items
{
    public interface IItemBuff
    {
        public const string PositiveColor = "#00FF00";
        public const string NegativeColor = "#FF0000";
        
        public string Description { get; }
        public bool DisplayUI { get; }
        
        public void Execute(GameObject go);
        public void Reset(GameObject go);
    }
    
    public class ItemBuffComposite
    {
        public class Group
        {
            public EffectType Type;
            public IItemBuff Buff;
            public ItemBuffConditionBase Condition;
            public CooldownTimer Timer;
            public bool IsExecuted;

            public void Enable()
            {
                IsExecuted = false;

                Condition.Enable();
            }

            public void Disable()
            {
                Condition.Disable();
            }

            public void Reset(GameObject go)
            {
                Buff.Reset(go);
                Timer.Stop();
                IsExecuted = false;
            }
        }

        public List<Group> GetGroups => _buffs.Select(x => x.Value).ToList();

        private readonly SortedList<int, Group> _buffs = new();

        public void AddBuff(int seq, EffectType type, IItemBuff buff, ItemBuffConditionBase condition, float effectTime)
        {
            if (buff != null)
            {
                Group group = new Group
                {
                    Type = type,
                    Buff = buff,
                    Condition = condition,
                    Timer = new CooldownTimer(effectTime),
                    IsExecuted = false
                };

                _buffs.Add(seq, group);
            }
        }

        public void RemoveBuff(int seq, IItemBuff buff)
        {
            if (buff != null)
            {
                _buffs.Remove(seq);
            }
        }
        
        public void ResetAll(GameObject go)
        {
            foreach (Group group in _buffs.Values)
            {
                group.Reset(go);
            }
        }

        public void Enable()
        {
            foreach (Group group in _buffs.Values)
            {
                group.Enable();
            }
        }
        
        public void Disable()
        {
            foreach (Group group in _buffs.Values)
            {
                group.Disable();
            }
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendJoin("\n", _buffs.Values.Select(x => x.Buff.Description));
            return sb.ToString();
        }
    }
    
    public class ItemBuffHeal : IItemBuff
    {
        public string Description => $"<color={IItemBuff.PositiveColor}>{_healAmount:F0} 회복</color>";
        public bool DisplayUI { get; }

        private readonly float _healAmount;

        public ItemBuffHeal(float healAmount, bool displayUI)
        {
            _healAmount = healAmount;
            DisplayUI = displayUI;
        }
        
        public void Execute(GameObject go)
        {
            if (go.TryGetComponent(out LivingEntity entity))
            {
                entity.Heal(_healAmount);
            }
        }

        public void Reset(GameObject go)
        {
            /*if (go.TryGetComponent(out LivingEntity entity))
            {
                entity.TakeDamageDirect(_healAmount);
            }*/
        }
    }
    
    public class ItemBuffIncreaseMaxHp : IItemBuff
    {
        public string Description
        {
            get
            {
                decimal v = Convert.ToDecimal(_ratio);
                decimal round = Math.Round((v - 1.0m) * 100.0m);
                decimal abs = Math.Abs(round);

                return _ratio < 1.0f ?
                    // 안좋은 효과
                    $"<b><color={IItemBuff.NegativeColor}>{abs:F0}% 최대 체력 감소</color></b>" :
                    // 좋은 효과
                    $"<color={IItemBuff.PositiveColor}>{abs:F0}% 최대 체력 증가</color>";
            }
        }
        public bool DisplayUI { get; }

        private readonly float _ratio;

        private float _increaseAmount;
        
        public ItemBuffIncreaseMaxHp(float ratio, bool displayUI)
        {
            _ratio = ratio;
            DisplayUI = displayUI;
        }
        
        public void Execute(GameObject go)
        {
            if (go.TryGetComponent(out LivingEntity entity))
            {
                float newMaxHp = entity.MaxHealth * _ratio;
                _increaseAmount = newMaxHp - entity.MaxHealth;
                
                entity.SetMaxHealth(newMaxHp);
            }
        }

        public void Reset(GameObject go)
        {
            if (go.TryGetComponent(out LivingEntity entity))
            {
                float newMaxHp = entity.MaxHealth - _increaseAmount;
                
                entity.SetMaxHealth(newMaxHp);
            }
        }
    }
    
    public class ItemBuffGetMoney : IItemBuff
    {
        public string Description => $"<color={IItemBuff.PositiveColor}>{_amount} 골드 증가</color>";
        public bool DisplayUI { get; }

        private readonly int _amount;
        
        public ItemBuffGetMoney(int amount, bool displayUI)
        {
            _amount = amount;
            DisplayUI = displayUI;
        }
        
        public void Execute(GameObject go)
        {
            if (_amount < 0)
            {
                PlayerCurrencyManager.Instance.UseGold(_amount);
            }
            else
            {
                PlayerCurrencyManager.Instance.Gold.Value += _amount;
            }
        }

        public void Reset(GameObject go)
        {
            /*if (_amount < 0)
            {
                PlayerCurrencyManager.Instance.Gold.Value += _amount;
            }
            else
            {
                PlayerCurrencyManager.Instance.UseGold(_amount);
            }*/
        }
    }
  
    public class ItemBuffGetKey : IItemBuff
    {
        public string Description => $"<color={IItemBuff.PositiveColor}>{_amount} 열쇠 증가</color>";
        public bool DisplayUI { get; }

        private readonly int _amount;
        
        public ItemBuffGetKey(int amount, bool displayUI)
        {
            _amount = amount;
            DisplayUI = displayUI;
        }
        
        public void Execute(GameObject go)
        {
            if (_amount < 0)
            {
                PlayerCurrencyManager.Instance.UseKey(_amount);
            }
            else
            {
                PlayerCurrencyManager.Instance.Key.Value += _amount;
            }
        }
        
        public void Reset(GameObject go)
        {
            /*if (_amount < 0)
            {
                PlayerCurrencyManager.Instance.Key.Value += _amount;
            }
            else
            {
                PlayerCurrencyManager.Instance.UseKey(_amount);
            }*/
        }
    }
    
    public class ItemBuffFillCurrentAmmo : IItemBuff
    {
        public string Description
        {
            get
            {
                decimal v = Convert.ToDecimal(_ratio);
                decimal round = Math.Round((v - 1.0m) * 100.0m);
                decimal abs = Math.Abs(round);

                return $"<color={IItemBuff.PositiveColor}>{abs:F0}% 현재 탄창 보충</color>";
            }
        }

        public bool DisplayUI { get; }

        private readonly float _ratio;
        
        public ItemBuffFillCurrentAmmo(float ratio, bool displayUI)
        {
            _ratio = ratio;
            DisplayUI = displayUI;
        }
        
        public void Execute(GameObject go)
        {
            if (go.TryGetComponent(out WeaponHandler weaponHandler))
            {
                weaponHandler.FillCurrentWeaponAmmo(_ratio);
            }
        }
        
        public void Reset(GameObject go)
        {
            
        }
    }
    
    public class ItemBuffFillAllAmmo : IItemBuff
    {
        public string Description
        {
            get
            {
                decimal v = Convert.ToDecimal(_ratio);
                decimal round = Math.Round((v - 1.0m) * 100.0m);
                decimal abs = Math.Abs(round);

                return $"<color={IItemBuff.PositiveColor}>{abs:F0}% 전체 탄창 보충</color>";
            }
        }

        public bool DisplayUI { get; }

        private readonly float _ratio;
        
        public ItemBuffFillAllAmmo(float ratio, bool displayUI)
        {
            _ratio = ratio;
            DisplayUI = displayUI;
        }
        
        public void Execute(GameObject go)
        {
            if (go.TryGetComponent(out WeaponHandler weaponHandler))
            {
                weaponHandler.FillAllAmmo(_ratio);
            }
        }
        
        public void Reset(GameObject go)
        {
            
        }
    }
    
    public class ItemBuffReduceReloadTime : IItemBuff
    {
        public string Description
        {
            get
            {
                decimal v = Convert.ToDecimal(_ratio);
                decimal round = Math.Round((v - 1.0m) * 100.0m);
                decimal abs = Math.Abs(round);

                return _ratio >= 1f ?
                    // 안좋은 효과
                    $"<b><color={IItemBuff.NegativeColor}>{abs:F0}% 재장전 시간 증가</color></b>" :
                    // 좋은 효과
                    $"<color={IItemBuff.PositiveColor}>{abs:F0}% 재장전 시간 감소</color>";
            }
        }

        public bool DisplayUI { get; }

        private readonly float _ratio;
        
        public ItemBuffReduceReloadTime(float ratio, bool displayUI)
        {
            _ratio = ratio;
            DisplayUI = displayUI;
        }
        
        public void Execute(GameObject go)
        {
            WeaponAlterStat.Instance.ReloadTime *= _ratio;
        }
        
        public void Reset(GameObject go)
        {
            WeaponAlterStat.Instance.ReloadTime /= _ratio;
        }
    }
    
    public class ItemBuffIncreaseValue1 : IItemBuff
    {
        public string Description
        {
            get
            {
                decimal v = Convert.ToDecimal(_ratio);
                decimal round = Math.Round((v - 1.0m) * 100.0m);
                decimal abs = Math.Abs(round);

                return _ratio >= 1f ?
                    // 안좋은 효과
                    $"<b><color={IItemBuff.NegativeColor}>{abs:F0}% 발사간 간격 및 차징 시간 증가</color></b>" :
                    // 좋은 효과
                    $"<color={IItemBuff.PositiveColor}>{abs:F0}% 발사간 간격 및 차징 시간 감소</color>";
            }
        }

        public bool DisplayUI { get; }

        private readonly float _ratio;
        
        public ItemBuffIncreaseValue1(float ratio, bool displayUI)
        {
            _ratio = ratio;
            DisplayUI = displayUI;
        }

        public void Execute(GameObject go)
        {
            WeaponAlterStat.Instance.Value1 *= _ratio;
        }
        
        public void Reset(GameObject go)
        {
            WeaponAlterStat.Instance.Value1 /= _ratio;
        }
    }
    
    public class ItemBuffIncreaseFireRate : IItemBuff
    {
        public string Description
        {
            get
            {
                decimal v = Convert.ToDecimal(_ratio);
                decimal round = Math.Round((v - 1.0m) * 100.0m);
                decimal abs = Math.Abs(round);

                return _ratio >= 1f ?
                    // 안좋은 효과
                    $"<b><color={IItemBuff.NegativeColor}>{abs:F0}% 발사 간격 증가</color></b>" :
                    // 좋은 효과
                    $"<color={IItemBuff.PositiveColor}>{abs:F0}% 발사 간격 감소</color>";
            }
        }

        public bool DisplayUI { get; }

        private readonly float _ratio;
        
        public ItemBuffIncreaseFireRate(float ratio, bool displayUI)
        {
            _ratio = ratio;
            DisplayUI = displayUI;
        }
        
        public void Execute(GameObject go)
        {
            WeaponAlterStat.Instance.FireInterval *= _ratio;
        }
        
        public void Reset(GameObject go)
        {
            WeaponAlterStat.Instance.FireInterval /= _ratio;
        }
    }
    
    public class ItemBuffIncreaseWeaponSwapTime : IItemBuff
    {
        public string Description
        {
            get
            {
                decimal v = Convert.ToDecimal(_ratio);
                decimal round = Math.Round((v - 1.0m) * 100.0m);
                decimal abs = Math.Abs(round);

                return _ratio >= 1f ?
                    // 안좋은 효과
                    $"<b><color={IItemBuff.NegativeColor}>{abs:F0}% 무기 스왑시간 증가</color></b>" :
                    // 좋은 효과
                    $"<color={IItemBuff.PositiveColor}>{abs:F0}% 무기 스왑시간 감소</color>";
            }
        }

        public bool DisplayUI { get; }

        private readonly float _ratio;
        
        public ItemBuffIncreaseWeaponSwapTime(float ratio, bool displayUI)
        {
            _ratio = ratio;
            DisplayUI = displayUI;
        }
        
        public void Execute(GameObject go)
        {
            WeaponAlterStat.Instance.SwapTime *= _ratio;
        }
        
        public void Reset(GameObject go)
        {
            WeaponAlterStat.Instance.SwapTime /= _ratio;
        }
    }
    
    public class ItemBuffIncreaseMagazineSize : IItemBuff
    {
        public string Description
        {
            get
            {
                int abs = Math.Abs(_amount);
                
                return _amount < 0 ?
                    // 안좋은 효과
                    $"<b><color={IItemBuff.NegativeColor}>{abs} 탄창 크기 감소</color></b>" :
                    // 좋은 효과
                    $"<color={IItemBuff.PositiveColor}>{abs} 탄창 크기 증가</color>";
            }
        }

        public bool DisplayUI { get; }

        private readonly int _amount;
        
        public ItemBuffIncreaseMagazineSize(int amount, bool displayUI)
        {
            _amount = amount;
            DisplayUI = displayUI;
        }
        
        public void Execute(GameObject go)
        {
            WeaponAlterStat.Instance.MagazineSize += _amount;
            if (go.TryGetComponent(out WeaponHandler weaponHandler))
            {
                weaponHandler.ResizeMagazine(_amount);
            }
            WeaponManager.Instance.ResizeMagazine(_amount);
        }
        
        public void Reset(GameObject go)
        {
            WeaponAlterStat.Instance.MagazineSize = Mathf.Max(0, WeaponAlterStat.Instance.MagazineSize - _amount);
            if (go.TryGetComponent(out WeaponHandler weaponHandler))
            {
                weaponHandler.ResizeMagazine(_amount);
            }
            WeaponManager.Instance.ResizeMagazine(_amount);
        }
    }

    public class ItemBuffIncreaseSpreadCount : IItemBuff
    {
        public string Description
        {
            get
            {
                int abs = Math.Abs(_amount);
                
                return _amount < 0 ?
                    // 안좋은 효과
                    $"<b><color={IItemBuff.NegativeColor}>{abs} 산탄량 감소</color></b>" :
                    // 좋은 효과
                    $"<color={IItemBuff.PositiveColor}>{abs} 산탄량 증가</color>";
            }
        }

        public bool DisplayUI { get; }

        private readonly int _amount;
        
        public ItemBuffIncreaseSpreadCount(int amount, bool displayUI)
        {
            _amount = amount;
            DisplayUI = displayUI;
        }
        
        public void Execute(GameObject go)
        {
            WeaponAlterStat.Instance.SpreadCount = Mathf.Max(0, WeaponAlterStat.Instance.SpreadCount + _amount);   
        }

        public void Reset(GameObject go)
        {
            WeaponAlterStat.Instance.SpreadCount = Mathf.Max(0, WeaponAlterStat.Instance.SpreadCount - _amount);
        }
    }

    public class ItemBuffIncreaseCriticalMagnification : IItemBuff
    {
        public string Description
        {
            get
            {
                decimal v = Convert.ToDecimal(_ratio);
                decimal round = Math.Round((v - 1.0m) * 100.0m);
                decimal abs = Math.Abs(round);

                return _ratio < 1f ?
                    // 안좋은 효과
                    $"<b><color={IItemBuff.NegativeColor}>{abs:F0}% 치명타 배율 감소</color></b>" :
                    // 좋은 효과
                    $"<color={IItemBuff.PositiveColor}>{abs:F0}% 치명타 배율 증가</color>";
            }
        }

        public bool DisplayUI { get; }

        private readonly float _ratio;

        public ItemBuffIncreaseCriticalMagnification(float ratio, bool displayUI)
        {
            _ratio = ratio;
            DisplayUI = displayUI;
        }
        
        public void Execute(GameObject go)
        {
            WeaponAlterStat.Instance.CriticalMagnification *= _ratio;
        }
        
        public void Reset(GameObject go)
        {
            WeaponAlterStat.Instance.CriticalMagnification /= _ratio;
        }
    }

    public class ItemBuffIncreaseBulletDamage : IItemBuff
    {
        public string Description
        {
            get
            {
                decimal v = Convert.ToDecimal(_ratio);
                decimal round = Math.Round((v - 1.0m) * 100.0m);
                decimal abs = Math.Abs(round);

                return _ratio < 1f ?
                    // 안좋은 효과
                    $"<b><color={IItemBuff.NegativeColor}>{abs:F0}% 탄알 대미지 감소</color></b>" :
                    // 좋은 효과
                    $"<color={IItemBuff.PositiveColor}>{abs:F0}% 탄알 대미지 증가</color>";
            }
        }

        public bool DisplayUI { get; }

        private readonly float _ratio;

        public ItemBuffIncreaseBulletDamage(float ratio, bool displayUI)
        {
            _ratio = ratio;
            DisplayUI = displayUI;
        }
        
        public void Execute(GameObject go)
        {
            WeaponAlterStat.Instance.BulletDamage *= _ratio;
        }

        public void Reset(GameObject go)
        {
            WeaponAlterStat.Instance.BulletDamage /= _ratio;
        }
    }
    
    public class ItemBuffIncreaseBulletSpeed : IItemBuff
    {
        public string Description
        {
            get
            {
                decimal v = Convert.ToDecimal(_ratio);
                decimal round = Math.Round((v - 1.0m) * 100.0m);
                decimal abs = Math.Abs(round);

                return _ratio < 1f ?
                    // 안좋은 효과
                    $"<b><color={IItemBuff.NegativeColor}>{abs:F0}% 탄알 속도 감소</color></b>" :
                    // 좋은 효과
                    $"<color={IItemBuff.PositiveColor}>{abs:F0}% 탄알 속도 증가</color>";
            }
        }

        public bool DisplayUI { get; }

        private readonly float _ratio;
        
        public ItemBuffIncreaseBulletSpeed(float ratio, bool displayUI)
        {
            _ratio = ratio;
            DisplayUI = displayUI;
        }
        
        public void Execute(GameObject go)
        {
            WeaponAlterStat.Instance.BulletSpeed *= _ratio;
        }

        public void Reset(GameObject go)
        {
            WeaponAlterStat.Instance.BulletSpeed /= _ratio;
        }
    }
    
    public class ItemBuffIncreaseBulletRange : IItemBuff
    {
        public string Description
        {
            get
            {
                decimal v = Convert.ToDecimal(_ratio);
                decimal round = Math.Round((v - 1.0m) * 100.0m);
                decimal abs = Math.Abs(round);

                return _ratio < 1f ?
                    // 안좋은 효과
                    $"<b><color={IItemBuff.NegativeColor}>{abs:F0}% 탄알 사거리 감소</color></b>" :
                    // 좋은 효과
                    $"<color={IItemBuff.PositiveColor}>{abs:F0}% 탄알 사거리 증가</color>";
            }
        }

        public bool DisplayUI { get; }

        private readonly float _ratio;
        
        public ItemBuffIncreaseBulletRange(float ratio, bool displayUI)
        {
            _ratio = ratio;
            DisplayUI = displayUI;
        }
        
        public void Execute(GameObject go)
        {
            WeaponAlterStat.Instance.BulletLifeTime *= _ratio;
        }

        public void Reset(GameObject go)
        {
            WeaponAlterStat.Instance.BulletLifeTime /= _ratio;
        }
    }
    
    public class ItemBuffIncreaseBulletSize : IItemBuff
    {
        public string Description
        {
            get
            {
                decimal v = Convert.ToDecimal(_ratio);
                decimal round = Math.Round((v - 1.0m) * 100.0m);
                decimal abs = Math.Abs(round);

                return _ratio < 1f ?
                    // 안좋은 효과
                    $"<b><color={IItemBuff.NegativeColor}>{abs:F0}% 탄알 크기 감소</color></b>" :
                    // 좋은 효과
                    $"<color={IItemBuff.PositiveColor}>{abs:F0}% 탄알 크기 증가</color>";
            }
        }

        public bool DisplayUI { get; }

        private readonly float _ratio;
        
        public ItemBuffIncreaseBulletSize(float ratio, bool displayUI)
        {
            _ratio = ratio;
            DisplayUI = displayUI;
        }
        
        public void Execute(GameObject go)
        {
            WeaponAlterStat.Instance.BulletSize *= _ratio;
        }

        public void Reset(GameObject go)
        {
            WeaponAlterStat.Instance.BulletSize /= _ratio;
        }
    }

    public class ItemBuffIncreasePlayerMoveSpeed : IItemBuff
    {
        public string Description
        {
            get
            {
                decimal v = Convert.ToDecimal(_ratio);
                decimal round = Math.Round((v - 1.0m) * 100.0m);
                decimal abs = Math.Abs(round);

                return _ratio < 1f ?
                    // 안좋은 효과
                    $"<b><color={IItemBuff.NegativeColor}>{abs:F0}% 이동 속도 감소</color></b>" :
                    // 좋은 효과
                    $"<color={IItemBuff.PositiveColor}>{abs:F0}% 이동 속도 증가</color>";
            }
        }

        public bool DisplayUI { get; }

        private readonly float _ratio;
        
        public ItemBuffIncreasePlayerMoveSpeed(float ratio, bool displayUI)
        {
            _ratio = ratio;
            DisplayUI = displayUI;
        }
        
        public void Execute(GameObject go)
        {
            PlayerAlterStat.Instance.MoveSpeedFactor *= _ratio;
        }

        public void Reset(GameObject go)
        {
            PlayerAlterStat.Instance.MoveSpeedFactor /= _ratio;
        }
    }
    
    public class ItemBuffIncreasePlayerDashCooldown : IItemBuff
    {
        public string Description
        {
            get
            {
                decimal v = Convert.ToDecimal(_ratio);
                decimal round = Math.Round((v - 1.0m) * 100.0m);
                decimal abs = Math.Abs(round);

                return _ratio >= 1f ?
                    // 안좋은 효과
                    $"<b><color={IItemBuff.NegativeColor}>{abs:F0}% 대쉬 쿨타임 증가</color></b>" :
                    // 좋은 효과
                    $"<color={IItemBuff.PositiveColor}>{abs:F0}% 대쉬 쿨타임 감소</color>";
            }
        }

        public bool DisplayUI { get; }

        private readonly float _ratio;
        
        public ItemBuffIncreasePlayerDashCooldown(float ratio, bool displayUI)
        {
            _ratio = ratio;
            DisplayUI = displayUI;
        }
        
        public void Execute(GameObject go)
        {
            PlayerAlterStat.Instance.DashCooldownFactor *= _ratio;
        }

        public void Reset(GameObject go)
        {
            PlayerAlterStat.Instance.DashCooldownFactor /= _ratio;
        }
    }
}