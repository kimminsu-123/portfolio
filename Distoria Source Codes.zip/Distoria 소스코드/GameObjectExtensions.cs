using System.Collections.Generic;
using UnityEngine;

namespace ProjectAAA.Utils
{
    public static class GameObjectExtensions
    {
        public static T GetOrAddComponent<T>(this GameObject gameObject) where T : Component
        {
            if (gameObject == null)
            {
                return null;
            }

            T result = gameObject.GetComponent<T>();
            if (result == null)
            {
                result = gameObject.AddComponent<T>();
            }
            
            return result;
        }
        
        /// <summary>
        /// 컴포넌트를 가져오거나 추가하는 함수
        /// </summary>
        /// <returns>AddComponent 가 된경우 True 가 됩니다. 다른 상황은 False</returns>
        public static bool TryGetOrAddComponent<T>(this GameObject gameObject, out T ret) where T : Component
        {
            ret = null;
            
            if (gameObject == null)
            {
                return false;
            }

            ret = gameObject.GetComponent<T>();
            if (ret == null)
            {
                ret = gameObject.AddComponent<T>();
                return true;
            }
            
            return false;
        }

        public static void ChangeLayerAll(this GameObject gameObject, int layer)
        {
            gameObject.layer = layer;
            for (int i = 0; i < gameObject.transform.childCount; i++)
            {
                Transform child = gameObject.transform.GetChild(i);
                ChangeLayerAll(child.gameObject, layer);
            }
        }
        
        public static T[] GetComponentsOnlyChildren<T>(this GameObject gameObject, int layer = -1) where T : Component
        {
            T[] components = gameObject.GetComponentsInChildren<T>();
            
            List<T> result = new List<T>();
            for (int i = 0; i < components.Length; i++)
            {
                if (components[i].gameObject.GetHashCode().Equals(gameObject.GetHashCode()))
                {
                    continue;
                }

                if (layer != -1 && components[i].gameObject.layer != layer)
                {
                    continue;
                }
                
                result.Add(components[i]);
            }
            return result.ToArray();
        }
    }
}