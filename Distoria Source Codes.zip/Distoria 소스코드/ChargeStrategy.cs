using ProjectAAA.Core.Timer;
using UnityEngine;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.WeaponSystem
{
    public class ChargeStrategy : WeaponNormalFireStrategy
    {
        private enum ChargeState
        {
            None,
            BeginCharge,
            Charging,
            EndCharge,
        }
        
        private readonly CooldownTimer _chargeTimer;

        private ChargeState _currentChargeState;

        public ChargeStrategy(Transform shootPos, WeaponNormal weapon) : base(shootPos, weapon)
        {
            _chargeTimer = new CooldownTimer(weapon.Value1);
            _chargeTimer.OnCompleteCallback += OnEndCharge;
            _currentChargeState = ChargeState.None;
        }

        public override void Trigger()
        {
            base.Trigger();
            
            if (FireIntervalTimer.IsRunning) return;
            if (CurrentMagazine.Count <= 0) return;
            if (CurrentFireState != FireState.None) return;
            
            if (_currentChargeState == ChargeState.None)
            {
                _currentChargeState = ChargeState.BeginCharge;
                
                Logger.Log("Charge Strategy", $"차징 시작", Color.green);
            }
        }
        
        public override void Active()
        {
            base.Active();

            if (CurrentTriggerState == TriggerState.Triggered)
            {
                Trigger();
            }
        }

        public override void Release()
        {
            base.Release();
            
            if (_currentChargeState == ChargeState.EndCharge)
            {
                Fire();
                
                FireIntervalTimer.SetTime(CurrentWeapon.FireInterval);
                FireIntervalTimer.Start();
            }
            else
            {
                Logger.Log("Charge Strategy", $"차징 취소", Color.green);
            }
            
            CurrentWeapon.onEndFireCallback?.Invoke();

            _chargeTimer.Stop();
            _currentChargeState = ChargeState.None;
        }

        public override void Stop()
        {
            base.Stop();
            
            _chargeTimer.Stop();
            _currentChargeState = ChargeState.None;
        }

        protected override void OnFireIntervalCompleted()
        {
            base.OnFireIntervalCompleted();
            
            _currentChargeState = ChargeState.None;

            if (CurrentTriggerState == TriggerState.Triggered)
            {
                Trigger();
            }
        }
        
        protected override void Process()
        {
            if (CurrentTriggerState != TriggerState.Triggered) return;
            
            switch (_currentChargeState)
            {
                case ChargeState.BeginCharge:
                    HandleTrigger();
                    break;
                case ChargeState.Charging:
                    HandleCharge();
                    break;
            }
        }

        private void HandleTrigger()
        {
            CurrentWeapon.onBeginFireCallback?.Invoke();

            _chargeTimer.SetTime(CurrentWeapon.Value1);
            _chargeTimer.Start();
            _currentChargeState = ChargeState.Charging;
            
            Logger.Log("Charge Strategy", $"차징 중....", Color.green);
        }

        private void HandleCharge()
        {
            _chargeTimer.Tick(Time.deltaTime);
        }
        
        private void OnEndCharge()
        {
            _currentChargeState = ChargeState.EndCharge;

            Logger.Log("Charge Strategy", $"차징 완료!", Color.green);
        }
    }
}