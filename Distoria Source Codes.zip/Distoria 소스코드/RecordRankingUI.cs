using System;
using ProjectAAA.Core.Managers;
using ProjectAAA.Core.Scene.Manager;
using ProjectAAA.Network;
using ProjectAAA.Utils;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace ProjectAAA.UI
{
    public class RecordRankingUI : UiBase
    {
        protected override Type RegisterType => typeof(RecordRankingUI);

        [SerializeField] private PointerButton sendRankButton;
        [SerializeField] private TMP_Text gameModeText;
        [SerializeField] private TMP_Text aliveTimeText;
        [SerializeField] private TMP_InputField userNameInput;

        protected override void OnAwake()
        {
            userNameInput.onSubmit.AddListener(_ => ProcessSend());
            sendRankButton.onClick.AddListener(ProcessSend);
        }

        private void Start()
        {
            gameObject.SetActive(false);
        }

        private void ProcessSend()
        {
            if (string.IsNullOrEmpty(userNameInput.text))
            {
                return;
            }
            
            GameMode mode = GameManager.Instance.Mode;
            string userName = userNameInput.text;
            long ticks = GameManager.Instance.AliveTimeStopwatch.ToTimeSpan().Ticks;
            
            RankingServer.Instance.Send(mode, userName, ticks);

            PlayerManager.Instance.ActionController.UnBlockAllActions();
            PlayerManager.Instance.PlayerUI.SetActive(false);

            SoundManager.Instance.StopBGM();
            GameManager.Instance.LeaveToLobby();
            
            Hide();
        }

        public void SetGameModeText(GameMode gameMode)
        {
            gameModeText.text = $"게임 모드 [ {gameMode} ]";
        }
        
        public void SetAliveTimeText(TimeSpan time)
        {
            aliveTimeText.text = $"생존 시간 [ {time.Minutes:00} : {time.Seconds:00} ]";
        }
        
        public override void Show()
        {
            CursorHandler.UnLock();
            
            gameObject.SetActive(true);

            userNameInput.text = string.Empty;
            userNameInput.ReleaseSelection();
        }

        public override void Hide()
        {
            CursorHandler.Lock();
            
            gameObject.SetActive(false);
        }
    }
}