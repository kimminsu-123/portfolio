using System;
using ProjectAAA.Core.Managers;
using ProjectAAA.Core.Timer;
using ProjectAAA.SO;
using ProjectAAA.Utils.DataTable;
using UnityEngine;

namespace ProjectAAA.UI.MainFight
{
    public struct BuffCollectData
    {
        public Color TypeColor;
        public string Description;
        public CooldownTimer Timer;
    }
    
    public class BuffCollectUI : CollectUI<BuffCollectElementUI, BuffCollectData>
    {
        public void Add(EffectType type, string desc, CooldownTimer timer)
        {
            var color = ItemManager.Instance.GetColorByBuffType(type);
            
            Add(new BuffCollectData()
            {
                TypeColor = color,
                Description = desc,
                Timer = timer
            });
        }
    }
}