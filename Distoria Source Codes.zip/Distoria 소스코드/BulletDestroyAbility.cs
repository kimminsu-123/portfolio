using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using ProjectAAA.Core.Entity;
using ProjectAAA.Utils;
using ProjectAAA.Utils.DataTable;
using UnityEngine;

namespace ProjectAAA.WeaponSystem
{
    public abstract class BulletDestroyAbility
    {
        protected BulletBase Bullet { get; private set; }
        protected AddBulletCondition Condition { get; private set; }
        protected BulletDestroyAbility Next { get; private set; } 
        
        protected BulletDestroyAbility(BulletBase bullet, AddBulletCondition condition)
        {
            Bullet = bullet;
            Condition = condition;
        }

        public void SetNext(BulletDestroyAbility ability)
        {
            if (Next == null)
            {
                Next = ability;
            }
            else
            {
                Next.SetNext(ability);
            }
        }

        public virtual void Init()
        {
            Next?.Init();
        }

        public virtual async UniTask OnDestroy(BulletDestroyType destroyType)
        {
            if (Next != null)
            {
                await Next.OnDestroy(destroyType);            
            }
        }

        protected bool CheckCondition(BulletDestroyType destroyType)
        {
            bool ret = Condition == AddBulletCondition.None;
            ret |= Condition == AddBulletCondition.DestroyAnyway;
            ret |= destroyType == BulletDestroyType.OverLifeTime && Condition == AddBulletCondition.DestroyByOverLifeTime;
            ret |= destroyType == BulletDestroyType.Hit && Condition == AddBulletCondition.DestroyByHit;
            return ret;
        }

        protected Collider GetCenter(Collider other)
        {
            bool ret = other.TryGetComponent(out HurtBox hurtBox);
            return ret ? hurtBox.centerHurtBox.CachedCollider : other;
        }
        
        protected bool CheckCenter(Collider other)
        {
            bool ret = other.TryGetComponent(out HurtBox hurtBox);
            if (ret)
            {
                ret &= hurtBox.isCenter;
            }
            return ret;
        }
    }
}