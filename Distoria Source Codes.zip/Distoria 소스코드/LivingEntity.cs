using System;
using System.Linq;
using Newtonsoft.Json;
using ProjectAAA.Core.Managers;
using ProjectAAA.UI;
using ProjectAAA.Utils;
using ProjectAAA.Utils.DataTable;
using UnityEngine;
using UnityEngine.Events;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.Core.Entity
{
    public class LivingEntity : MonoBehaviour, ISaveDataContainer
    {
        public UnityEvent onDeath;
        public UnityEvent<HitInfo> onTakeDamage;
        public UnityEvent onUpdate;

        [SerializeField] private float maxHealth;
        [SerializeField] private float defence;
        [SerializeField] private int statusResistance;

        public float MaxHealth => maxHealth;
        public float Defence => defence;

        public int StatusResistance => statusResistance;

        public float CurrentHealth { get; private set; }
        public HitInfo LastHitInfo { get; private set; }
        
        public bool IsDead => CurrentHealth <= 0f;

        private HurtBox[] _hurtBoxes;
        
        private void Awake()
        {
            Setup(MaxHealth, Defence);
            _hurtBoxes = GetComponentsInChildren<HurtBox>(true);
        }

        private void Start()
        {
            HurtBox center = _hurtBoxes.FirstOrDefault(x => x.isCenter);
            
            for (int i = 0; i < _hurtBoxes.Length; i++)
            {
                _hurtBoxes[i].centerHurtBox = center;
                _hurtBoxes[i].rootTr = transform;
                _hurtBoxes[i].onTakeDamage.AddListener(OnTakeDamage);
            }
        }

        private void OnEnable()
        {
            ActiveHurtBoxes();
        }

        private void OnTakeDamage(HitInfo info)
        {
            if (IsDead)
            {
                return;
            }
            
            LastHitInfo = info;
            
            float damage = info.Damage;
            float damageMultiplier = 100 / (100 + Defence);
            float result = damage * damageMultiplier;
            
            info.Damage = result;

            CurrentHealth = Mathf.Max(0f, CurrentHealth - info.Damage);
            if (CurrentHealth <= 0f)
            {
                onDeath?.Invoke();
                for (int i = 0; i < _hurtBoxes.Length; i++)
                {
                    _hurtBoxes[i].gameObject.SetActive(false);
                }
            }
            
            onUpdate?.Invoke();
            onTakeDamage?.Invoke(info);
        }

        public void Setup(float maxHp, float def, int status = 0)
        {
            LastHitInfo = default;
            maxHealth = maxHp;
            defence = def;
            CurrentHealth = maxHp;
            statusResistance = status;
            onUpdate?.Invoke();
        }

        public void SetMaxHealth(float maxHp)
        {
            float diff = Mathf.Max(0, maxHp - maxHealth);
            
            maxHealth = maxHp;
            CurrentHealth = Mathf.Min(CurrentHealth + diff, maxHealth);
            onUpdate?.Invoke();
        }

        public void Heal(float healAmount)
        {
            if (!IsDead)
            {
                CurrentHealth = Mathf.Min(CurrentHealth + healAmount, maxHealth);
                onUpdate?.Invoke();
            } 
        }

        public void ActiveHurtBoxes()
        {
            if (CurrentHealth > 0 && _hurtBoxes != null)
            {
                for (int i = 0; i < _hurtBoxes.Length; i++)
                {
                    _hurtBoxes[i].gameObject.SetActive(true);
                }
            }
        }
        
        public void TakeDamageDirect(float damage)
        {
            if (!float.IsFinite(damage) || damage <= 0f)
            {
                return;
            }
            
            if (IsDead)
            {
                return;
            }

            float prev = CurrentHealth;
            CurrentHealth = Mathf.Max(0f, prev - damage);

            GameObject hitter = gameObject;
            GameObject target = null;
            Vector3 point = transform.position;

            if (_hurtBoxes != null && _hurtBoxes.Length > 0 && _hurtBoxes[0] != null && _hurtBoxes[0].centerHurtBox != null)
            {
                target = _hurtBoxes[0].centerHurtBox.gameObject;
                point  = _hurtBoxes[0].centerHurtBox.transform.position;
            }
            else
            {
                target = gameObject;
            }

            LastHitInfo = new HitInfo
            {
                Hitter = hitter,
                Target = target,
                Point = point,
                Damage = damage,
            };
            onTakeDamage?.Invoke(LastHitInfo);

            if (CurrentHealth <= 0f)
            {
                onDeath?.Invoke();

                if (_hurtBoxes != null)
                {
                    for (int i = 0; i < _hurtBoxes.Length; i++)
                    {
                        if (_hurtBoxes[i] != null)
                            _hurtBoxes[i].gameObject.SetActive(false);
                    }
                }
            }
            onUpdate?.Invoke();
        }


        public string Save()
        {
            SaveDataElement_PlayerStat stat = new SaveDataElement_PlayerStat
            {
                MaxHp = MaxHealth,
                CurrentHp = CurrentHealth,
                Defense = defence
            };
            return JsonConvert.SerializeObject(stat);
        }

        public void Load(string json)
        {
            SaveDataElement_PlayerStat data = JsonConvert.DeserializeObject<SaveDataElement_PlayerStat>(json);
            SetMaxHealth(data.MaxHp);
            CurrentHealth = data.CurrentHp;
            defence = data.Defense;
        }

        public void Clear()
        {
            Setup(MaxHealth, Defence);
        }

        public void SetDefense(float def)
        {
            defence = def;
        }

        public void SetAllHurtBoxesToCritical()
        {
            for (int i = 0; i < _hurtBoxes.Length; i++)
            {
                _hurtBoxes[i].isCriticalZone = true;
            }
        }

        public void Stop()
        {
            CurrentHealth = 0;
            onDeath?.Invoke();
            for (int i = 0; i < _hurtBoxes.Length; i++)
            {
                _hurtBoxes[i].gameObject.SetActive(false);
            }
        }
        
        public string FileName => "playerstat";
    }
}