using System.Collections.Generic;
using ProjectAAA.Quests;
using TMPro;
using UnityEngine;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.UI.Shop
{
    public class DarkShopUI : MonoBehaviour
    {
        [SerializeField] private GameObject slotsPanel;
        [SerializeField] private GameObject lockedPanel;
        [SerializeField] private TMP_Text questMsg;
        [SerializeField] private TMP_Text goalMsg;
        
        public void Setup(string message, QuestBase.Status status)
        {
            if (!string.IsNullOrEmpty(message))
            {
                string[] split = message.Split('_');
                if (split.Length != 2)
                {
                    Logger.LogError("DarkShopUI", $"형식에 맞지 않는 문자열입니다 : {message}");
                    return;
                }
            
                questMsg.text = split[0];
                goalMsg.text = split[1];
            }
            else
            {
                questMsg.text = string.Empty;
                goalMsg.text = string.Empty;
            }
            
            slotsPanel.SetActive(status is QuestBase.Status.Clear or QuestBase.Status.Ended);
            lockedPanel.SetActive(status is QuestBase.Status.Started);
        }
    }
}