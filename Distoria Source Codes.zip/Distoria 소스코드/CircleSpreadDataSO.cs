using UnityEngine;

namespace ProjectAAA.SO
{
    [CreateAssetMenu(fileName = "CircleSpreadDataSO", menuName = "Scriptable Objects/Spread/CircleSpreadDataSO", order = 0)]
    public class CircleSpreadDataSO : BaseSpreadDataSO
    {
        [SerializeField, Tooltip("Spread 가 적용될 원형의 반지름")] 
        private float radius;

        public override Vector2 HalfScale => Vector2.one * (radius + CurrentYValue);
        public override SpreadType Type => SpreadType.Circle;

        protected override Vector3 CalcOffset()
        {
            Vector3 offset = Random.insideUnitCircle * HalfScale;

            return offset;
        }
    }
}