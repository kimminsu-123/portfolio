using UnityEngine;

namespace ProjectAAA.WeaponSystem
{
    public abstract class FireStrategy
    {
        protected Transform ShootPos { get; private set; } 

        protected FireStrategy(Transform shootPos)
        {
            ShootPos = shootPos;
        }
        
        public abstract void Trigger();
        public abstract void Release();
        public abstract void Active();
        public abstract void Stop();
        public abstract void Execute();
    }
}