namespace ProjectAAA.UI.MainFight
{
    public struct QuestCollectData
    {
        public string BodyMsg;
        public string GoalMsg;
    }
    
    public class QuestCollectUI : CollectUI<QuestCollectElementUI, QuestCollectData>
    {
        public void Add(string body, string goal)
        {
            Add(new QuestCollectData
            {
                BodyMsg = body,
                GoalMsg = goal,
            });
        }
        
        public void UpdateUI(string body, string goal)
        {
            QuestCollectElementUI element = GetElement(0);
            if (element != null)
            {
                element.UpdateUI(new QuestCollectData
                {
                    BodyMsg = body,
                    GoalMsg = goal,
                });
            }
        }

        public void AnimationClear()
        {
            QuestCollectElementUI element = GetElement(0);
            if (element != null)
            {
                element.AnimationClear();
            }
        }
    }
}