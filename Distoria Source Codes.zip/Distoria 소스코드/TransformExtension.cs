using System;
using UnityEngine;

namespace ProjectAAA.Utils
{
    public static class TransformExtension
    {
        public static void ResetPositionAndRotation(this Transform thisTr)
        {
            thisTr.localPosition = Vector3.zero;
            thisTr.localRotation = Quaternion.identity;
        }
        
        public static float GetAngleY(this Transform from, Transform to)
        {
            Vector3 dir = to.position - from.position;   
            float angle = Mathf.Atan2(dir.x, dir.z) * Mathf.Rad2Deg; 
            return angle;
        }
        
        public static Transform FindInChildren(this Transform parent, string name)
        {
            Transform target = parent.Find(name);
            for (int i = 0; i < parent.childCount && target == null; i++)
            {
                target = parent.GetChild(i).FindInChildren(name);
            }

            return target;
        }
        
        public static Transform FindInChildrenContains(this Transform parent, string name)
        {
            Transform target = null;
            for (int i = 0; i < parent.childCount && target == null; i++)
            {
                Transform child = parent.GetChild(i);

                target = child.name.Contains(name) ? child : child.FindInChildrenContains(name);
            }

            return target;
        }
        
        public static void LookAtIgnoreY(this Transform source, Transform target)
        {
            Vector3 targetPos = target.transform.position;
            targetPos.y = source.position.y;
            source.LookAt(targetPos, Vector3.up);
        }
        
        public static Transform TransformGetParentWithLayer(this Transform child, int layer)
        {
            Transform currentObject = child.parent;
            Transform foundParent = null;
            
            while (currentObject != null)
            {
                if (currentObject.gameObject.layer == layer)
                {
                    foundParent = currentObject;
                    break;
                }
                
                currentObject = currentObject.parent;
            }
            
            return foundParent;
        }
    }
}