using System;
using DG.Tweening;
using ProjectAAA.Core.Pool;
using ProjectAAA.Core.Timer;
using ProjectAAA.Utils;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.UI
{
    [Serializable]
    public class MinimapRadarData
    {
        public Color ImgColor = Color.red;
        public float RadarSmooth = 0.08f;
        public float Radius = 1f;
        public float RadiusSmooth = 0.042f;
        public Color HighlightColor = Color.white;

        [Space(20), Header("일정시간 생겼다가 사라지기")]
        public bool CanDisappear;
        public float Duration = 0.5f;
        public float FadeTime = 0.2f;
    }
    
    public class MinimapRadar : PoolObjMonoBehaviour
    {
        public UnityEvent<int> onSelfRelease;
        
        private Image _cachedImg;
        private Transform _sourceTr;
        private Transform _destTr;
        private float _startAlpha;
        private Tweener _fadeTweener;
        
        private CooldownTimer _cooldownTimer;
        private MinimapRadarData _cachedData;
        
        private static readonly int Rotation = Shader.PropertyToID("_Rotation");
        private static readonly int RadarSmooth = Shader.PropertyToID("_RaiderSmooth");
        private static readonly int Radius = Shader.PropertyToID("_Radius");
        private static readonly int RadiusSmooth = Shader.PropertyToID("_RadiusSmooth");
        private static readonly int HighlightColor = Shader.PropertyToID("_HilightColor");

        private void Awake()
        {
            _cachedImg = GetComponent<Image>();
            _cachedImg.material = _cachedImg.material.CopyMaterial();
            
            _cooldownTimer = new CooldownTimer(0f);
            _cooldownTimer.OnCompleteCallback = FadeOut;
            
            _startAlpha = _cachedImg.color.a;
            Color color = _cachedImg.color;
            color.a = 0f;
            _cachedImg.color = color;
        }

        private void FadeIn()
        {
            _fadeTweener?.Kill();
            _fadeTweener = _cachedImg.DOFade(_startAlpha, _cachedData.FadeTime)
                .SetAutoKill(true)
                .OnComplete(() =>
                {
                    _cooldownTimer.SetTime(_cachedData.Duration);
                    _cooldownTimer.Start();
                })
                .Play();
        }

        private void FadeOut()
        {
            _fadeTweener?.Kill();
            _fadeTweener = _cachedImg.DOFade(0f, _cachedData.FadeTime)
                .SetAutoKill(true)
                .OnComplete(() =>
                {
                    onSelfRelease?.Invoke(_destTr.GetHashCode());
                    SelfReturn();
                })
                .Play();
        }

        private float GetAngle()
        {
            Vector3 from = _sourceTr.forward;
            Vector3 to = _destTr.position - _sourceTr.position;

            from.y = 0f;
            to.y = 0f;

            from.Normalize();
            to.Normalize();

            return Vector3.SignedAngle(from, to, Vector3.up) + 180f;
        }
        
        public void UpdateRadar()
        {
            if (_sourceTr != null && _destTr != null)
            {
                float value = 1f - (GetAngle() / 360f);
                
                _cachedImg.transform.rotation = Quaternion.identity;
                _cachedImg.material.SetFloat(Rotation, value);

                _cooldownTimer?.Tick(Time.deltaTime);
            }
        }
        
        /// <summary>
        /// Setup 함수를 통해서 기본 속성을 초기화 합니다.
        /// </summary>
        /// <param name="src">기준이 되는 Transform 을 넘깁니다. ex) Player</param>
        /// <param name="dst">목적지가 되는 Transform 을 넘깁니다. ex) Monster</param>
        /// <param name="data">Radar 쉐이더데이터입니다.</param>
        public void Setup(Transform src, Transform dst, MinimapRadarData data)
        {
            _sourceTr = src;
            _destTr = dst;
            _cachedData = data;

            _cachedImg.color = data.ImgColor;
            _cachedImg.material.SetFloat(RadarSmooth,  data.RadarSmooth);
            _cachedImg.material.SetFloat(Radius,  data.Radius);
            _cachedImg.material.SetFloat(RadiusSmooth,  data.RadiusSmooth);
            _cachedImg.material.SetColor(HighlightColor,  data.HighlightColor);

            if (data.CanDisappear)
            {
                _cooldownTimer.Stop();
                
                FadeIn();
            }
        }
    }
}