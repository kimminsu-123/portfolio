using ProjectAAA.Core;
using UnityEngine;

namespace ProjectAAA.Interaction
{
    public interface IInteractable
    {
        public float InteractDuration { get; }
        public void Interact(GameObject target);
    }
}