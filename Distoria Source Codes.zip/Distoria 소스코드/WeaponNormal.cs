using System;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using NaughtyAttributes;
using ProjectAAA.Core.Managers;
using ProjectAAA.Core.OptimizedSensor;
using ProjectAAA.Core.Scene.Manager;
using ProjectAAA.Core.Timer;
using ProjectAAA.Player;
using ProjectAAA.SO;
using ProjectAAA.UI;
using ProjectAAA.Utils;
using ProjectAAA.Utils.DataTable;
using UnityEngine;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.WeaponSystem
{
    public class WeaponNormal : WeaponBase
    {
        [SerializeField] private LayerMask hitLayerMask;
        [SerializeField] private BaseSpreadDataSO spreadDataSo;
        
        public WeaponNormalData CurrentWeaponNormalData => DatabaseManager.Instance.GetTable<WeaponNormalTableSO>().Get(weaponId);
        public bool IsCompletedSpreadPhysics => _spreadRayData.Status != SensorStatus.Running;

        private MagazineGenerator _magazineGenerator;
        private MagazineBase _currentMagazine;
        private WeaponNormalFireStrategy _fireStrategy;
        private CooldownTimer _reloadTimer;
        private OptimizedRaycastSensorData _spreadRayData;
        
        [ShowNonSerializedField] private int _remainAmmoAmount;

        public override MagazineBase CurrentMagazine => _currentMagazine;
        public override string Name => CurrentWeaponNormalData.WeaponName;
        public override string Type => CurrentWeaponNormalData.WeaponType.ToString();
        public override string Desc => CurrentWeaponNormalData.WeaponSummary;      
        public override string Effect => CurrentWeaponNormalData.WeaponDescription;
        public override float FireInterval => CurrentWeaponNormalData.FireInterval * WeaponAlterStat.Instance.FireInterval;
        public override float SwapTime => CurrentWeaponNormalData.WeaponSwapTime * WeaponAlterStat.Instance.SwapTime;
        public override int AmmoAmount => CurrentWeaponNormalData.AmmoAmount;
        public override int CurrentAmmo => _remainAmmoAmount;

        public int SpreadCount => CurrentWeaponNormalData.SpreadCount + WeaponAlterStat.Instance.SpreadCount;
        public override float ReloadTime => CurrentWeaponNormalData.ReloadTime * WeaponAlterStat.Instance.ReloadTime;
        public override int CurrentMagazineAmmoCount => CurrentMagazine.Count;
        public override int CurrentMagazineSize => CurrentMagazine.Size;

        public override string Description => CurrentWeaponNormalData.WeaponSummary;
        public override string Summary => CurrentWeaponNormalData.WeaponDescription;
        public override Sprite WeaponImage => DatabaseManager.Instance.IconResources.GetIcon(RewardType.Weapon, weaponId);
        public float Value1 => CurrentWeaponNormalData.Value1 * WeaponAlterStat.Instance.Value1;

        protected override void OnInitialize()
        {
            _magazineGenerator = WeaponManager.Instance.MagazineGenerator;

            _currentMagazine = _magazineGenerator.Get(CurrentWeaponNormalData.MagazineId);
            _currentMagazine.Fill(CurrentMagazine.Size);

            _remainAmmoAmount = CurrentWeaponNormalData.AmmoAmount;
            
            _reloadTimer = new CooldownTimer(ReloadTime);
            _reloadTimer.OnCompleteCallback += OnReloadSuccess;
            _spreadRayData = new OptimizedRaycastSensorData(1, SpreadCount);
            
            MakeFireStrategy();
        }

        public override void ForceStopReload()
        {
            _reloadTimer.Stop();
            OnReloadSuccess();
        }

        public override void Reload()
        {
            if (CurrentMagazine.IsFull)
            {
                Logger.Log("Weapon Normal Reload", $"이미 탄약이 가득 차있습니다.");
                return;
            }
            
            if (CurrentWeaponNormalData.AmmoAmount != Global.InfinityAmmo && _remainAmmoAmount <= 0)
            {
                Logger.Log("Weapon Normal Reload", $"{_remainAmmoAmount} 탄약이 부족합니다.");
                return;
            }

            if (_reloadTimer.IsRunning)
            {
                Logger.Log("Weapon Normal Reload", $"이미 재장전 중입니다.");
                return;
            }
            
            Logger.Log("Weapon Normal Reload", $"재장전 중");

            _fireStrategy.Stop();
            
            _reloadTimer.SetTime(ReloadTime);
            _reloadTimer.Start();

            if (reloadSound != null)
            {
                PlayerManager.Instance.WeaponHandler.PlayHandlingSound(reloadSound);
            }
            
            onBeginReloadCallback?.Invoke();
        }

        public override void Trigger()
        {
            _fireStrategy.Trigger();
        }

        public override void FillAmmo(float percent)
        {
            if (AmmoAmount == Global.InfinityAmmo)
            {
                return;
            }

            int addAmount = (int) (AmmoAmount * percent);
            _remainAmmoAmount = Mathf.Min(AmmoAmount, _remainAmmoAmount + addAmount);
        }

        public override void Release()
        {
            _fireStrategy.Release();
        }
        
        private void OnReloadSuccess()
        {
            MagazineBase nextMagazine = _magazineGenerator.Get(CurrentMagazine.NextMagazineID);

            // 무한 탄환을 가지고 있는 총인 경우
            int totalAmount = nextMagazine.Size;
            if (CurrentWeaponNormalData.AmmoAmount != Global.InfinityAmmo)
            {
                int useAmount = Mathf.Min(_remainAmmoAmount, Mathf.Max(0, nextMagazine.Size - CurrentMagazine.Count));
                totalAmount = Mathf.Min(nextMagazine.Size, useAmount + CurrentMagazine.Count);
                
                _remainAmmoAmount -= useAmount;
            }
            
            nextMagazine.Fill(totalAmount);
            _fireStrategy.SetMagazine(nextMagazine);
            _fireStrategy.Active();
            
            _currentMagazine = nextMagazine;

            onEndReloadCallback?.Invoke();

            Logger.Log("Weapon Normal Reload", $"재장전 완료 {CurrentMagazineAmmoCount} {CurrentAmmo}");
        }
        
        private void MakeFireStrategy()
        {
            switch (CurrentWeaponNormalData.FireType)
            {
                case FireType.Automatic:
                    _fireStrategy = new AutomaticStrategy(ShootPos, this);
                    break;
                case FireType.SemiAutomatic:
                    _fireStrategy = new SemiAutomaticStrategy(ShootPos, this);
                    break;
                case FireType.Charge:
                    _fireStrategy = new ChargeStrategy(ShootPos, this);
                    break;
            }

            _fireStrategy.SetMagazine(CurrentMagazine);
        }

        private void Update()
        {
            if (CurrentStatus != Status.Using) return;
            
            spreadDataSo.UpdateSpread(Time.deltaTime);
            
            _reloadTimer.Tick(Time.deltaTime);
            _fireStrategy.Execute();
        }

        public override void Interact(GameObject target)
        {
            base.Interact(target);

            OnReloadSuccess();
        }

        public override void OnDropOff()
        {
            base.OnDropOff();
            
            _fireStrategy.Release();
            _fireStrategy.Active();
            _reloadTimer.Stop();
            
            spreadDataSo.Clear();
            onFireCallback.RemoveListener(spreadDataSo.NextStep);
            
            CrosshairUI crosshair = UiManager.Instance.Get<CrosshairUI>();
            crosshair.ChangeSpreadData(null);
        }

        public override void Use(GameObject target)
        {
            base.Use(target);

            spreadDataSo.Clear();
            onFireCallback.AddListener(spreadDataSo.NextStep);

            CrosshairUI crosshair = UiManager.Instance.Get<CrosshairUI>();
            crosshair.ChangeSpreadData(spreadDataSo);
        }

        public override void SetAmmo(int ammo, int remainAmmo)
        {
            _remainAmmoAmount = remainAmmo;
            CurrentMagazine.Clear();
            CurrentMagazine.Fill(ammo);
        }

        public async UniTask<HitInfo[]> EvaluateSpread(int count)
        {
            Transform aimPivot = PlayerManager.Instance.WeaponHandler.AimPivot;

            if (_spreadRayData.Results.Length < count)
            {
                _spreadRayData.ResizeResults(count);
            }
            
            List<OptimizedRaycastSensorModel> models = new List<OptimizedRaycastSensorModel>(count);
            for (int i = 0; i < count; i++)
            {
                Vector3 dir = aimPivot.transform.TransformDirection((Vector3.forward + spreadDataSo.GetRandomPoint(AxisFlag.Z)).normalized);

                models.Add(new OptimizedRaycastSensorModel()
                {
                    Origin = aimPivot.transform.position,
                    Direction = dir,
                    Distance = float.MaxValue,
                    LayerMask = hitLayerMask
                });
            }
            _spreadRayData.SetModelRange(models);   
            
            PhysicsManager.Instance.AddRaycast(_spreadRayData);
            await _spreadRayData.Handle.Task;

            HitInfo[] infos = new HitInfo[count];
            for (int i = 0; i < infos.Length; i++)
            {
                RaycastHit hit = _spreadRayData.Results[i];
                if (hit.collider != null)
                {
                    infos[i].Target = hit.collider.gameObject;
                    infos[i].Normal = hit.normal;
                    infos[i].Point = hit.point;
                }
                else
                {
                    infos[i].Point = aimPivot.transform.position + models[i].Direction * 3000f;
                }
            }

            return infos;   
        }
    }
}