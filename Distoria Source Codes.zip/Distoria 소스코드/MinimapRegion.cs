using System;
using UnityEngine;

namespace ProjectAAA.Interaction
{
    public class MinimapRegion : MonoBehaviour
    {
        [field: SerializeField] public Rect Rect { get; private set; }
        [field: SerializeField] public Texture2D MinimapTexture { get; private set; }

        private void OnDrawGizmosSelected()
        {
            Gizmos.color = Color.red;

            Vector3 size = new Vector3(Rect.width, 0f, Rect.height);
            Vector3 halfSize = size * 0.5f;
            Vector3 offset = new Vector3(Rect.x, 0f, Rect.y) + halfSize;

            Gizmos.matrix = transform.localToWorldMatrix;
            Gizmos.DrawWireCube(offset, size);
        }
    }
}