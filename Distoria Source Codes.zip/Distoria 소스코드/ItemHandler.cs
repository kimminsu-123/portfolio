using System;
using System.Collections.Generic;
using ProjectAAA.Core.Managers;
using ProjectAAA.Player;
using ProjectAAA.SO;
using ProjectAAA.UI.MainFight;
using ProjectAAA.WeaponSystem;
using UnityEngine;
using EventType = ProjectAAA.Core.Managers.EventType;

namespace ProjectAAA.Interaction.Items
{
    public class ItemHandler : MonoBehaviour
    {
        [SerializeField] private FMODEventInfoSO getConsumableItemSound;
        [SerializeField] private FMODEventInfoSO getPassiveItemSound;
        [SerializeField] private InventoryDataBaseSO itemInventorySo;

        private readonly List<ItemBase> _oneOffItems = new();

        private void Awake()
        {
            EventManager.Instance.AddListener(EventType.PlayerClear, OnPlayerClear);
        }

        private void Update()
        {
            ProcessInInventory();
            ProcessOneOffItems();
        }

        private void ProcessInInventory()
        {
            List<Iitem> items = itemInventorySo.GetItems();
            for (var index = items.Count - 1; index >= 0; index--)
            {
                Iitem item = items[index];
                
                ItemBase itemBase = item as ItemBase;
                if (itemBase != null)
                {
                    List<ItemBuffComposite.Group> groups = itemBase.Buffs.GetGroups;
                    foreach (ItemBuffComposite.Group group in groups)
                    {
                        if (group.Condition.Evaluate())
                        {
                            if (!group.IsExecuted)
                            {
                                group.Buff.Execute(gameObject);
                                group.IsExecuted = true;
                                group.Timer.OnCompleteCallback = () =>
                                {
                                    group.IsExecuted = false;
                                    group.Buff.Reset(gameObject);
                                };
                                group.Timer.Start();

                                if (group.Buff.DisplayUI)
                                {
                                    UiManager.Instance.Get<MainFightUI>().BuffCollectUI.Add(
                                        group.Type, 
                                        group.Buff.Description,
                                        group.Timer);   
                                }
                            }

                            group.Timer.Reset();
                        }
                        else
                        {
                            group.Timer.Tick(Time.deltaTime);
                        }
                    }
                }
            }
        }

        private void ProcessOneOffItems()
        {
            for (var index = _oneOffItems.Count - 1; index >= 0; index--)
            {
                bool ret = true;
                ItemBase item = _oneOffItems[index];

                List<ItemBuffComposite.Group> groups = item.Buffs.GetGroups;
                foreach (ItemBuffComposite.Group group in groups)
                {
                    if (group.Condition.Evaluate() && !group.IsExecuted)
                    {
                        group.Buff.Execute(gameObject);
                        if (!Mathf.Approximately(group.Timer.Time, 0f) && !group.Timer.IsRunning)
                        {
                            group.Timer.Start();
                            group.Timer.OnCompleteCallback = () => group.Buff.Reset(gameObject);

                            if (group.Buff.DisplayUI)
                            {
                                UiManager.Instance.Get<MainFightUI>().BuffCollectUI.Add(group.Type, group.Buff.Description, group.Timer);
                            }
                        }
                        else
                        {
                            if (group.Buff.DisplayUI)
                            {
                                UiManager.Instance.Get<MainFightUI>().BuffCollectUI.Add(group.Type, group.Buff.Description, null);
                            }
                        }
                    }
                    group.IsExecuted = true;
                    group.Timer.Tick(Time.deltaTime);
                    
                    ret &= !group.Timer.IsRunning && group.IsExecuted;
                }

                if (ret)
                {
                    DropItem(item);
                }
            }
        }

        private void OnPlayerClear(Component sender, object[] args)
        {
            itemInventorySo.ResetInventory();
            foreach (ItemBase item in _oneOffItems)
            {
                item.OnReset();
            }
            _oneOffItems.Clear();
        }
        
        public void InsertItem(ItemBase item, bool insertToInventory = true)
        {
            
            item.Buffs.Enable();
            item.Hold(transform);
            
            if (insertToInventory)
            {
                SoundManager.Instance.PlaySFX(getPassiveItemSound, transform.position);
                itemInventorySo.AddItem(item);
            }
            else
            {
                SoundManager.Instance.PlaySFX(getConsumableItemSound, transform.position);
                _oneOffItems.Add(item);
                ProcessOneOffItems();
            }
        }

        public void DropItem(ItemBase item)
        {
            if (item == null) return;
            
            item.Buffs.Disable();
            item.OnReset();
            
            if (itemInventorySo.Contains(item))
            {
                itemInventorySo.RemoveItem(item);
            }
            else if (_oneOffItems.Contains(item))
            {
                _oneOffItems.Remove(item);
            }
        }
    }
}