using ProjectAAA.SO.Pool;
using ProjectAAA.Utils;
using ProjectAAA.Utils.DataTable;

namespace ProjectAAA.Interaction.Items
{
    public class ItemGenerator : Generator<int, ItemBuilder>
    {
        protected override bool InitOnStart => true;

        protected override bool GetKey(ObjectPoolSO pool, ref int key)
        {
            ItemBuilder builder = pool.Get<ItemBuilder>(transform);

            if (builder == null) return false;
            
            key = builder.ItemID;
            
            pool.ReturnQueue(builder);
            return true;
        }
    }
}