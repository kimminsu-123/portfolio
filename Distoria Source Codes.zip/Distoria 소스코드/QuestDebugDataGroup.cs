using System.Collections.Generic;
using Newtonsoft.Json;
using ProjectAAA.Utils.DataTable;
using UnityEngine;

namespace ProjectAAA.SO.Debug
{
    [CreateAssetMenu(fileName = "QuestDebugDataGroup", menuName = "Scriptable Objects/DataTable/Debug/Quest")]
    public class QuestDebugDataGroup : DebugDataGroup
    {
        [SerializeField] private List<QuestData> quests;
        
        protected override void FromJson(string json)
        {
            quests.Clear();
            quests = JsonConvert.DeserializeObject<List<QuestData>>(json);
        }

        public override string ToJson()
        {
            return JsonConvert.SerializeObject(quests);
        }
    }
}