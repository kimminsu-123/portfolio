using System;
using UnityEngine;

namespace ProjectAAA.Utils.Visualizer
{
    public class CubeVisualizer : Visualizer
    {
        public Vector3 center;
        public Vector3 size;
        
        private void OnDrawGizmos()
        {
            Gizmos.color = gizmosColor;
            Gizmos.matrix = transform.localToWorldMatrix;
            if(drawWireframe) Gizmos.DrawWireCube(center, size);
            else Gizmos.DrawCube(center, size);
        }
    }
}