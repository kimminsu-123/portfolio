using ProjectAAA.Core.Pool;
using UnityEngine;
using UnityEngine.UI;

namespace ProjectAAA.UI
{
    public class ResultElement : PoolObjMonoBehaviour
    {
        [SerializeField] private Image iconImage;

        public void UpdateImage(Sprite sprite)
        {
            iconImage.sprite = sprite;   
        }
    }
}