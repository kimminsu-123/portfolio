using DG.Tweening;
using ProjectAAA.Core.Managers;
using ProjectAAA.Core.Timer;
using ProjectAAA.SO.CameraEffect;
using ProjectAAA.Utils;
using UnityEngine;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.CameraEffect
{
    public class ExplosionCameraShake : PhysicsCameraEffectBase
    {
        private ExplosionCameraShakeEffectDataSO _cameraShakeDataSO;
        private Tweener _shakeTweener;

        protected override void Setup(EffectDataSO effectData)
        {
            _cameraShakeDataSO = effectData as ExplosionCameraShakeEffectDataSO;

            Logger.Assert(_cameraShakeDataSO != null, "CameraShake", "CameraShakeEffectDataSO is null");
            
            _shakeTweener?.Kill();
            _shakeTweener = pivot.DOShakeRotation(duration: _cameraShakeDataSO.duration, _cameraShakeDataSO.amount, 90, 90, true, ShakeRandomnessMode.Harmonic);
        }

        protected override void Perform(float deltaTime)
        {
            if (_shakeTweener == null || !_shakeTweener.IsActive())
            {
                CameraEffectManager.Instance.UnRegister(_cameraShakeDataSO);
            }
        }

        protected override void PerformRestore(float deltaTime)
        {
            if (_cameraShakeDataSO != null)
            {
                pivot.transform.localRotation = Quaternion.Lerp(pivot.transform.localRotation, Quaternion.identity,
                    deltaTime * 2f);
            }
        }
    }
}