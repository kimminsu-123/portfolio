using ProjectAAA.Interaction;
using ProjectAAA.Utils;
using UnityEngine;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.Mob
{
    public class StageWaveTrigger : MonoBehaviour, IInteractable
    {
        public float InteractDuration => interactDuration;

        [SerializeField] private float interactDuration = 0.5f;
        [SerializeField] private MonsterStage monsterStage;
        
        public void Interact(GameObject target)
        {
            if (monsterStage.Mode != StageMode.Wave)
            {
                Logger.LogError("StageWaveTrigger", $"{monsterStage.Mode} is not wave");
                return;
            }
            
            monsterStage.BeginNextWave();
        }
    }
}