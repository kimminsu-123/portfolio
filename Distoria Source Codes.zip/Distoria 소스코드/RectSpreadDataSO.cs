using UnityEngine;

namespace ProjectAAA.SO
{
    [CreateAssetMenu(fileName = "RectSpreadDataSO", menuName = "Scriptable Objects/Spread/RectSpreadDataSO", order = 0)]
    public class RectSpreadDataSO : BaseSpreadDataSO
    {
        [SerializeField, Tooltip("Spread 가 적용될 사각형의 사이즈")] private Vector2 rectSize;

        public override Vector2 HalfScale => rectSize + (rectSize.normalized * CurrentYValue);
        public override SpreadType Type => SpreadType.Rect;

        protected override Vector3 CalcOffset()
        {
            Vector2 offset = Vector2.zero;
            Vector2 halfRectSize = HalfScale * 0.5f;
            
            offset.x = Random.Range(-halfRectSize.x, halfRectSize.x);
            offset.y = Random.Range(-halfRectSize.y, halfRectSize.y);
            
            return offset;
        }
    }
}