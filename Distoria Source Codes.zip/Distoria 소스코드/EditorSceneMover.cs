using System.Collections.Generic;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace ProjectAAA.Editor
{
    public class EditorScenesRef
    {
        public bool IsFoldout = false;
        public readonly List<SceneAsset> Scenes = new();
    }
    
    public class EditorSceneMover : EditorWindow
    {
        private Vector2 _scrollPosition;
        private readonly Dictionary<string, EditorScenesRef> _scenes = new();
        
        [InitializeOnLoadMethod]
        private static void Initialize()
        {
            SceneView.duringSceneGui += view =>
            {
                Event e = Event.current;
                
                if (e == null) return;
                if (e.type != EventType.KeyDown) return;
                if (e.keyCode != KeyCode.F1) return;
                
                ShowWindow();
                e.Use();
            };
        }

        [MenuItem("Window/EditorSceneMover")]
        public static void ShowWindow()
        {
            GetWindow(typeof(EditorSceneMover));
        }

        private void CreateGUI()
        {
            _scenes.Clear();
            
            string[] guids = AssetDatabase.FindAssets("t:Scene");
            foreach (string guid in guids)
            {
                string path = AssetDatabase.GUIDToAssetPath(guid);
                SceneAsset asset = AssetDatabase.LoadAssetAtPath<SceneAsset>(path);
                
                string dir = path.Substring(0, path.LastIndexOf('/'));

                if (!_scenes.ContainsKey(dir))
                {
                    _scenes[dir] = new EditorScenesRef();
                }
                _scenes[dir].Scenes.Add(asset);
            }
        }

        private void OnGUI()
        {
            string activeScenePath = EditorSceneManager.GetActiveScene().path;
            
            _scrollPosition = EditorGUILayout.BeginScrollView(_scrollPosition);
            EditorGUILayout.LabelField($"Current Active Scene : {activeScenePath}", EditorStyles.boldLabel);
            
            foreach (KeyValuePair<string, EditorScenesRef> pair in _scenes)
            {
                GUIStyle style = new GUIStyle
                {
                    fontStyle = FontStyle.Bold,
                    fontSize = 14,
                    normal = new GUIStyleState()
                    {
                        textColor = Color.green
                    },
                    padding = new RectOffset(10, 10, 10, 10),
                };
                EditorScenesRef scenesRef = pair.Value;
                string foldName = (scenesRef.IsFoldout ? "\u25b2" : "\u25bc") + pair.Key; 
                scenesRef.IsFoldout = EditorGUILayout.BeginFoldoutHeaderGroup(scenesRef.IsFoldout, foldName, style);
                if (scenesRef.IsFoldout)
                {
                    foreach (SceneAsset sceneAsset in scenesRef.Scenes)
                    {
                        if (GUILayout.Button(sceneAsset.name))
                        {
                            MoveScene(pair.Key, sceneAsset);
                        }
                    }   
                }
                EditorGUILayout.EndFoldoutHeaderGroup();
            }
            EditorGUILayout.EndScrollView();
        }

        private void MoveScene(string dir, SceneAsset sceneAsset)
        {
            Scene scene = EditorSceneManager.GetActiveScene();

            if (scene.isDirty)
            {
                EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo();
            }
            
            EditorSceneManager.OpenScene($"{dir}/{sceneAsset.name}.unity");
        }
    }
}