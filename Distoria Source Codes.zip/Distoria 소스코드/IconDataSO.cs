using System;
using ProjectAAA.Utils.DataTable;
using UnityEngine;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.SO.Resource
{
    [Serializable]
    public class IconResource
    {
        public RewardType type;
        public int id;
        public Sprite icon;
        public Texture2D texture;
    }
    
    [CreateAssetMenu(fileName = "IconDataSO", menuName = "Scriptable Objects/IconData")]
    public class IconDataSO : BaseSO
    {
        [SerializeField] private IconResource[] resources;

        public Sprite GetIcon(RewardType type, int id)
        {
            for (int i = 0; i < resources.Length; i++)
            {
                if (resources[i].type == type && resources[i].id == id)
                {
                    return resources[i].icon;
                }   
            }

            Logger.LogError("Icon Data SO", $"{type} - {id} 에 해당하는 아이콘 리소스 정보가 없습니다.");
            return null;
        }
        
        public Texture2D GetTexture(RewardType type, int id)
        {
            for (int i = 0; i < resources.Length; i++)
            {
                if (resources[i].type == type && resources[i].id == id)
                {
                    return resources[i].texture;
                }   
            }

            Logger.LogError("Icon Data SO", $"{type} - {id} 에 해당하는 텍스처 리소스 정보가 없습니다.");
            return null;
        }
    }
}