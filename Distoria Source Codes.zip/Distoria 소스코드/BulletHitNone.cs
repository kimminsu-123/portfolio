using ProjectAAA.Utils;

namespace ProjectAAA.WeaponSystem
{
    public class BulletHitNone : BulletHitAbility
    {
        public override bool IsDone => _isDone;
        
        private bool _isDone;
        
        public BulletHitNone(BulletHitHandler handler) : base(handler)
        {
        }
        
        public override void Init()
        {
            _isDone = true;
            
            Next?.Init();
        }
    }
}