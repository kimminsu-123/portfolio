using ProjectAAA.Utils;

namespace ProjectAAA.Core.Entity
{
    public interface IDamageable
    {
        public void TakeDamage(HitInfo hitInfo);
    }
}