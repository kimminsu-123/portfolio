using UnityEngine;

namespace ProjectAAA.Utils
{
    public static class Bezier
    {
        public static Vector3 Lerp(Vector3 p1, Vector3 p2, Vector3 p3, float t)
        {
            Vector3 b1 = Vector3.Lerp(p1, p2, t);
            Vector3 b2 = Vector3.Lerp(p2, p3, t);
            Vector3 ret = Vector3.Lerp(b1, b2, t);
            
            return ret;
        }
    }
}