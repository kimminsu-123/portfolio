using System;
using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;

namespace ProjectAAA.UI.MainFight
{
    public class DashUI : MonoBehaviour
    {
        [SerializeField] private GameObject[] dashBars;
        [SerializeField] private Image[] dashFillRects;
        
        private int _curDashIdx;

        private void Start()
        {
            ClearDash();
        }

        public void UseDash()
        {
            if (_curDashIdx < 0)
            {
                return;
            }
            
            dashBars[_curDashIdx].SetActive(false);

            _curDashIdx = (_curDashIdx - 1) % dashBars.Length;
        }

        public void FillDashUI(float coolTime)
        {
            foreach (Image element in dashFillRects)
            {
                element.fillAmount = 0;
            }

            dashFillRects[0].DOFillAmount(1, coolTime / 2).OnComplete(() => dashFillRects[1].DOFillAmount(1, coolTime / 2));
        }

        public void ClearDash()
        {
            for (int i = 0; i < dashBars.Length; i++)
            {
                dashBars[i].SetActive(true);
            }

            _curDashIdx = dashBars.Length - 1;
        }
    }
}