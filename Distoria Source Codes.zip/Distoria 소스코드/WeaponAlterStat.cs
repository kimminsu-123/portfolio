using Newtonsoft.Json;
using ProjectAAA.Utils;
using ProjectAAA.Utils.DataTable;

namespace ProjectAAA.Player
{
    public class WeaponAlterStat : Singleton<WeaponAlterStat>
    {
        public float ReloadTime { get; set; } = 1f;
        public float Value1 { get; set; } = 1f;
        public float FireInterval { get; set; } = 1f;
        public float SwapTime { get; set; } = 1f;
        public int MagazineSize { get; set; } = 0;
        public int SpreadCount { get; set; } = 0;
        public float CriticalMagnification { get; set; } = 1f;
        
        public float BulletDamage { get; set; } = 1f;
        public float BulletSpeed { get; set; } = 1f;
        public float BulletLifeTime { get; set; } = 1f;
        public float BulletSize { get; set; } = 1f;
        
        public void Clear()
        {
            ReloadTime = 1f;
            Value1 = 1f;
            FireInterval = 1f;
            SwapTime = 1f;
            MagazineSize = 0;
            SpreadCount = 0;
            CriticalMagnification = 1f;

            BulletDamage = 1f;
            BulletSpeed = 1f;
            BulletLifeTime = 1f;
            BulletSize = 1f;
        }
        public string FileName => "weaponalterstat";
    }
}