using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace ProjectAAA.UI
{
    public class NoticeUI : MonoBehaviour
    {
        [SerializeField] private TMP_Text text;
        [SerializeField] private Button confirmButton;
        [SerializeField] private Button revertButton;
        [SerializeField] private GameObject settingsUI;

        private Action _onConfirmEvent;
        private Action _onRevertEvent;

        private void Start()
        {
            confirmButton.onClick.AddListener(OnConfirm);
            revertButton.onClick.AddListener(OnRevert);
        }

        private void OnConfirm()
        {
            Close();

            _onConfirmEvent?.Invoke();
        }

        private void OnRevert()
        {
            Close();
            
            _onRevertEvent?.Invoke();
        }

        public void Show(string msg, Action onConfirm, Action onRevert)
        {
            text.text = msg;
            _onConfirmEvent = onConfirm;
            _onRevertEvent = onRevert;

            if (settingsUI != null)
            {
                settingsUI.SetActive(false);   
            }
            gameObject.SetActive(true);
            
            confirmButton.Select();
        }

        public void ForceRevert()
        {
            OnRevert();
        }

        public void Close()
        {
            if (settingsUI != null)
            {
                settingsUI?.SetActive(true);
            }
            gameObject.SetActive(false);
        }
    }
}