using UnityEngine;

namespace ProjectAAA.Utils
{
    public static class MeshExtension
    {
        public static bool IsMeshLayingDown(this Mesh mesh)
        {
            Vector3[] normals = mesh.normals;
            if (normals == null || normals.Length == 0)
            {
                return false;
            } 

            Vector3 averageNormal = Vector3.zero;
            foreach (Vector3 n in normals)
            {
                averageNormal += n;
            }
            averageNormal.Normalize(); 

            return Vector3.Dot(averageNormal, Vector3.up) < 0.5f; 
        }
    }
}