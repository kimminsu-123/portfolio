using ProjectAAA.SO.Pool;
using ProjectAAA.Utils;

namespace ProjectAAA.WeaponSystem
{
    public class BulletGenerator : Generator<int, BulletBase>
    {
        protected override bool InitOnStart => false;
        protected override bool GetKey(ObjectPoolSO pool, ref int key)
        {
            BulletBase bullet = pool.Get<BulletBase>(transform);
            
            if (bullet == null) return false;
            
            key = bullet.BulletId;
            pool.ReturnQueue(bullet);

            return true;
        }
    }
}