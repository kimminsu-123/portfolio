using System.Security.Cryptography;
using Cysharp.Threading.Tasks;
using ProjectAAA.Core;
using ProjectAAA.Core.Entity;
using ProjectAAA.Core.Managers;
using ProjectAAA.Core.Scanner;
using ProjectAAA.Core.Scene.Manager;
using ProjectAAA.SO;
using ProjectAAA.SO.CameraEffect;
using ProjectAAA.SO.Pool;
using ProjectAAA.Utils;
using ProjectAAA.Utils.DataTable;
using UnityEngine;

namespace ProjectAAA.WeaponSystem
{
    public class BulletExplosion : BulletDestroyAbility
    {
        private readonly float _radius;
        private readonly float _minDamage;
        private readonly float _maxDamage;
        private readonly float _cameraShakeRadius;
        private readonly float _cameraShakeValue;
        private readonly OverlapBlockScanner _scanner;

        public BulletExplosion(BulletBase bullet, AddBulletCondition condition,
            float radius, float minDmg, float maxDmg, float camShakeRadius,
            float camShakeValue) : base(bullet, condition)
        {
            _radius = radius;
            _minDamage = minDmg;
            _maxDamage = maxDmg;
            _cameraShakeRadius = camShakeRadius;
            _cameraShakeValue = camShakeValue;

            OverlapBlockScanner.OverlapBlockScannerConfig config = new OverlapBlockScanner.OverlapBlockScannerConfig
            {
                RangeLayerMask = Global.MonsterHurtBoxLayerMask,
                RangeRadius = radius,
                RangeDetectCount = Mathf.RoundToInt(radius),
                RangeConverter = GetCenter,

                BlockLayerMask = Global.PlayerAttackBlockMask,
            };
            _scanner = new OverlapBlockScanner(config);
        }
        
        public override async UniTask OnDestroy(BulletDestroyType destroyType)
        {
            if (CheckCondition(destroyType))
            {
                await Explosion();
                ExplosionEffect();
                ShakeCamera();
            }
            base.OnDestroy(destroyType);
        }
        
        private async UniTask Explosion()
        {
            Vector3 position = Bullet.transform.position;

            Collider[] ret = await _scanner.ScanRange(position);
            RaycastHit[] hits = await _scanner.ScanBlocked(position, ret);

            if (hits == null)
            {
                return;
            }
            
            int len = Mathf.Min(hits.Length, ret.Length);
            for (int i = 0; i < len; i++)
            {
                if (hits[i].collider == ret[i])
                {
                    GiveDamage(ret[i], hits[i]);
                }
            }                
            
            DebugVisualizerManager.Instance.DrawSphere(position, Quaternion.identity, _radius, 0.4f);
        }
        
        private void GiveDamage(Collider target, RaycastHit hit)
        {
            if (target == null) return;
            if (!target.TryGetComponent(out HurtBox hurtBox)) return;

            float ratio = Mathf.Clamp01(1f - hit.distance / _radius); 
            
            HitInfo info = new HitInfo
            {
                Hitter = Bullet.gameObject,
                Damage = Mathf.Lerp(_minDamage, _maxDamage, ratio),
                Point = target.transform.position,
                Normal = hit.normal,
            };
            hurtBox.TakeDamage(info);
        }

        private void ExplosionEffect()
        {
            ObjectPoolSO effectPool = Bullet.AbilitySettings.ExplosionEffectPool;
            FMODEventInfoSO clip = Bullet.AbilitySettings.ExplosionSound;

            if (effectPool != null)
            {
                ParticlePoolObj particle = effectPool.Get<ParticlePoolObj>(null);
                particle.SetOriginPool(effectPool);
                particle.SetPosition(Bullet.transform.position);
                particle.SetScale(Vector3.one * (_radius * 2f));
                particle.Play();
            }

            if (clip != null)
            {
                SoundManager.Instance.PlaySFX(clip, Bullet.transform.position);
            }
        }
        
        private void ShakeCamera()
        {
            Transform playerTr = PlayerManager.Instance.PlayerGo.transform;
            float distance = Vector3.Distance(playerTr.position, Bullet.transform.position);
            if (distance <= _cameraShakeRadius)
            {
                ExplosionCameraShakeEffectDataSO data = Bullet.AbilitySettings.CameraShakeData;
                data.amount = _cameraShakeValue;

                CameraEffectManager.Instance.Register(data);
            }
        }
    }
}