using System;
using System.Collections.Generic;
using UnityEngine;

namespace ProjectAAA.Core.Detector
{
    public enum DetectType
    {
        Update,
        Physics,
    }
    
    [Obsolete(error:true,message:"안쓰는 거임 ㅋ")]
    public class Detector : MonoBehaviour
    {
        public delegate void DetectCallback(Collider[] targets);
        
        private readonly Dictionary<DetectStrategy, List<DetectCallback>> _updateListeners = new();
        private readonly Dictionary<DetectStrategy, List<DetectCallback>> _physicsListeners = new();

        private void Update()
        {
            ExecuteUpdate();
        }

        private void FixedUpdate()
        {
            ExecuteFixedUpdate();
        }

        private void ExecuteUpdate()
        {
            foreach (KeyValuePair<DetectStrategy, List<DetectCallback>> listener in _updateListeners)
            {
                Collider[] target = listener.Key.Execute();
                for (int i = listener.Value.Count - 1; i >= 0; i--)
                {
                    listener.Value[i]?.Invoke(target);
                }
            }
        }

        private void ExecuteFixedUpdate()
        {
            foreach (KeyValuePair<DetectStrategy, List<DetectCallback>> listener in _physicsListeners)
            {
                Collider[] target = listener.Key.Execute();
                for (int i = listener.Value.Count - 1; i >= 0; i--)
                {
                    listener.Value[i]?.Invoke(target);
                }
            }
        }

        public void Register(DetectType type, DetectStrategy strategy, DetectCallback callback)
        {
            switch (type)
            {
                case DetectType.Update:
                    if (!_updateListeners.ContainsKey(strategy))
                    {
                        _updateListeners.Add(strategy, new List<DetectCallback>());
                    }
                    _updateListeners[strategy].Add(callback);
                    break;
                case DetectType.Physics:
                    if (!_physicsListeners.ContainsKey(strategy))
                    {
                        _physicsListeners.Add(strategy, new List<DetectCallback>());
                    }
                    _physicsListeners[strategy].Add(callback);
                    break;
            }
        }

        public void UnRegister(DetectType type, DetectStrategy strategy, DetectCallback callback)
        {
            switch (type)
            {
                case DetectType.Update:
                    if (_updateListeners.ContainsKey(strategy))
                    {
                        if (_updateListeners[strategy].Contains(callback))
                        {
                            strategy.Dispose();
                            _updateListeners[strategy].Remove(callback);
                        }
                    }
                    break;
                case DetectType.Physics:
                    if (_physicsListeners.ContainsKey(strategy))
                    {
                        if (_physicsListeners[strategy].Contains(callback))
                        {
                            strategy.Dispose();
                            _physicsListeners[strategy].Remove(callback);
                        }
                    }
                    break;
            }
        }

        public void Clear()
        {
            _updateListeners.Clear();
            _physicsListeners.Clear();
        }
    }
}