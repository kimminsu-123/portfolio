using Cysharp.Threading.Tasks;
using ProjectAAA.Core.Managers;
using ProjectAAA.Core.Scene.Manager;
using ProjectAAA.Core.Timer;
using ProjectAAA.Player;
using ProjectAAA.UI;
using ProjectAAA.Utils;
using ProjectAAA.Utils.DataTable;
using UnityEngine;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.WeaponSystem
{
    public abstract class WeaponNormalFireStrategy : FireStrategy
    {
        protected enum TriggerState
        {
            Triggered,
            Released,
        }
        
        protected enum FireState
        {
            None,
            Stopped,
            Cooldown,
        }

        protected WeaponNormal CurrentWeapon { get; private set; }
        protected WeaponNormalData CurrentWeaponNormalData => CurrentWeapon.CurrentWeaponNormalData;
        protected MagazineBase CurrentMagazine { get; private set; }
        protected CooldownTimer FireIntervalTimer { get; private set; }
        
        protected TriggerState CurrentTriggerState { get; private set; }
        protected FireState CurrentFireState { get; private set; }

        protected WeaponNormalFireStrategy(Transform shootPos, WeaponNormal weapon) : base(shootPos)
        {
            CurrentWeapon = weapon;
            
            FireIntervalTimer = new CooldownTimer(weapon.FireInterval);
            FireIntervalTimer.OnStartCallback += OnFireIntervalStarted;
            FireIntervalTimer.OnCompleteCallback += OnFireIntervalCompleted;

            CurrentTriggerState = TriggerState.Released;
            CurrentFireState = FireState.None;
        }

        public void SetMagazine(MagazineBase magazine)
        {
            CurrentMagazine = magazine;
        }

        public override void Trigger()
        {
            CurrentTriggerState = TriggerState.Triggered;
        }

        public override void Release()
        {
            CurrentTriggerState = TriggerState.Released;
        }

        public override void Active()
        {
            if (CurrentFireState == FireState.Stopped)
            {
                CurrentFireState = FireState.None;
            }
        }

        public override void Stop()
        {
            CurrentFireState = FireState.Stopped;
            
            FireIntervalTimer.Stop();
        }
        
        public override void Execute()
        {
            if (CurrentWeapon.IsCompletedSpreadPhysics)
            {
                FireIntervalTimer.Tick(Time.deltaTime);
            }

            if (FireIntervalTimer.IsRunning) return;
            if (CurrentFireState != FireState.None) return;
            if (CurrentMagazine.Count <= 0)
            {
                if (CurrentTriggerState == TriggerState.Triggered)
                {
                    CurrentWeapon.onFireFailedWhenAmmoZeroCallback?.Invoke();
                }
                return;
            }
            
            if (CurrentWeapon.IsCompletedSpreadPhysics)
            {
                Process();
            }
        }
        
        protected virtual void OnFireIntervalStarted()
        {
            if (CurrentFireState == FireState.None)
            {
                Logger.Log($"{GetType().Name}", "쿨타임 진행 중..", Color.red);
                CurrentFireState = FireState.Cooldown;
            }
        }

        protected virtual void OnFireIntervalCompleted()
        {
            if (CurrentFireState == FireState.Cooldown)
            {
                Logger.Log($"{GetType().Name}", "쿨타임 끝남", Color.red);
                CurrentFireState = FireState.None;
            }
        }

        protected async UniTask Fire()
        {
            if (CurrentMagazine.Count <= 0) return;
            if (CurrentFireState != FireState.None) return;

            CurrentWeapon.onFireCallback?.Invoke();
            CurrentWeapon.ModelAnimator.CrossFade(Global.PCAnimParamName.StNmFire, 0f, 0, 0f);

            BulletBase[] bullets = CurrentMagazine.Pop(ShootPos, CurrentWeapon.SpreadCount);

            HitInfo[] infos = await CurrentWeapon.EvaluateSpread(bullets.Length);
            for (int i = 0; i < infos.Length; i++)
            {
                HitInfo hitInfo = infos[i];
                bullets[i].CriticalMagnification = CurrentWeaponNormalData.CriticalMagnification * WeaponAlterStat.Instance.CriticalMagnification;
                bullets[i].SetupData();
                
                // 가까이에 있는 경우 카메라에서 부딪히도록 함
                if (CurrentWeapon.EvaluateNearTarget(hitInfo))
                {
                    bullets[i].ForceHit(hitInfo);
                }
                else
                {
                    bullets[i].Process(hitInfo.Point, CurrentWeapon.MainCamera.transform.forward);
                }
            }
            
            OnFireSuccess();
        }

        protected virtual void OnFireSuccess()
        {
            PlayerManager.Instance.WeaponHandler.onChangeAmmo?.Invoke();
        }

        protected abstract void Process();
    }
}