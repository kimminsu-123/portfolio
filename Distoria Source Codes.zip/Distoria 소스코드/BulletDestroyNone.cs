using ProjectAAA.Utils.DataTable;

namespace ProjectAAA.WeaponSystem
{
    public class BulletDestroyNone : BulletDestroyAbility
    {
        public BulletDestroyNone() : base(null, AddBulletCondition.None)
        {
        }
    }
}