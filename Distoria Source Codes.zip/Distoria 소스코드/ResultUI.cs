using System;
using System.Collections.Generic;
using ProjectAAA.Boss;
using ProjectAAA.Core.Managers;
using ProjectAAA.Core.Scene.Manager;
using ProjectAAA.Interaction;
using ProjectAAA.Interaction.Items;
using ProjectAAA.Mob.Normal;
using ProjectAAA.SO;
using ProjectAAA.SO.Pool;
using ProjectAAA.Utils;
using ProjectAAA.Utils.DataTable;
using ProjectAAA.WeaponSystem;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using EventType = ProjectAAA.Core.Managers.EventType;

namespace ProjectAAA.UI
{
    public class ResultUI : UiBase
    {
        protected override Type RegisterType => typeof(ResultUI);

        [Header("UI")]
        [SerializeField] private TMP_Text titleText;
        [SerializeField] private TMP_Text timeAliveText;
        [SerializeField] private TMP_Text lastedAttackerText;
        [SerializeField] private RectTransform weaponListContents;
        [SerializeField] private RectTransform itemListContents;
        [SerializeField] private Button lobbyButton;
        
        [Header("Reference Resources")]
        [SerializeField] private ObjectPoolSO elementPoolSo;
        [SerializeField] private InventoryDataBaseSO weaponInventory;
        [SerializeField] private InventoryDataBaseSO passiveItemInventory;

        private readonly List<ResultElement> _resultElements = new(100);
        
        private void Start()
        {
            EventManager.Instance.AddListener(EventType.OnGameClear, OnGameClear);
            EventManager.Instance.AddListener(EventType.OnPlayerDeath, OnStageFailed);
            
            lobbyButton.onClick.AddListener(Hide);
            lobbyButton.onClick.AddListener(GameManager.Instance.LeaveToLobby);

            Hide();
        }

        private void OnGameClear(Component sender, object[] args)
        {
            GameMode mode = GameManager.Instance.Mode;
            
            titleText.text = $"Game Clear ({mode})";

            Show();
        }

        private void OnStageFailed(Component sender, object[] args)
        {
            GameMode mode = GameManager.Instance.Mode;
            
            titleText.text = $"You Died ({mode})";
            
            Show();
        }

        public override void Show()
        {
            UpdateTimeAlive();
            UpdateLastHitInfo();
            UpdateWeaponList();
            UpdateItemList();
            
            PlayerManager.Instance.ActionController.BlockAllActions();
            CursorHandler.UnLock();
            
            gameObject.SetActive(true);
        }

        public override void Hide()
        {
            foreach (ResultElement element in _resultElements)
            {
                element.SelfReturn();
            }
            _resultElements.Clear();

            PlayerManager.Instance.ActionController.UnBlockAllActions();
            CursorHandler.Lock();
            
            gameObject.SetActive(false);
        }
        
        private void UpdateTimeAlive()
        {
            TimeSpan timeSpan = GameManager.Instance.AliveTimeStopwatch.ToTimeSpan();
            
            timeAliveText.text = $"생존 시간 [ {timeSpan.Minutes:00}:{timeSpan.Seconds:00} ]";
        }

        private void UpdateLastHitInfo()
        {
            GameObject hitter = PlayerManager.Instance.PlayerEntity.LastHitInfo.Hitter;

            string hitterName = "몬스터";
            if (hitter != null)
            {
                if (hitter.TryGetComponent(out MonsterBase monster))
                {
                    hitterName = monster.CurrentStatData.Name;
                }
                else if (hitter.TryGetComponent(out BossEntity entity))
                {
                    // 이름을 하드코딩으로 소스에서 적용중임 나중에 수정되면 거기서 가져올 수 있도록 함
                    hitterName = "거신 타르칸";
                }
            }
            
            lastedAttackerText.text = $"마지막 공격 [ {hitterName} ]";
        }

        private void UpdateWeaponList()
        {
            List<Iitem> items = weaponInventory.GetItems();
            foreach (Iitem item in items)
            {
                WeaponBase weapon = item as WeaponBase;
                if (weapon != null)
                {
                    Sprite icon = DatabaseManager.Instance.IconResources.GetIcon(RewardType.Weapon, weapon.WeaponId);
                    
                    ResultElement element = elementPoolSo.Get<ResultElement>(weaponListContents);
                    element.SetOriginPool(elementPoolSo);
                    element.UpdateImage(icon);
                    
                    _resultElements.Add(element);
                }
            }
            
            LayoutRebuilder.ForceRebuildLayoutImmediate(weaponListContents);
        }

        private void UpdateItemList()
        {
            List<Iitem> items = passiveItemInventory.GetItems();
            foreach (Iitem item in items)
            {
                ItemBase passiveItem = item as ItemBase;
                if (passiveItem != null)
                {
                    Sprite icon = DatabaseManager.Instance.IconResources.GetIcon(RewardType.PassiveItem, passiveItem.CachedBuilder.ItemID);
                    
                    ResultElement element = elementPoolSo.Get<ResultElement>(itemListContents);
                    element.SetOriginPool(elementPoolSo);
                    element.UpdateImage(icon);
                    
                    _resultElements.Add(element);
                }
            }
            
            LayoutRebuilder.ForceRebuildLayoutImmediate(itemListContents);
        }
    }
}