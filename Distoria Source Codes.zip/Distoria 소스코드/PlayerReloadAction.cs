using ProjectAAA.Core.Scene.Manager;
using ProjectAAA.Utils;
using UnityEngine;

namespace ProjectAAA.Player.Actions
{
    public class PlayerReloadAction : PlayerActionBase
    {
        private bool ReloadKeydown => PlayerActionController.PlayerInput.GamePlay.Reload.WasPerformedThisFrame();

        public override void OnRegister()
        {
            base.OnRegister();
            
            PlayerManager.Instance.WeaponHandler.Reload();
        }

        public override bool Validate()
        {
            return ReloadKeydown;
        }
    }
}