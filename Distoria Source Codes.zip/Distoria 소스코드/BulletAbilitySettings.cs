using NaughtyAttributes;
using ProjectAAA.SO;
using ProjectAAA.SO.CameraEffect;
using ProjectAAA.SO.Pool;
using UnityEngine;

namespace ProjectAAA.WeaponSystem.BulletAbility
{
    public class BulletAbilitySettings : MonoBehaviour
    {
        [BoxGroup("폭발 관련 데이터")]
        [SerializeField, Tooltip("폭발 이펙트")] private ObjectPoolSO explosionEffectPool;
        [BoxGroup("폭발 관련 데이터")]
        [SerializeField, Tooltip("폭발 사운드")] private FMODEventInfoSO explosionSound;
        [BoxGroup("폭발 관련 데이터")]
        [SerializeField, Tooltip("카메라 셰이크 데이터")] private ExplosionCameraShakeEffectDataSO cameraShakeData;

        [BoxGroup("탄 생성 관련 데이터")] 
        [SerializeField, Tooltip("탄 생성 이펙트")] private ObjectPoolSO addBulletEffectPool;
        [BoxGroup("탄 생성 관련 데이터")] 
        [SerializeField, Tooltip("탄 생성 사운드")] private FMODEventInfoSO addBulletSound;
        [BoxGroup("탄 생성 관련 데이터")] 
        [SerializeField, Tooltip("탄 생성 스프레드 데이터")] private BaseSpreadDataSO addBulletSpreadData;
        
        public ObjectPoolSO ExplosionEffectPool => explosionEffectPool;
        public FMODEventInfoSO ExplosionSound => explosionSound;
        public ExplosionCameraShakeEffectDataSO CameraShakeData => cameraShakeData;

        public ObjectPoolSO AddBulletEffectPool => addBulletEffectPool;
        public BaseSpreadDataSO AddBulletSpreadData => addBulletSpreadData;
        public FMODEventInfoSO AddBulletSound => addBulletSound;
    }
}