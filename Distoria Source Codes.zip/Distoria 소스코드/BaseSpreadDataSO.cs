using System;
using ProjectAAA.Utils;
using UnityEngine;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.SO
{
    public abstract class BaseSpreadDataSO : BaseSO
    {
        public enum SpreadType
        {
            Circle, 
            Rect,
            Line
        }
        
        [SerializeField] private AnimationCurve spreadCurve;
        [SerializeField, Tooltip("한발 쏠 때마다의 그래프 X 축 증가량")] private float increaseStep;
        [SerializeField, Tooltip("초당 감소량")] private float decreasePerSec;

        public AnimationCurve SpreadCurve => spreadCurve;

        public abstract Vector2 HalfScale { get; }
        public abstract SpreadType Type { get; }
        
        public float Delta { get; protected set; }
        public float CurrentYValue { get; protected set; }

        public void Clear()
        {
            Delta = 0;

            float firstTime = spreadCurve.keys[0].time;
            CurrentYValue = spreadCurve.Evaluate(firstTime);
        }

        public void NextStep()
        {
            float lastTime = spreadCurve.keys[spreadCurve.length - 1].time;
            
            Delta += increaseStep;
            Delta = Mathf.Min(lastTime, Delta);
        }

        public void UpdateSpread(float delta)
        {
            float firstTime = spreadCurve.keys[0].time;
            
            Delta -= decreasePerSec * delta;
            Delta = Mathf.Max(firstTime, Delta);
            
            CurrentYValue = SpreadCurve.Evaluate(Delta);
        }
        
        public Vector3 GetRandomPoint(AxisFlag ignoreAxis)
        {
            Vector3 offset = CalcOffset();

            if (Util.HasFlag((int)AxisFlag.X, (int)ignoreAxis)) offset.x = 0f;
            if (Util.HasFlag((int)AxisFlag.Y, (int)ignoreAxis)) offset.y = 0f;
            if (Util.HasFlag((int)AxisFlag.Z, (int)ignoreAxis)) offset.z = 0f;

            return offset;
        }

        protected abstract Vector3 CalcOffset();
    }
}