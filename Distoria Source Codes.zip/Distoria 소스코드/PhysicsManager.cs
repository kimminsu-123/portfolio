using System;
using System.Collections.Generic;
using ProjectAAA.Core.OptimizedSensor;
using ProjectAAA.Utils;

namespace ProjectAAA.Core.Managers
{
    public class PhysicsManager : SingletonMonoBehavior<PhysicsManager>
    {
        private readonly OptimizedRaycastSensor _raycastSensor = new(200);
        private readonly OptimizedSphereCastSenser _sphereCastSensor = new(2000);
        private readonly OptimizedOverlapSphereSenser _overlapSphereSensor = new(200);
        private readonly OptimizedOverlapBoxSenser _overlapBoxSensor = new(200);
        private readonly OptimizedOverlapSectorSenser _overlapSectorSensor = new(200);
        
        public void AddRaycast(IOptimizedSensorData sensorData)
        {
            _raycastSensor.Register(sensorData);
        }
        
        public void AddSphereCast(IOptimizedSensorData sensorData)
        {
            _sphereCastSensor.Register(sensorData);
        }

        public void AddOverlapSphereSensor(IOptimizedSensorData sensorData)
        {
            _overlapSphereSensor.Register(sensorData);
        }

        public void AddOverlapBoxSensor(IOptimizedSensorData sensorData)
        {
            _overlapBoxSensor.Register(sensorData);
        }

        public void AddOverlapSectorSensor(IOptimizedSensorData sensorData)
        {
            _overlapSectorSensor.Register(sensorData);
        }
        
        private void FixedUpdate()
        {
            try
            {
                _raycastSensor.Execute();
            }
            catch (Exception ex)
            {
                Logger.LogError("PhysicsManager", $"RaycastSensor Error : {ex.Message}");
            }

            try
            {
                _sphereCastSensor.Execute();
            }
            catch (Exception ex)
            {
                Logger.LogError("PhysicsManager", $"SphereCast Error : {ex.Message}");
            }

            try
            {
                _overlapSphereSensor.Execute();
            }
            catch (Exception ex)
            {
                Logger.LogError("PhysicsManager", $"OverlapSphere Error : {ex.Message}");
            }

            try
            {
                _overlapBoxSensor.Execute();
            }
            catch (Exception ex)
            {
                Logger.LogError("PhysicsManager", $"OverlapBox Error : {ex.Message}");
            }

            try
            {
                _overlapSectorSensor.Execute();
            }
            catch (Exception ex)
            {
                Logger.LogError("PhysicsManager", $"OverlapSector Error : {ex.Message}");
            }
        }
    }
}