using System;
using ProjectAAA.Core.Managers;
using ProjectAAA.SO;
using ProjectAAA.Utils.DataTable;
using UnityEngine;

namespace ProjectAAA.UI.MainFight
{
    public struct ItemCollectData
    {
        public string Name;
        public Color HighlightColor;
        public Sprite Icon;
    }
    
    public class ItemCollectUI : CollectUI<ItemCollectElementUI, ItemCollectData>
    {
        public void Add(RewardType rewardType, int code, string itemName)
        {
            Color color = Color.white;
            if (rewardType != RewardType.Weapon)
            {
                ItemGrade grade = DatabaseManager.Instance.GetTable<ItemTableSO>().GetItem(code).ItemGrade;
                color = ItemManager.Instance.GetColorByGrade(grade);
            }
            
            Add(new ItemCollectData()
            {
                Name = itemName,
                HighlightColor = color,
                Icon = DatabaseManager.Instance.IconResources.GetIcon(rewardType, code)
            });
        }
    }
}