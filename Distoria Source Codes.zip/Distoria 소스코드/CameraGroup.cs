using ProjectAAA.Core.Managers;
using ProjectAAA.Utils;
using UnityEngine;

namespace ProjectAAA.Core.Entity
{
    public class CameraGroup : MonoBehaviour
    {
        public CamGroupType groupType = CamGroupType.Main;
        
        private Camera[] _cameras;
        
        private void Awake()
        {
            _cameras = gameObject.GetComponentsInChildren<Camera>();            
        }

        private void OnDestroy()
        {
            for (int i = 0; i < _cameras.Length; i++)
            {
                CameraManager.Instance.RemoveCamera(groupType, _cameras[i]);
            }
        }

        private void Start()
        {
            if (groupType != CameraManager.Instance.CurGroupType)
            {
                gameObject.SetActive(false);
            }
            
            for (int i = 0; i < _cameras.Length; i++)
            {
                CameraManager.Instance.AddCamera(groupType, _cameras[i]);
            }
        }
    }
}