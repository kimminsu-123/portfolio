using System.Collections.Generic;
using Newtonsoft.Json;
using ProjectAAA.Utils.DataTable;
using UnityEngine;

namespace ProjectAAA.SO.Debug
{
    [CreateAssetMenu(fileName = "BulletAbilityDebugDataGroup", menuName = "Scriptable Objects/DataTable/Debug/BulletAbility")]
    public class BulletAbilityDebugDataGroup : DebugDataGroup
    {
        [SerializeField] private List<BulletAbilityData> abilities;
        
        protected override void FromJson(string json)
        {
            abilities.Clear();
            abilities = JsonConvert.DeserializeObject<List<BulletAbilityData>>(json);
        }

        public override string ToJson()
        {
            return JsonConvert.SerializeObject(abilities);
        }
    }
}