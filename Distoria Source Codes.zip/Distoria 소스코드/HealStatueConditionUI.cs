using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace ProjectAAA.UI.Statue
{
    public struct HealConditionData
    {
        public int CurrentGold { get; }
        public int RequireGold { get; }
        
        public HealConditionData(int currentGold, int requireGold)
        {
            CurrentGold = currentGold;
            RequireGold = requireGold;
        }        
    }
    
    public class HealStatueConditionUI : StatueConditionUI
    {
        protected override Type RegisterType => typeof(HealStatueConditionUI);
        
        [SerializeField] private TMP_Text currentGoldText;
        [SerializeField] private TMP_Text requireGoldText;
        [SerializeField] private Image fillImage;
        
        public void Setup(HealConditionData data)
        {
            BlockImage.gameObject.SetActive(data.CurrentGold < data.RequireGold);
            
            currentGoldText.text = $"{data.CurrentGold:F0}";
            requireGoldText.text = $"{data.RequireGold:F0}";
            
            if(Mathf.Approximately(0f, data.RequireGold))
            {
                fillImage.fillAmount = 1f;
            }
            else
            {
                fillImage.fillAmount = (float) data.CurrentGold / data.RequireGold;
            }
        }
    }
}