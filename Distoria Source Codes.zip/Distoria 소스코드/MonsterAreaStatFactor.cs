using ProjectAAA.Mob.Normal;
using UnityEngine;

namespace ProjectAAA.Mob
{
    public class MonsterAreaStatFactor : MonoBehaviour
    {
        [SerializeField] private float healthFactor = 1f;
        [SerializeField] private float defenseFactor = 1f;
        [SerializeField] private float attackFactor = 1f;
        
        public void ApplyFactor(MonsterBase monster)
        {
            monster.HealthFactor = healthFactor;
            monster.DefenseFactor = defenseFactor;
            monster.AttackFactor = attackFactor;
        }
    }
}