using System;
using ProjectAAA.Core;
using ProjectAAA.Core.Pool;
using ProjectAAA.SO.Pool;
using ProjectAAA.Utils;
using ProjectAAA.WeaponSystem.BulletAbility;
using UnityEngine;

namespace ProjectAAA.WeaponSystem
{
    public abstract class BulletBase : PoolObjMonoBehaviour
    {
        public abstract int AbilityID { get; }
        public abstract float GravityFactor { get; }
        public float BulletSize { get; protected set; }
        public float BulletLifeTime { get; protected set; }
        public float BulletSpeed { get; protected set; }
        public float CriticalMagnification { get; set; }
        
        public HitInfo CurrentHitInfo { get; set; }
        
        public int BulletId => bulletId;
        public BulletAbilitySettings AbilitySettings => _abilitySettings;
        public ObjectPoolSO TracerLineEffectPool => tracerLineEffectPool;
        
        [Header("기본 값")]
        [SerializeField] protected int bulletId;
        [SerializeField] protected LayerMask targetLayerMask;

        [Header("공용 이펙트")] 
        [SerializeField, Tooltip("ParticlePoolObj 가 부착된 파티클 이펙트 (총알을 따라 다니는 꼬리 이펙트)")]
        protected ObjectPoolSO bulletTracerEffectPool;
        [SerializeField, Tooltip("총알이 부딪혔을 때 생기는 이펙트")] 
        protected ObjectPoolSO onHitEffectPool;
        [SerializeField, Tooltip("총알이 사라질 때 생기는 이펙트")] 
        protected ObjectPoolSO onDestroyBulletEffectPool;
        
        [Header("HitScan 이펙트")]
        [SerializeField, Tooltip("LineRenderer 이펙트 (충돌된 영역으로 라인을 그리는 이펙트)")]
        private ObjectPoolSO tracerLineEffectPool;

        private BulletAbilitySettings _abilitySettings;
        private ParticlePoolObj _bulletTracerParticle;
        
        private void Awake()
        {
            _abilitySettings = GetComponent<BulletAbilitySettings>();
            
            OnAwake();
        }

        private void FixedUpdate()
        {
            OnFixedUpdate();
        }

        protected void PlayTracerEffect()
        {
            if (bulletTracerEffectPool != null)
            {
                _bulletTracerParticle = bulletTracerEffectPool.Get<ParticlePoolObj>(transform);
                _bulletTracerParticle.SetOriginPool(bulletTracerEffectPool);
                _bulletTracerParticle.SetScale(Vector3.one); // Bullet 의 자식으로가기 때문에 사이즈 조절이 필요없음 (bullet 이 사이즈 조절됨)
                _bulletTracerParticle.Play(true, false);
            }
        }

        public void PlayTracerLineEffect(Vector3 curPos, Vector3 point)
        {
            if (TracerLineEffectPool != null)
            {
                TracerLine tracer = TracerLineEffectPool.Get<TracerLine>(null);
                tracer.SetOriginPool(TracerLineEffectPool);
                tracer.SetPoint(0, curPos);
                tracer.SetPoint(1, point);
                tracer.SetWidthMultiplier(BulletSize);
            }
        }
        
        public override void OnRelease()
        {
            base.OnRelease();
            
            if (_bulletTracerParticle != null)
            {
                _bulletTracerParticle.SetParent(null);
                _bulletTracerParticle.Stop();
                _bulletTracerParticle = null;
            }

            if (onDestroyBulletEffectPool != null)
            {
                ParticlePoolObj particle = onDestroyBulletEffectPool.Get<ParticlePoolObj>(null);
                particle.SetOriginPool(onDestroyBulletEffectPool);
                particle.SetPosition(transform.position);
                particle.SetRotation(transform.rotation);
                particle.SetScale(Vector3.one * BulletSize);
                particle.Play();
            }
        }

        protected virtual void OnAwake() { }
        protected virtual void OnFixedUpdate() { }

        /// <summary>
        /// ForceHit, Process 를 호출하기 전에 먼저 호출해야하는 함수입니다.
        /// 데이터 테이블에 있는 속성들 중 버프 효과를 적용할 데이터를 셋업해주는 함수입니다.
        /// </summary>
        public abstract void SetupData();        
        
        /// <summary>
        /// 강제로 해당 지점에 맞추도록 하는 함수입니다.
        /// 현재는 가까이에 있을 때 쓰는 함수입니다.
        /// </summary>
        /// <param name="hitInfo">맞출 지점</param>
        public abstract void ForceHit(HitInfo hitInfo);
        
        /// <summary>
        /// 특정 방향의 점으로 향하도록 하는 함수입니다.
        /// </summary>
        /// <param name="hitInfoPoint">총알이 가길 원하는 지점</param>
        /// <param name="camForward">카메라가 바라보는 방향</param>
        public abstract void Process(Vector3 hitInfoPoint, Vector3 camForward);
    }
}