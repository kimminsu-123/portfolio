using System;
using ProjectAAA.Core.Timer;
using ProjectAAA.Network;
using ProjectAAA.SO;
using ProjectAAA.Utils;
using UnityEditor;
using UnityEngine;

namespace ProjectAAA.Core.Managers
{
    public class GameManager : SingletonMonoBehavior<GameManager>
    {
        [SerializeField] private SceneGroupSO lobbySceneGroup;

        public StopwatchTimer AliveTimeStopwatch { get; private set; }
        public GameMode Mode { get; private set; } = GameMode.None;

        private bool _isNewStartStopwatch = false;
        
        protected override void Initialize()
        {
            AliveTimeStopwatch = new StopwatchTimer(0f);
            
            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;
            
            EventManager.Instance.AddListener(EventType.OnBeginLoadSceneGroup, OnBeginLoadSceneGroup);
            EventManager.Instance.AddListener(EventType.OnEndDelayAfterLoadScene, OnEndDelayAfterLoadScene);
            EventManager.Instance.AddListener(EventType.OnGameClear, OnGameClear);
            EventManager.Instance.AddListener(EventType.OnPlayerDeath, OnPlayerDeath);
            
            RankingServer.Instance.Initialize();
        }

        private void OnBeginLoadSceneGroup(Component sender, object[] args)
        {
            SceneGroupSO cur = args[0] as SceneGroupSO;
            SceneGroupSO next = args[1] as SceneGroupSO;

            if (cur == null || next == null)
            {
                return;
            }

            _isNewStartStopwatch = false;
            AliveTimeStopwatch.Pause();
            
            // 로비에서 스테이지로 이동할 때만
            if (cur.ContainsType(SceneType.Lobby) && next.ContainsType(SceneType.Stage))
            {
                _isNewStartStopwatch = true;

                if (next.ContainsByName("WaveStage"))
                {
                    Mode = GameMode.Wave;
                }
                else if (next.ContainsByName("Stage"))
                {
                    Mode = GameMode.Stage;
                }
                else
                {
                    Mode = GameMode.None;
                }
            }
        }

        private void OnEndDelayAfterLoadScene(Component sender, object[] args)
        {
            if (_isNewStartStopwatch)
            {
                AliveTimeStopwatch.Start();
            }
            AliveTimeStopwatch.Resume();
        }
        
        private void OnGameClear(Component sender, object[] args)
        {
            AliveTimeStopwatch.Stop();
        }

        private void OnPlayerDeath(Component sender, object[] args)
        {
            AliveTimeStopwatch.Stop();
        }

        private void Update()
        {
            AliveTimeStopwatch?.Tick(Time.deltaTime);
            
            Shader.SetGlobalFloat("_UnscaledTime", Time.unscaledTime);
        }

        public void LeaveToLobby()
        {
            AliveTimeStopwatch.Stop();
            AliveTimeStopwatch.Reset();

            EventManager.Instance.PostNotification(EventType.PlayerClear, this);
            _ = LoadingManager.Instance.LoadSceneGroupAsync(lobbySceneGroup, true);
        }

        public void RestartStage()
        {
            AliveTimeStopwatch.Stop();
            AliveTimeStopwatch.Reset();
            
            EventManager.Instance.PostNotification(EventType.OnRestartGame, this);
            _ = LoadingManager.Instance.LoadSceneGroupAsync(LoadingManager.Instance.CurrentSceneGroup, true);
        }
        
        public void ExitGame()
        {
#if UNITY_EDITOR
            EditorApplication.isPlaying = false;
#else
            Application.Quit();
#endif
        }

        private void OnApplicationFocus(bool hasFocus)
        {
            EventManager.Instance.PostNotification(hasFocus ? EventType.OnHaveFocus : EventType.OnLostFocus, this);
        }
    }
}
