using UnityEditor;
using UnityEditor.Overlays;
using UnityEditor.UIElements;
using UnityEngine;
using UnityEngine.UIElements;

namespace ProjectAAA.EditorSelection
{
    [Overlay(typeof(SceneView), "SceneView Selection", true)]
    public class EditorSelectionOverlay : Overlay
    {
        private VisualElement _root;
        private Toggle _enableSelectionToggle;
        private ColorField _hoverColorField;
        private ColorField _selectionColorField;

        public override VisualElement CreatePanelContent()
        {
            InitializeOnLoad();

            return _root;
        }

        private void InitializeOnLoad()
        {
            _root = new VisualElement();
            _root.style.paddingLeft = 5;
            _root.style.paddingRight = 5;
            _root.style.paddingTop = 5;
            _root.style.paddingBottom = 5;

            _enableSelectionToggle = new Toggle("Enable Selection");
            _enableSelectionToggle.RegisterValueChangedCallback(evt =>
                EditorSelectionSettings.SaveEnableSelection(evt.newValue));
            _enableSelectionToggle.value = EditorSelectionSettings.EnableSelection;
            _root.Add(_enableSelectionToggle);

            _hoverColorField = new ColorField("Hover Color");
            _hoverColorField.RegisterValueChangedCallback(evt => EditorSelectionSettings.SaveHoverColor(evt.newValue));
            _hoverColorField.showAlpha = true;
            _hoverColorField.value = EditorSelectionSettings.HoverColor;
            _hoverColorField.schedule.Execute(() =>
            {
                var picker = _hoverColorField.Q(className: "unity-color-field__color-container");
                if (picker != null)
                {
                    picker.style.width = 50f;
                }
            });
            _root.Add(_hoverColorField);

            _selectionColorField = new ColorField("Selection Color");
            _selectionColorField.RegisterValueChangedCallback(evt =>
                EditorSelectionSettings.SaveSelectionColor(evt.newValue));
            _selectionColorField.showAlpha = true;
            _selectionColorField.value = EditorSelectionSettings.SelectionColor;
            _selectionColorField.schedule.Execute(() =>
            {
                var picker = _selectionColorField.Q(className: "unity-color-field__color-container");
                if (picker != null)
                {
                    picker.style.width = 50f;
                }
            });
            _root.Add(_selectionColorField);
        }
    }
}