using System;
using System.Diagnostics;
using ProjectAAA.Core.Managers;
using UnityEngine;
using Debug = UnityEngine.Debug;

namespace ProjectAAA.Utils
{
    public static class Logger
    {
        public static void Log(string title, string msg)
        {
#if ENABLE_DEBUG
            Debug.Log($"[{title}] : {msg}");
#else
            FileLoggerManager.Instance.CaptureLogs($"[{title}] : {msg}", "NON-STACKTRACE", LogType.Log);
#endif
        }
        
        public static void Log(string title, string msg, Color color)
        {
#if ENABLE_DEBUG
            Debug.Log($"<color=#{ColorUtility.ToHtmlStringRGBA(color)}>[{title}] : {msg}</color>");
#else
            FileLoggerManager.Instance.CaptureLogs($"[{title}] : {msg}", "NON-STACKTRACE", LogType.Log);
#endif
        }
        
        public static void LogError(string title, string msg)
        {
#if ENABLE_DEBUG
            Debug.LogError($"[{title}] : {msg}");
#else
            FileLoggerManager.Instance.CaptureLogs($"[{title}] : {msg}", "NON-STACKTRACE", LogType.Error);
#endif
        }
        
        public static void LogWarning(string title, string msg)
        {
#if ENABLE_DEBUG
            Debug.LogWarning($"[{title}] : {msg}");
#else
            FileLoggerManager.Instance.CaptureLogs($"[{title}] : {msg}", "NON-STACKTRACE", LogType.Warning);
#endif
        }
        
        public static void Assert(bool condition, string title, string msg)
        {
#if ENABLE_DEBUG
            Debug.Assert(condition, $"[{title}] : {msg}");
#else
            FileLoggerManager.Instance.CaptureLogs($"[{title}] : {msg} - {condition}", "NON-STACKTRACE", LogType.Assert);
#endif
        }
        
        public static void LogException(Exception exception)
        {
#if ENABLE_DEBUG
            Debug.LogException(exception);
#else
            FileLoggerManager.Instance.CaptureLogs($"{exception.Message}", $"{exception.StackTrace}", LogType.Exception);
#endif
        }

        [Conditional("ENABLE_DEBUG")]
        public static void DrawLine(Vector3 from, Vector3 to, Color color, float duration = 1f)
        {
            Debug.DrawLine(from, to, color, duration);
        }
        
        [Conditional("ENABLE_DEBUG")]
        public static void DrawRay(Ray ray, Color color)
        {
            Debug.DrawRay(ray.origin, ray.direction, color);
        }
        
        [Conditional("ENABLE_DEBUG")]
        public static void DrawRay(Vector3 start, Vector3 dir, Color color)
        {
            Debug.DrawRay(start, dir, color);
        }

        [Conditional("ENABLE_DEBUG")]
        public static void Break()
        {
            Debug.Break();
        }
        
        [Conditional("ENABLE_DEBUG")]
        public static void BreakIf(IPredicate condition)
        {
            if (condition.Evaluate())
            {
                Debug.Break();
            }
        }
    }
}