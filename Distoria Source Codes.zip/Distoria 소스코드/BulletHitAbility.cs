using Cysharp.Threading.Tasks;
using ProjectAAA.Utils;

namespace ProjectAAA.WeaponSystem
{
    public abstract class BulletHitAbility 
    {
        public bool IsDoneAll
        {
            get
            {
                bool ret = IsDone;
                BulletHitAbility next = Next;
                while (next != null)
                {
                    ret &= next.IsDone;
                    next = next.Next;
                }
                return ret;
            }
        }

        public abstract bool IsDone { get; }
        
        protected BulletHitAbility Next { get; private set; }
        protected BulletHitHandler Handler { get; private set; }

        protected BulletHitAbility(BulletHitHandler handler)
        {
            Handler = handler;
        }

        public void SetNext(BulletHitAbility ability)
        {
            if (Next == null)
            {
                Next = ability;
            }
            else
            {
                Next.SetNext(ability);
            }
        }

        public abstract void Init();

        public virtual async UniTask OnHit(HitInfo info)
        {
            if (IsDone)
            {
                if (Next != null)
                {
                    await Next.OnHit(info);
                }
            }
        }

        public virtual async UniTask OnHitOther(HitInfo info)
        {
            if (IsDone)
            {
                if (Next != null)
                {
                    await Next.OnHitOther(info);
                }
            }
        }
    }
}