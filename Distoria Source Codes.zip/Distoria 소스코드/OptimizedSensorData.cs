using System;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using Unity.VisualScripting;
using UnityEngine;

namespace ProjectAAA.Core.OptimizedSensor
{
    public enum SensorStatus
    {
        None,
        Running,
        Completed,
    }
    
    public interface IOptimizedSensorData
    {
        public int Count { get; }
        public SensorStatus Status { get; }
        public UniTaskCompletionSource Handle { get; }

        public void Initialize();
        public void Run();
        public void Complete();
    }

    public abstract class OptimizedSensorData<TModel> : IOptimizedSensorData where TModel : struct
    {
        public int Count => SensorModels.Count;
        public SensorStatus Status { get; private set; }
        public UniTaskCompletionSource Handle { get; private set; }
        
        public List<TModel> SensorModels { get; private set; }

        protected OptimizedSensorData(int modelCapacity)
        {
            SensorModels = new List<TModel>(modelCapacity);
            Handle = new UniTaskCompletionSource();
            Status = SensorStatus.None;
        }

        public void Initialize()
        {
            Status = SensorStatus.None;
            
            OnInitialize();
        }

        public void Run()
        {
            Status = SensorStatus.Running;
            
            OnRun();
        }
        
        public void Complete()
        {
            SensorModels.Clear();
            
            Status = SensorStatus.Completed;
            OnComplete();
            
            Handle.TrySetResult();

            Handle = null;
            Handle = new UniTaskCompletionSource();
        }

        public void SetModel(TModel model)
        {
            SensorModels.Clear();
            SensorModels.Add(model);
        }

        public void SetModelRange(IEnumerable<TModel> models)
        {
            SensorModels.Clear();
            SensorModels.AddRange(models);
        }

        protected virtual void OnInitialize(){}
        protected virtual void OnRun(){}
        protected virtual void OnComplete(){}
        
        public abstract void ResizeResults(int resultCapacity);
    }
    
    public class OptimizedRaycastSensorData : OptimizedSensorData<OptimizedRaycastSensorModel>
    {
        public RaycastHit[] Results { get; set; }
        
        public OptimizedRaycastSensorData(int modelCapacity, int resultCapacity) : base(modelCapacity)
        {
            Results = new RaycastHit[resultCapacity];
        }

        public override void ResizeResults(int resultCapacity)
        {
            Results = new RaycastHit[resultCapacity];
        }
    }
    
    public class OptimizedSphereCastSensorData : OptimizedSensorData<OptimizedSphereCastSensorModel>
    {
        public RaycastHit[] Results { get; private set; }

        public OptimizedSphereCastSensorData(int modelCapacity, int resultCapacity) : base(modelCapacity)
        {
            Results = new RaycastHit[resultCapacity];
        }
        
        public override void ResizeResults(int resultCapacity)
        {
            Results = new RaycastHit[resultCapacity];
        }
    }

    public class OptimizedOverlapSphereSensorData : OptimizedSensorData<OptimizedOverlapSphereSensorModel>
    {
        public int TotalCount => Count * MaxHits;
        public int MaxHits { get; private set; }
        public ColliderHit[] Results { get; private set; }
        
        public OptimizedOverlapSphereSensorData(int modelCapacity, int maxHits) : base(modelCapacity)
        {
            MaxHits = maxHits;
            Results = new ColliderHit[maxHits * modelCapacity];
        }
        
        public override void ResizeResults(int resultCapacity)
        {
            Results = new ColliderHit[resultCapacity];
        }
    }
    
    public class OptimizedOverlapBoxSensorData : OptimizedSensorData<OptimizedOverlapBoxSensorModel>
    {
        public int TotalCount => Count * MaxHits;
        public int MaxHits { get; private set; }
        public ColliderHit[] Results { get; private set; }
        
        public OptimizedOverlapBoxSensorData(int modelCapacity, int maxHits) : base(modelCapacity)
        {
            MaxHits = maxHits;
            Results = new ColliderHit[maxHits * modelCapacity];
        }
        
        public override void ResizeResults(int resultCapacity)
        {
            Results = new ColliderHit[resultCapacity];
        }
    }

    public class OptimizedOverlapSectorData : OptimizedSensorData<OptimizedOverlapSectorSensorModel>
    {
        public int TotalCount => Count * MaxHits;
        public int MaxHits { get; private set; }
        public ColliderHit[] Results { get; private set; }
        
        public OptimizedOverlapSectorData(int modelCapacity, int maxHits) : base(modelCapacity)
        {
            MaxHits = maxHits;
            Results = new  ColliderHit[maxHits * modelCapacity];
        }
        
        public override void ResizeResults(int resultCapacity)
        {
            Results = new ColliderHit[resultCapacity];
        }
    }
}