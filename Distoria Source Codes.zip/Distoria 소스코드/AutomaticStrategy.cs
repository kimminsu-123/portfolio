using UnityEngine;

namespace ProjectAAA.WeaponSystem
{
    public class AutomaticStrategy : WeaponNormalFireStrategy
    {
        public AutomaticStrategy(Transform shootPos, WeaponNormal weapon) : base(shootPos, weapon)
        {
        }

        public override void Trigger()
        {
            base.Trigger();
            
            if (FireIntervalTimer.IsRunning) return;
            if (CurrentMagazine.Count <= 0) return;
            if (CurrentFireState != FireState.None) return;
            
            CurrentWeapon.onBeginFireCallback?.Invoke();
        }

        public override void Release()
        {
            base.Release();
            
            CurrentWeapon.onEndFireCallback?.Invoke();
        }

        public override void Active()
        {
            base.Active();

            if (CurrentTriggerState == TriggerState.Triggered)
            {
                Trigger();
            }
        }

        protected override void Process()
        {
            if (CurrentTriggerState != TriggerState.Triggered) return;
            
            Fire();
            
            FireIntervalTimer.SetTime(CurrentWeapon.FireInterval);
            FireIntervalTimer.Start();
        }
    }
}