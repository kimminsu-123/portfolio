using System;
using System.Collections.Generic;
using JetBrains.Annotations;
using ProjectAAA.Core.Managers;
using ProjectAAA.Core.Scene.Manager;
using ProjectAAA.Interaction.Items;
using ProjectAAA.Mob.Normal;
using ProjectAAA.SO;
using ProjectAAA.SO.Quest;
using ProjectAAA.Utils;
using ProjectAAA.Utils.DataTable;
using UniRx;
using Unity.Entities.Content;
using UnityEngine.InputSystem.XR.Haptics;

namespace ProjectAAA.Quests
{
    public abstract class QuestBase : DisposeBase
    {
        public enum Status
        {
            Created,
            Started,
            Clear,
            Ended,
        }

        public string ShopMessage => ConvertMessage(QuestData.String1);
        public string MainFightMessage => ConvertMessage(QuestData.String2);
        public int RewardGroupId => QuestData.RewardGroupId;
        public int DeBuffItemId => QuestData.ItemIdDebuff;

        public ReactiveProperty<Status> CurrentStatus { get; }
        public ReactiveProperty<int> CurrentValue { get; }
        public QuestData QuestData { get; }
        
        private ItemGenerator ItemGenerator => ItemManager.Instance.Generator;
        private ItemBase _deBuffItem;
        
        protected QuestBase(QuestData data)
        {
            QuestData = data;
            CurrentStatus = new ReactiveProperty<Status>(Status.Created);
            CurrentValue = new ReactiveProperty<int>(0);

            CurrentStatus.Subscribe(OnChangeCurrentStatus);
            CurrentValue.Subscribe(OnChangeCurrentValue);
        }
        
        /// <summary>
        /// 퀘스트를 활성화 합니다.
        /// </summary>
        protected abstract void OnEnable();
        
        /// <summary>
        /// 퀘스트를 비활성화 합니다.
        /// </summary>
        protected abstract void OnDisable();

        /// <summary>
        /// 퀘스트가 클리어 됐을 때 행동을 작성합니다.
        /// </summary>
        public virtual void Clear()
        {
            CurrentStatus.Value = Status.Clear;
        }

        public void Enable()
        {
            if (CurrentStatus.Value == Status.Started)
            {
                return;
            }
            
            CurrentStatus.Value = Status.Started;
            GrantItem();
            OnEnable();
        }

        public void Disable()
        {
            if (CurrentStatus.Value == Status.Ended)
            {
                return;
            }
            
            CurrentStatus.Value = Status.Ended;
        }
        
        /// <summary>
        /// 정해진 Format 에 맞게 문자열을 변환합니다.
        /// </summary>
        /// <param name="msg">Quest 의 String1, String2 값</param>
        /// <returns>변환된 최종 문자열</returns>
        private string ConvertMessage(string msg)
        {
            // 몬스터 이름으로 치환
            if (QuestData.MonsterId != 0)
            {
                MonsterStatData monster = DatabaseManager.Instance.GetTable<MonsterStatDataTableSO>().Get(QuestData.MonsterId);

                if (monster != null)
                {
                    msg = msg.Replace("MonsterID", monster.Name);
                }
            }
            else
            {
                msg = msg.Replace("MonsterID", "몬스터");
            }
            
            // 디버프 아이템 이름으로 치환
            if (QuestData.ItemIdDebuff != 0)
            {
                ItemData item = DatabaseManager.Instance.GetTable<ItemTableSO>().GetItem(QuestData.ItemIdDebuff);

                if (item != null)
                {
                    msg = msg.Replace("Item_D", item.ItemName);
                }
            }
            else
            {
                msg = msg.Replace("Item_D", string.Empty);
            }
            
            // 약점 여부 치환
            msg = msg.Replace("WeakCondition", QuestData.WeakCondition ? "약점" : string.Empty);

            // 현재 값 치환
            msg = msg.Replace("Current", $"{CurrentValue.Value}");
            
            // 목표 값 치환
            msg = msg.Replace("ClearValue", $"{QuestData.ClearValue}");

            return msg;
        }
        
        /// <summary>
        /// 버프와 디버프 아이템의 효과를 부여합니다.
        /// </summary>
        private void GrantItem()
        {
            if (ItemGenerator.Contains(QuestData.ItemIdDebuff))
            {
                _deBuffItem = ItemGenerator.GetValue(QuestData.ItemIdDebuff, null).Reference;
                _deBuffItem.Use(PlayerManager.Instance.PlayerGo);
            }
        }

        /// <summary>
        /// 디버프 아이템의 효과를 다시 회수합니다.
        /// </summary>
        private void RevokeItem()
        {
            if (_deBuffItem != null)
            {
                PlayerManager.Instance.ItemHandler.DropItem(_deBuffItem);
            }
        }

        private void OnChangeCurrentStatus(Status status)
        {
            switch (status)
            {
                case Status.Started:
                    CurrentValue.Value = 0;
                    break;
                case Status.Clear:
                    OnDisable();
                    break;
                case Status.Ended:
                    RevokeItem();
                    OnDisable();
                    break;
            }
        }

        private void OnChangeCurrentValue(int value)
        {
            if (value >= QuestData.ClearValue)
            {
                Clear();
            }
        }

        protected override void DisposeNotManagedResources()
        {
            CurrentStatus.Dispose();
            CurrentValue.Dispose();
        }
    }
}