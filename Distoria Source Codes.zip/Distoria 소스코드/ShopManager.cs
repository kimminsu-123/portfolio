using System;
using ProjectAAA.Core.Action;
using ProjectAAA.Core.Scene.Manager;
using ProjectAAA.Interaction.Shop;
using ProjectAAA.UI.Shop;
using ProjectAAA.Utils;
using UniRx;
using UnityEngine;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.Core.Managers
{
    public class ShopManager : SingletonMonoBehavior<ShopManager>
    {
        private ShopUI ShopUI => UiManager.Instance.Get<ShopUI>();
        private GameObject _cachedBuyer;
        private IDisposable _goldSubscription;

        public void Enter(GameObject buyer, ShopEntryData data, int cameraHash)
        {
            _cachedBuyer = buyer;
            
            IActionable actionable = buyer.GetComponent<IActionable>();
            actionable?.BlockAllActions();

            _goldSubscription = PlayerCurrencyManager.Instance.Gold.Subscribe(ShopUI.UpdateUI);
            
            ShopUI.onSuccessPurchase.AddListener(OnSuccessPurchase);
            ShopUI.Setup(data);
            ShopUI.Show();
            
            PlayerManager.Instance.PlayerUI.SetActive(false);
            CursorHandler.UnLock();
            //CameraManager.Instance.ChangeCameraGroup(CamGroupType.Shop, cameraHash);
        }
        
        private void OnSuccessPurchase(ProductRow row)
        {
            if (row.Reward != null)
            {
                RewardManager.Instance.UseDirectByReward(row.Reward, _cachedBuyer);
                
                row.RemainSellCount = Mathf.Min(0, row.RemainSellCount - 1);
            
                PlayerCurrencyManager.Instance.UseGold(row.Cost);
                RewardManager.Instance.AddUniqueHistory(row.Reward);
            }
        }

        public void Exit()
        {
            ShopUI.onSuccessPurchase.RemoveListener(OnSuccessPurchase);
            ShopUI.Hide();

            if (_cachedBuyer == null)
            {
                return;
            }
            
            PlayerManager.Instance.PlayerUI.SetActive(true);
            CursorHandler.Lock();
            //CameraManager.Instance.ChangeCameraGroup(CamGroupType.Main);
            
            IActionable actionable = _cachedBuyer.GetComponent<IActionable>();
            actionable?.UnBlockAllActions();
            
            _goldSubscription?.Dispose();
            
            Logger.Log("ShopManager", "Action UnBlock", Color.yellow);
        }
    }
}