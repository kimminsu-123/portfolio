using UnityEngine;

namespace ProjectAAA.Core.Timer
{
    public class CooldownTimer : Timer<float>
    {
        public OnTimerEvent OnTickCallback;
        
        public CooldownTimer(float initTime) : base(initTime)
        {
        }

        public override void Tick(float delta)
        {
            if (!IsRunning || IsPause) return;

            CurrentTime = Mathf.Max(0f, CurrentTime - delta);
            
            OnTickCallback?.Invoke();
            
            if (CurrentTime <= 0f)
            {
                Stop();
                OnCompleteCallback?.Invoke();
            }
        }
    }
}