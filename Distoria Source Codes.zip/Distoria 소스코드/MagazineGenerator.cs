using System;
using System.Collections.Generic;
using ProjectAAA.Core.Managers;
using ProjectAAA.SO;
using ProjectAAA.Utils.DataTable;
using UnityEngine;
using EventType = ProjectAAA.Core.Managers.EventType;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.WeaponSystem
{
    public class MagazineGenerator : MonoBehaviour
    {
        public MagazineBase Get(int magazineId)
        {
            MagazineData data = DatabaseManager.Instance.GetTable<MagazineTableSO>().Get(magazineId);

            if (data == null)
            {
                Logger.LogError("MagazineGenerator", $"존재하지 않는 탄창입니다. {magazineId}");
                return null;
            }
            
            BulletGenerator generator = WeaponManager.Instance.BulletGenerator;

            return new MagazineBase(data, generator);
        }
    }
}