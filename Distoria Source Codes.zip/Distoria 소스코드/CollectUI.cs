using System;
using System.Collections.Generic;
using ProjectAAA.SO.Pool;
using UnityEngine;
using EventManager = ProjectAAA.Core.Managers.EventManager;
using EventType = ProjectAAA.Core.Managers.EventType;

namespace ProjectAAA.UI
{
    public abstract class CollectUI<TElement, TData> : MonoBehaviour where TElement : CollectElementUI<TData>
    {
        [SerializeField] private ObjectPoolSO elementPool;
        [SerializeField] private int maxCount = 6;
        [SerializeField] private float elementSpace = 10f;
        
        private List<TElement> _itemElements;
        
        private void Start()
        {
            _itemElements = new List<TElement>(maxCount);
            
            EventManager.Instance.AddListener(EventType.PlayerClear, OnPlayerClear);
        }

        private void OnPlayerClear(Component sender, object[] args)
        {
            Clear();
        }

        public void Clear()
        {
            foreach (TElement element in _itemElements)
            {
                element.SelfReturn();
            }
        }

        private void Update()
        {
            for (int i = _itemElements.Count - 1; i >= 0; i--)
            {
                if (_itemElements[i].NeedHide)
                {
                    RemoveAt(i);
                } 
            }
        }

        public void RemoveAt(int index)
        {
            _itemElements[index].Hide();
            _itemElements.RemoveAt(index);
            
            MoveElements();
        }

        public void MoveElements()
        {
            for (var i = 0; i < _itemElements.Count; i++)
            {
                _itemElements[i].Move(_itemElements.Count - 1 - i, elementSpace);
            }
        }

        public TElement GetElement(int index)
        {
            if (index < 0 || index >= _itemElements.Count)
            {
                return null;
            }
            
            return _itemElements[index];
        }

        protected void Add(TData data)
        {
            TElement ele = elementPool.Get<TElement>(transform);
            ele.SetOriginPool(elementPool);
            ele.Setup(data);
            ele.Show();
            _itemElements.Add(ele);
            
            if (_itemElements.Count > maxCount)
            {
                RemoveAt(0);
            }
            else
            {
                MoveElements();
            }
        }
    }
}