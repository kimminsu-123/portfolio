using System;
using System.Collections.Generic;
using ProjectAAA.SO;
using ProjectAAA.SO.Resource;
using ProjectAAA.Utils;
using UnityEngine;

namespace ProjectAAA.Core.Managers
{
    public class DatabaseManager : SingletonMonoBehavior<DatabaseManager>, IDownload
    {
        [SerializeField] private IconDataSO iconResources;
        [SerializeField] private DataTableSO[] tables;
        
        private readonly Dictionary<Type, DataTableSO> _database = new();

        public IconDataSO IconResources => iconResources;

        protected override async void Initialize()
        {
            foreach (DataTableSO table in tables)
            {
                _database.TryAdd(table.GetType(), table);
            }
            
            await LoadAsync();
        }

        public async Awaitable LoadAsync()
        {
            foreach (DataTableSO table in tables)
            {
                await table.LoadAsync();
            }
        }

        public T GetTable<T>() where T : DataTableSO
        {
            return _database[typeof(T)] as T;
        }
    }
}