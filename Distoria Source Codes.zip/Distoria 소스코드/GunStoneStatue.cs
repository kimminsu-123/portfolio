using System;
using ProjectAAA.Core.Managers;
using ProjectAAA.Core.Scene.Manager;
using ProjectAAA.UI.Statue;
using ProjectAAA.Utils;
using ProjectAAA.WeaponSystem;
using UnityEngine;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.Interactables.Statue
{
    public class GunStoneStatue : StoneStatue
    {
        protected override StatueConditionUI ConditionUI => UiManager.Instance.Get<GunStatueConditionUI>();
        protected override IPredicate AcceptCondition => _acceptCondition;
        protected override IPredicate DenyCondition => null;

        private WeaponHandler WeaponHandler => PlayerManager.Instance.WeaponHandler;
        
        private ChestBase _chest;
        private IPredicate _acceptCondition;

        protected override void Awake()
        {
            base.Awake();

            _chest = GetComponentInChildren<ChestBase>(true);
            
            Logger.Assert(_chest != null, "GunStoneStatue", "석상 하위에 Chest 가 없습니다.");
        }

        private void Start()
        {
            _acceptCondition = new FuncPredicate(CheckWeapon);
        }

        protected override void OnInteract()
        {
            GunStatueConditionUI gun = ConditionUI as GunStatueConditionUI;

            gun?.Setup(new GunConditionData(WeaponHandler.CurrentWeapon.Value.WeaponId, WeaponHandler.DefaultWeaponId));
        }
        
        protected override void OnEnable()
        {
            base.OnEnable();
            
            _chest.gameObject.SetActive(false);
        }

        private bool CheckWeapon()
        {
            int curWeaponId = WeaponHandler.CurrentWeapon.Value.WeaponId;
            int defaultWeaponId = WeaponHandler.DefaultWeaponId;

            return !curWeaponId.Equals(defaultWeaponId);
        }

        protected override void OnAccept()
        {
            WeaponBase curWeapon = WeaponHandler.CurrentWeapon.Value;
            WeaponHandler.DropWeapon();
            curWeapon.SelfReturn();
            
            _chest.gameObject.SetActive(true);
            
            InteractionCollider.enabled = false;
        }

        protected override void OnDeny()
        {
        }
    }
}