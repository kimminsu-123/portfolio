using System;
using System.Collections.Generic;
using System.Linq;
using Cysharp.Threading.Tasks;
using Unity.Burst;
using Unity.Collections;
using Unity.Jobs;
using UnityEngine;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.Core.OptimizedSensor
{
    public abstract class OptimizedSensor
    {
        public bool IsEmpty => DataList.Count <= 0;
        
        protected List<List<IOptimizedSensorData>> DataList { get; }

        protected OptimizedSensor(int capacity)
        {
            DataList = new List<List<IOptimizedSensorData>>(capacity);
        }

        public void Register(IOptimizedSensorData sensorData)
        {
            if (DataList.Count <= 0)
            {
                DataList.Add(new List<IOptimizedSensorData>(512));
            }
            DataList[0].Add(sensorData);
        }

        protected int CalcCommandsPerJob(int count)
        {
            return Mathf.Clamp(Mathf.CeilToInt(count * 32 * 0.01f), 1, 128);
        }
        
        public abstract UniTask Execute();
    }

    public class OptimizedRaycastSensor : OptimizedSensor
    {
        public OptimizedRaycastSensor(int capacity) : base(capacity)
        {
        }

        public override async UniTask Execute()
        {
            if (IsEmpty)
            {
                return;
            }

            List<IOptimizedSensorData> first = DataList[0];
            DataList.RemoveAt(0);

            int totalCount = 0;
            foreach (IOptimizedSensorData data in first)
            {
                totalCount += data.Count;
            }
            
            NativeArray<RaycastCommand> commands = new NativeArray<RaycastCommand>(totalCount, Allocator.TempJob);
            NativeArray<RaycastHit> results = new NativeArray<RaycastHit>(totalCount, Allocator.TempJob);
            
            int offset = 0;
            foreach (IOptimizedSensorData data in first)
            {
                if (data is OptimizedRaycastSensorData raycastData)
                {
                    data.Run();
                    
                    List<OptimizedRaycastSensorModel> models = raycastData.SensorModels;
                    for (int i = 0; i < models.Count; i++)
                    {
                        OptimizedRaycastSensorModel model = models[i];
                        commands[offset + i] = new RaycastCommand(model.Origin, model.Direction, new QueryParameters(model.LayerMask, false, QueryTriggerInteraction.Collide), model.Distance);
                    }
                    offset += models.Count;
                }
            }

            int minCommandsPerJob = CalcCommandsPerJob(results.Length);
            JobHandle physicsHandle = RaycastCommand.ScheduleBatch(commands, results, minCommandsPerJob);
            
            await UniTask.WaitUntil(() => physicsHandle.IsCompleted);
            physicsHandle.Complete();
            
            offset = 0;
            foreach (IOptimizedSensorData data in first)
            {
                if (data is OptimizedRaycastSensorData raycastData)
                {
                    NativeArray<RaycastHit>.Copy(results, offset, raycastData.Results, 0, data.Count);
                    offset += data.Count;
                    
                    data.Complete();
                }
            }
            
            commands.Dispose();
            results.Dispose();
            
            first.Clear();
        }
    }
    
    public class OptimizedSphereCastSenser : OptimizedSensor
    {
        public OptimizedSphereCastSenser(int capacity) : base(capacity)
        {
        }

        public override async UniTask Execute()
        {
            if (IsEmpty)
            {
                return;
            }

            List<IOptimizedSensorData> first = DataList[0];
            DataList.RemoveAt(0);

            int totalCount = first.Sum(x => x.Count);
            
            NativeArray<SpherecastCommand> commands = new NativeArray<SpherecastCommand>(totalCount, Allocator.TempJob);
            NativeArray<RaycastHit> results = new NativeArray<RaycastHit>(totalCount, Allocator.TempJob);   
            
            int offset = 0;
            foreach (IOptimizedSensorData data in first)
            {
                if (data is OptimizedSphereCastSensorData sphereData)
                {
                    data.Run();
                    
                    List<OptimizedSphereCastSensorModel> models = sphereData.SensorModels;
                    for (int i = 0; i < models.Count; i++)
                    {
                        OptimizedSphereCastSensorModel model = models[i];
                        commands[offset + i] = new SpherecastCommand(model.Origin, model.Radius, model.Direction, new  QueryParameters(model.LayerMask, false, QueryTriggerInteraction.Collide), model.Distance);
                    }
                    offset += models.Count;
                }
            }

            int minCommandsPerJob = CalcCommandsPerJob(results.Length);
            JobHandle physicsHandle = SpherecastCommand.ScheduleBatch(commands, results, minCommandsPerJob);
            
            await UniTask.WaitUntil(() => physicsHandle.IsCompleted);
            physicsHandle.Complete();

            offset = 0;
            foreach (IOptimizedSensorData data in first)
            {
                if (data is OptimizedSphereCastSensorData sphereData)
                {
                    NativeArray<RaycastHit>.Copy(results, offset, sphereData.Results, 0, data.Count);
                    offset += data.Count;
                    
                    data.Complete();
                }
            }
            
            commands.Dispose();
            results.Dispose();
            
            first.Clear();
        }
    }
    
    public class OptimizedOverlapSphereSenser : OptimizedSensor
    {
        public OptimizedOverlapSphereSenser(int capacity) : base(capacity)
        {
        }

        public override async UniTask Execute()
        {
            if (IsEmpty)
            {
                return;
            }

            List<IOptimizedSensorData> first = DataList[0];
            DataList.RemoveAt(0);

            int totalCount = first.Sum(x => x.Count);
            
            NativeArray<OverlapSphereCommand> commands = new NativeArray<OverlapSphereCommand>(totalCount, Allocator.TempJob);

            int maxHits = 0;
            int offset = 0;
            foreach (IOptimizedSensorData data in first)
            {
                if (data is OptimizedOverlapSphereSensorData overlapSphereData)
                {
                    data.Run();
                    
                    List<OptimizedOverlapSphereSensorModel> models = overlapSphereData.SensorModels;
                    for (int i = 0; i < models.Count; i++)
                    {
                        OptimizedOverlapSphereSensorModel model = models[i];
                        commands[offset + i] = new OverlapSphereCommand(model.Origin, model.Radius, new  QueryParameters(model.LayerMask, false, QueryTriggerInteraction.Collide));
                    }
                    offset += data.Count;
                    maxHits = Mathf.Max(maxHits, overlapSphereData.MaxHits);
                }
            }
            NativeArray<ColliderHit> results = new NativeArray<ColliderHit>(totalCount * maxHits, Allocator.TempJob);

            int minCommandsPerJob = CalcCommandsPerJob(results.Length);
            JobHandle physicsHandle = OverlapSphereCommand.ScheduleBatch(commands, results, minCommandsPerJob, maxHits);
            
            await UniTask.WaitUntil(() => physicsHandle.IsCompleted);
            physicsHandle.Complete();

            offset = 0;
            foreach (IOptimizedSensorData data in first)
            {
                if (data is OptimizedOverlapSphereSensorData overlapSphereData)
                {
                    NativeArray<ColliderHit>.Copy(results, offset, overlapSphereData.Results, 0, overlapSphereData.TotalCount);

                    offset += overlapSphereData.TotalCount;
                    
                    data.Complete();
                }
            }
            
            commands.Dispose();
            results.Dispose();
            
            first.Clear();
        }
    }
    
    public class OptimizedOverlapBoxSenser : OptimizedSensor
    {
        public OptimizedOverlapBoxSenser(int capacity) : base(capacity)
        {
        }

        public override async UniTask Execute()
        {
            if (IsEmpty)
            {
                return;
            }

            List<IOptimizedSensorData> first = DataList[0];
            DataList.RemoveAt(0);

            int totalCount = first.Sum(x => x.Count);
            
            NativeArray<OverlapBoxCommand> commands = new NativeArray<OverlapBoxCommand>(totalCount, Allocator.TempJob);

            int maxHits = 0;
            int offset = 0;
            foreach (IOptimizedSensorData data in first)
            {
                if (data is OptimizedOverlapBoxSensorData overlapBoxData)
                {
                    data.Run();
                    
                    List<OptimizedOverlapBoxSensorModel> models = overlapBoxData.SensorModels;
                    for (int i = 0; i < models.Count; i++)
                    {
                        OptimizedOverlapBoxSensorModel model = models[i];
                        commands[offset + i] = new OverlapBoxCommand(model.Origin, model.HalfExtents, model.Orientation, new  QueryParameters(model.LayerMask, false, QueryTriggerInteraction.Collide));
                    }
                    offset += data.Count;
                    maxHits = Mathf.Max(maxHits, overlapBoxData.MaxHits);
                }
            }
            NativeArray<ColliderHit> results = new NativeArray<ColliderHit>(totalCount * maxHits, Allocator.TempJob);

            int minCommandsPerJob = CalcCommandsPerJob(results.Length);
            JobHandle physicsHandle = OverlapBoxCommand.ScheduleBatch(commands, results, minCommandsPerJob, maxHits);
            
            await UniTask.WaitUntil(() => physicsHandle.IsCompleted);
            physicsHandle.Complete();

            offset = 0;
            foreach (IOptimizedSensorData data in first)
            {
                if (data is OptimizedOverlapBoxSensorData overlapBoxData)
                {
                    NativeArray<ColliderHit>.Copy(results, offset, overlapBoxData.Results, 0, overlapBoxData.TotalCount);
                    offset += overlapBoxData.TotalCount;
                    
                    data.Complete();
                }
            }
            
            commands.Dispose();
            results.Dispose();
            
            first.Clear();
        }
    }
    
    public class OptimizedOverlapSectorSenser : OptimizedSensor
    {
        private readonly OptimizedOverlapSphereSenser _overlapSphereSenser;
        private readonly OptimizedOverlapSphereSensorData _overlapSphereSensorData;
            
        public OptimizedOverlapSectorSenser(int capacity) : base(capacity)
        {
            _overlapSphereSenser = new OptimizedOverlapSphereSenser(capacity);
            _overlapSphereSensorData = new OptimizedOverlapSphereSensorData(3, 1);
        }

        public override async UniTask Execute()
        {
            if (IsEmpty)
            {
                return;
            }
            
            List<IOptimizedSensorData> first = DataList[0];
            DataList.RemoveAt(0);

            int maxHits = 0;
            for (int i = 0; i < first.Count; i++)
            {
                if (first[i] is not OptimizedOverlapSectorData overlapSectorData)
                {
                    continue;
                }
                
                for (var index = 0; index < overlapSectorData.SensorModels.Count; index++)
                {
                    OptimizedOverlapSectorSensorModel model = overlapSectorData.SensorModels[index];
                    _overlapSphereSensorData.SetModel(new OptimizedOverlapSphereSensorModel()
                    {
                        Origin = model.Origin,
                        LayerMask = model.LayerMask,
                        Radius = model.Radius
                    });
                    
                    maxHits = Mathf.Max(maxHits, overlapSectorData.MaxHits);
                }
            }

            if (maxHits < _overlapSphereSensorData.MaxHits)
            {
                _overlapSphereSensorData.ResizeResults(maxHits);
            }
            _overlapSphereSenser.Register(_overlapSphereSensorData);
            await _overlapSphereSenser.Execute();
            
            int offset = 0;
            foreach (IOptimizedSensorData data in first)
            {
                if (data is OptimizedOverlapSectorData overlapSectorData)
                {
                    Array.Copy(_overlapSphereSensorData.Results, offset, overlapSectorData.Results, 0, overlapSectorData.TotalCount);

                    int copyOffset = 0;
                    for (int i = 0; i < overlapSectorData.SensorModels.Count; i++)
                    {
                        OptimizedOverlapSectorSensorModel model = overlapSectorData.SensorModels[i];
                        for (int j = 0; j < overlapSectorData.MaxHits; j++)
                        {
                            int index = copyOffset + j;
                            Collider col = overlapSectorData.Results[index].collider;
                            if (col == null)
                            {
                                continue;
                            }
                        
                            Vector3 toTarget = col.transform.position - model.Origin;
                            float sqrMag = toTarget.sqrMagnitude;
                            float angle = Vector3.Angle(model.Direction.normalized, toTarget.normalized);

                            if (sqrMag > model.Radius * model.Radius)
                            {
                                continue;
                            }
                            
                            if (angle > model.Angle * 0.5f)
                            {
                                // collider 지우기
                                overlapSectorData.Results[index] = default;
                            }   
                        }
                        copyOffset += overlapSectorData.MaxHits;
                    }

                    offset += overlapSectorData.TotalCount;
                    
                    data.Complete();
                }
            }
            
            first.Clear();
        }
    }
}