using ProjectAAA.SO.Pool;
using UnityEngine;

namespace ProjectAAA.Core.Pool
{
    public interface IPoolObj
    {
        public void SetPosition(Vector3 pos, Space space = Space.World);
        public void SetRotation(Quaternion rot, Space space = Space.World);
        public void SetScale(Vector3 scale);
        public void SetParent(Transform p);
        public void Active();
        public void Inactive();
        public void OnGet();
        public void OnRelease();
    }
}