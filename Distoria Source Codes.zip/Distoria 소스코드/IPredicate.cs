namespace ProjectAAA.Utils
{
    public interface IPredicate
    {
        bool Evaluate();
    }
}