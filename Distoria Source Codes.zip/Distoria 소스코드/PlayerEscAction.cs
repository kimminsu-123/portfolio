using ProjectAAA.Core.Managers;
using ProjectAAA.UI;
using ProjectAAA.Utils;
using UnityEngine;
using EventType = ProjectAAA.Core.Managers.EventType;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.Player.Actions
{
    public class PlayerEscAction : PlayerActionBase
    {
        private SettingUI SettingUI => UiManager.Instance.Get<SettingUI>();
        private bool EscKeyDown
        {
            get
            {
#if UNITY_EDITOR
                return Input.GetKeyDown(KeyCode.BackQuote);
#else
                return PlayerActionController.PlayerInput.GamePlay.ESC.WasPressedThisFrame();
#endif
            }
        }

        private bool _isEnabled;

        public override void Initialize(GameObject target)
        {
            EventManager.Instance.AddListener(EventType.OnBeginLoadSceneGroup, OnBeginLoadScene);
            EventManager.Instance.AddListener(EventType.OnEndDelayAfterLoadScene, OnEndLoadScene);
            
            base.Initialize(target);

            _isEnabled = false;
        }

        public override void OnRegister()
        {
            base.OnRegister();
            
            TimeHandler.SetTimeScale(GetHashCode(), 0f);
            CursorHandler.UnLock();

            SettingUI.Show();
        }

        public override void OnUnRegister()
        {
            base.OnUnRegister();
            
            TimeHandler.ResetTimeScale(GetHashCode());
            CursorHandler.Lock();

            _isEnabled = false;

            SettingUI.Hide();
        }

        private void OnBeginLoadScene(Component sender, object[] args)
        {
            BlockCount++;
            
            _isEnabled = false;

            ForceUnRegister();
        }

        private void OnEndLoadScene(Component sender, object[] args)
        {
            BlockCount--;
        }

        public override bool Validate()
        {
            if (EscKeyDown)
            {
                _isEnabled = !_isEnabled;
            }
            
            return _isEnabled;
        }
    }
}