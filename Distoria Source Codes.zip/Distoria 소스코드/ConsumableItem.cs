using ProjectAAA.Core.Managers;
using ProjectAAA.UI.MainFight;
using ProjectAAA.Utils;
using ProjectAAA.Utils.DataTable;
using UnityEngine;

namespace ProjectAAA.Interaction.Items
{
    public class ConsumableItem : ItemBase
    {
        private void OnTriggerEnter(Collider target)
        {
            if (target.CompareTag(Global.PlayerTag))
            {
                Use(target.gameObject);
            }
        }

        public override void Use(GameObject target)
        {
            base.Use(target);
            
            if (target.TryGetComponent(out ItemHandler handler))
            {
                handler.InsertItem(this, false);
                
                UiManager.Instance.Get<MainFightUI>().ItemCollectUI.Add(RewardType.ConsumableItem, CachedBuilder.ItemID, ItemData.ItemName);
            }
        }

        public override void OnReset()
        {
            CachedBuilder.SelfReturn();
        }
    }
}