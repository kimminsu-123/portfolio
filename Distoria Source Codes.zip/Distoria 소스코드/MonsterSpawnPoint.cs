using System;
using System.Collections.Generic;
using System.Linq;
using ProjectAAA.Mob.Normal;
using ProjectAAA.SO;
using ProjectAAA.SO.Pool;
using ProjectAAA.Utils;
using ProjectAAA.Utils.DataTable;
using UnityEngine;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.Mob
{
    public class MonsterSpawnPoint : MonoBehaviour
    {
        [SerializeField] private MonsterStatDataTableSO statTable;
        [SerializeField] private MonsterSkillDataTableSO skillTable;
        
        [HideInInspector] public MonsterArea area;
        [HideInInspector] public ObjectPoolSO monsterPool;

        public void Initialize()
        {
            if (area != transform.parent.GetComponent<MonsterArea>())
            {
                Logger.LogError("MonsterSpawnPoint", $"SpawnPoint 에서 설정된 Area 와 실제 Area 가 다릅니다.");
            }
            
            Logger.Log("MonsterSpawnPoint", $"{name} Initialize", Color.green);
            
            MonsterBase monster = monsterPool.Get<MonsterBase>(transform);
            monster.SetOriginPool(monsterPool);
            monster.Stop();

            area.AddMonster(monster);
        }

        #region Debugging Code
        private IEnumerable<Mesh> _filterMeshes;        
        private IEnumerable<Mesh> _rendererMeshes;        

        private void OnDrawGizmos()
        {
            if (monsterPool != null)
            {
                Gizmos.color = Color.red;

                _filterMeshes ??= monsterPool.Prefab.GetComponentsInChildren<MeshFilter>(true)?.Select(x => x.mesh);
                _rendererMeshes ??= monsterPool.Prefab.GetComponentsInChildren<SkinnedMeshRenderer>(true)?.Select(x => x.sharedMesh);
                
                if (_filterMeshes != null)
                {
                    foreach (Mesh mesh in _filterMeshes)
                    {
                        if (mesh == null) continue;
                        
                        Quaternion offset = Quaternion.identity;
                        if (mesh.IsMeshLayingDown())
                        {
                            offset = Quaternion.Euler(-90f, 0f, 0f);
                        }
                        
                        Gizmos.DrawMesh(mesh, transform.position, transform.rotation * offset, transform.lossyScale);                
                    }
                }
                
                if (_rendererMeshes != null)
                {
                    foreach (Mesh mesh in _rendererMeshes)
                    {
                        if (mesh == null) continue;
                        
                        Quaternion offset = Quaternion.identity;
                        if (mesh.IsMeshLayingDown())
                        {
                            offset = Quaternion.Euler(-90f, 0f, 0f);
                        }
                        
                        Gizmos.DrawMesh(mesh, transform.position, transform.rotation * offset, transform.lossyScale);                
                    }
                }
            }
        }

        private void OnDrawGizmosSelected()
        {
            DrawMonsterRanges();
        }

        private void DrawMonsterRanges()
        {
            MonsterBase monster = monsterPool.Prefab.GetComponent<MonsterBase>();

            if (monster != null)
            {
                MonsterStatData stat = statTable.Get(monster.MonsterId);

                if (stat != null)
                {
                    Gizmos.color = Color.red;
                    Gizmos.DrawWireSphere(transform.position, stat.ChaseRadius);

                    Gizmos.color = Color.yellow;
                    Gizmos.DrawWireSphere(transform.position, stat.WanderRadius);
                }   
            }
        }
        #endregion
    }
}