using Newtonsoft.Json;
using ProjectAAA.Core;
using ProjectAAA.Core.Managers;
using ProjectAAA.Core.Scene.Manager;
using ProjectAAA.SO;
using ProjectAAA.Utils;
using ProjectAAA.Utils.DataTable;
using UnityEngine;

namespace ProjectAAA.Interaction.Items
{
    public abstract class ItemBase : MonoBehaviour, Iitem, IItemDropper
    {
        public ItemBuffComposite Buffs { get; private set; }
        public ItemBuilder CachedBuilder { get; private set; }
        public GameObject CachedTarget { get; private set; }
        public ItemData ItemData => DatabaseManager.Instance.GetTable<ItemTableSO>().GetItem(CachedBuilder.ItemID);

        protected ParticlePoolObj CachedParticle => _cachedParticle;

        private ItemBuffDataGroup ItemBuffGroup => DatabaseManager.Instance.GetTable<ItemBuffTableSO>().GetGroup(ItemData.EffectId);
        private Magnetic _magnetic;
        private ParticlePoolObj _cachedParticle;
        private Rigidbody _cachedRigidbody;
        private Collider _cachedCollider;

        public void Setup(ItemBuilder builder)
        {
            CachedBuilder = builder;
            
            Buffs = ItemBuffFactory.GetBuffs(ItemBuffGroup);
        }

        private void Awake()
        {
            _magnetic = GetComponentInChildren<Magnetic>(true);
            _cachedRigidbody = GetComponent<Rigidbody>();
            _cachedCollider = GetComponent<Collider>();
        }

        public void StartParticle()
        {
            StopParticle();
            
            _cachedParticle = ItemManager.Instance.GetParticleByGrade(ItemData.ItemGrade, transform);
            _cachedParticle?.Play(false, false, -1);
            
            OnGetParticle();
        }

        public void StopParticle()
        {
            _cachedParticle?.Stop();
            _cachedParticle?.SelfReturn();
            _cachedParticle = null;
        }
        
        public virtual void Active()
        {
            if (ItemData.MagnetReaction)
            {
                _magnetic?.Run();
            }
            _cachedCollider.enabled = true;
        }

        public virtual void InActive()
        {
            _magnetic?.Stop();
            _cachedCollider.enabled = false;
        }

        public virtual void Use(GameObject target)
        {
            CachedTarget = target;
            
            StopParticle();
            InActive();
        }

        public virtual void OnReset()
        {
            StartParticle();
            Active();
        }

        public void DropStart(bool useRigidbody)
        {
            InActive();
            StartParticle();

            _cachedRigidbody.isKinematic = !useRigidbody;
            if (useRigidbody)
            {
                _cachedRigidbody.AddForce(new Vector3(Random.Range(-1f, 1f), 1f, Random.Range(-1f, 1f)));
            }
        }

        public void ActiveItem()
        {
            Active();
        }

        public string Save()
        {
            SaveDataElement item = new SaveDataElement
            {
                SaveDataType = SaveElementType.Item,
                id = ItemData.ItemId,
                ItemType = ItemData.ItemType
            };
            
            return JsonConvert.SerializeObject(item);
        }

        public void Load(string json)
        {
            Use(PlayerManager.Instance.PlayerGo);
            PostLoadItem();
        }

        /// <summary>
        /// 각 아이템이 로드 될때 비활성화 등 해줘야하는 조치들을 구현해 주시면 됩니다.
        /// 실행할게 없다면 return 하시면 됩니다.
        /// </summary>
        protected virtual void PostLoadItem()
        {
        }

        protected virtual void OnGetParticle()
        {
            
        }

        public virtual void Hold(Transform parent)
        {
            gameObject.SetActive(false);
            transform.parent = parent;
            transform.localPosition = Vector3.zero;
            transform.localRotation = Quaternion.identity;
        }
    }
}