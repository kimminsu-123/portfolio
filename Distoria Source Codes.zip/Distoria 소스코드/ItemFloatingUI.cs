using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace ProjectAAA.UI
{
    public interface IItemFloatingModel
    {
        public Sprite Icon { get; }
        public string Name { get; }
        public string Type { get; }
        public string Desc { get; }
        public string Effect { get; }
        public Transform ParentTr { get; }
    }
    
    public class ItemFloatingUI : UiBase
    {
        protected override Type RegisterType => typeof(ItemFloatingUI);

        [SerializeField] private Image iconImg;
        [SerializeField] private TMP_Text nameText;
        [SerializeField] private TMP_Text typeText;
        [SerializeField] private TMP_Text descText;
        [SerializeField] private TMP_Text effectText;

        private IItemFloatingModel _model;
        private Transform _targetTr;

        private void Start()
        {
            Hide();
        }

        private void LateUpdate()
        {
            LookAt();
        }

        private void LookAt()
        {
            if (_targetTr !=null)
            {
                Vector3 vec = transform.position - _targetTr.position;
                Quaternion rot = Quaternion.LookRotation(vec);
                
                transform.rotation = rot;
            }
        }

        public void Setup(IItemFloatingModel model, Transform from, Transform to)
        {
            transform.position = from.position + model.ParentTr.localPosition;
            
            if (_model == model)
            {
                return;
            }
            
            _model = model;
            iconImg.sprite = model.Icon;
            nameText.text = model.Name;
            typeText.text = model.Type;
            descText.text = model.Desc;
            effectText.text = model.Effect;
            
            _targetTr = to;
            
            LayoutRebuilder.ForceRebuildLayoutImmediate(descText.rectTransform);
            LayoutRebuilder.ForceRebuildLayoutImmediate(effectText.rectTransform);
        }
        
        public override void Show()
        {
            LookAt();
            
            gameObject.SetActive(true);
        }

        public override void Hide()
        {
            gameObject.SetActive(false);
        }
    }
}