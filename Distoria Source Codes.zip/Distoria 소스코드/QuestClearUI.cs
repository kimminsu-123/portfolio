using System;
using DG.Tweening;
using ProjectAAA.Core.Managers;
using ProjectAAA.SO;
using TMPro;
using UnityEngine;

namespace ProjectAAA.UI
{
    public class QuestClearUI : UiBase
    {
        protected override Type RegisterType => typeof(QuestClearUI);

        [SerializeField] private TMP_Text clearText;
        [SerializeField] private FMODEventInfoSO sound;
        [SerializeField] private float duration = 0.8f;

        private Tweener _tweener;

        public override void Show()
        {
            gameObject.SetActive(true);
            
            SoundManager.Instance.PlaySFX(sound, Vector3.zero);
            
            _tweener?.Kill();
            _tweener = clearText
                .DOFade(1f, duration)
                .SetEase(Ease.OutCirc)
                .SetLoops(2, LoopType.Yoyo)
                .SetAutoKill(true)
                .OnComplete(Hide)
                .Play();
        }

        public override void Hide()
        {
            _tweener?.Kill();
            
            gameObject.SetActive(false);
        }
    }
}