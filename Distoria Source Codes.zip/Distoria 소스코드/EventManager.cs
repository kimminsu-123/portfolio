using System;
using System.Collections.Generic;
using ProjectAAA.Utils;
using UnityEngine;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.Core.Managers
{
    public enum EventType
    {
        PlayerClear,                            // 플레이어가 들고있는 무기 및 적용된 패시브, 액티브 아이템을 초기화하는 이벤트
        PlayerClearLastedSaveData,              // 마지막으로 저장된 플레이어의 세이브 데이터로 초기화하는 이벤트
        
        OnRestartGame,                          // 현재 씬을 다시 재시작하는 이벤트
        
        OnBeginLoadSceneGroup,                  // 씬 그룹 로딩이 시작될 때 호출되는 이벤트
        OnEndLoadSceneGroup,                    // 씬 그룹 로딩이 종료될 때 호출되는 이벤트
        OnEndDelayAfterLoadScene,               // 씬 그룹 로딩이 종료되고 나서 딜레이 이후 UI 가 꺼질 때 호출됨
        
        OnPlayerActive,                         // 씬이 로딩 되고 플레이어가 활성화 됐을 때
        OnPlayerDeActive,                       // 씬이 로딩 되고 플레이어가 비활성화 됐을 때
        
        OnStageClear,                           // 스테이지가 클리어 됐을 때
        OnPlayerDeath,                          // 플레이어가 죽을 때
        
        OnHaveFocus,
        OnLostFocus,
        OnKillMonster,
        
        OnGameClear,                            // 게임 클리어 했을 때 
    }
    
    public class EventManager : SingletonMonoBehavior<EventManager>
    {
        public delegate void OnEvent(Component sender, params object[] args);

        private readonly Dictionary<EventType, List<OnEvent>> _listeners = new();

        public void AddListener(EventType type, OnEvent callback)
        {
            if (!_listeners.ContainsKey(type))
            {
                _listeners.Add(type, new List<OnEvent>());
            }
            _listeners[type].Add(callback);
        }

        public void RemoveListener(EventType type, OnEvent callback)
        {
            if (_listeners.TryGetValue(type, out List<OnEvent> listener))
            {
                listener.Remove(callback);
            }
        }

        public void PostNotification(EventType type, Component sender, params object[] args)
        {
            if (_listeners.TryGetValue(type, out List<OnEvent> listeners))
            {
                try
                {
                    for (var index = listeners.Count - 1; index >= 0; index--)
                    {
                        var listener = listeners[index];
                        listener?.Invoke(sender, args);
                    }
                }
                catch (Exception e)
                {
                    Logger.LogError("Event Manager",$"{type}, {e.Message}\n{e.StackTrace}");
                }
            }
        }
    }
}