using System.Collections.Generic;
using ProjectAAA.Core.FSM;
using ProjectAAA.Utils;
using UnityEngine;

namespace ProjectAAA.Core.FSM
{
    public class StateNode
    {
        public IState State { get; }
        public HashSet<ITransition> Transitions { get; }

        public StateNode(IState state)
        {
            State = state;
            Transitions = new HashSet<ITransition>();
        }

        public void AddTransition(IState to, IPredicate condition)
        {
            Transitions.Add(new Transition(to, condition));
        }

        public void RemoveTransition(IState to)
        {
            Transitions.RemoveWhere(x => x.To.Equals(to));
        }
    }
}