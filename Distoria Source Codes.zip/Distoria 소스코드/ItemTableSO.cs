using System.Collections.Generic;
using Newtonsoft.Json;
using ProjectAAA.Utils.DataTable;
using UnityEngine;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.SO
{
    [CreateAssetMenu(fileName = "ItemTableSO", menuName = "Scriptable Objects/DataTable/ItemTableSO")]
    public class ItemTableSO : DataTableSO
    {
        private Dictionary<int, ItemData> _items;
        
        protected override void FromJson(string json)
        {
            List<ItemData> deserialized = JsonConvert.DeserializeObject<List<ItemData>>(json);
            
            Logger.Assert(deserialized != null, "ItemTable", "아이템 테이블이 비어있습니다.");

            _items = new Dictionary<int, ItemData>();
            foreach (ItemData item in deserialized)
            {
                _items.TryAdd(item.ItemId, item);
            }
        }
        
        public ItemData GetItem(int itemId) => _items.GetValueOrDefault(itemId);
    }
}