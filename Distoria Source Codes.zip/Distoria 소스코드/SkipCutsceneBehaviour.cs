using ProjectAAA.UI;
using UnityEngine;
using UnityEngine.Playables;

namespace ProjectAAA.Timeline
{
    public class SkipCutsceneBehaviour : PlayableBehaviour
    {
        /*
        OnBehaviourPause - 클립이 비활성화될 때 호출됩니다. 타임라인이 시작될 때, 클립의 재생 시간이 경과할 때, 또는 타임라인이 중지될 때 발생합니다.
        OnBehaviourPlay - 클립이 활성화될 때 호출됩니다. 클립이 첫 번째 프레임에 있더라도 타임라인이 시작될 때 Pause 호출이 먼저 실행될 수 있습니다.
        OnProcessFrame - 클립이 활성화된 모든 프레임에서 호출됩니다.
        OnGraphStart - 타임라인이 재생을 시작할 때 또는 첫 번째 평가 전에 호출됩니다.
        OnGraphStop - 타임라인 재생이 중지되면 호출됩니다.
    */
        public KeyCode SkipKeyCode;
        public SkipType SkipType;
        public float PressDuration;
        public string SkipHelpText;
        public PlayableDirector OwnerDirector;
        public double SkipTime;

        private SkipUI _skipUI;
        private bool _isSkipped;

        public override void OnBehaviourPlay(Playable playable, FrameData info)
        {
            _isSkipped = false;
        }

        public override void OnBehaviourPause(Playable playable, FrameData info)
        {
            if (_skipUI != null)
            {
                _skipUI.onCompleted.RemoveListener(OnComplete);
                _skipUI.helpText.text = string.Empty;
                _skipUI.Hide();

                _isSkipped = true;
            }
        }

        public override void ProcessFrame(Playable playable, FrameData info, object playerData)
        {
            if (_isSkipped) return;
            if (playerData == null) return;
            
            if (_skipUI == null)
            {
                _skipUI = playerData as SkipUI;
            }

            if (!_skipUI.IsShow)
            {
                _skipUI.onCompleted.AddListener(OnComplete);
                _skipUI.helpText.text = SkipHelpText;
                _skipUI.Show();
            }

            switch (SkipType)
            {
                case SkipType.Down:
                    HandleDown();
                    break;
                case SkipType.Press:
                    HandlePress();
                    break;
            }
        }

        private void HandleDown()
        {
            if (Input.GetKeyDown(SkipKeyCode))
            {
                _skipUI.pressDuration = 0f;
                _skipUI.Hold();
            }
        }

        private void HandlePress()
        {
            _skipUI.pressDuration = PressDuration;

            if (Input.GetKeyDown(SkipKeyCode))
            {
                _skipUI.Hold();
            }
            else if (Input.GetKeyUp(SkipKeyCode))
            {
                _skipUI.Release();
            }
        }

        private void OnComplete()
        {
            _skipUI.onCompleted.RemoveListener(OnComplete);
            _skipUI.Hide();

            OwnerDirector.time = SkipTime;

            _isSkipped = true;
        }
    }
}