using System;
using System.Collections.Generic;
using ProjectAAA.Quests;
using ProjectAAA.SO;
using ProjectAAA.SO.Quest;
using ProjectAAA.UI;
using ProjectAAA.UI.MainFight;
using ProjectAAA.Utils;
using ProjectAAA.Utils.DataTable;
using UniRx;
using UnityEngine;
using Logger = ProjectAAA.Utils.Logger;
using Random = UnityEngine.Random;

namespace ProjectAAA.Core.Managers
{
    public class QuestManager : SingletonMonoBehavior<QuestManager>
    {
        [SerializeField, TextArea] private string[] questDescriptions;
        
        public QuestBase CurrentQuest { get; private set; }

        private QuestTableSO QuestTable => DatabaseManager.Instance.GetTable<QuestTableSO>();
        private QuestCollectUI QuestCollectUI => UiManager.Instance.Get<MainFightUI>().QuestCollectUI;
        private QuestClearUI QuestClearUI => UiManager.Instance.Get<QuestClearUI>();
        private IDisposable _statusSubscription;
        private IDisposable _valueSubscription;

        private int[] _shuffledKeys;
        private int _curQuestIndex;
        private int _curDescIndex;

        private void Start()
        {
            EventManager.Instance.AddListener(EventType.OnBeginLoadSceneGroup, ResetQuestOnNextStage);
            EventManager.Instance.AddListener(EventType.PlayerClear, ResetQuestOnPlayerClear);
            EventManager.Instance.AddListener(EventType.OnRestartGame, ResetQuestOnPlayerClear);

            _shuffledKeys = new int[QuestTable.Count];
            QuestTable.Keys.CopyTo(_shuffledKeys);

            ShuffleQuests();
        }

        private void ShuffleQuests()
        {
            for (int i = 0; i < _shuffledKeys.Length * 100; i++)
            {
                int left = Random.Range(0, _shuffledKeys.Length);
                int right = Random.Range(0, _shuffledKeys.Length);
                
                (_shuffledKeys[left], _shuffledKeys[right]) = (_shuffledKeys[right], _shuffledKeys[left]);
            }

            _curQuestIndex = 0;
            _curDescIndex = 0;
        }

        private void ResetQuestOnNextStage(Component sender, object[] args)
        {
            SceneGroupSO cur = args[0] as SceneGroupSO;
            SceneGroupSO next = args[1] as SceneGroupSO;

            if (cur == null || next == null)
            {
                return;
            }

            if (cur.ContainsType(SceneType.Stage) && next.ContainsType(SceneType.Stage))
            {
                ResetQuest();
            }
        }
        
        private void ResetQuestOnPlayerClear(Component sender, object[] args)
        {
            ShuffleQuests();
            ResetQuest();
        }

        public void ResetQuest()
        {
            if (CurrentQuest != null)
            {
                CurrentQuest.Disable();
                _statusSubscription.Dispose();
                _valueSubscription.Dispose();
                CurrentQuest.Dispose();
            }
            CurrentQuest = null;
        }

        public void ClearCurrentQuest()
        {
            CurrentQuest?.Clear();
        }

        public void Next()
        {
            _curQuestIndex = (_curQuestIndex + 1) % _shuffledKeys.Length;
            _curDescIndex = Mathf.Min(_curDescIndex + 1, questDescriptions.Length - 1);
        }

        public void SetCurrent()
        {
            QuestData data = QuestTable.Get(_shuffledKeys[_curQuestIndex]);
            SetQuest(data);
        }

        public string GetCurrentDesc() => questDescriptions[_curDescIndex];
        
        public void SetQuest(QuestData data)
        {
            ResetQuest();

            CurrentQuest = MakeQuest(data);
            _statusSubscription = CurrentQuest.CurrentStatus.Subscribe(OnChangeStatus);
            _valueSubscription = CurrentQuest.CurrentValue.Subscribe(OnChangeValue);
            CurrentQuest.Enable();    
        }
        
        private void OnChangeStatus(QuestBase.Status status)
        {
            if (status == QuestBase.Status.Started)
            {
                string[] arr = CurrentQuest.MainFightMessage.Split("_");
                if (arr.Length != 2)
                {
                    Logger.LogError("QuestManager", $"UI 에 표시할 문자열이 형식에 맞지 않습니다 : {CurrentQuest.MainFightMessage}");
                    return;
                }
                QuestCollectUI.Add(arr[0], arr[1]);
            }
            else if (status == QuestBase.Status.Clear)
            {
                QuestClearUI.Show();
                QuestCollectUI.AnimationClear();
            }
        }

        private void OnChangeValue(int curValue)
        {
            string[] arr = CurrentQuest.MainFightMessage.Split("_");
            if (arr.Length != 2)
            {
                Logger.LogError("QuestManager", $"UI 에 표시할 문자열이 형식에 맞지 않습니다 : {CurrentQuest.MainFightMessage}");
                return;
            }
            QuestCollectUI.UpdateUI(arr[0], arr[1]);
        }

        private QuestBase MakeQuest(QuestData data)
        {
            switch (data.QuestType)
            {
                case QuestType.KillMonster:
                    return new KillMonsterQuest(data);
                case QuestType.GiveStatus:
                    Logger.LogError("QuestManager", $"아직 만들어지지 않은 퀘스트 타입입니다. (상태이상 부여)");
                    return null;
                default:
                    return null;
            }
        }
    }
}