using System;
using System.Linq;
using System.Threading.Tasks;
using Cysharp.Threading.Tasks;
using ProjectAAA.Core.Entity;
using ProjectAAA.Core.Scanner;
using ProjectAAA.Utils;
using ProjectAAA.Utils.DataTable;
using UnityEngine;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.WeaponSystem
{
    public class BulletRicochet : BulletHitAbility
    {
        public override bool IsDone => _currentCount <= 0;

        private readonly RicochetType _sourceType;
        private readonly int _sourceCount;
        private readonly OverlapBlockScanner _scanner;
        
        private int _currentCount;

        public BulletRicochet(BulletHitHandler handler, RicochetType type, int count, float radius) : base(handler)
        {
            _sourceType = type;
            _sourceCount = count;

            _currentCount = _sourceCount;

            if (type == RicochetType.NearedEnemy)
            {
                OverlapBlockScanner.OverlapBlockScannerConfig config = new OverlapBlockScanner.OverlapBlockScannerConfig
                    {
                        RangeLayerMask = Global.MonsterHurtBoxLayerMask,
                        RangeDetectCount = Mathf.RoundToInt(radius),
                        RangeRadius = radius,
                        RangeFilter = CheckCenter,

                        BlockLayerMask = Global.PlayerAttackBlockMask,
                    };
                _scanner = new OverlapBlockScanner(config);
            }
        }

        public override void Init()
        {
            _currentCount = _sourceCount;

            Next?.Init();
        }

        public override async UniTask OnHit(HitInfo info)
        {
            if (IsDone)
            {
                if (Next != null)
                {
                    await Next.OnHit(info);
                }
                return;
            }

            _currentCount--;

            switch (_sourceType)
            {
                case RicochetType.Reflect:
                    HandleReflect(info);
                    break;
                case RicochetType.NearedEnemy:
                    await HandleNearedEnemy(info);
                    break;
            }
        }

        private void HandleReflect(HitInfo info)
        {
            Vector3 direction = Handler.CurrentBullet.transform.forward;
            Vector3 reflect = Vector3.Reflect(direction, info.Normal);
            Handler.CurrentBullet.transform.forward = reflect;

            Handler.Shoot(info.Point);
        }

        private async UniTask HandleNearedEnemy(HitInfo info)
        {
            Collider[] result = await _scanner.ScanRange(info.Point);
            
            bool hasScan = false;
            for (int i = 0; i < result.Length && !hasScan; i++)
            {
                hasScan |= result[i] != null;
            }
            
            if (hasScan)
            {
                await ReflectToEnemy(info, result);
            }
            else
            {
                HandleReflect(info);
            }
        }

        private bool CheckCenter(Collider other)
        {
            bool ret = other.TryGetComponent(out HurtBox hurtBox);
            if (ret)
            {
                ret &= hurtBox.isCenter;
                ret &= Handler.LastedHitTarget != hurtBox.RootHash;
            }

            return ret;
        }

        private async UniTask ReflectToEnemy(HitInfo info, Collider[] result)
        {
            Collider[] copied = result.Where(x => x != null)
                .OrderBy(x => Vector3.Distance(info.Point, x.transform.position))
                .ToArray();
            
            RaycastHit[] hits = await _scanner.ScanBlocked(info.Point, copied);
            
            if (hits != null)
            {
                int len = Mathf.Min(hits.Length, copied.Length);
                for (int i = 0; i < len; i++)
                {
                    if (hits[i].collider == copied[i])
                    {
                        Vector3 direction = (hits[i].transform.position - info.Point).normalized;
                        Handler.CurrentBullet.transform.forward = direction;
                        Handler.Shoot(info.Point);
                        return;
                    }   
                }
                HandleReflect(info);
            }
            else
            {
                HandleReflect(info);
            }
        }
    }
}