using System;
using System.Collections.Generic;
using FMOD.Studio;
using FMODUnity;
using ProjectAAA.Core.Entity;
using ProjectAAA.Core.Managers;
using ProjectAAA.Core.Scene.Manager;
using ProjectAAA.Core.Timer;
using ProjectAAA.Interaction;
using ProjectAAA.Player;
using ProjectAAA.SO;
using ProjectAAA.SO.Pool;
using ProjectAAA.UI.MainFight;
using ProjectAAA.Utils;
using ProjectAAA.Utils.DataTable;
using UniRx;
using UnityEngine;
using UnityEngine.Animations.Rigging;
using UnityEngine.Events;
using EventManager = ProjectAAA.Core.Managers.EventManager;
using EventType = ProjectAAA.Core.Managers.EventType;
using STOP_MODE = FMOD.Studio.STOP_MODE;
using Util = ProjectAAA.Utils.Util;

namespace ProjectAAA.WeaponSystem
{
    public class WeaponHandler : MonoBehaviour
    {
        public ReactiveProperty<WeaponBase> CurrentWeapon
        {
            get
            {
                if (_currentWeapon == null)
                {
                    _currentWeapon = new ReactiveProperty<WeaponBase>(null);
                }
                return _currentWeapon;
            }
        }
        public UnityEvent onChangeAmmo;
        public UnityEvent onEndPortalInteract;
        
        public int DefaultWeaponId { get; private set; }
        public Transform AimPivot => aimPivot;

        private const string IK_PLAYER_PREFIX = "Bip001";
        private const string IK_LEFT_NAME = " L ";
        private const string IK_RIGHT_NAME = " R ";
        private const string IK_ROOT_SUFFIX = "UpperArm";
        private const string IK_MID_SUFFIX = "Forearm";
        private const string IK_TIP_SUFFIX = "Hand";

        [SerializeField] private Recoil recoilHolder; 
        [SerializeField] private Transform weaponHolder;
        [SerializeField] private ObjectPoolSO defaultWeaponPool;
        [SerializeField] private Transform aimPivot;

        [Header("Animations")] 
        [SerializeField] private AnimatorWrapper playerAnimator;
        [SerializeField] private RuntimeAnimatorController basicAnimatorController;

        [Header("IKs")] 
        [SerializeField] private RigBuilder rigBuilder;
        [SerializeField] private TwoBoneIKConstraint leftHandIK;
        [SerializeField] private TwoBoneIKConstraint rightHandIK;

        [Header("Inventory")] 
        [SerializeField] private InventoryDataBaseSO inventoryDataBase;

        private EventInstance _weaponHandlingSound;
        private ReactiveProperty<WeaponBase> _currentWeapon { get; set; }

        private CooldownTimer _pickUpTimer;
        private IDisposable _reloadEndDisposable;

        private bool _isReloading;
        private bool _isDropping;
        
        private void Awake()
        {
            _pickUpTimer = new CooldownTimer(0f);
        }
        
        private void Start()
        {
            EventManager.Instance.AddListener(EventType.PlayerClear, OnPlayerClear);
            EventManager.Instance.AddListener(EventType.OnPlayerActive, OnPlayerActive);
            FindIKTransforms();
            EquipDefaultWeapon();
        }

        private void OnPlayerActive(Component sender, object[] args)
        {
            recoilHolder.gameObject.SetActive(true);
            
            if (CurrentWeapon.Value == null)
            {
                EquipDefaultWeapon();
            }
        }

        private void FindIKTransforms()
        {
            leftHandIK.data.root = transform.FindInChildren($"{IK_PLAYER_PREFIX}{IK_LEFT_NAME}{IK_ROOT_SUFFIX}"); 
            leftHandIK.data.mid = transform.FindInChildren($"{IK_PLAYER_PREFIX}{IK_LEFT_NAME}{IK_MID_SUFFIX}");
            leftHandIK.data.tip = transform.FindInChildren($"{IK_PLAYER_PREFIX}{IK_LEFT_NAME}{IK_TIP_SUFFIX}");
            
            rightHandIK.data.root = transform.FindInChildren($"{IK_PLAYER_PREFIX}{IK_RIGHT_NAME}{IK_ROOT_SUFFIX}");
            rightHandIK.data.mid = transform.FindInChildren($"{IK_PLAYER_PREFIX}{IK_RIGHT_NAME}{IK_MID_SUFFIX}");
            rightHandIK.data.tip = transform.FindInChildren($"{IK_PLAYER_PREFIX}{IK_RIGHT_NAME}{IK_TIP_SUFFIX}");
        } 

        private void EquipDefaultWeapon()
        {
            WeaponBase weapon = defaultWeaponPool.Get<WeaponBase>(weaponHolder);
            weapon.SetOriginPool(defaultWeaponPool);
            weapon.Interact(gameObject);

            DefaultWeaponId = weapon.WeaponId;
        }

        private void OnPlayerClear(Component sender, object[] args)
        {
            DisarmWithInventory();
            inventoryDataBase.Clear();
        }

        private void OnEnable()
        {
            if (CurrentWeapon.Value)
            {
                playerAnimator.AddAnimator(CurrentWeapon.Value.ModelAnimator);
                playerAnimator.SetOverrideController(CurrentWeapon.Value.PlayerOverrideController);
                playerAnimator.Rebind();   
            }
        }

        private void OnDisable()
        {
            if (CurrentWeapon.Value)
            {
                playerAnimator.RemoveAnimator(CurrentWeapon.Value.ModelAnimator);
                playerAnimator.SetOverrideController(null);
                playerAnimator.Rebind();   
            }
            
            if (_isReloading)
            {
                CurrentWeapon.Value?.ForceStopReload();
            }
        }

        private void Update()
        {
            _pickUpTimer.Tick(Time.deltaTime);
        }

        public void Trigger()
        {
            if (CurrentWeapon.Value == null) return;
            if (_pickUpTimer.IsRunning) return;
            if (_isReloading) return;

            CurrentWeapon.Value.Trigger();
        }

        public void Release()
        {
            if (CurrentWeapon.Value == null) return;
            
            CurrentWeapon.Value.Release();
        }

        public void Reload()
        {
            if (CurrentWeapon.Value == null) return;
            if (_pickUpTimer.IsRunning) return;
            if (_isReloading) return;
            if (CurrentWeapon.Value.CurrentAmmo <= 0 && CurrentWeapon.Value.CurrentAmmo != Global.InfinityAmmo) return;

            CurrentWeapon.Value.Reload();
        }

        public void ChangeWeapon(WeaponBase newWeapon)
        {
            DisarmWithInventory();
            Equip(newWeapon);
        }

        public void DropWeapon()
        {
            Drop();
        }

        public void AddWeaponToInventory(WeaponBase newWeapon)
        {
            if (CurrentWeapon.Value != null)
            {
                UiManager.Instance.Get<MainFightUI>().ItemCollectUI.Add(RewardType.Weapon, newWeapon.WeaponId, newWeapon.Name);
            }
            inventoryDataBase.AddItem(newWeapon);
        }

        public int CurrentWeaponIndex()
        {
            return inventoryDataBase.GetItemIndexID(CurrentWeapon.Value);
        }
        
        private void Equip(WeaponBase newWeapon)
        {
            if (newWeapon != null)
            {
                newWeapon.gameObject.SetActive(true);

                recoilHolder.Setup(newWeapon.RecoilData, newWeapon.FireInterval);

                playerAnimator.SetBool(Global.PCAnimParamName.BIsFiring, false);
                _isReloading = false;

                newWeapon.onBeginFireCallback.AddListener(OnBeginFire);
                newWeapon.onFireCallback.AddListener(OnFire);
                newWeapon.onFireFailedWhenAmmoZeroCallback.AddListener(OnFireFailedWhenAmmoZero);
                newWeapon.onEndFireCallback.AddListener(OnEndFire);
                newWeapon.onBeginReloadCallback.AddListener(OnBeginReload);
                newWeapon.onEndReloadCallback.AddListener(OnEndReload);

                newWeapon.SetParent(weaponHolder);
                newWeapon.SetPosition(Vector3.zero, Space.Self);
                newWeapon.SetRotation(Quaternion.identity, Space.Self);

                playerAnimator.AddAnimator(newWeapon.ModelAnimator);
                playerAnimator.SetOverrideController(newWeapon.PlayerOverrideController);
                playerAnimator.CrossFade(Global.PCAnimParamName.StNmPickup, 0f, 0, 0f, 0f);

                SetupIK(newWeapon.LeftHandTarget, newWeapon.RightHandTarget);

                recoilHolder.RunRecoil();

                _pickUpTimer.SetTime(newWeapon.SwapTime);
                _pickUpTimer.Start();
            }

            CurrentWeapon.Value = newWeapon;
            
            onChangeAmmo?.Invoke();
        }

        private void SetupIK(Transform left, Transform right)
        {
            leftHandIK.data.target = left;
            leftHandIK.weight = 1f;

            rightHandIK.data.target = right;
            rightHandIK.weight = 1f;

            rigBuilder.Build();
        }

        private void DisarmWithDrop()
        {
            if (CurrentWeapon.Value != null)
            {
                inventoryDataBase.RemoveItem(CurrentWeapon.Value);

                playerAnimator.RemoveAnimator(CurrentWeapon.Value.ModelAnimator);
                playerAnimator.SetOverrideController(basicAnimatorController);
                CurrentWeapon.Value.gameObject.SetActive(true);
                CurrentWeapon.Value.onBeginFireCallback.RemoveListener(OnBeginFire);
                CurrentWeapon.Value.onFireCallback.RemoveListener(OnFire);
                CurrentWeapon.Value.onEndFireCallback.RemoveListener(OnEndFire);
                CurrentWeapon.Value.onFireFailedWhenAmmoZeroCallback.RemoveListener(OnFireFailedWhenAmmoZero);
                CurrentWeapon.Value.onBeginReloadCallback.RemoveListener(OnBeginReload);
                CurrentWeapon.Value.onEndReloadCallback.RemoveListener(OnEndReload);
                CurrentWeapon.Value.OnDropOff();
                CurrentWeapon.Value.SetParent(null);
            }
        }

        private void DisarmWithInventory()
        {
            if (_isDropping)
            {
                _isDropping = false;
                return;
            }

            if (CurrentWeapon.Value != null)
            {
                playerAnimator.RemoveAnimator(CurrentWeapon.Value.ModelAnimator);
                playerAnimator.SetOverrideController(basicAnimatorController);

                CurrentWeapon.Value.onBeginFireCallback.RemoveListener(OnBeginFire);
                CurrentWeapon.Value.onFireCallback.RemoveListener(OnFire);
                CurrentWeapon.Value.onEndFireCallback.RemoveListener(OnEndFire);
                CurrentWeapon.Value.onFireFailedWhenAmmoZeroCallback.RemoveListener(OnFireFailedWhenAmmoZero);
                CurrentWeapon.Value.onBeginReloadCallback.RemoveListener(OnBeginReload);
                CurrentWeapon.Value.onEndReloadCallback.RemoveListener(OnEndReload);
                CurrentWeapon.Value.OnDropOff();
                CurrentWeapon.Value.gameObject.SetActive(false);

                CurrentWeapon.Value = null;
            }
        }

        private void Drop()
        {
            if (CurrentWeapon.Value == null) return;
            if (!inventoryDataBase.GetItems().Contains(CurrentWeapon.Value)) return;

            int weaponIdx = inventoryDataBase.GetItemIndexID(CurrentWeapon.Value);
            if (weaponIdx <= 0) return;

            DisarmWithDrop();

            weaponIdx -= 1;
            WeaponBase weaponBase = inventoryDataBase.SelectItem(weaponIdx) as WeaponBase;
            if (weaponBase != null)
            {
                _isDropping = true;
                weaponBase.Use(gameObject);
            }
        }

        private void OnBeginFire()
        {
            if (_isReloading) return;
            
            leftHandIK.weight = 1f;
            rightHandIK.weight = 1f;
            
            playerAnimator.SetBool(Global.PCAnimParamName.BIsFiring, true);
            playerAnimator.CrossFade(Global.PCAnimParamName.StNmFire, 0f, 0, 0f, 0f, false);
        }

        private void OnFire()
        {
            recoilHolder.SetFireRate(CurrentWeapon.Value.FireInterval);
            recoilHolder.RunRecoil();
            recoilHolder.Trigger();
        }

        private void OnFireFailedWhenAmmoZero()
        {
            Reload();
        }

        private void OnEndFire()
        {
            playerAnimator.SetBool(Global.PCAnimParamName.BIsFiring, false);
        }

        private void OnBeginReload()
        {
            _reloadEndDisposable?.Dispose();
            _isReloading = true;

            //if (CurrentWeapon.Value.AmmoAmount == Global.InfinityAmmo) return;
            
            recoilHolder.StopRecoil();
            recoilHolder.ResetRecoil();

            leftHandIK.weight = 0f;
            rightHandIK.weight = 0f;
            
            playerAnimator.SetBool(Global.PCAnimParamName.BIsFiring, false);
            playerAnimator.CrossFade(Global.PCAnimParamName.StNmReload, 0f, 0, 0f, 0f, true, 1f / WeaponAlterStat.Instance.ReloadTime);
        }

        private void OnEndReload()
        {
            _isReloading = false;

            onChangeAmmo?.Invoke();
        }

        public void OnEndReloadAnimation()
        {
            // 나중에 GC 이슈 생기면 캐시 필수!
            _reloadEndDisposable?.Dispose();
            _reloadEndDisposable = Observable.EveryUpdate()
                .Where(_ => !Util.ApproximatelyFloats(rightHandIK.weight, 1f) ||
                            !Util.ApproximatelyFloats(leftHandIK.weight, 1f))
                .Subscribe(_ =>
                {
                    OnEndReload();
                    recoilHolder.RunRecoil();

                    leftHandIK.weight = 1f;
                    rightHandIK.weight = 1f;
                });
        }

        public void FillCurrentWeaponAmmo(float percent)
        {
            CurrentWeapon.Value?.FillAmmo(percent);

            onChangeAmmo?.Invoke();
        }

        public void FillAllAmmo(float percent)
        { 
            List<Iitem> items = inventoryDataBase.GetItems();
            foreach (Iitem item in items)
            {
                WeaponBase weapon = item as WeaponBase;
                if (weapon != null)
                {
                    weapon.FillAmmo(percent);
                }
            }

            onChangeAmmo?.Invoke();
        }

        public void ResizeMagazine(int amount)
        {
            List<Iitem> items = inventoryDataBase.GetItems();
            foreach (Iitem item in items)
            {
                WeaponBase weapon = item as WeaponBase;
                if (weapon != null)
                {
                    weapon.CurrentMagazine.Fill(weapon.CurrentMagazine.Count + amount);
                }
            }
            
            onChangeAmmo?.Invoke();
        }

        public void PlayHandlingSound(FMODEventInfoSO soundInfoSO)
        {
            if (_weaponHandlingSound.isValid())
            {
                _weaponHandlingSound.stop(STOP_MODE.IMMEDIATE);
                _weaponHandlingSound.release();
            }
            _weaponHandlingSound = RuntimeManager.CreateInstance(soundInfoSO.eventGuid);
            _weaponHandlingSound.start();
        }

        public void EndInteractPortal()
        {
            playerAnimator.SetBool(Global.PCAnimParamName.BIsInteractPortal, false);
            onEndPortalInteract?.Invoke();
        }

        public void SetIKWeight(float weight)
        {
            _reloadEndDisposable?.Dispose();
            leftHandIK.weight = weight;
            rightHandIK.weight = weight;
        }
    }
}