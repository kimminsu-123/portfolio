using UnityEngine;

namespace ProjectAAA.Utils
{
    public interface IDownload
    {
        public Awaitable LoadAsync();
    }
}