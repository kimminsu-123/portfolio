using System;
using ProjectAAA.Core.Managers;
using ProjectAAA.Interaction;
using ProjectAAA.SO;
using ProjectAAA.UI.Statue;
using ProjectAAA.Utils;
using UnityEngine;

namespace ProjectAAA.Interactables.Statue
{
    public abstract class StoneStatue : MonoBehaviour, IInteractable
    {
        public float InteractDuration => interactDuration;
        
        [Header("상호작용 속성")]
        [SerializeField] private float interactDuration = 0.5f;
        [SerializeField, Range(1, 20)] private int interactCount = 1;
        [SerializeField] private GameObject model;

        [Header("UI 속성")]
        [SerializeField] private string uiTitle;
        [SerializeField, TextArea] private string uiDescription;
        [SerializeField, TextArea] private string uiEffectDescription;
        [SerializeField] private string uiAcceptText;
        [SerializeField] private string uiDenyText;

        [Header("사운드")] 
        [SerializeField] private FMODEventInfoSO showSound;
        [SerializeField] private FMODEventInfoSO confirmSound;
        [SerializeField] private FMODEventInfoSO cancelSound;

        protected StatueUI StatueUI => UiManager.Instance.Get<StatueUI>();
        protected GameObject CachedGo { get; private set; }
        protected int CurInteractCount { get; private set; }
        protected Collider InteractionCollider { get; private set; }
        protected Camera CachedCamera { get; private set; }

        /// <summary>
        /// 석상 긍정적 선택에 조건을 UI 로 표시할 수 있는 UI 입니다.
        /// </summary>
        protected abstract StatueConditionUI ConditionUI { get; }
        
        /// <summary>
        /// 긍정적 선택 활성화 조건입니다.
        /// </summary>
        protected abstract IPredicate AcceptCondition { get; }
        
        /// <summary>
        /// 부정적 선택 활성화 조건입니다.
        /// </summary>
        protected abstract IPredicate DenyCondition { get; }
        
        protected virtual void Awake()
        {
            InteractionCollider = GetComponent<Collider>();
            CachedCamera = GetComponentInChildren<Camera>(true);
        }

        protected virtual void OnEnable()
        {
            if (CachedCamera != null)
            {
                CachedCamera.gameObject.SetActive(false);
            }

            if (model != null)
            {
                model.ChangeLayerAll(Global.OutlineLayerIndex);
            }
            
            CurInteractCount = 0;
            InteractionCollider.enabled = true;
        }

        public void Interact(GameObject target)
        {
            if (CachedCamera != null)
            {
                CachedCamera.gameObject.SetActive(true);
            }
            
            CachedGo = target;
            StatueUI.SetTitle(uiTitle)
                    .SetDescription(uiDescription)
                    .SetEffectDescription(uiEffectDescription)
                    .SetAcceptText(uiAcceptText)
                    .SetDenyText(uiDenyText)
                    .AddOnAccept(Accept)
                    .AddOnDeny(Deny)
                    .SetAcceptCondition(AcceptCondition)
                    .SetDenyCondition(DenyCondition)
                    .SetConditionUI(ConditionUI)
                    .Show();
            
            if (model != null)
            {
                model.ChangeLayerAll(Global.WallLayerIndex);
            }
            SoundManager.Instance.PlaySFX(showSound, transform.position);
            OnInteract();
        }

        private void Accept()
        {   
            if (CachedCamera != null)
            {
                CachedCamera.gameObject.SetActive(false);
            }
            
            SoundManager.Instance.PlaySFX(confirmSound, transform.position);
            OnAccept();
            
            StatueUI?.RemoveOnAccept(Accept)
                    ?.RemoveOnDeny(Deny);

            if (++CurInteractCount >= interactCount)
            {
                if (model != null)
                {
                    model.ChangeLayerAll(Global.WallLayerIndex);
                }
                InteractionCollider.enabled = false;
            }
            else
            {
                model.ChangeLayerAll(Global.OutlineLayerIndex);
            }
        }

        private void Deny()
        {
            if (CachedCamera != null)
            {
                CachedCamera.gameObject.SetActive(false);
            }
            
            SoundManager.Instance.PlaySFX(cancelSound, transform.position);
            OnDeny();

            StatueUI?.RemoveOnAccept(Accept)
                    ?.RemoveOnDeny(Deny);
            
            if (model != null)
            {
                model.ChangeLayerAll(Global.OutlineLayerIndex);
            }
        }

        private void OnDisable()
        {
            if (CachedCamera != null)
            {
                CachedCamera.gameObject.SetActive(false);
            }
            
            StatueUI?.RemoveOnAccept(Accept)
                    ?.RemoveOnDeny(Deny);   
        }

        protected virtual void OnInteract()
        {
        }

        /// <summary>
        /// 긍정적 선택지를 클릭한 경우입니다.
        /// 각 석상 로직에서 긍정 선택에 대한 로직을 넣어주시면 됩니다.
        /// </summary>
        protected abstract void OnAccept();
        
        /// <summary>
        /// 부정적 선택지를 클릭한 경우입니다.
        /// 각 석상 로직에서 부정 선택에 대한 로직을 넣어주시면 됩니다.
        /// </summary>
        protected abstract void OnDeny();
    }
}