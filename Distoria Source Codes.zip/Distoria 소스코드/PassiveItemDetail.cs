using System;
using ProjectAAA.Utils.DataTable;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace ProjectAAA.UI
{
    public class PassiveItemDetail : UiBase
    {
        protected override Type RegisterType => typeof(PassiveItemDetail);
        
        [SerializeField] private Vector2 offset = new Vector2(20f, -20f);
        [SerializeField] private Image itemImage;
        [SerializeField] private TMP_Text nameText;
        [SerializeField] private TMP_Text gradeText;
        [SerializeField] private TMP_Text descriptionText;
        [SerializeField] private CanvasScaler parentCanvasScaler;

        private void Start()
        {
            Hide();
        }

        public override void Hide()
        {
            gameObject.SetActive(false);
        }
        
        public override void Show()
        {
            gameObject.SetActive(true);
        }

        public void SetIcon(Sprite icon)
        {
            itemImage.sprite = icon;
        }
        
        public void SetName(string itemName)
        {
            nameText.text = itemName;
        }

        public void SetGrade(ItemGrade grade)
        {
            gradeText.text = $"{grade}";
        }

        public void SetDescription(string description)
        {
            descriptionText.text = description;
        }
        
        public void Move(Vector2 eventDataPosition)
        {
            RectTransform rectTr = transform as RectTransform;

            float ratioX = parentCanvasScaler.referenceResolution.x / Screen.width;
            float ratioY = parentCanvasScaler.referenceResolution.y / Screen.height;

            float xMax = Screen.width - rectTr.sizeDelta.x;
            float yMin = rectTr.sizeDelta.y;

            Vector2 pos = eventDataPosition + offset;
            pos.x = Mathf.Clamp(pos.x * ratioX, 0f, xMax * ratioX);
            pos.y = Mathf.Clamp(pos.y * ratioY, yMin, Screen.height * ratioY);
            rectTr.anchoredPosition = pos;
        }
    }
}