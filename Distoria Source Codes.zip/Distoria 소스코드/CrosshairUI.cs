using System;
using ProjectAAA.SO;
using ProjectAAA.Utils;
using UnityEngine;
using UnityEngine.UI;

namespace ProjectAAA.UI
{
    public class CrosshairUI : UiBase
    {
        protected override Type RegisterType => typeof(CrosshairUI);
        
        [SerializeField] private RectTransform parentCanvas;

        [Header("원형 스프레드 이미지 (쉐이더 사용)")] [SerializeField]
        private Image circleImg;

        [Header("사각형 스프레드 RectTransform")] [SerializeField]
        private RectTransform rectTr;

        [Header("직선 스프레드 RectTransform (최 상위 객체)")] [SerializeField]
        private RectTransform lineTr;

        [Header("수평 스프레드 Left, Right")] [SerializeField]
        private RectTransform lineLeftTr;

        [SerializeField] private RectTransform lineRightTr;

        [Header("수직 스프레드 Top, Bottom")] [SerializeField]
        private RectTransform lineTopTr;

        [SerializeField] private RectTransform lineBottomTr;

        private BaseSpreadDataSO _spreadData;
        private Camera _mainCamera;
        
        private static readonly int RingSize = Shader.PropertyToID("_RingSize");

        protected override void OnAwake()
        {
            DisableCrosshair();
        }

        private void Start()
        {
            _mainCamera = Camera.main;

            circleImg.material = circleImg.material.CopyMaterial();
        }

        private void Update()
        {
            UpdateSpread();
        }

        private void UpdateSpread()
        {
            if (_spreadData == null) return;
            if (_mainCamera == null)
            {
                _mainCamera = Camera.main;
                return;
            }

            Vector2 halfScale = _spreadData.HalfScale;

            Vector3 center = _mainCamera.transform.position + _mainCamera.transform.forward;
            Vector3 edgeUp = center + _mainCamera.transform.up * halfScale.y;
            Vector3 edgeRight = center + _mainCamera.transform.right * halfScale.x;

            Vector3 centerViewport = _mainCamera.WorldToViewportPoint(center);
            Vector3 edgeUpViewport = _mainCamera.WorldToViewportPoint(edgeUp);
            Vector3 edgeRightViewport = _mainCamera.WorldToViewportPoint(edgeRight);

            switch (_spreadData.Type)
            {
                case BaseSpreadDataSO.SpreadType.Circle:
                    HandleTypeCircle(centerViewport, edgeRightViewport);
                    break;
                case BaseSpreadDataSO.SpreadType.Rect:
                    HandleTypeRect(centerViewport, edgeRightViewport, edgeUpViewport);
                    break;
                case BaseSpreadDataSO.SpreadType.Line:
                    HandleTypeLine(centerViewport, edgeRightViewport, edgeUpViewport);
                    break;
            }
        }

        private void DisableCrosshair()
        {
            if (_spreadData != null) return;
            
            circleImg.gameObject.SetActive(false);
            rectTr.gameObject.SetActive(false);
            lineTr.gameObject.SetActive(false);
            lineTopTr.gameObject.SetActive(false);
            lineBottomTr.gameObject.SetActive(false);
            lineLeftTr.gameObject.SetActive(false);
            lineRightTr.gameObject.SetActive(false);
        }

        private void HandleTypeCircle(Vector3 centerViewport, Vector3 edgeRightViewport)
        {
            float radius = Vector2.Distance(centerViewport, edgeRightViewport);
            circleImg.material.SetFloat(RingSize, radius);
        }

        private void HandleTypeRect(Vector3 centerViewport, Vector3 edgeRightViewport, Vector3 edgeUpViewport)
        {
            float viewportHeight = Vector2.Distance(centerViewport, edgeUpViewport);
            float viewportWidth = Vector2.Distance(centerViewport, edgeRightViewport);
            float pixelHeight = viewportHeight * parentCanvas.sizeDelta.y;
            float pixelWidth = viewportWidth * parentCanvas.sizeDelta.x;

            rectTr.sizeDelta = Vector2.up * (pixelHeight * 2f) + Vector2.right * (pixelWidth * 2f);
        }

        private void HandleTypeLine(Vector3 centerViewport, Vector3 edgeRightViewport, Vector3 edgeUpViewport)
        {
            float viewportHeight = Vector2.Distance(centerViewport, edgeUpViewport);
            float viewportWidth = Vector2.Distance(centerViewport, edgeRightViewport);
            float pixelHeight = viewportHeight * parentCanvas.sizeDelta.y;
            float pixelWidth = viewportWidth * parentCanvas.sizeDelta.x;

            Vector2 heightUp = Vector2.up * (pixelHeight * 2f);
            Vector2 heightRight = Vector2.right * (pixelHeight * 2f);
            Vector2 widthUp = Vector2.up * (pixelWidth * 2f);
            Vector2 widthRight = Vector2.right * (pixelWidth * 2f);

            lineTr.sizeDelta = heightUp + widthRight;
            lineLeftTr.sizeDelta = heightUp + heightRight;
            lineRightTr.sizeDelta = heightUp + heightRight;
            lineTopTr.sizeDelta = widthUp + widthRight;
            lineBottomTr.sizeDelta = widthUp + widthRight;
        }

        public void ChangeSpreadData(BaseSpreadDataSO data)
        {
            _spreadData = data;

            UpdateSpread();
            
            if (_spreadData != null)
            {
                circleImg.gameObject.SetActive(data.Type == BaseSpreadDataSO.SpreadType.Circle);
                rectTr.gameObject.SetActive(data.Type == BaseSpreadDataSO.SpreadType.Rect);
                
                LineSpreadDataSO lineData = _spreadData as LineSpreadDataSO;
                if (lineData != null)
                {
                    lineTr.gameObject.SetActive(true);
                    lineTopTr.gameObject.SetActive(lineData.LineTp == LineSpreadDataSO.LineType.Vertical);
                    lineBottomTr.gameObject.SetActive(lineData.LineTp == LineSpreadDataSO.LineType.Vertical);
                    lineLeftTr.gameObject.SetActive(lineData.LineTp == LineSpreadDataSO.LineType.Horizontal);
                    lineRightTr.gameObject.SetActive(lineData.LineTp == LineSpreadDataSO.LineType.Horizontal);
                }
                else
                {
                    lineTr.gameObject.SetActive(false);
                    lineTopTr.gameObject.SetActive(false);
                    lineBottomTr.gameObject.SetActive(false);
                    lineLeftTr.gameObject.SetActive(false);
                    lineRightTr.gameObject.SetActive(false);
                }
            }
            
            LayoutRebuilder.ForceRebuildLayoutImmediate(parentCanvas);
        }
    }
}