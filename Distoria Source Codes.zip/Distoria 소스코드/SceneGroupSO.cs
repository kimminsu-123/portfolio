using FMODUnity;
using UnityEngine;
using ProjectAAA.Utils;
using SceneReference = ProjectAAA.Utils.SceneReference;

namespace ProjectAAA.SO
{
    [CreateAssetMenu(fileName = "SceneGroupSO", menuName = "Scriptable Objects/SceneGroupSO")]
    public class SceneGroupSO : BaseSO
    {
        [field:SerializeField] public SceneProfile[] SceneProfiles { get; private set; }
        [field:SerializeField] public FMODEventInfoSO BGMSoundInfo { get; private set; }
        [field:SerializeField] public ShaderVariantCollection ShaderVariantCollection { get; private set; }

        public int Count => SceneProfiles.Length;

        public bool ContainsType(SceneType type)
        {
            bool ret = false;
            for (int i = 0; i < Count; i++)
            {
                if (SceneProfiles[i].Type == type)
                {
                    ret = true;
                    break;
                }
            }
            return ret;
        }

        public bool ContainsByName(string sceneName)
        {
            bool ret = false;
            for (int i = 0; i < Count; i++)
            {
                if (SceneProfiles[i].SceneRef.SceneName.ToUpper().Contains(sceneName.ToUpper()))
                {
                    ret = true;
                    break;
                }
            }
            return ret;
        }

        public bool Contains(SceneReference sceneRef)
        {
            bool ret = false;
            for (int i = 0; i < Count; i++)
            {
                if (SceneProfiles[i].SceneRef.Equals(sceneRef))
                {
                    ret = true;
                    break;
                }
            }
            return ret;
        }
    }
}