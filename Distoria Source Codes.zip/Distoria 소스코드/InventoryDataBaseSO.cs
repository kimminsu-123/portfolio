using System.Collections.Generic;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using ProjectAAA.Core.Managers;
using ProjectAAA.Core.Scene.Manager;
using ProjectAAA.Interaction;
using ProjectAAA.Interaction.Items;
using ProjectAAA.Utils;
using ProjectAAA.Utils.DataTable;
using ProjectAAA.WeaponSystem;
using UnityEngine;
using Logger = ProjectAAA.Utils.Logger;


namespace ProjectAAA.SO
{
    public class InventoryDataBaseSO : BaseSO, ISaveDataContainer
    {
        [SerializeField] private string _fileName;
        private List<Iitem> _items = new List<Iitem>();
        
        public void AddItem(Iitem item)
        {
            _items.Add(item);
        }

        public void RemoveItem(Iitem item)
        {
            _items.Remove(item);
        }

        public List<Iitem> GetItems()
        {
            return _items;
        }

        public Iitem SelectItem(int selectId)
        {
            return _items[selectId];
        }

        public int GetItemIndexID(Iitem item)
        {
            return _items.IndexOf(item);
        }

        public bool Contains(Iitem item)
        {
            return _items.Contains(item);
        }

        public void ResetInventory()
        {
            foreach (Iitem item in _items)
            {
                item.OnReset();
            }
            _items.Clear();
        }

        public string Save()
        {
            JArray arr = new JArray();
            foreach (Iitem item in _items)
            {
                var s = item.Save();
                if (string.IsNullOrWhiteSpace(s)) continue;

                arr.Add(JObject.Parse(s));
            }

            return arr.ToString(Formatting.None);
        }

        public void Load(string json)
        {
            List<SaveDataElement> datas = JsonConvert.DeserializeObject<List<SaveDataElement>>(json);
            if (datas == null) return;
            
            ResetInventory();
            foreach (SaveDataElement data in datas)
            {
                switch (data.SaveDataType)
                {
                    case SaveElementType.Item:
                        ItemBase item = ItemManager.Instance.Generator.GetValue(data.id, null).Reference;
                        item.Load(JsonConvert.SerializeObject(data));
                        break;
                    case SaveElementType.Weapon:
                        WeaponBase weapon = WeaponManager.Instance.WeaponGenerator.GetValue(data.id, null);
                        weapon.Load(JsonConvert.SerializeObject(data));
                        break;
                }
            }
        }

        public void Clear()
        {
            ResetInventory();
        }

        public string FileName => _fileName;
    }
}