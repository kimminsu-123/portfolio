using System.Collections.Generic;
using Newtonsoft.Json;
using ProjectAAA.Utils.DataTable;
using UnityEngine;

namespace ProjectAAA.SO.Debug.Item
{
    [CreateAssetMenu(fileName = "ItemDebugDataGroup", menuName = "Scriptable Objects/DataTable/Debug/Item")]
    public class ItemDebugDataGroup : DebugDataGroup
    {
        [SerializeField] private List<ItemData> items;
        
        protected override void FromJson(string json)
        {
            items.Clear();
            items = JsonConvert.DeserializeObject<List<ItemData>>(json);
        }

        public override string ToJson()
        {
            return JsonConvert.SerializeObject(items);
        }
    }
}