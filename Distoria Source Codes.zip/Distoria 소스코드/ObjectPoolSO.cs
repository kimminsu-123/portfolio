using System;
using System.Collections.Generic;
using System.Linq;
using ProjectAAA.Core.Pool;
using UnityEngine;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.SO.Pool
{
    [CreateAssetMenu(fileName = "ObjectPoolSO", menuName = "Scriptable Objects/ObjectPoolSO", order = 0)]
    public class ObjectPoolSO : BaseSO
    {
        public bool IsEmpty => _poolQueue.Count <= 0;
        public GameObject Prefab => originPrefab;
        
        [SerializeField] private GameObject originPrefab;
        [SerializeField] private int defaultSize;
        [SerializeField] private int addSize;
        
        private readonly Queue<IPoolObj> _poolQueue = new();

        private Transform _defaultParent;

        public void SetupPool(Transform parent)
        {
            _defaultParent = parent;
            ExpendPool(defaultSize);
        }

        public void ExpendPool(int size)
        {
            for (int i = 0; i < size; i++)
            {
                GameObject instance = Instantiate(originPrefab, _defaultParent);
                instance.transform.localPosition = Vector3.zero;
                instance.transform.localRotation = Quaternion.identity;
                instance.SetActive(false);
                
                _poolQueue.Enqueue(instance.GetComponent<IPoolObj>());
            }   
        }
        
        public T Get<T>(Transform parent) where T : class, IPoolObj
        {
            if (IsEmpty)
            {
                ExpendPool(addSize);
            }

            IPoolObj obj = _poolQueue.Dequeue();
            obj.SetParent(parent);
            obj.SetPosition(Vector3.zero, Space.Self);
            obj.SetRotation(Quaternion.identity, Space.Self);
            obj.Active();
            obj.OnGet();

            return obj as T;
        }
        
        public T GetSafe<T>(Transform parent) where T : class, IPoolObj
        {
            IPoolObj obj = null;

            while (_poolQueue.Count > 0)
            {
                obj = _poolQueue.Dequeue();
        
                if (obj is MonoBehaviour mono)
                {
                    if (mono != null && mono.gameObject != null)
                    {
                        break;
                    }
                }

                obj = null;
            }

            if (obj == null)
            {
                ExpendPool(addSize);
                obj = _poolQueue.Dequeue();
            }

            obj.SetParent(parent);
            obj.SetPosition(Vector3.zero, Space.Self);
            obj.SetRotation(Quaternion.identity, Space.Self);
            obj.Active();
            obj.OnGet();

            return obj as T;
        }

        public List<T> ToList<T>() where T : class, IPoolObj => _poolQueue.Select(x => x as T).ToList();

        public void ReturnQueue(IPoolObj obj)
        {
            obj.OnRelease();
            
            obj.SetParent(_defaultParent);
            obj.SetPosition(Vector3.zero, Space.Self);
            obj.SetRotation(Quaternion.identity, Space.Self);
            obj.Inactive();

            _poolQueue.Enqueue(obj);
        }

        public void Clear()
        {
            while (_poolQueue.Count > 0)
            {
                IPoolObj obj = _poolQueue.Dequeue();
                if (obj is MonoBehaviour mono)
                {
                    try
                    {
                        Destroy(mono.gameObject);
                    }
                    catch (Exception)
                    {
                        // ignored
                    }
                }
            }
            _poolQueue.Clear();
        }
    }
}