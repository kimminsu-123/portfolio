using TMPro;
using UniRx;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.UI.Shop
{
    public enum SlotType
    {
        None,
        Normal,
        NoGold,
        NoCount,
    }
    
    public class ProductSlotUI : MonoBehaviour, IPointerEnterHandler, IPointerMoveHandler, IPointerExitHandler, IPointerDownHandler, IPointerUpHandler
    {
        [SerializeField] private Image iconImg;
        [SerializeField] private Image blockImg;
        [SerializeField] private TMP_Text costText;
        
        public UnityEvent<ProductRow> onClick;
        public UnityEvent<ProductRow, PointerEventData> onPointerEnter;
        public UnityEvent<ProductRow, PointerEventData> onPointerMove;
        public UnityEvent<ProductRow, PointerEventData> onPointerExit;

        private ReactiveProperty<ProductRow> CachedRowData
        {
            get
            {
                if (_cachedRowData == null)
                {
                    _cachedRowData = new ReactiveProperty<ProductRow>();
                    _cachedRowData.Subscribe(UpdateCurrentType);
                    _cachedRowData.Subscribe(UpdateIcon);
                    _cachedRowData.Subscribe(UpdateCost);
                    _cachedRowData.Subscribe(UpdateBlock);
                    _cachedRowData.Subscribe(UpdateButton);
                }
                return _cachedRowData;
            }
        }

        private ReactiveProperty<ProductRow> _cachedRowData;
        private Button _cachedButton;
        private SlotType _curSlotType;
        private Animator _animator;

        private void Awake()
        {
            _cachedButton = GetComponent<Button>();
            _cachedButton.onClick.AddListener(OnClick);
            
            _animator = GetComponent<Animator>();
        }

        public void Setup(ProductRow rowData)
        {
            _animator.Rebind();
            _animator.Update(0);
            CachedRowData.Value = rowData;
            
            UpdateSlot();
        }

        public void UpdateSlot()
        {
            CachedRowData.SetValueAndForceNotify(CachedRowData.Value);
        }

        private void UpdateCurrentType(ProductRow data)
        {
            if (data == null)
            {
                _curSlotType = SlotType.None;
            }
            else if (data.RemainSellCount <= 0)
            {
                _curSlotType = SlotType.NoCount;
            }
            else if (data.Cost > PlayerCurrencyManager.Instance.Gold.Value)
            {
                _curSlotType = SlotType.NoGold;
            }
            else
            {
                _curSlotType = SlotType.Normal;
            }
            
            _animator.SetBool("NonItem", _curSlotType == SlotType.NoCount);
        }

        private void UpdateIcon(ProductRow data)
        {
            if (iconImg == null)
            {
                return;
            }
            
            iconImg.gameObject.SetActive(_curSlotType != SlotType.None);
            iconImg.sprite = data?.Icon;
        }

        private void UpdateCost(ProductRow data)
        {
            if (costText == null)
            {
                return;
            }
            
            costText.gameObject.SetActive(_curSlotType != SlotType.None);
            costText.text = data == null ? "0" : $"{data.Cost}";
        }
        
        private void UpdateBlock(ProductRow data)
        {
            if (blockImg != null)
            {
                blockImg.gameObject.SetActive(_curSlotType == SlotType.NoCount);
            }
        }
        
        private void UpdateButton(ProductRow data)
        {
            _cachedButton.interactable = _curSlotType == SlotType.Normal;
        }
        
        public void OnPointerEnter(PointerEventData eventData)
        {
            onPointerEnter?.Invoke(CachedRowData.Value, eventData);
            
            _animator.SetBool("IsHover", true);
        }

        public void OnPointerMove(PointerEventData eventData)
        {
            onPointerMove?.Invoke(CachedRowData.Value, eventData);
        }

        public void OnPointerExit(PointerEventData eventData)
        {
            onPointerExit?.Invoke(CachedRowData.Value, eventData);
            
            _animator.SetBool("IsHover", false);
        }

        public void OnPointerDown(PointerEventData eventData)
        {
            if (_cachedButton.interactable)
            {
                _animator.SetBool("IsPress", true);
            }
        }

        public void OnPointerUp(PointerEventData eventData)
        {
            if (_cachedButton.interactable)
            {
                _animator.SetBool("IsPress", false);
            }
        }

        public void OnClick()
        {
            onClick?.Invoke(CachedRowData.Value);
            
            _animator.SetTrigger("Click");
        }

        public bool Select()
        {
            if (_curSlotType != SlotType.Normal)
            {
                return false;
            }
            
            _cachedButton.Select();

            return true;
        }
    }
}