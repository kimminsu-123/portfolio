using System;
using FMOD.Studio;
using FMODUnity;
using ProjectAAA.Core.Managers;
using ProjectAAA.Core.Scene.Manager;
using ProjectAAA.SO;
using ProjectAAA.Utils;
using UnityEngine;
using EventManager = ProjectAAA.Core.Managers.EventManager;
using EventType = ProjectAAA.Core.Managers.EventType;
using STOP_MODE = FMOD.Studio.STOP_MODE;

namespace ProjectAAA.Interaction
{
    public class Portal : MonoBehaviour, IInteractable
    {
        public float InteractDuration => interactDuration;

        [SerializeField] private PortalInSO _portalInSO;
        [SerializeField] private float interactDuration = 1f;
        [SerializeField] private SceneGroupSO scene;
        [SerializeField] private FMODEventInfoSO portalIdleSound;
        [SerializeField] private FMODEventInfoSO interactSound;

        [SerializeField] private bool useSaveData = false;

        private EventInstance _idleSoundInstance;
        private void Awake()
        {
            if(!useSaveData) return;
            gameObject.SetActive(SaveLoadManager.Instance.HasSaveData());
        }

        private void OnEnable()
        {
            _idleSoundInstance = RuntimeManager.CreateInstance(portalIdleSound.eventGuid);
            RuntimeManager.AttachInstanceToGameObject(_idleSoundInstance, gameObject);
            
            _idleSoundInstance.start();
        }

        private void OnDisable()
        {
            if (_idleSoundInstance.isValid())
            {
                RuntimeManager.DetachInstanceFromGameObject(_idleSoundInstance);
                _idleSoundInstance.stop(STOP_MODE.IMMEDIATE);
                _idleSoundInstance.release();
            }
        }

        public void Interact(GameObject target)
        {
            SoundManager.Instance.PlaySFX(interactSound, transform.position);
            CameraEffectManager.Instance.Register(_portalInSO);
            PlayerManager.Instance.ActionController.BlockAllActions();
            PlayerManager.Instance.PlayerUI.SetActive(false);
            PlayerManager.Instance.WeaponHandler.onEndPortalInteract.AddListener(IsEndInteractPortal);
            PlayerManager.Instance.PlayerController.Animator.CrossFade(Global.PCAnimParamName.StNmPortal, 0f, 0, 0f, 0f);
            PlayerManager.Instance.PlayerController.Animator.SetBool(Global.PCAnimParamName.BIsInteractPortal, true);
            PlayerManager.Instance.WeaponHandler.SetIKWeight(0f);
            PlayerManager.Instance.PlayerController.EffectDistortion();
            PlayerManager.Instance.PlayerController.SetArmEmissive(1f, 1f, _portalInSO.AnimationCurve);
        }

        public void IsEndInteractPortal()
        {
            PlayerManager.Instance.ActionController.UnBlockAllActions();
            PlayerManager.Instance.WeaponHandler.onEndPortalInteract.RemoveListener(IsEndInteractPortal);
            PlayerManager.Instance.PlayerController.Animator.SetBool(Global.PCAnimParamName.BIsInteractPortal, false);
            PlayerManager.Instance.WeaponHandler.SetIKWeight(1f);
            PlayerManager.Instance.PlayerController.SetArmEmissive();
            PlayerManager.Instance.PlayerUI.SetActive(true);
            
             if (useSaveData)
             {
                 EventManager.Instance.PostNotification(EventType.PlayerClearLastedSaveData, this);
             }
            
             if (_idleSoundInstance.isValid())
             {
                 RuntimeManager.DetachInstanceFromGameObject(_idleSoundInstance);
                 _idleSoundInstance.stop(STOP_MODE.IMMEDIATE);
                 _idleSoundInstance.release();
             }
             _ = LoadingManager.Instance.LoadSceneGroupAsync(scene);
            gameObject.SetActive(false);
        }
    }
}