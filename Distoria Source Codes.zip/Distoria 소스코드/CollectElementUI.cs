using DG.Tweening;
using ProjectAAA.Core.Pool;
using UnityEditor;
using UnityEngine;

namespace ProjectAAA.UI
{
    public abstract class CollectElementUI<TData> : PoolObjMonoBehaviour
    {
        protected enum Status
        {
            None,
            BeginShow,
            Showing,
            Hiding,
        }

        public bool NeedHide { get; set; }
        
        [SerializeField] protected float moveDuration = 0.2f;
        [SerializeField] private bool reverse;

        protected RectTransform CachedRectTr => transform as RectTransform;
        protected Status CurrentStatus { get; private set; } = Status.None;
        
        private Tweener _horiTweener;
        private Tweener _vertTweener;

        public void Setup(TData data)
        {
            OnSetup(data);
            
            _horiTweener?.Kill();
            _vertTweener?.Kill();

            CurrentStatus = Status.None;

            NeedHide = false;
        }

        public void Move(float order, float offsetY)
        {
            float nextY = (CachedRectTr.sizeDelta.y + offsetY) * order;
            
            _vertTweener?.Kill();
            _vertTweener = CachedRectTr.DOAnchorPosY(nextY, moveDuration)
                .SetAutoKill(true)
                .SetEase(Ease.OutCirc)
                .Play();
        }

        public void Show()
        {
            if (CurrentStatus != Status.None)
            {
                return;
            }

            OnBeginShow();

            CachedRectTr.anchoredPosition = new Vector2(reverse ? CachedRectTr.sizeDelta.x : -CachedRectTr.sizeDelta.x, 0f);   
            
            _horiTweener?.Kill();
            _horiTweener = CachedRectTr.DOAnchorPosX(0, moveDuration)
                .SetEase(Ease.OutCirc)
                .SetAutoKill(true)
                .OnComplete(() =>
                {
                    CurrentStatus = Status.Showing;
                    OnCompletedShow();
                })
                .Play();
            CurrentStatus = Status.BeginShow;
        }

        public void Hide()
        {
            if (CurrentStatus is Status.Hiding or Status.None)
            {
                return;
            }

            NeedHide = false;
            
            OnBeginHide();
            
            _horiTweener?.Kill();
            _horiTweener = CachedRectTr.DOAnchorPosX(reverse ? CachedRectTr.sizeDelta.x : -CachedRectTr.sizeDelta.x, moveDuration)
                .SetEase(Ease.OutCirc)
                .SetAutoKill(true)
                .OnComplete(() =>
                {
                    OnCompletedHide();
                    SelfReturn();
                })
                .Play();

            CurrentStatus = Status.Hiding;
        }
        
        public override void OnRelease()
        {
            base.OnRelease();
            
            _horiTweener?.Kill();
            _vertTweener?.Kill();
            
            CurrentStatus = Status.None;
        }
        
        protected abstract void OnSetup(TData data);
        protected virtual void OnBeginShow() { }
        protected virtual void OnCompletedShow() { }
        protected virtual void OnBeginHide() { }
        protected virtual void OnCompletedHide() { }
    }
}