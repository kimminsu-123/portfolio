using Cysharp.Threading.Tasks;
using ProjectAAA.Core.Managers;
using ProjectAAA.Core.OptimizedSensor;
using ProjectAAA.Utils;
using UnityEditor;
using UnityEngine;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.WeaponSystem
{
    public class BulletHitSplitCastHandler : BulletHitHandler
    {
        private Vector3 _velocity;
        private Vector3 _gravity;

        private OptimizedSphereCastSensorData _data;

        protected override void Setup()
        {
            base.Setup();

            _data = new OptimizedSphereCastSensorData(1, 1);
        }

        public override void Init()
        {
            base.Init();

            _gravity = Vector3.zero;
            _velocity = CurrentBullet.transform.forward * Speed;
        }

        protected override UniTask ProcessShoot(Vector3 origin)
        {
            CurrentBullet.transform.position = origin;

            _velocity = CurrentBullet.transform.forward * _velocity.magnitude;

            return UniTask.CompletedTask;
        }

        protected override async UniTask ProcessUpdate(float deltaTime)
        {
            if (LifeTimeTimer.IsRunning && _data.Status != SensorStatus.Running)
            {
                float distance = _velocity.magnitude * deltaTime;
                Vector3 dir = _velocity.normalized;
                
                await CastJob(CurrentBullet.transform.position, dir, distance, deltaTime);
            }
        }

        private async UniTask CastJob(Vector3 from, Vector3 dir, float distance, float deltaTime)
        {
            _data.SetModel(new OptimizedSphereCastSensorModel
            {
                Origin = from,
                Direction = dir,
                Distance = distance,
                Radius = Size * 0.5f,
                LayerMask = TargetLayerMask
            });
            
            PhysicsManager.Instance.AddSphereCast(_data);
            
            await _data.Handle.Task;
            
            RaycastHit hit = _data.Results[0];
            if (hit.collider != null)
            {
                HitInfo info = new HitInfo
                {
                    Target = hit.collider.gameObject,
                    Point = hit.point,
                    Normal = hit.normal
                };
                
                CurrentBullet.transform.position = hit.point;

                _velocity = Vector3.zero;
                await ProcessHit(info);
                _velocity = CurrentBullet.transform.forward * Speed + _gravity;
            }

            if (CurrentBullet == null)
            {
                return;
            }
            
            CurrentBullet.transform.position += _velocity * deltaTime;

            if (_velocity != Vector3.zero)
            {
                _gravity += Physics.gravity * (CurrentBullet.GravityFactor * deltaTime);
                _velocity += Physics.gravity * (CurrentBullet.GravityFactor * deltaTime);
                CurrentBullet.transform.forward = _velocity.normalized;
            }
        }
    }
}