using Unity.AI.Navigation;
using UnityEngine;

namespace ProjectAAA.Mob
{
    [RequireComponent(typeof(NavMeshModifierVolume), typeof(BoxCollider))]
    public class NavMeshWallModifier : MonoBehaviour
    {
    }
}