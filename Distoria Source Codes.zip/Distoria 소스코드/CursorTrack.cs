using UnityEngine.Timeline;

namespace ProjectAAA.Timeline
{
    [TrackClipType(typeof(CursorAsset))]
    public class CursorTrack : PlayableTrack
    {
        
    }
}