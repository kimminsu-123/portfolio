using UnityEngine;

#if UNITY_EDITOR
using UnityEditor;
#endif

namespace ProjectAAA.Utils.Visualizer
{
    public class SectorVisualizer : Visualizer
    {
        public Vector3 center;
        public float angle;
        public float radius;
        public float height;
    }
#if UNITY_EDITOR
    [CustomEditor(typeof(SectorVisualizer))]
    public class DrawSectorVisualizer : Editor
    {
        private void OnSceneGUI()
        {
            SectorVisualizer inst = (SectorVisualizer)target;
            Handles.color = inst.gizmosColor;
            Handles.matrix = inst.transform.localToWorldMatrix;

            Vector3 toLeft = Quaternion.Euler(0f, -inst.angle * 0.5f, 0f) * Vector3.forward * inst.radius;
            Vector3 toRight = Quaternion.Euler(0f, inst.angle * 0.5f, 0f) * Vector3.forward * inst.radius;

            if (inst.drawWireframe)
            {
                Handles.DrawLine(inst.center, inst.center + toRight);
                Handles.DrawWireArc(inst.center, Vector3.up, toLeft.normalized, inst.angle, inst.radius);
                Handles.DrawLine(inst.center, inst.center + toLeft);   
            }
            else
            {
                Handles.DrawSolidArc(inst.center, Vector3.up, toLeft.normalized, inst.angle, inst.radius);
            }

            if (inst.height != 0f)
            {
                Vector3 upCenter = inst.center + Vector3.up * inst.height;
                if (inst.drawWireframe)
                {
                    Handles.DrawLine(upCenter, upCenter + toRight);
                    Handles.DrawWireArc(upCenter, Vector3.up, toLeft.normalized, inst.angle, inst.radius);
                    Handles.DrawLine(upCenter, upCenter + toLeft);
                
                    Handles.DrawLine(inst.center + toLeft, upCenter + toLeft);
                    Handles.DrawLine(inst.center + toRight, upCenter + toRight);   
                }
                else
                {
                    Handles.DrawSolidArc(upCenter, Vector3.up, toLeft.normalized, inst.angle, inst.radius);
                }
            }
        }
    }
#endif
}