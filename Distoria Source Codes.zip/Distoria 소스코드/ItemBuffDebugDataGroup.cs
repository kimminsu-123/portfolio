using System.Collections.Generic;
using Newtonsoft.Json;
using ProjectAAA.Utils.DataTable;
using UnityEngine;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.SO.Debug.Item
{
    [CreateAssetMenu(fileName = "ItemBuffDebugDataGroup", menuName = "Scriptable Objects/DataTable/Debug/ItemBuff")]
    public class ItemBuffDebugDataGroup : DebugDataGroup
    {
        [SerializeField] private List<ItemBuffData> itemsBuffs;
        
        protected override void FromJson(string json)
        {
            itemsBuffs.Clear();
            itemsBuffs = JsonConvert.DeserializeObject<List<ItemBuffData>>(json);
        }

        public override string ToJson()
        {
            return JsonConvert.SerializeObject(itemsBuffs);
        }
    }
}