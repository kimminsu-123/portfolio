using System;
using ProjectAAA.Utils;

namespace ProjectAAA.Core.Timer
{
    public abstract class Timer<T> : DisposeBase
    {
        public delegate void OnTimerEvent();

        public OnTimerEvent OnStartCallback;
        public OnTimerEvent OnStopCallback;
        public OnTimerEvent OnCompleteCallback;
        public OnTimerEvent OnPauseCallback;
        public OnTimerEvent OnResumeCallback;

        public T Time { get; private set; }
        public T CurrentTime { get; protected set; }
        public bool IsRunning { get; protected set; }
        public bool IsPause { get; protected set; }

        public Timer(T initTime)
        {
            SetTime(initTime);
            IsRunning = false;
        }

        public void SetTime(T time)
        {
            Time = time;
            CurrentTime = time;
        }

        public void Reset()
        {
            CurrentTime = Time;
        }
        
        public void Start()
        {
            CurrentTime = Time;
            if (!IsRunning)
            {
                OnStartCallback?.Invoke();
            }
            Resume();

            IsRunning = true;
        }

        public void Stop()
        {
            if (IsPause) return;
            
            if (IsRunning)
            {
                OnStopCallback?.Invoke();
            }
            IsRunning = false;
        }

        public void Pause()
        {
            if (!IsPause)
            {
                OnPauseCallback?.Invoke();
            }
            IsPause = true;
        }

        public void Resume()
        {
            if (IsPause)
            {
                OnResumeCallback?.Invoke();
            }
            IsPause = false;
        }
        
        public abstract void Tick(T delta);
    }
}