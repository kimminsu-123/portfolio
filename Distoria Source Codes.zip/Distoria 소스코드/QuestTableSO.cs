using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using ProjectAAA.Utils.DataTable;
using UnityEngine;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.SO.Quest
{
    [CreateAssetMenu(fileName = "QuestTableSO", menuName = "Scriptable Objects/DataTable/QuestTableSO")]
    public class QuestTableSO : DataTableSO
    {
        public List<int> Keys { get; private set; }
        public int Count => Keys.Count;
        
        private Dictionary<int, QuestData> _quests;

        protected override void FromJson(string json)
        {
            List<QuestData> deserialized = JsonConvert.DeserializeObject<List<QuestData>>(json);
        
            Logger.Assert(deserialized != null, "QuestTable", "퀘스트 테이블이 비어있습니다.");

            if (deserialized != null)
            {
                _quests = deserialized.ToDictionary(x => x.QuestId, x => x);
                Keys = _quests.Keys.ToList();
            }
        }
    
        public QuestData Get(int questId) => _quests[questId];
        public bool Contains(int questId) => _quests.ContainsKey(questId);
    }
}