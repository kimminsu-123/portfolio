using System;
using UnityEngine;

namespace ProjectAAA.Interaction.Shop
{
    public class Trader : MonoBehaviour
    {
        private Animator _cachedAnimator;

        private void Awake()
        {
            _cachedAnimator = GetComponent<Animator>();
        }

        public void PlayIdle()
        {
            _cachedAnimator?.CrossFade("Idle", 0.5f);
        }

        public void PlayTrade()
        {
            _cachedAnimator?.SetTrigger("TrgIsTrade");
        }
    }
}