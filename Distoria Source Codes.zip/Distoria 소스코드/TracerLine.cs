using System;
using Amazon.Runtime.Telemetry.Tracing;
using ProjectAAA.Core.Pool;
using ProjectAAA.Core.Timer;
using UnityEngine;

namespace ProjectAAA.Core
{
    [RequireComponent(typeof(LineRenderer))]
    public class TracerLine : PoolObjMonoBehaviour
    {
        public float activeTime = 1f;

        private float _startWidthMultiplier;
        private LineRenderer _lineRenderer;
        private CooldownTimer _activeTimer;
        
        private static readonly int Animation1 = Shader.PropertyToID("_Animation");

        private void Awake()
        {
            _lineRenderer = GetComponent<LineRenderer>();
            _startWidthMultiplier = _lineRenderer.widthMultiplier;
            
            _activeTimer = new CooldownTimer(activeTime);
            _activeTimer.OnCompleteCallback += OnCompleted;
        }

        private void OnCompleted()
        {
            _lineRenderer.material.SetFloat(Animation1, 1f);
            
            SelfReturn();
        }

        private void OnEnable()
        {
            _activeTimer.SetTime(activeTime);
            _activeTimer.Start();
        }

        private void Update()
        {
            if (_activeTimer.IsRunning)
            {
                float normalized = 1f - (_activeTimer.CurrentTime / _activeTimer.Time);
                
                _lineRenderer.material.SetFloat(Animation1, normalized);
            }
            
            _activeTimer.Tick(Time.deltaTime);
        }

        public void SetPoint(int index, Vector3 position)
        {
            _lineRenderer.SetPosition(index, position);
        }

        public void SetWidthMultiplier(float multiplier)
        {
            _lineRenderer.widthMultiplier = _startWidthMultiplier * multiplier;
        }
    }
}