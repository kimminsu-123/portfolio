using UnityEngine;

namespace ProjectAAA.Utils.Visualizer
{
    public class ModelVisualizer : Visualizer
    {
        public Mesh[] meshes;
        
        private void OnDrawGizmos()
        {
            Gizmos.color = gizmosColor;
            Gizmos.matrix = transform.localToWorldMatrix;
            
            foreach (Mesh mesh in meshes)
            {
                if (drawWireframe) Gizmos.DrawWireMesh(mesh);
                else Gizmos.DrawMesh(mesh);
            }
        }
    }
}