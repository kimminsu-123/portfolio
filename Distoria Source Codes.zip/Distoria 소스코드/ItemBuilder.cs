using ProjectAAA.Core.Managers;
using ProjectAAA.Core.Pool;
using ProjectAAA.SO;
using ProjectAAA.Utils;
using ProjectAAA.Utils.DataTable;
using UnityEngine;

namespace ProjectAAA.Interaction.Items
{
    [RequireComponent(typeof(Rigidbody), typeof(SphereCollider))]
    public class ItemBuilder : PoolObjMonoBehaviour
    {
        [field: SerializeField] public int ItemID { get; private set; }
        [field: SerializeField] public GameObject Model { get; private set; }
        
        public ItemBase Reference { get; private set; }

        private void Reset()
        {
            gameObject.layer = Global.ItemLayerIndex;
        }

        private void Awake()
        {
            InitComponents();
        }

        private void InitComponents()
        {
            ItemData data = DatabaseManager.Instance.GetTable<ItemTableSO>().GetItem(ItemID);
            
            switch (data.ItemType)
            {
                case ItemType.Consumable:
                    Reference = gameObject.AddComponent<ConsumableItem>();
                    break;
                case ItemType.Passive:
                    Reference = gameObject.AddComponent<PassiveItem>();
                    break;
            }

            gameObject.name = data.ItemName;

            Reference.Setup(this);
        }
    }
}