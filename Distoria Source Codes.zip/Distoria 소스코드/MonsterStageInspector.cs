using System;
using ProjectAAA.Utils;
using UnityEditor;
using UnityEditorInternal;
using UnityEngine;

namespace ProjectAAA.Mob
{
    [CanEditMultipleObjects]
    [CustomEditor(typeof(MonsterStage))]
    public class MonsterStageInspector : UnityEditor.Editor
    {
        private ReorderableList _areaListReorderableList;
        private int _prevStageMode = -1;
        private int _prevSpawnCondition = -1;

        private bool _initialized = false;

        [MenuItem("GameObject/Monster Stage")]
        private static void CreateStage()
        {
            GameObject stage = new GameObject("Stage");
            stage.AddComponent<MonsterStage>();
        }

        public override void OnInspectorGUI()
        {
            if (!_initialized)
            {
                Initialize();
            }
            
            serializedObject.Update();

            EditorGUILayout.PropertyField(serializedObject.FindProperty("onBeginStage"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("onEndStage"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("stageMode"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("startCondition"));
            DrawIsAutoWave();
            
            _areaListReorderableList.DoLayoutList();
            
            DrawButtons();
            CheckDiffChild();
            CheckStageMode();
            CheckStartCondition();

            serializedObject.ApplyModifiedProperties();
        }

        private void Initialize()
        {
            SerializedProperty stageModeProperty = serializedObject.FindProperty("stageMode");
            
            _areaListReorderableList = new ReorderableList (serializedObject,serializedObject.FindProperty("areaList"), false, true, false, false);
            _areaListReorderableList.drawHeaderCallback += (rect) =>
            {
                string header = stageModeProperty.enumValueIndex == (int) StageMode.Wave ? "웨이브 순서" : "할당된 지역들";
                EditorGUI.LabelField(rect, header);
            };
            _areaListReorderableList.drawElementCallback += DrawElement;
            _areaListReorderableList.elementHeight = EditorGUIUtility.singleLineHeight + 4f;

            _initialized = true;
        }

        private void DrawElement(Rect rect, int index, bool isactive, bool isfocused)
        {
            SerializedProperty property = serializedObject.FindProperty("areaList");
            SerializedProperty element = property.GetArrayElementAtIndex (index);
            rect.height -= 4;
            rect.y += 2;

            EditorGUI.PropertyField(rect, element);
        }

        private void DrawIsAutoWave()
        {
            SerializedProperty property = serializedObject.FindProperty("stageMode");

            if ((StageMode)property.enumValueIndex == StageMode.Wave)
            {
                EditorGUILayout.PropertyField(serializedObject.FindProperty("isAutoWave"));
            }
        }

        private void DrawButtons()
        {
            if (GUILayout.Button("몬스터 스폰 영역 만들기"))
            {
                MonsterStage monsterStage = target as MonsterStage;
                SerializedProperty areaListProperty = serializedObject.FindProperty("areaList");
                
                GameObject area = new GameObject($"Area {monsterStage.transform.childCount}");
                
                area.transform.SetParent(monsterStage.transform);
                area.transform.localPosition = Vector3.zero;
                area.transform.localRotation = Quaternion.identity;

                MonsterArea monsterArea = area.AddComponent<MonsterArea>();
                
                UpdateMonsterAreaSubjectType(monsterArea);
                
                int index = areaListProperty.arraySize;
                areaListProperty.InsertArrayElementAtIndex(index);
                areaListProperty.GetArrayElementAtIndex(index).objectReferenceValue = monsterArea;
            }

            if (GUILayout.Button("자식 영역 강제 업데이트"))
            {
                UpdateChildAreas();
            }
        }

        private void CheckDiffChild()
        {
            MonsterStage monsterStage = target as MonsterStage;

            int childCount = monsterStage.transform.childCount;
            int listCount = _areaListReorderableList.count;
            if (childCount != listCount)
            {
                UpdateChildAreas();
            }
        }

        private void CheckStageMode()
        {
            SerializedProperty property = serializedObject.FindProperty("stageMode");

            if (_prevStageMode != property.enumValueIndex)
            {
                SerializedProperty areaListProperty = serializedObject.FindProperty("areaList");
                int childCount = areaListProperty.arraySize;
                for (int i = 0; i < childCount; i++)
                {
                    SerializedProperty element = areaListProperty.GetArrayElementAtIndex(i);
                    MonsterArea area = element.objectReferenceValue as MonsterArea;
                    
                    UpdateMonsterAreaSubjectType(area);
                }
            }
            
            _prevStageMode = property.enumValueIndex;
        }
        
        private void CheckStartCondition()
        {
            MonsterStage stage = target as MonsterStage;
            SerializedProperty property = serializedObject.FindProperty("startCondition");

            if (_prevSpawnCondition != property.enumValueIndex)
            {
                StartCondition condition = (StartCondition)property.enumValueIndex;
                switch (condition)
                {
                    case StartCondition.OnSceneLoaded:
                    case StartCondition.OnOtherCall:
                        if (stage.TryGetComponent(out Collider col))
                        {
                            DestroyImmediate(col);
                        }
                    
                        if (stage.TryGetComponent(out Rigidbody rigidbody))
                        {
                            DestroyImmediate(rigidbody);
                        }
                        stage.gameObject.layer = Global.DefaultLayerIndex;
                        break;
                    case StartCondition.OnTrigger:
                        stage.gameObject.layer = Global.InteractionLayerIndex;

                        var collider = stage.gameObject.GetOrAddComponent<BoxCollider>();
                        collider.isTrigger = true;

                        var rigid = stage.gameObject.GetOrAddComponent<Rigidbody>();
                        rigid.isKinematic = true;
                        rigid.useGravity = false;
                        break;
                }
            }

            _prevSpawnCondition = property.enumValueIndex;
        }
        
        private void UpdateChildAreas()
        {
            MonsterStage monsterStage = target as MonsterStage;
            SerializedProperty areaListProperty = serializedObject.FindProperty("areaList");
            int childCount = monsterStage.transform.childCount;
            
            areaListProperty.ClearArray();            
            
            for (int i = 0; i < childCount; i++)
            {
                Transform child = monsterStage.transform.GetChild(i);
                MonsterArea area = child.GetComponent<MonsterArea>();
                
                UpdateMonsterAreaSubjectType(area);
                
                areaListProperty.InsertArrayElementAtIndex(i);
                areaListProperty.GetArrayElementAtIndex(i).objectReferenceValue = area;
            }
        }

        private void UpdateMonsterAreaSubjectType(MonsterArea area)
        {
            if (area == null)
            {
                return;
            }
            
            SerializedProperty stageModeProperty = serializedObject.FindProperty("stageMode");
            SerializedObject areaSO = new SerializedObject(area);
            
            bool ret = (StageMode)stageModeProperty.enumValueIndex == StageMode.SubjectArea;
            areaSO.FindProperty("isSubject").boolValue = ret; 
            
            areaSO.ApplyModifiedProperties();
        }
    }
}