using System.Collections.Generic;
using ProjectAAA.Utils;
using UnityEngine;

namespace ProjectAAA.Core.Managers
{
    public class CameraManager : SingletonMonoBehavior<CameraManager>
    {
        public CamGroupType CurGroupType { get; private set; }
        
        private readonly Dictionary<CamGroupType, List<Camera>> _groupCams = new();

        public void AddCamera(CamGroupType groupType, Camera cam)
        {
            if (!_groupCams.ContainsKey(groupType))
            {
                _groupCams.Add(groupType, new List<Camera>());
            }
            _groupCams[groupType].Add(cam);
        }

        public void RemoveCamera(CamGroupType groupType, Camera cam)
        {
            if (!_groupCams.TryGetValue(groupType, out List<Camera> groupCam))
            {
                return;
            }
            
            groupCam.Remove(cam);
        }
        
        public void ChangeCameraGroup(CamGroupType groupType)
        {
            if (CurGroupType == groupType)
            {
                return;
            }

            foreach (KeyValuePair<CamGroupType, List<Camera>> kvp in _groupCams)
            {
                foreach (Camera cam in kvp.Value)
                {
                    cam.gameObject.SetActive(kvp.Key == groupType);
                }
            }

            CurGroupType = groupType;
        }
        
        public void ChangeCameraGroup(CamGroupType groupType, int hash)
        {
            if (CurGroupType == groupType)
            {
                return;
            }

            foreach (KeyValuePair<CamGroupType, List<Camera>> kvp in _groupCams)
            {
                foreach (Camera cam in kvp.Value)
                {
                    cam.gameObject.SetActive(kvp.Key == groupType && cam.gameObject.GetHashCode() == hash);
                }
            }

            CurGroupType = groupType;
        }
    }
}