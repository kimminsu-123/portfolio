using ProjectAAA.Utils;

namespace ProjectAAA.Player
{
    public class PlayerAlterStat : Singleton<PlayerAlterStat>
    {
        public float JumpSpeed { get; set; }
        public float MoveSpeedFactor { get; set; } = 1f;
        public float DashCooldownFactor { get; set; } = 1f;
        
        public void Clear()
        {
            JumpSpeed = 0f;

            MoveSpeedFactor = 1f;
            DashCooldownFactor = 1f;
        }

        public string FileName => "playeralterstat";
    }
}