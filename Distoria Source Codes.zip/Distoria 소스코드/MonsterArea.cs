using System;
using System.Collections.Generic;
using System.Linq;
using DG.Tweening;
using FMODUnity;
using ProjectAAA.Core;
using ProjectAAA.Core.Managers;
using ProjectAAA.Core.Scene.Manager;
using ProjectAAA.Core.Timer;
using ProjectAAA.Interaction;
using ProjectAAA.Mob.Normal;
using ProjectAAA.Player;
using ProjectAAA.SO;
using ProjectAAA.SO.Pool;
using ProjectAAA.Utils;
using UniRx;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.Events;
using Logger = ProjectAAA.Utils.Logger;
using Random = System.Random;

namespace ProjectAAA.Mob
{
    public class MonsterArea : MonoBehaviour
    {
        [Serializable]
        public class MonsterSpawnSettings
        {
            public ObjectPoolSO monsterPool;
            public int spawnCount;
        }
        
        private enum Status
        {
            Began,
            Ended,
        }

        public bool IsClear { get; private set; }

        public ReactiveProperty<int> KillCount
        {
            get
            {
                if (_killCount == null)
                {
                    _killCount = new ReactiveProperty<int>(0);
                }
                return _killCount;
            }
        }

        public int Count => _spawnedMonsters.Count;

        public UnityEvent<int> onBeginArea;
        public UnityEvent<int> onEndArea;

        [SerializeField] private ObjectPoolSO endAreaEffectPool;
        [SerializeField] private FMODEventInfoSO clearAreaSoundInfo;
        [SerializeField] private SpawnMode spawnMode;
        
        // Random 관련 변수들 (Debugging 용)
        [SerializeField] private AreaType areaType;
        [SerializeField] private Color gizmosColor = Color.red;
        [SerializeField] private float sphereRadius = 1f;
        [SerializeField] private Vector3 cubeSize = Vector3.one;
        [SerializeField] private List<ObjectPoolSO> monsterPoolList;

        // Random 관련 변수들 (Runtime 용)
        [SerializeField] private List<MonsterSpawnSettings> randomMonsterSpawnSettings;
        [SerializeField] private float spawnInterval;
        [SerializeField] private int spawnCount;

        // 주체적으로 동작할 수 있도록 하는 변수들 
        [SerializeField] private bool isSubject;
        private BoxCollider _triggerBoxCol;

        private List<MonsterBase> _spawnedMonsters = new();
        private CooldownTimer _spawnIntervalTimer;
        private Collider[] _wallColliders;
        private MeshRenderer[] _wallMeshRenderers;
        private Tweener[] _wallTweeners;
        private MonoBehaviour[] _cachedInteractables;
        private MonsterAreaStatFactor _statFactor;

        private ReactiveProperty<int> _killCount;

        private Status _currentStatus = Status.Ended;
        private int _currentSpawnMonsterIndex;
        private int _areaIndex;
        
        private void Awake()
        {
            _spawnIntervalTimer = new CooldownTimer(0f);
            _spawnIntervalTimer.OnCompleteCallback += SpawnNextMonster;
            
            if (isSubject)
            {
                _triggerBoxCol = GetComponent<BoxCollider>();
            }

            _wallColliders = gameObject.GetComponentsOnlyChildren<Collider>(Global.WallLayerIndex);
            _wallMeshRenderers = new MeshRenderer[_wallColliders.Length];
            for (int i = 0; i < _wallColliders.Length; i++)
            {
                _wallMeshRenderers[i] = _wallColliders[i].GetComponentInChildren<MeshRenderer>(true);
            }
            _wallTweeners = new Tweener[_wallMeshRenderers.Length];
            
            IInteractable[] interactables = GetComponentsInChildren<IInteractable>(true);
            if (interactables.Length > 0)
            {
                _cachedInteractables = new MonoBehaviour[interactables.Length];
                for (int i = 0; i < _cachedInteractables.Length; i++)
                {
                    _cachedInteractables[i] = (interactables[i] as MonoBehaviour);
                }   
            }

            _statFactor = GetComponent<MonsterAreaStatFactor>();
        }

        public void Initialize(int index)
        {
            Logger.Log("MonsterArea", $"{spawnMode} {name} Initialize", Color.yellow);

            _areaIndex = index;
            
            if (spawnMode == SpawnMode.RandomizeOnRuntime)
            {
                ShuffleMonstersByRandom();
                foreach (MonsterBase monster in _spawnedMonsters)
                {
                    monster.Stop();
                }
            }
            else
            {
                MonsterSpawnPoint[] points = GetComponentsInChildren<MonsterSpawnPoint>(true);
                foreach (MonsterSpawnPoint point in points)
                {
                    point.Initialize();
                }
            }

            if (isSubject)
            {
                _triggerBoxCol.enabled = true;
            }
            
            for (int i = 0; _wallColliders != null && i < _wallColliders.Length; i++)
            {
                _wallColliders[i].enabled = false;
            }

            for (int i = 0; _wallMeshRenderers != null && i < _wallMeshRenderers.Length; i++)
            {
                _wallMeshRenderers[i].material.SetFloat("_Anim", 0f);
            }

            DisableRewards();
        }

        public void Begin()
        {
            Logger.Log("MonsterArea", $"{_spawnedMonsters.Count} {name} Begin", Color.yellow);

            IsClear = false;
            KillCount.Value = 0;
            onBeginArea?.Invoke(_areaIndex);
            
            if (spawnMode == SpawnMode.Manual)
            {
                foreach (MonsterBase monster in _spawnedMonsters)
                {
                    if (_statFactor != null)
                    {
                        _statFactor.ApplyFactor(monster);
                    }
                    monster.Run();
                }   
            }
            else
            {
                SpawnNextMonster();
            }
            
            foreach (MonsterBase monster in _spawnedMonsters)
            {
                monster.LivingEntity.onDeath.AddListener(OnKillMonster);
            }
            
            if (isSubject)
            {
                _triggerBoxCol.enabled = false;
            }
            
            for (int i = 0; _wallColliders != null && i < _wallColliders.Length; i++)
            {
                _wallColliders[i].enabled = true;
            }
            
            for (int i = 0; _wallMeshRenderers != null && i < _wallMeshRenderers.Length; i++)
            {
                _wallTweeners[i]?.Kill();
                _wallTweeners[i] = _wallMeshRenderers[i].material
                    .DOFloat(1f, "_Anim", 2f)
                    .SetEase(Ease.OutCirc)
                    .SetAutoKill(true)
                    .Play();
            }

            DisableRewards();

            _currentStatus = Status.Began;
            
            // 만약 설치한 스폰 포인트가 없거나 Random 값이 0 일 경우 바로 Area 종료
            if (KillCount.Value >= Count)
            {
                IsClear = true;
            }
        }
        
        public void End()
        {
            if (_currentStatus == Status.Ended)
            {
                return;
            }
            
            EnableRewards();

            if (IsClear)
            {
                if (clearAreaSoundInfo != null)
                {
                    try
                    {
                        SoundManager.Instance.PlaySFX(clearAreaSoundInfo, transform.position);
                    }
                    catch (EventNotFoundException e)
                    {
                        Logger.LogError($"MonsterArea", $"Monster Area Clear Sound not Found : {e.Message}");
                    }
                
                    PlayerManager.Instance.PlayerController.ShakeCamera();
                    PlayerManager.Instance.PlayerController.EffectChromatic();
                }
            
                if (endAreaEffectPool != null)
                {
                    ParticlePoolObj effect = endAreaEffectPool.Get<ParticlePoolObj>(null);
                    effect.SetParent(transform);
                    effect.SetPosition(Vector3.zero, Space.Self);
                    effect.SetOriginPool(endAreaEffectPool);
                    effect.Play();
                }
            }
            
            onEndArea?.Invoke(_areaIndex);
            
            _spawnIntervalTimer.Stop();
            
            ClearMonster();
            
            if (isSubject)
            {
                _triggerBoxCol.enabled = false;
            }

            for (int i = 0; _wallColliders != null && i < _wallColliders.Length; i++)
            {
                _wallColliders[i].enabled = false;
            }
            
            for (int i = 0; _wallMeshRenderers != null && i < _wallMeshRenderers.Length; i++)
            {
                _wallTweeners[i]?.Kill();
                _wallTweeners[i] = _wallMeshRenderers[i].material
                    .DOFloat(0f, "_Anim", 2f)
                    .SetEase(Ease.OutCirc)
                    .SetAutoKill(true)
                    .Play();
            }
            
            _currentStatus = Status.Ended;
        }

        public void AddMonster(MonsterBase monster)
        {
            _spawnedMonsters.Add(monster);
        }

        public void ClearMonster()
        {
            foreach (MonsterBase monster in _spawnedMonsters)
            {
                monster.LivingEntity.onDeath.RemoveListener(OnKillMonster);
            }
            _spawnedMonsters.Clear();
        }

        private void ShuffleMonstersByRandom()
        {
            List<MonsterBase> monsterList = new List<MonsterBase>();
            int count = randomMonsterSpawnSettings.Count;
            for (int i = 0; i < count; i++)
            {
                MonsterSpawnSettings setting = randomMonsterSpawnSettings[i];
                for (int j = 0; j < setting.spawnCount; j++)
                {
                    MonsterBase monster = setting.monsterPool.Get<MonsterBase>(transform);
                    monster.SetOriginPool(setting.monsterPool);
                    monster.Stop();
                    
                    monsterList.Add(monster);
                }
            }

            Random rand = new Random(DateTime.Now.Millisecond);
            _spawnedMonsters = monsterList.OrderBy(_ => rand.Next()).ToList();
        }

        private void Update()
        {
            if (_currentStatus == Status.Began && spawnMode == SpawnMode.RandomizeOnRuntime)
            {
                _spawnIntervalTimer.Tick(Time.deltaTime);
            }

            if (IsClear && _currentStatus != Status.Ended)
            {
                End();
            }
        }

        private void SpawnNextMonster()
        {
            if (_currentSpawnMonsterIndex >= _spawnedMonsters.Count) return;
            
            for (int i = 0; i < spawnCount && _currentSpawnMonsterIndex < _spawnedMonsters.Count; i++)
            {
                MonsterBase monster = _spawnedMonsters[_currentSpawnMonsterIndex];
                
                if (_statFactor != null)
                {
                    _statFactor.ApplyFactor(monster);
                }
                
                Vector3 point = GetRandomPosition();
                Vector3 randomPos = GetPointOnNavmesh(point);
                monster.SetPosition(randomPos);
                monster.Run();
                
                Logger.Log("MonsterArea", $"SpawnMonster : {monster.name} {i + 1} / {spawnCount}", Color.green);
                
                _currentSpawnMonsterIndex++;
            }
            
            _spawnIntervalTimer.SetTime(spawnInterval);
            _spawnIntervalTimer.Start();
        }

        private Vector3 GetRandomPosition()
        {
            Vector3 pos = transform.position;

            switch (areaType)
            {
                case AreaType.Sphere:
                    pos += UnityEngine.Random.insideUnitSphere * sphereRadius;
                    break;
                case AreaType.Cube:
                    float x = UnityEngine.Random.Range(-cubeSize.x, cubeSize.x);
                    float y = UnityEngine.Random.Range(-cubeSize.y, cubeSize.y);
                    float z = UnityEngine.Random.Range(-cubeSize.z, cubeSize.z);
                    pos += new Vector3(x, y, z);
                    break;
            }

            return pos;
        }

        private Vector3 GetPointOnNavmesh(Vector3 point)
        {
            Vector3 pos = point;
            
            for (int i = 0; i < 100; i++)
            {
                if (NavMesh.SamplePosition(point, out var hit, 1f, NavMesh.AllAreas))
                {
                    pos = hit.position;
                    break;
                }   
            }
            
            return pos;
        }

        private void OnTriggerEnter(Collider other)
        {
            if (isSubject && other.CompareTag(Global.PlayerTag))
            {
                Begin();
            }
        }

        public void EnableRewards()
        {
            for (int i = 0; _cachedInteractables != null && i < _cachedInteractables.Length; i++)
            {
                if (_cachedInteractables[i].transform.parent == transform)
                {
                    _cachedInteractables[i].gameObject.SetActive(true);
                }
            }
        }

        public void DisableRewards()
        {
            for (int i = 0; _cachedInteractables != null && i < _cachedInteractables.Length; i++)
            {
                if (_cachedInteractables[i].transform.parent == transform)
                {
                    _cachedInteractables[i].gameObject.SetActive(false);
                }
            }
        }
        
        private void OnKillMonster()
        {
            KillCount.Value += 1;
            
            if (KillCount.Value >= Count)
            {
                IsClear = true;
            }
        }
        
        #region Debugging Code
        private void OnDrawGizmos()
        {
            if (spawnMode == SpawnMode.Manual) return;

            Gizmos.color = gizmosColor;
            Gizmos.matrix = transform.localToWorldMatrix;

            switch (areaType)
            {
                case AreaType.Sphere:
                    Gizmos.DrawWireSphere(Vector3.zero, sphereRadius);
                    break;
                case AreaType.Cube:
                    Gizmos.DrawWireCube(Vector3.zero, cubeSize);
                    break;
            }
        }        
        #endregion
    }
}