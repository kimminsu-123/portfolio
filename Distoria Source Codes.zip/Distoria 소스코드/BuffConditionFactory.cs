using ProjectAAA.Utils;
using ProjectAAA.Utils.DataTable;

namespace ProjectAAA.Interaction.Items
{
    public class BuffConditionFactory : Singleton<BuffConditionFactory>
    {
        public ItemBuffConditionBase GetCondition(ItemBuffData data)
        {
            switch (data.ConditionType)
            {
                case ItemConditionType.None:
                    return new ConditionNone();
                case ItemConditionType.UnderPlayerHealthPercent:
                    return new ConditionUnderPlayerHealth(data.ConditionValue);
                case ItemConditionType.FlyPlayer:
                    return new ConditionFlyPlayer();
                case ItemConditionType.MovePlayer:
                    return new ConditionMovePlayer();
                case ItemConditionType.StopPlayer:
                    return new ConditionStopPlayer();
                case ItemConditionType.OnPlayerDash:
                    return new ConditionOnPlayerDash();
                case ItemConditionType.InSafeTimePlayer:
                    return new ConditionInSafeTimePlayer(data.ConditionValue);
                case ItemConditionType.OnKillMonster:
                    return new ConditionOnKillMonster((int) data.ConditionValue);
                case ItemConditionType.OnSwapWeapon:
                    return new ConditionOnSwapWeapon();
                default:
                    Logger.LogError("BuffConditionFactory", $"{data.ConditionType} 존재하지 않거나 개발되지 않은 타입입니다.");
                    return null;
            }
        }
    }
}