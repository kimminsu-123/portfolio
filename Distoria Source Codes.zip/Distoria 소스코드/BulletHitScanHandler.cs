using Cysharp.Threading.Tasks;
using ProjectAAA.Core.Managers;
using ProjectAAA.Core.OptimizedSensor;
using ProjectAAA.Utils;
using UnityEngine;

namespace ProjectAAA.WeaponSystem
{
    public class BulletHitScanHandler : BulletHitHandler
    {
        private OptimizedSphereCastSensorData _data;

        protected override void Setup()
        {
            base.Setup();

            _data = new OptimizedSphereCastSensorData(1, 1);
        }

        protected override async UniTask ProcessShoot(Vector3 origin)
        {
            if (_data.Status == SensorStatus.Running)
            {
                return;
            }
            
            await Process(origin);
        }

        private async UniTask Process(Vector3 origin)
        {
            Vector3 direction = CurrentBullet.transform.forward;

            _data.SetModel(new OptimizedSphereCastSensorModel()
            {
                Origin = origin,
                Direction = direction,
                Distance = LifeTime * Speed,
                Radius = Size * 0.5f,
                LayerMask = TargetLayerMask
            });
            
            PhysicsManager.Instance.AddSphereCast(_data);
            await _data.Handle.Task;

            RaycastHit hit = _data.Results[0];
            Vector3 point = origin + direction * (LifeTime * Speed);
            if (hit.collider != null)
            {
                point = hit.point;
            }

            CurrentBullet.PlayTracerLineEffect(CurrentBullet.transform.position, point);
            CurrentBullet.transform.position = point;

            await UniTask.Yield();
            
            if (hit.collider != null)
            {
                HitInfo info = new HitInfo
                {
                    Target = hit.collider.gameObject,
                    Point = hit.point,
                    Normal = hit.normal
                };
                await ProcessHit(info);
            }

            if (!hit.collider && BulletHitAbility.IsDoneAll)
            {
                await ProcessComplete(BulletDestroyType.OverLifeTime);
            }
        }

        protected override UniTask ProcessUpdate(float deltaTime)
        {
            // nothing
            return UniTask.CompletedTask;
        }
    }
}