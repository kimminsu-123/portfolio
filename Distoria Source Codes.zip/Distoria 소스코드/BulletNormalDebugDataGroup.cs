using System.Collections.Generic;
using Newtonsoft.Json;
using ProjectAAA.Utils.DataTable;
using UnityEngine;

namespace ProjectAAA.SO.Debug
{
    [CreateAssetMenu(fileName = "BulletNormalDebugDataGroup", menuName = "Scriptable Objects/DataTable/Debug/BulletNormal")]
    public class BulletNormalDebugDataGroup : DebugDataGroup
    {
        [SerializeField] private List<BulletNormalData> bullets;

        protected override void FromJson(string json)
        {
            bullets.Clear();
            bullets = JsonConvert.DeserializeObject<List<BulletNormalData>>(json);
        }

        public override string ToJson()
        {
            return JsonConvert.SerializeObject(bullets);
        }
    }
}