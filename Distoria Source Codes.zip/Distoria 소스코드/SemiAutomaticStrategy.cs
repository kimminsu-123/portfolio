using ProjectAAA.Core.Timer;
using ProjectAAA.Utils;
using ProjectAAA.Utils.DataTable;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.WeaponSystem
{
    public class SemiAutomaticStrategy : WeaponNormalFireStrategy
    {
        private readonly CooldownTimer _burstIntervalTimer;

        private bool _isShooting;
        private bool _isBursting;
        private int _burstCount;
        
        public SemiAutomaticStrategy(Transform shootPos, WeaponNormal weapon) : base(shootPos, weapon)
        {
            _burstIntervalTimer = new CooldownTimer(CurrentWeaponNormalData.Value1);
        }

        public override void Trigger()
        {
            base.Trigger();

            if (FireIntervalTimer.IsRunning) return;
            if (CurrentMagazine.Count <= 0) return;
            if (CurrentFireState != FireState.None) return;
            if (_isShooting) return;
            
            CurrentWeapon.onBeginFireCallback?.Invoke();
            
            _burstCount = CurrentWeaponNormalData.BurstCount;
            _isShooting = true;
        }

        public override void Stop()
        {
            base.Stop();
            _isBursting = false;
            _burstCount = 0;
            _isShooting = false;
            _burstIntervalTimer.Stop();
        }

        protected override void Process()
        {
            if (CurrentTriggerState != TriggerState.Triggered && !_isShooting) return;
            if (_isBursting) return;
            
            _burstIntervalTimer.Tick(Time.deltaTime);
            
            if (!_burstIntervalTimer.IsRunning && _burstCount > 0)
            {
                _isBursting = true;
                Fire();
            }
        }

        protected override void OnFireSuccess()
        {
            base.OnFireSuccess();

            _isBursting = false;
            _burstCount--;
            if (_burstCount <= 0)
            {
                CurrentWeapon.onEndFireCallback?.Invoke();
                
                FireIntervalTimer.SetTime(CurrentWeapon.FireInterval);
                FireIntervalTimer.Start();
            }
            else
            {
                _burstIntervalTimer.Start();
            }
        }

        public override void Active()
        {
            base.Active();

            OnFireIntervalCompleted();
        }

        protected override void OnFireIntervalCompleted()
        {
            base.OnFireIntervalCompleted();

            _isBursting = false;
            _isShooting = false;
        }
    }
}