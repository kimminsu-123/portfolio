using System.Collections.Generic;
using Newtonsoft.Json;
using ProjectAAA.Utils.DataTable;
using UnityEngine;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.SO
{
    [CreateAssetMenu(fileName = "WeaponNormalTableSO", menuName = "Scriptable Objects/DataTable/WeaponNormalTableSO", order = 0)]
    public class WeaponNormalTableSO : DataTableSO
    {
        private Dictionary<int, WeaponNormalData> _weaponData;
        
        protected override void FromJson(string json)
        {
            List<WeaponNormalData> list = JsonConvert.DeserializeObject<List<WeaponNormalData>>(json);

            Logger.Assert(list != null, "WeaponNormalTable", "무기 (일반형) 데이터 테이블이 비어있습니다.");
            
            _weaponData = new Dictionary<int, WeaponNormalData>(list.Count);
            foreach (WeaponNormalData data in list)
            {
                _weaponData.TryAdd(data.WeaponId, data);
            }
        }

        public WeaponNormalData Get(int weaponId)
        {
            if (!_weaponData.ContainsKey(weaponId))
            {
                Logger.LogError("WeaponNormalTableSO", $"{weaponId} 데이터가 존재하지 않습니다.");
                return null;
            }
            return _weaponData[weaponId];
        }
    }
}