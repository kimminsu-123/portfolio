using System.Linq.Expressions;
using ProjectAAA.Core.Timer;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace ProjectAAA.UI.MainFight
{
    public class ItemCollectElementUI : CollectElementUI<ItemCollectData>
    {
        [SerializeField] private TMP_Text nameText;
        [SerializeField] private Image colorTagImage;
        [SerializeField] private Image iconImage;
        [SerializeField] private Image gaugeImage;
        [SerializeField] private float visibleDuration = 1f;

        private CooldownTimer _timer;

        private void Update()
        {
            _timer?.Tick(Time.deltaTime);
        }
        
        protected override void OnSetup(ItemCollectData data)
        {
            gaugeImage.fillAmount = 0f;
            nameText.text = data.Name;
            colorTagImage.color = data.HighlightColor;
            iconImage.sprite = data.Icon;
            
            _timer ??= new CooldownTimer(visibleDuration);
            _timer.SetTime(visibleDuration);
            _timer.OnTickCallback = OnTickTimer;
            _timer.OnCompleteCallback = () =>
            {
                NeedHide = true;
            };
        }

        protected override void OnCompletedShow()
        {
            _timer.Start();
        }

        protected override void OnCompletedHide()
        {
            _timer.Stop();
        }

        private void OnTickTimer()
        {
            gaugeImage.fillAmount = 1f - _timer.CurrentTime / _timer.Time;
        }
    }
}