using System;
using ProjectAAA.Core.Managers;
using ProjectAAA.UI;
using UnityEngine;
using EventType = ProjectAAA.Core.Managers.EventType;

namespace ProjectAAA.Core.Entity
{
    /// <summary>
    /// 미니맵에 표현될 오브젝트에 대한 컴포넌트입니다.
    /// 기본적으로 이동에 대한것은 자동으로 연결되나 Active, InActive 는 수동으로 진행해야합니다.
    /// </summary>

    public enum MinimapObjectMode
    {
        Radar = 0,
        TargetPoint,
        Both
    }

    public class MinimapObject : MonoBehaviour
    {
        [field: SerializeField] public MinimapObjectMode Mode { get; private set; }
        [field: SerializeField] public MinimapRadarData RadarData { get; private set; }
        [field: SerializeField] public MinimapTargetPointData TargetPointData { get; private set; }

        private MinimapUI MinimapUI => UiManager.Instance.Get<MinimapUI>();
        private bool _initialized = false;

        private void Awake()
        {
            EventManager.Instance.AddListener(EventType.OnEndLoadSceneGroup, OnLoadedSceneGroup);
        }

        private void OnDestroy()
        {
            EventManager.Instance.RemoveListener(EventType.OnEndLoadSceneGroup, OnLoadedSceneGroup);
        }

        private void OnLoadedSceneGroup(Component sender, object[] args)
        {
            _initialized = true;
        }

        private void OnDisable()
        {
            if (!_initialized) return;
            if (MinimapUI == null) return;
            if (!MinimapUI.IsValid) return;
            
            switch (Mode)
            {
                case MinimapObjectMode.Radar:
                    MinimapUI.RemoveRadar(transform);
                    break;
                case MinimapObjectMode.TargetPoint:
                    MinimapUI.RemoveTargetPoint(transform);
                    break;
                case MinimapObjectMode.Both:
                    MinimapUI.RemoveRadar(transform);
                    MinimapUI.RemoveTargetPoint(transform);
                    break;
            }
        }

        private void Update()
        {
            if (!_initialized) return;
            if (MinimapUI == null) return;
            if (!MinimapUI.IsValid)
            {
                enabled = false;
                return;
            }
            
            if (MinimapUI.IsInMinimapBoundary(transform))
            {
                if (Mode is MinimapObjectMode.TargetPoint or MinimapObjectMode.Both && !MinimapUI.HasTargetPoint(transform))
                {
                    MinimapUI.AddTargetPoint(transform, TargetPointData);
                }
                
                if (Mode is MinimapObjectMode.Radar or MinimapObjectMode.Both)
                {
                    MinimapUI.RemoveRadar(transform);
                }
            }
            else
            {
                if (Mode is MinimapObjectMode.TargetPoint or MinimapObjectMode.Both)
                {
                    MinimapUI.RemoveTargetPoint(transform);
                }
                
                if (Mode is MinimapObjectMode.Radar or MinimapObjectMode.Both && !MinimapUI.HasRadar(transform))
                {
                    MinimapUI.AddRadar(transform, RadarData);
                }
            }
        }
    }
}