using System;
using DG.Tweening;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace ProjectAAA.UI
{
    public class StageUI : UiBase
    {
        protected override Type RegisterType => typeof(StageUI);

        [SerializeField] private Image processFillImg;
        [SerializeField] private TMP_Text processPercentText;
        [SerializeField] private TMP_Text waveText;

        private Tweener _sliderTweener;
        
        private void Start()
        {
            Hide();
        }

        public override void Hide()
        {
            _sliderTweener?.Kill();
            gameObject.SetActive(false);
        }
        
        public override void Show()
        {
            gameObject.SetActive(true);
        }
        
        public void SetProcess(int curValue, int maxValue)
        {
            if (maxValue <= 0)
            {
                processFillImg.fillAmount = 0f;
                processPercentText.text = $"0 %";
                return;
            }
            
            float ratio = (float)curValue / maxValue;

            _sliderTweener?.Kill();
            _sliderTweener = processFillImg.DOFillAmount(ratio, 0.15f)
                .SetEase(Ease.OutCirc)
                .SetAutoKill(true)
                .Play();
            processPercentText.text = $"{ratio * 100f:F0} %";
        }
        
        public void SetCurrentWaveIndex(int waveIndex, int maxWaveIndex)
        {
            if (waveIndex == -1)
            {
                waveText.text = string.Empty;
                return;
            }
            waveText.text = $"{waveIndex} / {maxWaveIndex}";
        }
    }
}