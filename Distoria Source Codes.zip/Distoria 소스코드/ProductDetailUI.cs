using System;
using ProjectAAA.Utils;
using TMPro;
using UniRx;
using UnityEngine;
using UnityEngine.UI;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.UI.Shop
{
    public class ProductDetailUI : MonoBehaviour
    {
        [SerializeField] private Vector2 offset = new Vector2(20f, -20f);
        [SerializeField] private Image blockImg;
        [SerializeField] private TMP_Text blockText;
        [SerializeField] private Image iconImg;
        [SerializeField] private TMP_Text nameText;
        [SerializeField] private TMP_Text descText;
        [SerializeField] private TMP_Text sellCountText;
        
        private CanvasScaler _parentCanvasScaler;

        private ReactiveProperty<ProductRow> CachedRowData
        {
            get
            {
                if (_cachedRowData == null)
                {
                    _cachedRowData = new ReactiveProperty<ProductRow>();
                    _cachedRowData.Subscribe(UpdateBlock);
                    _cachedRowData.Subscribe(UpdateInfo);
                }
                return _cachedRowData;
            }
        }

        private ReactiveProperty<ProductRow> _cachedRowData;

        private void Awake()
        {
            _parentCanvasScaler = GetComponentInParent<CanvasScaler>(true);
        }

        public void Setup(ProductRow rowData)
        {
            CachedRowData.Value = rowData;

            UpdateDetail();
        }

        public void UpdateDetail()
        {
            CachedRowData.SetValueAndForceNotify(CachedRowData.Value);
        }

        private void UpdateBlock(ProductRow rowData)
        {
            if (rowData == null)
            {
                return;
            }
            
            if (CachedRowData.Value.RemainSellCount <= 0)
            {
                blockText.text = Global.Message.SoldOutMessage;
                blockImg.gameObject.SetActive(true);
            }
            else if (CachedRowData.Value.Cost > PlayerCurrencyManager.Instance.Gold.Value)
            {
                blockText.text = Global.Message.LackOfMoneyMessage;
                blockImg.gameObject.SetActive(true);
            }
            else
            {
                blockImg.gameObject.SetActive(false);
            }
        }

        private void UpdateInfo(ProductRow rowData)
        {
            if (rowData == null)
            {
                return;
            }
            
            iconImg.sprite = rowData.Icon;
            nameText.text = rowData.Name;
            descText.text = rowData.Description;
            sellCountText.text = $"{Global.Message.SellCountMessage} {rowData.RemainSellCount}";
        }
        
        public void Move(Vector2 eventDataPosition)
        {
            RectTransform rectTr = transform as RectTransform;

            float ratioX = _parentCanvasScaler.referenceResolution.x / Screen.width;
            float ratioY = _parentCanvasScaler.referenceResolution.y / Screen.height;
            
            float xMax = _parentCanvasScaler.referenceResolution.x - rectTr.sizeDelta.x;
            float yMin = rectTr.sizeDelta.y;

            Vector2 pos = eventDataPosition + offset;
            Logger.Log($"Move", $"{Screen.width} - {rectTr.sizeDelta.x} - {pos}");
            
            pos.x = Mathf.Clamp(pos.x * ratioX, 0f, xMax);
            pos.y = Mathf.Clamp(pos.y * ratioY, yMin, _parentCanvasScaler.referenceResolution.y);
            rectTr.anchoredPosition = pos;
        }
    }
}