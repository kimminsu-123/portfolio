using System;
using Cysharp.Threading.Tasks;
using ProjectAAA.Core.Entity;
using ProjectAAA.Core.Managers;
using ProjectAAA.Core.Timer;
using ProjectAAA.Player;
using ProjectAAA.SO;
using ProjectAAA.Utils;
using UnityEngine;
using Logger = ProjectAAA.Utils.Logger;

namespace ProjectAAA.WeaponSystem
{
    public enum BulletDestroyType
    {
        OverLifeTime,
        Hit
    }
    
    public abstract class BulletHitHandler : DisposeBase
    {
        public BulletBase CurrentBullet { get; private set; }
        protected LayerMask TargetLayerMask { get; private set; }
        protected float Size => CurrentBullet.BulletSize;
        protected float LifeTime => CurrentBullet.BulletLifeTime;
        protected float Speed => CurrentBullet.BulletSpeed;
        
        public class Builder<T> where T : BulletHitHandler, new()
        {
            private BulletBase _bullet;
            private LayerMask _layerMask;

            public Builder<T> SetBulletBase(BulletBase bullet)
            {
                _bullet = bullet;
                return this;
            }
            
            public Builder<T> SetLayerMask(LayerMask layerMask)
            {
                _layerMask = layerMask;
                return this;
            }
            
            public T Build() 
            {
                T handler = new T();
                handler.CurrentBullet = _bullet;
                handler.TargetLayerMask = _layerMask;
                handler.Setup();
                
                return handler;
            }
        }
        
        public int LastedHitTarget { get; private set; }
        public event Action<HitInfo> OnHitCallback;
        public event Action<HitInfo> OnHitOtherCallback;
        public event Action<BulletDestroyType> OnCompletedCallback;
        protected CooldownTimer LifeTimeTimer { get; private set; }
        
        protected BulletHitAbility BulletHitAbility { get; private set; }
        protected BulletDestroyAbility BulletDestroyAbility { get; private set; }

        protected virtual void Setup()
        {
            LifeTimeTimer = new CooldownTimer(CurrentBullet.BulletLifeTime);
            LifeTimeTimer.OnCompleteCallback += () => ProcessComplete(BulletDestroyType.OverLifeTime);

            SetupAbility();
        }

        private void SetupAbility()
        {
            BulletAbilityTableSO table = DatabaseManager.Instance.GetTable<BulletAbilityTableSO>();
            int abilityId = CurrentBullet.AbilityID;
            
            BulletHitAbility = table.CreateHitAbility(abilityId, this);
            BulletDestroyAbility = table.CreateDestroyAbility(abilityId, CurrentBullet);
        }

        public virtual void Init()
        {
            LifeTimeTimer.SetTime(LifeTime);
            LifeTimeTimer.Start();
            
            LastedHitTarget = -1;
            
            BulletHitAbility.Init();
        }

        public void Shoot(Vector3 origin)
        {
            ProcessShoot(origin);
        }

        public async UniTask Update(float deltaTime)
        {
            if (LifeTimeTimer.IsRunning)
            {
                LifeTimeTimer.Tick(deltaTime);

                await ProcessUpdate(deltaTime);
            }
        }

        public async UniTask ProcessHit(HitInfo info)
        {
            CurrentBullet.CurrentHitInfo = info;

            if (BulletHitAbility.IsDoneAll)
            {
                await ProcessComplete(BulletDestroyType.Hit);
            }
            
            OnHitCallback?.Invoke(info);
            await BulletHitAbility.OnHit(info);

            int currentTargetHash = info.Target.GetHashCode();
            if (info.Target.TryGetComponent(out HurtBox hurtBox))
            {
                currentTargetHash = hurtBox.RootHash;
            }

            if (currentTargetHash != LastedHitTarget)
            {
                OnHitOtherCallback?.Invoke(info);
                await BulletHitAbility.OnHitOther(info);
            }

            LastedHitTarget = currentTargetHash;
        }

        public async UniTask ProcessComplete(BulletDestroyType type)
        {
            LifeTimeTimer.Stop();
            await BulletDestroyAbility.OnDestroy(type);
            
            OnCompletedCallback?.Invoke(type);
        }
        
        protected abstract UniTask ProcessShoot(Vector3 origin);
        protected abstract UniTask ProcessUpdate(float deltaTime);
    }
}