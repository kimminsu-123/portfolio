using System;
using System.Collections.Generic;
using System.Linq;
using ProjectAAA.SO;
using ProjectAAA.Utils;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using Logger = ProjectAAA.Utils.Logger;
using SceneReference = ProjectAAA.Utils.SceneReference;

namespace ProjectAAA.Core.Managers
{
    public class LoadingManager : SingletonMonoBehavior<LoadingManager>
    {
        public SceneGroupSO CurrentSceneGroup { get; private set; }
        
        [SerializeField] private float loadInterval = 0.2f;
        [SerializeField] private float delay = 1f;
        [SerializeField] private SceneGroupSO initializeSceneGroup;
        [SerializeField] private Slider loadingSlider;
        [SerializeField] private TMP_Text loadingText;
        [SerializeField] private GameObject loadingUI;
        [SerializeField] private GameObject uiCamera;
        
        private readonly Dictionary<SceneReference, SceneProfile> _loadedScenes = new();
        private Dictionary<int, FMOD_SurfaceSoundData> _soundDatas = new();
        
        private int _loadingCount;

        protected override async void Initialize()
        {
            await LoadSceneGroupAsync(initializeSceneGroup);
        }

        public async Awaitable LoadSceneGroupAsync(SceneGroupSO sceneGroup, bool reloadLoadedScene = false)
        {
            Logger.Log("LoadingManager", $"씬 그룹 로딩을 시작합니다. {sceneGroup}", Color.magenta);
            
            if (sceneGroup == null)
            {
                sceneGroup = initializeSceneGroup;
            }

            if (sceneGroup.Count <= 0)
            {
                return;
            }
            
            EventManager.Instance.PostNotification(EventType.OnBeginLoadSceneGroup, this, CurrentSceneGroup, sceneGroup);

            CurrentSceneGroup = sceneGroup;
            uiCamera.SetActive(true);
            loadingUI.SetActive(true);

            await CompileShader(sceneGroup);
            await UnloadScenesAsync(sceneGroup, reloadLoadedScene);
            await LoadSceneAsync(sceneGroup, 0);
            SoundManager.Instance.PlayBGM(sceneGroup.BGMSoundInfo);
        }

        private Awaitable GetSoundData()
        {
            SurfaceSoundData[] data = FindObjectsByType<SurfaceSoundData>(FindObjectsInactive.Include, FindObjectsSortMode.None);
            
            foreach (SurfaceSoundData obj in data)
            {
                _soundDatas.Add(obj.HashCode, obj.SoundData);
            }
            
            SoundManager.Instance.InitSound(_soundDatas);
            _soundDatas.Clear();

            return Awaitable.NextFrameAsync();
        }

        private async Awaitable CompileShader(SceneGroupSO sceneGroup)
        {
            if (sceneGroup.ShaderVariantCollection == null) return;

            ShaderVariantCollection collection = sceneGroup.ShaderVariantCollection;
            
            loadingText.text = "쉐이더 컴파일 중...";
            loadingSlider.value = 0f;
            loadingSlider.maxValue = 1f;

            bool completed = collection.WarmUpProgressively(1);
            while (!completed)
            {
                completed = collection.WarmUpProgressively(1);

                int variantCount = collection.variantCount;
                int warmUpCount = collection.warmedUpVariantCount;
                loadingSlider.value = (float) warmUpCount / variantCount;
                
                await Awaitable.NextFrameAsync();
            }
        }

        private async Awaitable LoadSceneAsync(SceneGroupSO sceneGroup, int index)
        {
            if (index >= sceneGroup.Count)
            {
                await PostCompletedSceneGroup();
                return;
            }

            SceneProfile profile = sceneGroup.SceneProfiles[index];
            
            _loadingCount++;

            if (!_loadedScenes.ContainsKey(profile.SceneRef))
            {
                AsyncOperation operation = profile.Load(LoadSceneMode.Additive);

                float prev = 0f;
                float current = 0f;
                while (!operation.isDone)
                {
                    float diff = current - prev;
                    float speed = diff / 0.9f;
                    loadingSlider.value = Mathf.Lerp(loadingSlider.value, _loadingCount, Time.deltaTime * speed);                
                
                    current = operation.progress;
                
                    await Awaitable.NextFrameAsync();
                }
            
                if (profile.IsActive)
                {
                    SceneManager.SetActiveScene(SceneManager.GetSceneByBuildIndex(profile.SceneRef.BuildIndex));
                }

                if (profile.Type != SceneType.System)
                {
                    CurrentSceneGroup = sceneGroup;
                }
            
                _loadedScenes.Add(profile.SceneRef, profile);
            }
            
            await FillRemainProgressAsync(loadingSlider.value, _loadingCount, 2f);
            await Awaitable.WaitForSecondsAsync(loadInterval);
            await LoadSceneAsync(sceneGroup, index + 1);
        }

        private async Awaitable PostCompletedSceneGroup()
        {
            await GetSoundData();
            await FillRemainProgressAsync(loadingSlider.value, _loadingCount, 2f);
            
            EventManager.Instance.PostNotification(EventType.OnEndLoadSceneGroup, this);
            await Awaitable.WaitForSecondsAsync(delay);
            EventManager.Instance.PostNotification(EventType.OnEndDelayAfterLoadScene, this);

            uiCamera.SetActive(false);
            loadingUI.SetActive(false);
        }

        private async Awaitable UnloadScenesAsync(SceneGroupSO sceneGroup, bool reloadLoadedScene = false)
        {            
            loadingText.text = "씬 로딩 중...";
            _loadingCount = 0;
            loadingSlider.value = 0;
            loadingSlider.maxValue = sceneGroup.Count;
            
            SceneProfile[] profiles = _loadedScenes.Values.ToArray();

            for (int i = profiles.Length - 1; i >= 0; i--)
            {
                SceneProfile profile = profiles[i];
                SceneReference scene = profile.SceneRef;
                
                if (profile.Type == SceneType.System) continue;
                if (!reloadLoadedScene && sceneGroup.Contains(scene)) continue;
                
                _loadingCount++;
                loadingSlider.maxValue = _loadingCount; 
                
                AsyncOperation operation = SceneManager.UnloadSceneAsync(scene.BuildIndex);
                float prev = 0f;
                float current = 0f;
                while (!operation.isDone)
                {
                    float diff = current - prev;
                    float speed = diff / 0.9f;
                    loadingSlider.value = Mathf.Lerp(loadingSlider.value, _loadingCount, Time.deltaTime * speed);                
            
                    current = operation.progress;
            
                    await Awaitable.NextFrameAsync();
                }
                _loadedScenes.Remove(scene); 
            }
        }

        private async Awaitable FillRemainProgressAsync(float from, float to, float speed)
        {
            float t = 0f;
            while (t < 1f)
            {
                t += Time.deltaTime * speed;
                
                loadingSlider.value = Mathf.Lerp(from, to, t);
                
                await Awaitable.NextFrameAsync();
            }
        }
    }
}