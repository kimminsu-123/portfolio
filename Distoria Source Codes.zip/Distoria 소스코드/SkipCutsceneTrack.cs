using ProjectAAA.UI;
using UnityEngine;
using UnityEngine.Playables;
using UnityEngine.Timeline;

namespace ProjectAAA.Timeline
{
    [TrackClipType(typeof(SkipCutsceneAsset))]
    [TrackBindingType(typeof(SkipUI))]
    public class SkipCutsceneTrack : TrackAsset
    {
        public override Playable CreateTrackMixer(PlayableGraph graph, GameObject go, int inputCount)
        {
            if (hasClips)
            {
                foreach (TimelineClip clip in GetClips())
                {
                    SkipCutsceneAsset asset = clip.asset as SkipCutsceneAsset;
                    if (asset != null)
                    {
                        asset.skipTime = clip.end;
                    }
                }
            }

            return base.CreateTrackMixer(graph, go, inputCount);
        }
    }
}