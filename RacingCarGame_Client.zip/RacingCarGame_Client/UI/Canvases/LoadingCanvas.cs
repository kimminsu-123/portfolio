using UnityEngine;

public class LoadingCanvas : MonoBehaviour
{
}