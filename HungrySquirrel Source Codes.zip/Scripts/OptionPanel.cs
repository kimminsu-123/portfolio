﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class OptionPanel : MonoBehaviour
{
    public Slider BGMSlider;
    public Text BGMText;

    public Slider effectSlider;
    public Text effectText;

    public Dropdown resolutionDropdown;
    private Resolution[] resolutions;
    private int currResolutionIndex = 0;

    public Dropdown qualityDropDown;
    public Toggle fullScreenToggle;

    void Start()
    {
        Init();
    }

    private void Init()
    {
        if(AudioManager.Instance != null)
        {
            BGMSlider.value = AudioManager.Instance.sourceBGM.volume;
            effectSlider.value = AudioManager.Instance.source.volume;
        }
        else
        {
            BGMSlider.value = GameObject.FindWithTag("EffectSource").GetComponent<SourceEffect>().GetValue();
            effectSlider.value = GameObject.FindWithTag("BGMSource").GetComponent<SourceBGM>().GetValue();
        }
        SetResolution();

        SetQuality(ValueSender.instance.qualityIndex);
        SetFullscreen(Screen.fullScreen);
        SetResolution(ValueSender.instance.resolutionIndex);

        UpdateText();
    }

    private void SetResolution()
    {
        resolutions = Screen.resolutions;

        resolutionDropdown.ClearOptions();

        List<string> options = new List<string>();

        for(int i = 0; i < resolutions.Length; i++)
        {
            string option = $"{resolutions[i].width} x {resolutions[i].height}";
            options.Add(option);

            if (resolutions[i].width == Screen.currentResolution.width &&
                resolutions[i].height == Screen.currentResolution.height)
            {
                currResolutionIndex = i;
            }
        }

        resolutionDropdown.AddOptions(options);
    }

    private void UpdateText()
    {
        BGMText.text = $"{(BGMSlider.value * 100f).ToString("00.0")}%";
        effectText.text = $"{(effectSlider.value * 100f).ToString("00.0")}%";
    }

    public void OnBGMChange()
    {
        AudioManager.Instance.SetVolumeBGM(BGMSlider.value);
        UpdateText();
    }

    public void OnEffectChange()
    {
        AudioManager.Instance.SetVolumeEffectSound(effectSlider.value);
        UpdateText();
    }

    public void OnBGMChangeMain()
    {
        GameObject.FindWithTag("BGMSource").GetComponent<SourceBGM>().SetValue(BGMSlider.value);
        UpdateText();
    }

    public void OnEffectChangeMain()
    {
        GameObject.FindWithTag("EffectSource").GetComponent<SourceEffect>().SetValue(effectSlider.value);
        UpdateText();
    }

    public void SetQuality(int qualityIndex)
    {
        QualitySettings.SetQualityLevel(qualityIndex);

        resolutionDropdown.RefreshShownValue();
        qualityDropDown.value = qualityIndex;

        ValueSender.instance.SetQuality(qualityIndex);
    }

    public void SetResolution(int resolutionIndex)
    {
        Resolution resolution = resolutions[resolutionIndex];
        Screen.SetResolution(resolution.width, resolution.height, Screen.fullScreen);

        resolutionDropdown.value = resolutionIndex;
        resolutionDropdown.RefreshShownValue();

        ValueSender.instance.SetResolution(resolutionIndex);
    }

    public void SetFullscreen(bool isFullscreen)
    {
        Screen.fullScreen = isFullscreen;

        fullScreenToggle.isOn = isFullscreen;
    }
}
