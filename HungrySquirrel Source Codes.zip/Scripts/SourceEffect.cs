﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SourceEffect : MonoBehaviour
{
    private AudioSource source;

    private static SourceEffect instance;
    private void Awake()
    {
        if (instance != null)
            Destroy(gameObject);
        else
            instance = this;

        DontDestroyOnLoad(gameObject);
        source = GetComponent<AudioSource>();
    }

    public void OneShotPlay(AudioClip clip)
    {
        source.PlayOneShot(clip);
    }

    public void Play(AudioClip clip)
    {
        source.clip = clip;
        source.Play();
    }

    public void Pause(bool isPause)
    {
        if (isPause)
            source.Pause();
        else
            source.UnPause();
    }

    public void Stop()
    {
        source.Stop();
    }

    public float GetValue()
    {
        return source.volume;
    }

    public void SetValue(float value)
    {
        source.volume = value;
    }
}
