﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ValueSender : MonoBehaviour
{
    public static ValueSender instance;
    private void Awake()
    {
        if (instance != null)
            Destroy(gameObject);
        else
            instance = this;

        DontDestroyOnLoad(gameObject);
    }

    public int qualityIndex = 2;
    public void SetQuality(int index)
    {
        qualityIndex = index;
    }

    public int resolutionIndex = 19;
    public void SetResolution(int index)
    {
        resolutionIndex = index;
    }
}
