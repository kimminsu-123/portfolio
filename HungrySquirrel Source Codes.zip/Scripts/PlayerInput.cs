﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerInput : MonoBehaviour
{
    public float H
    {
        get;
        private set;
    }

    public float V
    {
        get;
        private set;
    }

    public bool IsDash
    {
        get;
        private set;
    }

    public bool Interation
    {
        get;
        private set;
    }

    public bool IsMove
    {
        get
        {
            if (H != 0f || V != 0f)
                return true;

            return false;
        }
    }

    private void Start()
    {
        EventManager.Instance.AddListener(EventType.OnPause, OnGameStatusChanged);
        EventManager.Instance.AddListener(EventType.EatFoodBegin, OnGameStatusChanged);
        EventManager.Instance.AddListener(EventType.EatFoodEnd, OnGameStatusChanged);
    }

    void Update()
    {
        if (GameManager.Instance.IsGameover)
            return;

        if (Input.GetKeyDown(KeyCode.Escape))
        {
            GameManager.Instance.Pause = !GameManager.Instance.Pause;
        }

        if (GameManager.Instance.Pause)
            return;

        H = Input.GetAxis("Horizontal");
        V = Input.GetAxis("Vertical");

        IsDash = Input.GetKey(KeyCode.LeftShift) && IsMove;

        Interation = Input.GetKeyDown(KeyCode.Z) && canEat;
    }

    private bool canEat = true;
    private void OnGameStatusChanged(EventType et, Component sender, object args = null)
    {
        switch (et)
        {
            case EventType.EatFoodBegin:
                canEat = false;
                break;

            case EventType.EatFoodEnd:
                canEat = true;
                break;

            case EventType.OnPause:
                var pause = (bool)args;
                if (pause)
                {
                    H = 0f;
                    V = 0f;
                }
                break;
        }
    }
}
