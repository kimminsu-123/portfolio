﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public enum Direction
{
    Up,
    Down,
    Horizontal,
}
public class PlayerMovement : MonoBehaviour
{
    [Header("대쉬 게이지")]
    public float maxDashGauge;
    public float dashPerSec;
    private float currDashGauge;
    public float CurrDashGauge
    {
        get
        {
            return currDashGauge;
        }
        private set
        {
            currDashGauge = value;

            if (UIManager.Instance == null)
                return;

            UIManager.Instance.playerInfoPanel.UpdateDashGauge(CurrDashGauge / maxDashGauge);
        }
    }
    public float feelDashPerSec;
    private float feelDashTimer;

    [Header("이동")]
    private float currSpeed;
    public float CurrSpeed
    {
        get
        {
            return currSpeed;
        }
        private set
        {
            currSpeed = value;
        }
    }
    public float defaultSpeed;
    public float dashSpeed;

    private PlayerInput playerInput;
    private Rigidbody2D cachedRg;
    private Transform cachedTr;
    private SpriteRenderer sr;

    public bool CanMove {
        get;
        private set;
    }

    private void Awake()
    {
        playerInput = GetComponent<PlayerInput>();

        cachedRg = GetComponent<Rigidbody2D>();
        cachedTr = GetComponent<Transform>();

        sr = GetComponent<SpriteRenderer>();

        boxCol = GetComponent<BoxCollider2D>();
    }

    void Start()
    {
        CurrDashGauge = maxDashGauge;
        CanMove = true;

        if(EventManager.Instance != null)
        {
            EventManager.Instance.AddListener(EventType.EatFoodBegin, OnGameStatusChanged);
            EventManager.Instance.AddListener(EventType.EatFoodEnd, OnGameStatusChanged);
            EventManager.Instance.AddListener(EventType.OnChangedRainbow, OnGameStatusChanged);
            EventManager.Instance.AddListener(EventType.OnPause, OnGameStatusChanged);
        }

        saveSpeed = defaultSpeed;
        saveDash = dashSpeed;
    }

    void Update()
    {
        if (GameManager.Instance.Pause)
            return;

        FeelDash();
        SetDirection();
    }

    private void FixedUpdate()
    {
        if (GameManager.Instance.Pause)
            return;

        //movement
        if (!CanMove)
        {
            cachedRg.velocity = Vector2.zero;
            return;
        }

        CurrSpeed = defaultSpeed;
        
        if (playerInput.IsDash)
        {
            Dash();
        }

        Move();
    }

    private void Move()
    {
        var h = playerInput.H;
        var v = playerInput.V;

        var dir = new Vector2(h, v);
        var velocity = dir * CurrSpeed;

        if (h != 0f)
            sr.flipX = h > 0f ? true : false;

        cachedRg.velocity = velocity;
    }

    private void Dash()
    {
        //Check DashGauge
        if (CurrDashGauge <= 0 || isRainbow)
            return;

        //ChangeCurrSpeed
        CurrSpeed = dashSpeed;

        //Update Gauge
        var dashValue = dashPerSec * Time.fixedDeltaTime * GameManager.Instance.TimeScale;
        CurrDashGauge = Mathf.Max(CurrDashGauge - dashValue, 0f);
    }

    private void FeelDash()
    {
        //Check Dash
        if (playerInput.IsDash)
        {
            feelDashTimer = 0f;
            return;
        }

        //Check Timer
        feelDashTimer += Time.deltaTime * GameManager.Instance.TimeScale;
        if (feelDashTimer < 1f)
            return;

        //Feel Dash
        var feelAmount = feelDashPerSec * Time.deltaTime * GameManager.Instance.TimeScale;
        CurrDashGauge = Mathf.Min(CurrDashGauge + feelAmount, maxDashGauge);
    }

    private bool isRainbow = false;
    private void OnGameStatusChanged(EventType et, Component sender, object args = null)
    {
        switch (et)
        {
            case EventType.Opening:
                break;
            case EventType.EatFoodBegin:
                CanMove = false;
                break;
            case EventType.EatFoodEnd:
                CanMove = true;
                break;
            case EventType.Story:
                break;
            case EventType.Gameover:
                break;
            case EventType.OnChangedRainbow:
                isRainbow = (bool)args;
                if (isRainbow)
                {
                    ChangeSpeed(dashSpeed, dashSpeed);
                }
                else
                {
                    ChangeSpeed(saveSpeed, saveDash);
                }
                break;

            case EventType.OnPause:
                var pause = (bool)args;
                if (pause)
                {
                    cachedRg.velocity = Vector2.zero;
                }
                break;
        }
    }
    private BoxCollider2D boxCol;
    private Vector2 currDir;
    public Vector2 GetDirection()
    {
        if(playerInput.H != 0f || playerInput.V != 0f)
        {
            currDir = new Vector2(playerInput.H, playerInput.V);
        }

        return currDir;
    }

    public Direction DirEnum
    {
        get;
        private set;
    }
    public void SetDirection()
    {
        var dir = GetDirection();

        if(dir.y > 0f)
        {
            var yAbs = Mathf.Abs(dir.y);
            var xAbs = Mathf.Abs(dir.x);
            DirEnum = yAbs < xAbs ? Direction.Horizontal : Direction.Up;
        }

        else
        {
            var yAbs = Mathf.Abs(dir.y);
            var xAbs = Mathf.Abs(dir.x);
            DirEnum = yAbs < xAbs? Direction.Horizontal : Direction.Down;
        }

        SetColliderRange();
    }

    private void SetColliderRange()
    {
        Vector2 size = boxCol.size;
        Vector2 offset = boxCol.offset;
        switch (DirEnum)
        {
            case Direction.Horizontal:
                offset.x = -0.3f;
                offset.y = 0.3f;
                size.x = 1f;
                size.y = 0.5f;
                break;
            case Direction.Down:
                offset.x = -0.05f;
                offset.y = 0.3f;                                       
                size.x = 0.45f;
                size.y = 0.5f;
                break;
            case Direction.Up:
                offset.x = 0f;
                offset.y = 0.8f;
                size.x = 0.5f;
                size.y = 0.8f;
                break;
        }
        boxCol.size = size;
        boxCol.offset = offset;
    }
    private float minSpeed;
    private float minDash;

    [HideInInspector]
    public float saveSpeed;
    [HideInInspector]
    public float saveDash;
    public void ChangeSpeed(float speed, float dash)
    {
        defaultSpeed = Mathf.Max(speed, minSpeed);
        dashSpeed = Mathf.Max(dash, minDash);
    }

    public void SetMinSpeed(float speed, float dash)
    {
        minSpeed = speed;
        minDash = dash;
    }
}
