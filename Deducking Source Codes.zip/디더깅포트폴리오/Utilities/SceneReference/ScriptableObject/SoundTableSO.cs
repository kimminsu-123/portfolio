using System;
using System.Collections.Generic;
using UnityEngine;

namespace DeDucking.Utilities
{
    [Serializable]
    public class AudioData
    {
        [SerializeField] private int id;
        [SerializeField] private AudioClip clip;
        [SerializeField] private string description;

        public int ID => id;
        public AudioClip Clip => clip;
        public string Description => description;
    }
    
    [CreateAssetMenu(fileName = "SoundTableSO", menuName = "Assets/SO/SoundTable", order = 3)]
    public class SoundTableSO : ScriptableObject
    {
        [SerializeField] private AudioData[] audioClips;
        
        public AudioData[] AudioClips => audioClips;

        private Dictionary<int, AudioClip> _hashClips;

        public void Initialize()
        {
            _hashClips = new Dictionary<int, AudioClip>();
            foreach (var data in audioClips)
            { 
                _hashClips.Add(data.ID, data.Clip);
            }
        }
        
        public AudioClip GetAudio(int id)
        {
            if (_hashClips.ContainsKey(id))
            {
                return _hashClips[id];
            }
            return null;
        }
    }
}