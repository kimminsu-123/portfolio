﻿using System.Collections.Generic;
using UnityEngine;

namespace DeDucking.Utilities
{
    [CreateAssetMenu(fileName = "ObjectPoolDataSO", menuName = "Assets/SO/ObjectPoolData", order = 2)]
    public class ObjectPoolDataSO : ScriptableObject
    {
        public bool IsEmpty => _poolObjs.Count <= 0;
        
        [SerializeField] private int defaultCount;
        [SerializeField] private int addCount;
        [SerializeField] private GameObject prefab;

        private Transform _parent;
        
        private readonly Queue<IPoolObj> _poolObjs = new();

        public void SetupPool(Transform parent)
        {
            _parent = parent;
            
            for (int i = 0; i < defaultCount; i++)
            {
                var instance = Instantiate(prefab, parent);
                instance.transform.localPosition = Vector3.zero;
                instance.transform.localRotation = Quaternion.identity;
                instance.SetActive(false);
                
                _poolObjs.Enqueue(instance.GetComponent<IPoolObj>());
            }
        }

        public void UpsizeQueue()
        {
            for (int i = 0; i < addCount; i++)
            {
                var instance = Instantiate(prefab, _parent);
                instance.transform.localPosition = Vector3.zero;
                instance.transform.localRotation = Quaternion.identity;
                instance.SetActive(false);
                
                _poolObjs.Enqueue(instance.GetComponent<IPoolObj>());
            }
        }

        public T GetQueue<T>(Transform parent) where T : class, IPoolObj
        {
            if (IsEmpty)
            {
                UpsizeQueue();
            }

            var go = _poolObjs.Dequeue();
            go.SetParent(parent);
            go.SetPosition(Vector3.zero, Space.Self);
            go.SetRotation(Quaternion.identity, Space.Self);
            go.Active();
            go.OnGet();

            return (go as T);
        }

        public void ReturnQueue(IPoolObj obj)
        {
            obj.OnRelease();
            
            obj.SetParent(_parent);
            obj.SetPosition(Vector3.zero, Space.Self);
            obj.SetRotation(Quaternion.identity, Space.Self);
            obj.Inactive();

            _poolObjs.Enqueue(obj);
        }

        public void Clear()
        {
            _poolObjs.Clear();
        }
    }
}