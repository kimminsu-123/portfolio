﻿using System;
using System.Collections.Generic;
using System.Linq;
using Spine;
using Spine.Unity;
using UnityEngine;
using UnityEngine.Events;

namespace DeDucking.Utilities
{
    [Serializable]
    public class SpineEvent
    {
        [SerializeField, Range(0f, 1f)] private float normalizeTime;
        [SerializeField] private UnityEvent callbacks;
        [SerializeField] private bool isLoopCall = true;
        
        public float NormalizeTime => normalizeTime;
        public UnityEvent Callbacks => callbacks;
        public bool IsLoopCall => isLoopCall;
        public bool HasCalled { get; set; } = false;
    }
    
    public class SpineEventRegister : MonoBehaviour
    {
        [SerializeField] private SerializableDictionary<AnimationReferenceAsset, List<SpineEvent>> spineEvents;
        
        [SerializeField] private SkeletonAnimation skeletonAnimation;
        private TrackEntry _currentTrackEntry;
        private List<SpineEvent> _currentEvents;

        private void Update()
        {
            Process();
        }

        private void Process()
        {
            var nextTrackEntry = skeletonAnimation.AnimationState.GetCurrent(0);
            
            if (_currentTrackEntry != nextTrackEntry)
            {
                if (_currentTrackEntry != null)
                {
                    _currentTrackEntry.Complete -= OnCompletedAnimation;
                }
                
                // 이전 이벤트 초기화
                if (_currentEvents != null)
                {
                    foreach (var spineEvent in _currentEvents)
                    {
                        spineEvent.HasCalled = false;
                    }
                }
                _currentTrackEntry = nextTrackEntry;
                if(_currentTrackEntry != null)
                {
                    _currentTrackEntry.Complete += OnCompletedAnimation;
                }
            }

            if (_currentTrackEntry != null)
            {
                CallEventByNormalizedTime();
            }
        }

        private void CallEventByNormalizedTime()
        {
            _currentEvents = GetEvent();
            if (_currentEvents == null)
            {
                return;
            }
            
            var normalizedTime = _currentTrackEntry.AnimationTime / _currentTrackEntry.Animation.Duration;

            foreach (var spineEvent in _currentEvents)
            {
                if (spineEvent.NormalizeTime <= normalizedTime && !spineEvent.HasCalled)
                {
                    spineEvent.HasCalled = true;
                    spineEvent.Callbacks?.Invoke();
                }
            }
        }

        private List<SpineEvent> GetEvent()
        {
            var currentTrack = skeletonAnimation.AnimationState.GetCurrent(0);
            if (currentTrack == null)
            {
                return null;
            }
            
            var animationName = currentTrack.Animation.Name;
            var key = spineEvents.Keys.FirstOrDefault(x => x.Animation.Name.Equals(animationName));

            return key == null ? null : spineEvents[key];
        }

        private void OnCompletedAnimation(TrackEntry trackEntry)
        {
            if (_currentEvents == null) return;
            
            foreach (var spineEvent in _currentEvents)
            {
                if (!spineEvent.HasCalled)
                {
                    spineEvent.Callbacks?.Invoke();
                    spineEvent.HasCalled = true;
                }

                if (!spineEvent.IsLoopCall)
                {
                    return;
                }
                
                spineEvent.HasCalled = !_currentTrackEntry.Loop;    
            }
        }
    }
}