﻿using UnityEditor;
using UnityEngine;
using Spine.Unity;

namespace DeDucking.Utilities
{
    [CustomEditor(typeof(SpineEventRegister))]
    public class SpineEventRegisterEditor : UnityEditor.Editor
    {
        private float _normalizedTime = 0f;
        private float _prevNormalizedTime = 0f;

        public override void OnInspectorGUI()
        {
            DrawDefaultInspector();

            SpineEventRegister controller = (SpineEventRegister)target;

            EditorGUILayout.LabelField("Preview");
            _normalizedTime = EditorGUILayout.Slider(_normalizedTime, 0f, 1f);

            if (!Mathf.Approximately(_prevNormalizedTime, _normalizedTime))
            {
                SkeletonAnimation skeletonAnimation = controller.GetComponentInChildren<SkeletonAnimation>();
                var currentTrack = skeletonAnimation.AnimationState.GetCurrent(0);
                if (currentTrack != null)
                {
                    var previewTime = _normalizedTime * currentTrack.Animation.Duration;

                    currentTrack.TrackTime = previewTime;
                    skeletonAnimation.Update(0f);
                    skeletonAnimation.LateUpdate();

                    SceneView.RepaintAll();
                }
            }
            _prevNormalizedTime = _normalizedTime;
        }
    }
}