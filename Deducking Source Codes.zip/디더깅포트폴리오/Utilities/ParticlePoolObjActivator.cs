﻿using UnityEngine;

namespace DeDucking.Utilities
{
    public class ParticlePoolObjActivator : PoolObjMonoBehavior
    {
        public float Duration => _particle.main.duration;
        
        private ParticleSystem _particle;
        private CooldownTimer _cooldownTimer;

        protected override void OnAwake()
        {
            _particle = GetComponent<ParticleSystem>();
            _cooldownTimer = new CooldownTimer(Duration);
            _cooldownTimer.OnStopped += SelfReturn;
        }

        private void Update()
        {
            _cooldownTimer?.Tick(Time.deltaTime);
        }

        public void Play()
        {
            _particle.Play();
            _cooldownTimer.SetTime(Duration);
            _cooldownTimer.Start();
        }

        public void Stop()
        {
            _particle.Stop();
        }
    }
}