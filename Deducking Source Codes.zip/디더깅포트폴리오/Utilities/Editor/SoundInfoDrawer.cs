﻿using UnityEditor;
using UnityEngine;

namespace DeDucking.Utilities
{
    [CustomPropertyDrawer(typeof(SoundInfo))]
    public class SoundInfoDrawer : PropertyDrawer
    {
        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            EditorGUI.BeginProperty(position, label, property);

            var idProperty = property.FindPropertyRelative("id");
            var volumeProperty = property.FindPropertyRelative("volume");

            Rect labelRect = new Rect(position.x, position.y, position.width, EditorGUIUtility.singleLineHeight);
            Rect idRect = new Rect(position.x + 10, position.y + EditorGUIUtility.singleLineHeight + 2, position.width, EditorGUIUtility.singleLineHeight);
            Rect volumeRect = new Rect(position.x + 10, position.y + (EditorGUIUtility.singleLineHeight + 2) * 2, position.width, EditorGUIUtility.singleLineHeight);

            EditorGUI.LabelField(labelRect, label, EditorStyles.boldLabel);
            EditorGUI.PropertyField(idRect, idProperty, new GUIContent("Sound ID"));
            EditorGUI.PropertyField(volumeRect, volumeProperty, new GUIContent("Volume"));

            EditorGUI.EndProperty();
        }

        public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
        {
            return EditorGUIUtility.singleLineHeight * 3 + 6;
        }
    }
}