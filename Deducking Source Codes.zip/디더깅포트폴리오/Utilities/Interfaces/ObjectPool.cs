﻿using System;
using DeDucking.Managers;
using UnityEngine;
using EventType = DeDucking.Managers.EventType;

namespace DeDucking.Utilities
{
    public interface IPoolObj
    {
        public void SetPosition(Vector3 pos, Space space = Space.World);
        public void SetRotation(Quaternion rot, Space space = Space.World);
        public void SetParent(Transform p);
        public void Active();
        public void Inactive();
        public void OnGet();
        public void OnRelease();
    }

    public class PoolObjMonoBehavior : MonoBehaviour, IPoolObj
    {
        private enum Status
        {
            Released,
            Holding,
        }
        private ObjectPoolDataSO _originPool;
        private Status _currentStatus = Status.Released;

        private void Awake()
        {
            EventManager.Instance.AddListener(EventType.OnBeginSceneLoad, OnBeginSceneLoad);
            OnAwake();
        }

        private void OnDestroy()
        {
            EventManager.Instance.RemoveListener(EventType.OnBeginSceneLoad, OnBeginSceneLoad);
        }

        private void OnBeginSceneLoad(EventType type, Component sender, object[] args)
        {
            if (_currentStatus == Status.Holding)
            {
                _originPool?.ReturnQueue(this);
            }
        }

        public void SetPosition(Vector3 pos, Space space = Space.World)
        {
            if (space == Space.Self)
            {
                transform.localPosition = pos;
            }
            else
            {
                transform.position = pos;
            }
        }

        public void SetRotation(Quaternion rot, Space space = Space.World)
        {
            if (space == Space.Self)
            {
                transform.localRotation = rot;
            }
            else
            {
                transform.rotation = rot;
            }
        }

        public void SetParent(Transform p)
        {
            transform.SetParent(p);
        }

        public void Active()
        {
            gameObject.SetActive(true);
        }

        public void Inactive()
        {
            gameObject.SetActive(false);
        }

        public void SelfReturn()
        {
            _originPool.ReturnQueue(this);
        }

        public void SetOriginPool(ObjectPoolDataSO origin)
        {
            _originPool = origin;
        }

        protected virtual void OnAwake() { }

        public virtual void OnGet()
        {
            _currentStatus = Status.Holding;
        }

        public virtual void OnRelease()
        {
            _currentStatus = Status.Released;
        }
    }
}