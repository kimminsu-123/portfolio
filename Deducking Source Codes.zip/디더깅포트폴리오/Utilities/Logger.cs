﻿using System.Diagnostics;
using UnityEngine;
using Debug = UnityEngine.Debug;

namespace DeDucking.Utilities
{
    public static class Logger
    {
        [Conditional("ENABLED_LOGGER")]
        public static void Log(string title, string msg)
        {
            Debug.Log($"[{title}] : {msg}");
        }
        
        [Conditional("ENABLED_LOGGER")]
        public static void Log(string title, string msg, Color color)
        {
            Debug.Log($"<color=#{ColorUtility.ToHtmlStringRGBA(color)}>[{title}] : {msg}</color>");
        }
        
        [Conditional("ENABLED_LOGGER")]
        public static void LogError(string title, string msg)
        {
            Debug.LogError($"[{title}] : {msg}");
        }
        
        [Conditional("ENABLED_LOGGER")]
        public static void LogWarning(string title, string msg)
        {
            Debug.LogWarning($"[{title}] : {msg}");
        }
        
        [Conditional("ENABLED_LOGGER")]
        public static void Assert(bool condition, string title, string msg)
        {
            Debug.Assert(condition, $"[{title}] : {msg}");
        }
    }
}