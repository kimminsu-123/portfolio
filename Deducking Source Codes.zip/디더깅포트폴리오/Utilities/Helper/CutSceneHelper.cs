﻿using System;
using Cinemachine;
using UnityEngine;
using UnityEngine.Rendering.Universal;
using Utilities.Handler;

namespace DeDucking.Utilities
{
    [Serializable]
    public class BlendVCamDefinition
    {
        public CinemachineVirtualCamera toCam;
        public AnimationCurve blendCurve;
        public float duration;
    }
    
    public class CutSceneHelper : MonoBehaviour
    {
        [SerializeField] private BlendVCamDefinition[] blendDefinitions;

        private BlendVCamDefinition _currentBlendDefinition;
        private int _index;

        private void Start()
        {
            _index = 0;
        }

        public void BlendNextVirtualCam()
        {
            _index = (_index + 1) % blendDefinitions.Length;
            _currentBlendDefinition = blendDefinitions[_index];
            CameraHandler.Instance.Blend(_currentBlendDefinition.toCam, _currentBlendDefinition.blendCurve, _currentBlendDefinition.duration);
        }

        public void ResetBlending()
        {
            if (_currentBlendDefinition != null)
            {
                CameraHandler.Instance.Blend(CameraHandler.Instance.FollowCam, _currentBlendDefinition.blendCurve, _currentBlendDefinition.duration);
                _currentBlendDefinition = null;    
            }
        }

        public void ShakeCameraHigh()
        {
            CameraHandler.Instance.ShakeOtherCam(_currentBlendDefinition.toCam, CameraEffectType.High);
        }
        
        public void ShakeCameraMid()
        {
            CameraHandler.Instance.ShakeOtherCam(_currentBlendDefinition.toCam, CameraEffectType.Middle);
        }
        
        public void ShakeCameraLow()
        {
            CameraHandler.Instance.ShakeOtherCam(_currentBlendDefinition.toCam, CameraEffectType.Low);
        }

        private void OnDisable()
        {
            ResetBlending();
        }
    }
}