﻿using System;
using UnityEngine;

namespace DeDucking.Utilities
{
    public interface IDetectStrategy
    {
        public void Initialize();
        public Collider2D Execute();
        public void Release();
    }
}