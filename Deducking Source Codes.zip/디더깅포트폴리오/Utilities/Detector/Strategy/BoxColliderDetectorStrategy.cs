using UnityEngine;

namespace DeDucking.Utilities
{
    public class BoxColliderDetectorStrategy : IDetectStrategy
    {
        private readonly ObjectPoolDataSO _receiverPool;
        private readonly Transform _parent;
        private Vector2 _center;
        private Vector2 _size;
        private LayerMask _layerMask;
        
        private BoxColliderEventReceiver _receiver;
        private Collider2D _targetCollider;
        
        public BoxColliderDetectorStrategy(ObjectPoolDataSO receiverPool, Transform parent, Vector2 size, Vector2 center, LayerMask layerMask)
        {
            _receiverPool = receiverPool;
            _parent = parent;
            Setup(size, center, layerMask);
        }

        public void Setup(Vector2 size, Vector2 center, LayerMask layerMask)
        {
            _center = center;
            _size = size;
            _layerMask = layerMask;
        }
        
        private void OnExit(Collider2D other)
        {
            if (_targetCollider == null)
            {
                return;
            }

            int targetHashCode = _targetCollider.GetHashCode();
            int otherHashCode = other.GetHashCode();
            
            if (otherHashCode.Equals(targetHashCode))
            {
                _targetCollider = null;
            }
        }

        private void OnEnter(Collider2D other)
        {
            int layer = other.gameObject.layer;
            if (!_layerMask.Contains(layer))
            {
                return;
            }
            _targetCollider = other;
        }

        public void Initialize()
        {
            _receiver = _receiverPool.GetQueue<BoxColliderEventReceiver>(_parent);
            _receiver.gameObject.layer = _parent.gameObject.layer;
            _receiver.SetCenter(_center);
            _receiver.SetSize(_size);
            _receiver.onEnter.AddListener(OnEnter);
            _receiver.onExit.AddListener(OnExit);
        }

        public Collider2D Execute()
        {
            return _targetCollider;
        }

        public void Release()
        {
            _targetCollider = null;
            _receiver.onEnter.RemoveListener(OnEnter);
            _receiver.onExit.RemoveListener(OnExit);
            _receiverPool.ReturnQueue(_receiver);
        }
    }
}