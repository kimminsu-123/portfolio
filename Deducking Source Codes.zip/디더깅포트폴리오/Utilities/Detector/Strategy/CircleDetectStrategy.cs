using System;
using Unity.VisualScripting;
using UnityEngine;

namespace DeDucking.Utilities
{
    public class CircleDetectStrategy : IDetectStrategy
    {
        private readonly Transform _cachedTr;
        private readonly Vector2 _center; 
        private readonly float _radius;
        private readonly LayerMask _layerMask;
        private readonly Collider2D[] _detects;
        
        public CircleDetectStrategy(Transform cachedTr, Vector2 center, float radius, LayerMask layerMask)
        {
            _cachedTr = cachedTr;
            _center = center;
            _radius = radius;
            _layerMask = layerMask;

            _detects = new Collider2D[2];
        }

        public void Initialize()
        {
        }
        
        public Collider2D Execute()
        {
            Vector3 center = _center;
            center.x *= _cachedTr.right.x;
            
            Vector2 pos = _cachedTr.position + center;
            int count = Physics2D.OverlapCircleNonAlloc(pos, _radius, _detects, _layerMask);

            return count <= 0 ? null : _detects[0];
        }

        public void Release()
        {
        }
    }
}