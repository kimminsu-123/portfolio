﻿using System;
using UnityEngine;

namespace DeDucking.Utilities
{
    public class RectangleDetectStrategy : IDetectStrategy
    {
        private readonly Transform _cachedTr;
        private readonly Vector2 _size;
        private readonly Vector2 _center;
        private readonly LayerMask _layerMask;
        private readonly Collider2D[] _detects;
        
        public RectangleDetectStrategy(Transform originTr, Vector2 size, Vector2 center, LayerMask layerMask)
        {
            _cachedTr = originTr;
            _size = size;
            _center = center;
            _layerMask = layerMask;
            
            _detects = new Collider2D[2];
        }

        public void Initialize()
        {
        }

        public Collider2D Execute()
        {
            Vector3 center = _center;
            center.x *= _cachedTr.right.x < 0 ? -1f : 1f;
            
            Vector2 pos = _cachedTr.position + center;
            int count = Physics2D.OverlapBoxNonAlloc(pos, _size, 0f, _detects, _layerMask);

            return count <= 0 ? null : _detects[0];
        }

        public void Release()
        {
        }
    }
}