﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace DeDucking.Utilities
{
    public enum DetectType
    {
        Update,
        Physics,
    }

    public class Detector : MonoBehaviour
    {
        private readonly Dictionary<IDetectStrategy, List<Action<Collider2D>>> _standardListeners = new();
        private readonly Dictionary<IDetectStrategy, List<Action<Collider2D>>> _physicsListeners = new();

        private void Update()
        {
            foreach (var listener in _standardListeners)
            {
                var target = listener.Key.Execute();

                for (int i = listener.Value.Count - 1; i >= 0; i--)
                {
                    listener.Value[i]?.Invoke(target);
                }
            }
        }

        private void FixedUpdate()
        {
            foreach (var listener in _physicsListeners)
            {
                var target = listener.Key.Execute();

                for (int i = listener.Value.Count - 1; i >= 0; i--)
                {
                    listener.Value[i]?.Invoke(target);
                }
            }
        }

        public void Register(DetectType type, IDetectStrategy strategy, Action<Collider2D> callback)
        {
            switch (type)
            {
                case DetectType.Update:
                    if (!_standardListeners.ContainsKey(strategy))
                    {
                        _standardListeners.Add(strategy, new List<Action<Collider2D>>());
                    }
                    strategy.Initialize();
                    _standardListeners[strategy].Add(callback);
                    break;
                case DetectType.Physics:
                    if (!_physicsListeners.ContainsKey(strategy))
                    {
                        _physicsListeners.Add(strategy, new List<Action<Collider2D>>());
                    }
                    strategy.Initialize();
                    _physicsListeners[strategy].Add(callback);
                    break;
            }
        }

        public void UnRegister(DetectType type, IDetectStrategy strategy, Action<Collider2D> callback)
        {
            switch (type)
            {
                case DetectType.Update:
                    if (_standardListeners.ContainsKey(strategy))
                    {
                        if (_standardListeners[strategy].Contains(callback))
                        {
                            strategy.Release();
                            _standardListeners[strategy].Remove(callback);
                        }
                    }
                    break;
                case DetectType.Physics:
                    if (_physicsListeners.ContainsKey(strategy))
                    {
                        if (_physicsListeners[strategy].Contains(callback))
                        {
                            strategy.Release();
                            _physicsListeners[strategy].Remove(callback);
                        }
                    }
                    break;
            }
        }
    }
}