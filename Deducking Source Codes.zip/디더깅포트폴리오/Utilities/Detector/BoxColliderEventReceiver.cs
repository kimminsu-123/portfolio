using System;
using UnityEngine;
using UnityEngine.Events;

namespace DeDucking.Utilities
{
    [RequireComponent(typeof(BoxCollider2D))]
    public class BoxColliderEventReceiver : PoolObjMonoBehavior
    {
        public UnityEvent<Collider2D> onEnter;
        public UnityEvent<Collider2D> onExit;

        private BoxCollider2D _boxCollider2D;

        protected override void OnAwake()
        {
            _boxCollider2D = GetComponent<BoxCollider2D>();
        }

        private void OnTriggerEnter2D(Collider2D col)
        {
            onEnter?.Invoke(col);
        }

        private void OnTriggerExit2D(Collider2D other)
        {
            onExit?.Invoke(other);
        }

        public void SetSize(Vector2 size)
        {
            _boxCollider2D.size = size;
        }

        public void SetCenter(Vector2 center)
        {
            _boxCollider2D.offset = center;
        }
    }
}