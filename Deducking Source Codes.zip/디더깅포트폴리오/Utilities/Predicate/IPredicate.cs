namespace DeDucking.Utilities
{
    public interface IPredicate
    {
        bool Evaluate();
    }
}