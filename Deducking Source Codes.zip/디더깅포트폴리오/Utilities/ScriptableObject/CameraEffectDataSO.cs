﻿using UnityEngine;
using UnityEngine.Serialization;

namespace DeDucking.Utilities
{
    public enum CameraEffectType
    {
        Low = 1,
        Middle,
        High
    }
    
    [CreateAssetMenu(fileName = "CameraEffectData", menuName = "Assets/SO/Camera Effect", order = 4)]
    public class CameraEffectDataSO : ScriptableObject
    {
        [FormerlySerializedAs("freqGain")]
        [Header("카메라 셰이킹 데이터")]
        [SerializeField] private float gain = 3f;
        [SerializeField] private float shakeDuration = 0.5f;
        
        [Header("카메라 스탑 이펙트 데이터")]
        [SerializeField] private float timeScale = 0f;
        [SerializeField] private float stopCameraDuration = 0.3f;

        [Header("Vignette 이펙트 데이터")]
        [SerializeField] private Vector2 vignetteRange = new(0.0f, 0.25f);
        [SerializeField] private float vignetteInDuration = 1.5f;
        [SerializeField] private float vignetteOutDuration = 0.5f;
        
        [Header("Chromatic 이펙트 데이터")]
        [SerializeField] private Vector2 chromaticRange = new(0f, 1f);
        [SerializeField] private float chromaticInDuration = 1.5f;
        [SerializeField] private float chromaticOutDuration = 0.5f;
        
        public float Gain => gain;
        public float ShakeDuration => shakeDuration;
        public float TimeScale => timeScale;
        public float StopCameraDuration => stopCameraDuration;
        public Vector2 VignetteRange => vignetteRange;
        public float VignetteInDuration => vignetteInDuration;
        public float VignetteOutDuration => vignetteOutDuration;
        public Vector2 ChromaticRange => chromaticRange;
        public float ChromaticInDuration => chromaticInDuration;
        public float ChromaticOutDuration => chromaticOutDuration;
    }
}