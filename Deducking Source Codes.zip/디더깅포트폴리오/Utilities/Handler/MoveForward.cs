﻿using System;
using DeDucking.Entity;
using UnityEngine;

namespace DeDucking.Utilities
{
    public class MoveForward : MonoBehaviour, IMoveBehavior
    {
        public float moveSpeed;

        public bool IsRunning => _isRunning;
        private bool _isRunning = true;

        private void Update()
        {
            if (IsRunning)
            {
                Move();
            }
        }

        public void SetMoveSpeed(float speed)
        {
            moveSpeed = speed;
        }

        public void Run()
        {
            _isRunning = true;
        }

        public void Move()
        {
            transform.Translate(Vector3.right * (moveSpeed * Time.deltaTime));
        }

        public void Stop()
        {
            _isRunning = false;
        }
    }
}