﻿using System;
using UniRx;
using UnityEngine;

namespace DeDucking.Utilities
{
    [RequireComponent(typeof(AudioSource))]
    public class Speaker : PoolObjMonoBehavior
    {
        public ObjectPoolDataSO originPool;

        private AudioSource _source;
        private CooldownTimer _oneShotTimer;

        protected override void OnAwake()
        {
            _source = GetComponent<AudioSource>();
            _oneShotTimer = new CooldownTimer();
        }

        public void PlayLoop(AudioClip clip, float volume)
        {
            if (clip == null) return;

            _source.clip = clip;
            _source.loop = true;
            _source.volume = volume;
            _source.Play();
        }

        public void PlayOneShot(AudioClip clip, float volume)
        {
            if (clip == null) return;

            _source.volume = volume;
            _source.PlayOneShot(clip);

            _oneShotTimer.OnStopped = () => { originPool.ReturnQueue(this); };
            _oneShotTimer.SetTime(clip.length);
            _oneShotTimer.Start();

            Logger.Log("Speaker", $"Position : {transform.position}", Color.green);
            Logger.Log("Speaker", $"Sound Play One Shot : {clip.name}", Color.green);
        }

        private void Update()
        {
            _oneShotTimer.Tick(Time.deltaTime);
        }
    }
}