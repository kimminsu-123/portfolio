﻿using System;
using DeDucking.Managers;
using NaughtyAttributes;
using UniRx;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Playables;
using UnityEngine.Timeline;
using EventType = DeDucking.Managers.EventType;

namespace DeDucking.Utilities
{
    [RequireComponent(typeof(PlayableDirector))]
    public class CutScenePlayer : MonoBehaviour
    {
        public bool playOnSceneLoaded = false;
        [ShowIf("playOnSceneLoaded")] public PlayableAsset preAsset;
        [ShowIf("playOnSceneLoaded")] public UnityEvent preCallback;
        public bool useTimerForCompletion = true;
        
        public int TrackCount { get; private set; }
        
        private PlayableDirector _director;

        private void Awake()
        {
            _director = GetComponent<PlayableDirector>();
        }

        private void Start()
        {
            if (playOnSceneLoaded)
            {
                EventManager.Instance.AddListener(EventType.OnSceneLoaded, OnSceneLoaded);
            }
        }

        private void OnSceneLoaded(EventType type, Component sender, object[] args)
        {
            if (preCallback.GetPersistentEventCount() > 0)
            {
                Play(preAsset, () => preCallback.Invoke());
            }
            else
            {
                Play(preAsset, null);
            }
        }

        private void OnDestroy()
        {
            if (playOnSceneLoaded)
            {
                EventManager.Instance.RemoveListener(EventType.OnSceneLoaded, OnSceneLoaded);
            }
        }

        public bool Play(PlayableAsset asset, Action callback)
        {
            if (_director.state == PlayState.Playing)
            {
                return false;
            }
            
            EventManager.Instance.PostNotification(EventType.OnBeginCutScene, this);

            TrackCount = (asset as TimelineAsset).rootTrackCount;
            
            _director.playableAsset = asset;
            _director.Play();

            if (callback != null)
            {
                if (useTimerForCompletion)
                {
                    Observable.Timer(TimeSpan.FromSeconds(asset.duration))
                        .Subscribe(_ =>
                        {
                            callback?.Invoke();
                            EventManager.Instance.PostNotification(EventType.OnEndCutScene, this);
                        });
                }
                else
                {
                    Observable.EveryUpdate()
                        .Where(_ => asset.duration.EqualWithMarginOfError(_director.time) || asset.duration <= _director.time)
                        .Take(1)
                        .Subscribe(_ =>
                        {
                            callback.Invoke();
                            EventManager.Instance.PostNotification(EventType.OnEndCutScene, this);
                        });
                }
            }
            
            return true;
        }

        /// <summary>
        /// 트랙이 모두 일정한 간격으로 동일한 재생시간을 가지고 있을때만 사용가능!
        /// </summary>
        public void MoveToNextTrack()
        {
            if (_director.state != PlayState.Playing)
            {
                return;
            }
            
            TimelineAsset timeline = _director.playableAsset as TimelineAsset;
            TrackAsset track = timeline.GetRootTrack(1);

            int nextIndex = (int)(_director.time / track.duration) + 1;
            if (nextIndex < TrackCount)
            {
                _director.time = timeline.GetRootTrack(nextIndex).end;
            }
        }
    }
}