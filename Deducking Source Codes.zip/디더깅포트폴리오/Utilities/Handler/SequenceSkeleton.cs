﻿using System;
using Spine.Unity;
using UnityEngine;

namespace DeDucking.Utilities
{
    [RequireComponent(typeof(SkeletonAnimation))]
    public class SequenceSkeleton : MonoBehaviour
    {
        [SerializeField] private AnimationReferenceAsset[] assets;
        [SerializeField] private bool isLoopLastAnimation = false;
        
        private SkeletonAnimation _animation;

        private void Awake()
        {
            _animation = GetComponent<SkeletonAnimation>();
        }

        private void OnEnable()
        {
            for (int i = 0; i < assets.Length; i++)
            {
                _animation.CrossFade(0, assets[i], false);
                if (i == assets.Length - 1 && isLoopLastAnimation)
                {
                    _animation.QueuedCrossFade(0, assets[i], true);
                }
            }
        }
    }
}