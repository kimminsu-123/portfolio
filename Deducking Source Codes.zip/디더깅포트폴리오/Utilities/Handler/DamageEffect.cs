using System.Collections;
using DeDucking.Entity;
using DeDucking.Managers;
using DeDucking.Utilities;
using NaughtyAttributes;
using Spine.Unity;
using UnityEngine;

namespace Utilities.Handler
{
    public class DamageEffect : MonoBehaviour
    {
        [SerializeField] private SoundInfo damageSound;
        [SerializeField] private ObjectPoolDataSO damageEffectPool;
        [SerializeField] private bool useCameraStopEffect;
        [SerializeField, ShowIf("useCameraStopEffect")] private CameraEffectType type;
        [SerializeField] private bool useBlink = true;
        [SerializeField, ShowIf("useBlink")] private float delay = 0.3f;
        [SerializeField, ShowIf("useBlink")] private SkeletonAnimation skeleton;
        
        private LivingEntity _livingEntity;
        private SpineEffectPoolObj _curDamageEffect;
        private Coroutine _blinkCoroutineInstance;

        private void Awake()
        {
            _livingEntity = GetComponentInParent<LivingEntity>();
        }

        private void Start()
        {
            _livingEntity.onDamageCallback.AddListener(PlayDamageEffect);
        }

        private void OnDisable()
        {
            if (_blinkCoroutineInstance != null)
            {
                StopCoroutine(_blinkCoroutineInstance);
                _blinkCoroutineInstance = null;
            }
            
            skeleton.Skeleton.SetColor(Color.white);
        }

        public void PlayDamageEffect(GameObject hitter)
        {
            if (useBlink)
            {
                if (_blinkCoroutineInstance != null)
                {
                    StopCoroutine(_blinkCoroutineInstance);
                    _blinkCoroutineInstance = null;
                }
                _blinkCoroutineInstance = StartCoroutine(Blink());
            }
            
            var effect = damageEffectPool.GetQueue<SpineEffectPoolObj>(transform);
            effect.SetOriginPool(damageEffectPool);
            effect.SetParent(null);
            effect.Play();
            
            AudioManager.Instance.PlayOneShot(transform, damageSound.Id, damageSound.Volume);

            if (useCameraStopEffect)
            {
                CameraHandler.Instance.EffectCameraStop(type);
            }
        }

        private IEnumerator Blink()
        {
            Color targetColor = new Color(0.8f, 0f, 0f, 1f);
            skeleton.skeleton.SetColor(targetColor);

            yield return new WaitForSeconds(delay);
            
            skeleton.skeleton.SetColor(Color.white);
        }
    }
}
