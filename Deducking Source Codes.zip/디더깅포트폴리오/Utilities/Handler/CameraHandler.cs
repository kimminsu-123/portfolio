﻿using System;
using System.Collections;
using Cinemachine;
using DeDucking.Managers;
using DeDucking.Utilities;
using DG.Tweening;
using UniRx;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using EventType = DeDucking.Managers.EventType;
using Logger = DeDucking.Utilities.Logger;

namespace Utilities.Handler
{
    public class CameraHandler : SingletonMonoBehavior<CameraHandler>
    {
        private const string CAMERA_LIMIT_TAG = "CameraLimit";

        [SerializeField] private CameraEffectDataSO lowData;
        [SerializeField] private CameraEffectDataSO middleData;
        [SerializeField] private CameraEffectDataSO highData;
        [SerializeField] private ParticleSystem diffuseEffect;

        public CinemachineBrain MainCamera => _mainCamera;
        public CinemachineVirtualCamera FollowCam => _virtualCamera;

        private CinemachineBrain _mainCamera;
        private CinemachineVirtualCamera _virtualCamera;
        private ICinemachineCamera _currentBlendCamera;
        
        private CinemachineConfiner2D _confiner;
        private CinemachineLateImpulseListener _noise;
        private CinemachineImpulseSource _noiseSource;
        private PolygonCollider2D _currentSceneCamLimit;

        private Volume _volume;
        private Vignette _vignette;
        private ChromaticAberration _chromatic;

        private IDisposable _shakeTimer;
        private Coroutine _stopCamCoroutineInstance;

        protected override void Initialize()
        {
            RegisterEvents();
            GetAllCameras();

            _volume = _mainCamera.GetComponent<Volume>();
            _volume.profile.TryGet(out _vignette);
            _volume.profile.TryGet(out _chromatic);
            
            CinemachineImpulseManager.Instance.IgnoreTimeScale = true;
        }

        protected override void OnDestroy()
        {
            base.OnDestroy();

            EventManager.Instance.RemoveListener(EventType.OnSceneLoadedBefore, OnSceneLoaded);
        }

        private void RegisterEvents()
        {
            EventManager.Instance.AddListener(EventType.OnSceneLoadedBefore, OnSceneLoaded);
        }

        private void OnSceneLoaded(EventType type, Component sender, object[] args)
        {
            GameObject camLimit = GameObject.FindGameObjectWithTag(CAMERA_LIMIT_TAG);
            if (camLimit != null)
            {
                _confiner.m_BoundingShape2D = camLimit.GetComponent<PolygonCollider2D>();
            }
        }

        private void GetAllCameras()
        {
            _mainCamera = Camera.main.GetComponent<CinemachineBrain>();
            _virtualCamera = GetComponentInChildren<CinemachineVirtualCamera>(true);
            _confiner = _virtualCamera.GetComponent<CinemachineConfiner2D>();
            _noise = _virtualCamera.GetComponentInChildren<CinemachineLateImpulseListener>(true);
            _noiseSource = _virtualCamera.GetComponent<CinemachineImpulseSource>();
        }

        private CameraEffectDataSO GetEffectData(CameraEffectType type)
        {
            switch (type)
            {
                case CameraEffectType.Low:
                    return lowData;
                case CameraEffectType.Middle:
                    return middleData;
                case CameraEffectType.High:
                    return highData;
                default:
                    Logger.Assert(true, "EffectData", "Type is Null!");
                    return null;
            }
        }

        private void Update()
        {
            CinemachineCore.CurrentTimeOverride = Time.unscaledTime;
            CinemachineCore.UniformDeltaTimeOverride = Time.unscaledDeltaTime;
        }

        public void Shake(CameraEffectType type, float delay = 0f)
        {
            var data = GetEffectData(type);

            if (delay > 0f)
            {
                Observable.Timer(TimeSpan.FromSeconds(delay), Scheduler.MainThreadIgnoreTimeScale)
                    .Subscribe(_ =>
                    {
                        _noise.m_Gain = data.Gain;
                        _noiseSource.m_ImpulseDefinition.m_ImpulseDuration = data.ShakeDuration;
                        _noiseSource.GenerateImpulse();
                    });
                return;
            }

            _noise.m_Gain = data.Gain;
            _noiseSource.m_ImpulseDefinition.m_ImpulseDuration = data.ShakeDuration;
            _noiseSource.GenerateImpulse();
        }
        
        public void ShakeOtherCam(CinemachineVirtualCamera cam, CameraEffectType type)
        {
            var data = GetEffectData(type);
            var noise = cam.GetComponentInChildren<CinemachineLateImpulseListener>(true);
            var noiseSource = cam.GetComponent<CinemachineImpulseSource>();
            
            noise.m_Gain = data.Gain;
            noiseSource.m_ImpulseDefinition.m_ImpulseDuration = data.ShakeDuration;
            noiseSource.GenerateImpulse();
        }

        public void EffectDiffuse()
        {
            diffuseEffect.Play();
        }

        public void EffectCameraStop(CameraEffectType type, float delay = 0f)
        {
            var data = GetEffectData(type);

            if (_stopCamCoroutineInstance != null)
            {
                StopCoroutine(_stopCamCoroutineInstance);
                _stopCamCoroutineInstance = null;
            }

            _stopCamCoroutineInstance = StartCoroutine(EffectCameraStopCoroutine(data, delay));
        }

        private IEnumerator EffectCameraStopCoroutine(CameraEffectDataSO data, float delay = 0f)
        {
            if (delay > 0f)
            {
                yield return new WaitForSeconds(delay);
            }
            
            Time.timeScale = data.TimeScale;
            yield return new WaitForSecondsRealtime(data.StopCameraDuration);
            Time.timeScale = 1f;
        }

        public void EffectVignette(CameraEffectType type)
        {
            var data = GetEffectData(type);
            var param = new FloatParameter(0f);

            var vignetteRangeSt = data.VignetteRange.x;
            var vignetteRangeEnd = data.VignetteRange.y;
            var vignetteInDuration = data.VignetteInDuration;
            var vignetteOutDuration = data.VignetteOutDuration;

            DOTween.To(() => vignetteRangeSt, x =>
            {
                param.value = x;
                _vignette.intensity.SetValue(param);
                _chromatic.intensity.SetValue(param);
            }, vignetteRangeEnd, vignetteInDuration).OnComplete(() =>
            {
                DOTween.To(() => vignetteRangeEnd, x =>
                {
                    param.value = x;
                    _vignette.intensity.SetValue(param);
                    _chromatic.intensity.SetValue(param);
                }, vignetteRangeSt, vignetteOutDuration).OnComplete(() =>
                {
                    param.value = 0f;
                    _vignette.intensity.SetValue(param);
                    _chromatic.intensity.SetValue(param);
                }).Play();
            }).Play();
        }

        public void EffectChromatic(CameraEffectType type)
        {
            var data = GetEffectData(type);
            var param = new FloatParameter(0f);

            var chromaticRangeSt = data.ChromaticRange.x;
            var chromaticRangeEnd = data.ChromaticRange.y;
            var chromaticInDuration = data.ChromaticInDuration;
            var chromaticOutDuration = data.ChromaticOutDuration;

            DOTween.To(() => chromaticRangeSt, x =>
            {
                param.value = x;
                _chromatic.intensity.SetValue(param);
            }, chromaticRangeEnd, chromaticInDuration).OnComplete(() =>
            {
                DOTween.To(() => chromaticRangeEnd, x =>
                {
                    param.value = x;
                    _chromatic.intensity.SetValue(param);
                }, chromaticRangeSt, chromaticOutDuration).OnComplete(() =>
                {
                    param.value = 0f;
                    _chromatic.intensity.SetValue(param);
                }).Play();
            }).Play();
        }

        public void Blend(ICinemachineCamera to, AnimationCurve curve, float duration)
        {
            if (to == null)
            {
                return;
            }
            
            _currentBlendCamera ??= FollowCam;
            _currentBlendCamera.Priority = 0;
            to.Priority = 1;
            
            var blendDef = new CinemachineBlendDefinition
            {
                m_Style = CinemachineBlendDefinition.Style.Custom,
                m_CustomCurve = curve,
                m_Time = duration
            };
            
            MainCamera.m_DefaultBlend = blendDef;
            MainCamera.ActiveBlend = new CinemachineBlend(_currentBlendCamera, to, curve, duration, 0f);
            _currentBlendCamera = to;
        }
    }
}