﻿using System;
using DeDucking.Utilities.SO;
using UnityEngine;

namespace DeDucking.Utilities
{
    public class ObjectPoolContainer : MonoBehaviour
    {
        [SerializeField] private ObjectPoolDataSO[] poolDataSo;
        
        private void Start()
        {
            for (int i = 0; i < poolDataSo.Length; i++)
            {
                poolDataSo[i].SetupPool(transform);
            }
        }

        private void OnDestroy()
        {
            for (int i = 0; i < poolDataSo.Length; i++)
            {
                poolDataSo[i].Clear();
            }
        }
    }
}