﻿using UnityEngine;

namespace DeDucking.Utilities
{
    public class CutSceneSkipHandler : MonoBehaviour
    {
        public CutScenePlayer player;
        public KeyCode skipKeyCode = KeyCode.Return;

        private void Update()
        {
            if (Input.GetKeyDown(skipKeyCode))
            {
                player.MoveToNextTrack();
            }
        }
    }
}