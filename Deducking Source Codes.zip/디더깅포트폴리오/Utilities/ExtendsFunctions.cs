using System;
using System.Collections.Generic;
using Spine;
using Spine.Unity;
using UniRx;
using UnityEngine;
using AnimationState = Spine.AnimationState;

namespace DeDucking.Utilities
{
    public static class ExtendsFunctionsForGameObject
    {
        public static T GetOrAddComponent<T>(this GameObject go) where T : MonoBehaviour
        {
            T component = go.GetComponent<T>();

            if (component == null)
            {
                component = go.AddComponent<T>();
            }

            return component;
        }
    }

    public static class ExtendsFunctionsForTransform
    {
        public static void FlipLookAtUsingRotation(this Transform thisTr, Transform target)
        {
            if (target == null)
            {
                return;
            }

            Vector3 dir = (target.position - thisTr.position).normalized;
            float angleY = dir.x switch
            {
                < 0f => 180f,
                > 0f => 0f,
                _ => thisTr.rotation.y
            };

            thisTr.rotation = Quaternion.Euler(0f, angleY, 0f);
        }

        public static void FlipLookAtUsingRotation(this Transform thisTr)
        {
            float anglesY = thisTr.rotation.eulerAngles.y switch
            {
                <= 0f => 180f,
                _ => 0f
            };
            thisTr.rotation = Quaternion.Euler(0f, anglesY, 0f);
        }

        public static void LookAt2D(this Transform thisTr, Vector3 targetPos, Vector3 offset, bool onlyUp = false)
        {
            Vector3 direction = (targetPos - thisTr.position + offset).normalized;
            float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;

            if (onlyUp)
            {
                if (direction.x < 0)
                {
                    thisTr.localScale = new Vector3(thisTr.localScale.x, -Mathf.Abs(thisTr.localScale.y),
                        thisTr.localScale.z);
                }
                else
                {
                    thisTr.localScale = new Vector3(thisTr.localScale.x, Mathf.Abs(thisTr.localScale.y),
                        thisTr.localScale.z);
                }
            }

            thisTr.rotation = Quaternion.Euler(0, 0, angle);
        }
        
        public static void LookAt2DReverse(this Transform thisTr, Vector3 targetPos, Vector3 offset, bool onlyUp = false)
        {
            Vector3 direction = (thisTr.position - targetPos + offset).normalized;
            float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;

            if (onlyUp)
            {
                if (direction.x < 0)
                {
                    thisTr.localScale = new Vector3(thisTr.localScale.x, -Mathf.Abs(thisTr.localScale.y),
                        thisTr.localScale.z);
                }
                else
                {
                    thisTr.localScale = new Vector3(thisTr.localScale.x, Mathf.Abs(thisTr.localScale.y),
                        thisTr.localScale.z);
                }
            }

            thisTr.rotation = Quaternion.Euler(0, 0, angle);
        }
    }

    public static class ExtendsFunctionsForRigidbody2D
    {
        public static void Fall(this Rigidbody2D self)
        {
            var currentVel = self.velocity;
            currentVel.y = 0f;
            self.velocity = currentVel;
        }
    }

    public static class ExtendsFunctionsForData
    {
        public static bool EqualWithMarginOfError(this float lhs, float rhs)
        {
            return Mathf.Abs(lhs - rhs) <= float.Epsilon;
        }
        
        public static bool EqualWithMarginOfError(this double lhs, double rhs)
        {
            return ((float)lhs).EqualWithMarginOfError((float)rhs);
        }

        public static bool Contains(this LayerMask layerMask, int otherLayer)
        {
            int result = layerMask.value & (1 << otherLayer);

            return result > 0;
        }
    }

    public static class AnimationUtils
    {
        private static readonly Dictionary<int, IDisposable> Disposables = new();

        public static void CrossFade(this SkeletonAnimation animation, int trackIndex, AnimationReferenceAsset asset,
            bool loop, float timeScale = 1f)
        {
            if (asset == null) return;
            
            animation.CrossFade(trackIndex, asset.Animation.Name, loop, timeScale);
        }

        public static void CrossFade(this SkeletonAnimation animation, int trackIndex, AnimationReferenceAsset asset,
            Action callback, float timeScale = 1f)
        {
            if (asset == null)
            {
                callback?.Invoke();
                return;
            }
            
            animation.CrossFade(trackIndex, asset.Animation.Name, callback, timeScale);
        }

        public static void QueuedCrossFade(this SkeletonAnimation animation, int trackIndex, AnimationReferenceAsset asset,
            bool loop = false, float delay = 0f, float timeScale = 1f)
        {
            if (asset == null) return;
            
            animation.QueuedCrossFade(trackIndex, asset.Animation.Name, loop, delay, timeScale);
        }
        
        public static void QueuedCrossFade(this SkeletonAnimation animation, int trackIndex, AnimationReferenceAsset asset,
            AnimationState.TrackEntryDelegate callback, float delay = 0f, float timeScale = 1f)
        {
            if (asset == null)
            {
                if (delay <= 0f) return;

                Observable.Timer(TimeSpan.FromSeconds(delay))
                    .Subscribe(_ => callback?.Invoke(null));
                return;
            }
            
            animation.QueuedCrossFade(trackIndex, asset.Animation.Name, callback, delay, timeScale);
        }
        
        public static void CrossFade(this SkeletonAnimation animation, int trackIndex, string animationName, bool loop,
            float timeScale = 1f)
        {
            if (animation.AnimationState.Data.SkeletonData.FindAnimation(animationName) == null)
            {
                return;
            }

            animation.AnimationState.SetAnimation(trackIndex, animationName, loop).TimeScale = timeScale;
        }

        public static void CrossFade(this SkeletonAnimation animation, int trackIndex, string animationName,
            Action callback, float timeScale = 1f)
        {
            if (animation.AnimationState.Data.SkeletonData.FindAnimation(animationName) == null)
            {
                callback?.Invoke();
                return;
            }

            animation.CrossFade(trackIndex, animationName, false);

            var timer = Observable.EveryUpdate()
                .Where(_ => animation.AnimationState.GetCurrent(0).Animation.Name.Equals(animationName))
                .Take(1)
                .Subscribe(_ =>
                {
                    float time = animation.AnimationState.GetCurrent(trackIndex).AnimationEnd;
                    Observable.Timer(TimeSpan.FromSeconds(time)).Subscribe(__ => { callback?.Invoke(); });
                });

            int hash = animation.GetHashCode();

            if (!Disposables.TryAdd(hash, timer))
            {
                Disposables[hash]?.Dispose();
                Disposables[hash] = timer;
            }
        }

        public static void QueuedCrossFade(this SkeletonAnimation animation, int trackIndex, string animationName,
            bool loop = false, float delay = 0f, float timeScale = 1f)
        {
            if (animation.AnimationState.Data.SkeletonData.FindAnimation(animationName) == null)
            {
                return;
            }

            animation.AnimationState.AddAnimation(trackIndex, animationName, loop, delay).TimeScale = timeScale;
        }
        
        public static void QueuedCrossFade(this SkeletonAnimation animation, int trackIndex, string animationName,
            AnimationState.TrackEntryDelegate callback, float delay = 0f, float timeScale = 1f)
        {
            if (animation.AnimationState.Data.SkeletonData.FindAnimation(animationName) == null)
            {
                if (delay <= 0f) return;

                Observable.Timer(TimeSpan.FromSeconds(delay))
                    .Subscribe(_ => callback?.Invoke(null));
                return;
            }

            TrackEntry nextTrackEntry = animation.AnimationState.AddAnimation(trackIndex, animationName, false, delay);
            nextTrackEntry.Complete += callback;
            nextTrackEntry.TimeScale = timeScale;
        }
    }
    
    public static class SkeletonGraphicUtils
    {
        private static readonly Dictionary<int, IDisposable> Disposables = new();

        public static void CrossFade(this SkeletonGraphic animation, int trackIndex, AnimationReferenceAsset asset,
            bool loop, float timeScale = 1f)
        {
            if (asset == null) return;
            
            animation.CrossFade(trackIndex, asset.Animation.Name, loop, timeScale);
        }

        public static void CrossFade(this SkeletonGraphic animation, int trackIndex, AnimationReferenceAsset asset,
            Action callback, float timeScale = 1f)
        {
            if (asset == null)
            {
                callback?.Invoke();
                return;
            }
            
            animation.CrossFade(trackIndex, asset.Animation.Name, callback, timeScale);
        }

        public static void QueuedCrossFade(this SkeletonGraphic animation, int trackIndex, AnimationReferenceAsset asset,
            bool loop = false, float delay = 0f, float timeScale = 1f)
        {
            if (asset == null) return;
            
            animation.QueuedCrossFade(trackIndex, asset.Animation.Name, loop, delay, timeScale);
        }
        
        public static void QueuedCrossFade(this SkeletonGraphic animation, int trackIndex, AnimationReferenceAsset asset,
            AnimationState.TrackEntryDelegate callback, float delay = 0f, float timeScale = 1f)
        {
            if (asset == null)
            {
                if (delay <= 0f) return;

                Observable.Timer(TimeSpan.FromSeconds(delay))
                    .Subscribe(_ => callback?.Invoke(null));
                return;
            }
            
            animation.QueuedCrossFade(trackIndex, asset.Animation.Name, callback, delay, timeScale);
        }
        
        public static void CrossFade(this SkeletonGraphic animation, int trackIndex, string animationName, bool loop,
            float timeScale = 1f)
        {
            if (animation.AnimationState.Data.SkeletonData.FindAnimation(animationName) == null)
            {
                return;
            }

            animation.AnimationState.SetAnimation(trackIndex, animationName, loop).TimeScale = timeScale;
        }

        public static void CrossFade(this SkeletonGraphic animation, int trackIndex, string animationName,
            Action callback, float timeScale = 1f)
        {
            if (animation.AnimationState.Data.SkeletonData.FindAnimation(animationName) == null)
            {
                callback?.Invoke();
                return;
            }

            animation.CrossFade(trackIndex, animationName, false);

            var timer = Observable.EveryUpdate()
                .Where(_ => animation.AnimationState.GetCurrent(0).Animation.Name.Equals(animationName))
                .Take(1)
                .Subscribe(_ =>
                {
                    float time = animation.AnimationState.GetCurrent(trackIndex).AnimationEnd;
                    Observable.Timer(TimeSpan.FromSeconds(time)).Subscribe(__ => { callback?.Invoke(); });
                });

            int hash = animation.GetHashCode();

            if (!Disposables.TryAdd(hash, timer))
            {
                Disposables[hash]?.Dispose();
                Disposables[hash] = timer;
            }
        }

        public static void QueuedCrossFade(this SkeletonGraphic animation, int trackIndex, string animationName,
            bool loop = false, float delay = 0f, float timeScale = 1f)
        {
            if (animation.AnimationState.Data.SkeletonData.FindAnimation(animationName) == null)
            {
                return;
            }

            animation.AnimationState.AddAnimation(trackIndex, animationName, loop, delay).TimeScale = timeScale;
        }
        
        public static void QueuedCrossFade(this SkeletonGraphic animation, int trackIndex, string animationName,
            AnimationState.TrackEntryDelegate callback, float delay = 0f, float timeScale = 1f)
        {
            if (animation.AnimationState.Data.SkeletonData.FindAnimation(animationName) == null)
            {
                if (delay <= 0f) return;

                Observable.Timer(TimeSpan.FromSeconds(delay))
                    .Subscribe(_ => callback?.Invoke(null));
                return;
            }

            TrackEntry nextTrackEntry = animation.AnimationState.AddAnimation(trackIndex, animationName, false, delay);
            nextTrackEntry.Complete += callback;
            nextTrackEntry.TimeScale = timeScale;
        }
    }
}