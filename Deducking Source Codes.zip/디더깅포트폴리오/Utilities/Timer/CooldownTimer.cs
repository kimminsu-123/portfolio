﻿using UnityEngine;

namespace DeDucking.Utilities
{
    public class CooldownTimer : Timer<float>
    {
        public CooldownTimer(float initialTime) : base(initialTime) { }
        public CooldownTimer() : base(0f) { }

        public override void Tick(float delta)
        {
            if (!IsRunning) return;
            
            CurrentTime -= delta;
            if (CurrentTime <= 0f)
            {
                CurrentTime = 0f;
                Stop();
            }
            OnTick.Invoke(CurrentTime);
        }
    }
}