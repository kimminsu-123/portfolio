﻿using System;

namespace DeDucking.Utilities
{
    public abstract class Timer<TIMEType>
    {
        public bool IsRunning { get; private set; }

        public Action<TIMEType> OnTick = delegate { };
        public Action OnStarted = delegate { };
        public Action OnStopped = delegate { };

        protected TIMEType InitialTime;
        protected TIMEType CurrentTime;
        
        protected Timer(TIMEType initialTime)
        {
            InitialTime = initialTime;
            IsRunning = false;
        }
        
        public void Start()
        {
            CurrentTime = InitialTime;
            
            if (!IsRunning)
            {
                IsRunning = true;
                OnStarted?.Invoke();
            }
        }

        public void Stop()
        {
            if (IsRunning)
            {
                IsRunning = false;
                OnStopped?.Invoke();
            }
        }

        public void SetTime(TIMEType time)
        {
            InitialTime = time;
        }
        
        public void Pause() => IsRunning = false;
        public void Resume() => IsRunning = true;

        public abstract void Tick(TIMEType delta);
    }
}