﻿namespace DeDucking.Utilities
{
    public class FrameTimer : Timer<int>
    {
        public FrameTimer(int initialTime) : base(initialTime) { }
        public FrameTimer() : base(0) { }

        public override void Tick(int delta)
        {
            if (!IsRunning) return;

            CurrentTime -= delta;
            if (CurrentTime <= 0)
            {
                Stop();
            }
            OnTick.Invoke(CurrentTime);
        }
    }
}