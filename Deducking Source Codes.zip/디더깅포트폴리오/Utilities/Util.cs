﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Random = UnityEngine.Random;

namespace DeDucking.Utilities
{
    public interface IWeightRandom
    {
        public int Weight { get; }
    }

    [Serializable]
    public class SoundInfo
    {
        [SerializeField, SoundElement] private int id;
        [SerializeField, Range(0f, 1f)] private float volume = 1f;
        
        public int Id => id;
        public float Volume => volume;
    }
    
    public static class Util
    {
        public const string PLAYER_SPAWN_POINT = "PlayerSpawnPoint";
        
        public static T WeightRandomize<T>(IEnumerable<T> enumerable) where T : IWeightRandom
        {
            T[] array = enumerable as T[] ?? enumerable.OrderBy(x => x.Weight).ToArray();

            if (array.Length <= 0)
            {
                throw new ArgumentException("enumerable can not empty");
            }
            
            int sum = array.Sum(x => x.Weight);
            int randomize = Random.Range(0, sum + 1);

            T result = array[0];
            
            foreach (T item in array)
            {
                if (item.Weight >= randomize)
                {
                    result = item;
                    break;
                }

                randomize -= item.Weight;
            }

            return result;
        }

        public static float GetAngle(Vector2 from, Vector2 to)
        {
            Vector2 dest = to - from;
            return Mathf.Atan2(dest.y, dest.x) * Mathf.Rad2Deg;
        }

        public static Transform FindSpawnPoint()
        {
            var point = GameObject.FindGameObjectWithTag(PLAYER_SPAWN_POINT);

            return point == null ? null : point.transform;
        }

        public static float GetDistance(Vector3 lhs, Vector3 rhs)
        {
            Vector3 v = rhs - lhs;
            float sqrMag = v.sqrMagnitude;
            float dist = Mathf.Abs(sqrMag * sqrMag);

            return dist;
        }
    }
}