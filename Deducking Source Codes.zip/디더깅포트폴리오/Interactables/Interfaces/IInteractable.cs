﻿using UnityEngine;

namespace DeDucking.Interactables.Interfaces
{
    public interface IInteractable
    {
        public void Interact(GameObject target);
    }
}