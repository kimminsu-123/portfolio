using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace DeDucking.Interactables.Interfaces
{
    public interface IItem
    {
        public void Use(GameObject target);
    }
}