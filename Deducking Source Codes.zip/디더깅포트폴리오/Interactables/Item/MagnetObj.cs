using System;
using DeDucking.Entity.Avatar;
using DeDucking.Managers;
using DeDucking.Utilities;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace DeDucking.Item
{
    [RequireComponent(typeof(FollowTargetMoveBehavior), typeof(Detector))]
    public class MagnetObj : MonoBehaviour
    {
        [SerializeField] private LayerMask targetLayer;
        [SerializeField] private Vector2 center;
        [SerializeField] private float radius;
        
        private FollowTargetMoveBehavior _follower;
        private Detector _detector;
        private IDetectStrategy _detectStrategy;

        private void Awake()
        {
            _follower = GetComponent<FollowTargetMoveBehavior>();
            _detector = GetComponent<Detector>();
            _detectStrategy = new CircleDetectStrategy(transform, center, radius, targetLayer);
        }

        private void OnEnable()
        {
            _detector.Register(DetectType.Physics, _detectStrategy, OnDetect);
            _detector.enabled = true;
            
            _follower.SetTarget(null);
            _follower.Stop();
        }

        private void OnDetect(Collider2D other)
        {
            if (other != null)
            {
                _detector.UnRegister(DetectType.Physics, _detectStrategy, OnDetect);
                _detector.enabled = false;
                
                _follower.SetTarget(other.transform);
                _follower.Run();
            }
        }

        private void OnDisable()
        {
            _detector.UnRegister(DetectType.Physics, _detectStrategy, OnDetect);
            _detector.enabled = false;    
            
            _follower.SetTarget(null);
            _follower.Stop();
        }

        private void OnDrawGizmos()
        {
            Gizmos.color = Color.red;
            Gizmos.matrix = transform.localToWorldMatrix;
            Gizmos.DrawWireSphere(Vector2.zero + center, radius);
        }
    }
}