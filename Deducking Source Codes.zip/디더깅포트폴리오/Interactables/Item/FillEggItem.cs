﻿using DeDucking.Player.SO;
using UnityEngine;

namespace DeDucking.Item
{
    public class FillEggItem : CollisionItem
    {
        [SerializeField] private PlayerDataSO playerData;
        [SerializeField] private int fillAmount;
        
        public override void Use(GameObject target)
        {
            //playerData.FillEgg(fillAmount);
        }
    }
}