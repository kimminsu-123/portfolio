using System;
using DeDucking.Interactables.Interfaces;
using DeDucking.Utilities;
using UnityEngine;

namespace DeDucking.Item
{
    public abstract class CollisionItem : MonoBehaviour, IItem
    {
        [SerializeField] private LayerMask collisionLayer;
        
        private void OnTriggerEnter2D(Collider2D col)
        {
            if (col != null)
            {
                int layer = col.gameObject.layer;

                if (collisionLayer.Contains(layer))
                {
                    Use(col.gameObject);             
                    gameObject.SetActive(false);
                }
            }
        }

        public abstract void Use(GameObject target);
    }
}