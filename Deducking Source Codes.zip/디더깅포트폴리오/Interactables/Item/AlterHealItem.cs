using DeDucking.Entity;
using UnityEngine;

namespace DeDucking.Item
{
    public class AlterHealItem : CollisionItem
    {
        public int alterHealAmount = 0;
        
        public override void Use(GameObject target)
        {
            if (target.TryGetComponent(out LivingEntity entity))
            {
                entity.AddAlterHealth(alterHealAmount);
            }
        }
    }
}