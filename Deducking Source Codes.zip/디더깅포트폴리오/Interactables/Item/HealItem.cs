using DeDucking.Entity;
using DeDucking.Utilities.SO;
using UnityEngine;

namespace DeDucking.Item
{
    public class HealItem : CollisionItem
    {
        public int healAmount = 0;
        
        public override void Use(GameObject target)
        {
            if (target.TryGetComponent(out LivingEntity entity))
            {
                entity.Heal(healAmount);
            }
        }
    }
}