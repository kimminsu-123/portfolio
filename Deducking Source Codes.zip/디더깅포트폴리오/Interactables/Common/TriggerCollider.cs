﻿using System.Collections.Generic;
using DeDucking.Utilities;
using UnityEngine;
using UnityEngine.Events;

namespace DeDucking.Interactables.Common
{
    public class TriggerCollider : MonoBehaviour
    {
        public UnityEvent<GameObject> onTriggerEnter;
        public UnityEvent<GameObject> onTriggerExit;
        public LayerMask layerMask;

        private Collider2D _cachedCol2D;
        private readonly HashSet<int> _hashSet = new();

        private void Awake()
        {
            _cachedCol2D = GetComponent<Collider2D>();
        }

        private void Start()
        {
            _cachedCol2D.isTrigger = true;
        }

        private void OnTriggerEnter2D(Collider2D col)
        {
            int layer = col.gameObject.layer;
            int hash = col.GetHashCode();

            if (!layerMask.Contains(layer))
            {
                return;
            }
            
            if (_hashSet.Contains(hash))
            {
                return;
            }
            
            _hashSet.Add(hash);
            onTriggerEnter.Invoke(col.gameObject);
        }

        private void OnTriggerExit2D(Collider2D col)
        {
            int layer = col.gameObject.layer;
            int hash = col.GetHashCode();
            
            if (!layerMask.Contains(layer))
            {
                return;
            }

            if (!_hashSet.Contains(hash))
            {
                return;
            }
            
            _hashSet.Remove(hash);
            onTriggerExit.Invoke(col.gameObject);
        }
    }
}