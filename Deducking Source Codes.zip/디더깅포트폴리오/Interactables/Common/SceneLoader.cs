﻿using System;
using DeDucking.Interactables.Interfaces;
using DeDucking.Managers;
using DeDucking.Utilities;
using UnityEngine;

namespace DeDucking.Interactables.Common
{
    public class SceneLoader : MonoBehaviour, IInteractable
    {
        public SceneReference additiveScene;
        
        public void Interact(GameObject target)
        {
            bool success = MultiSceneManager.Instance.LoadSceneAdditive(additiveScene);

            if(!success)
            {
                throw new Exception("load scene failed : already loading other scene..");
            }
        }
    }
}