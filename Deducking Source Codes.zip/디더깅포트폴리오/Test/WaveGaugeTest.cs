﻿using System;
using UnityEngine;
using UnityEngine.UI;

namespace _2.Scripts.Test
{
    public class WaveGaugeTest : MonoBehaviour
    {
        public Image image;
        public float amount = 1f;

        private void Update()
        {
            if (Input.GetKeyDown(KeyCode.Space))
            {
                amount = Mathf.Min(1f, amount + 0.1f);
                image.materialForRendering.SetFloat("_FillAmount", amount);
            }

            if (Input.GetKeyDown(KeyCode.Backspace))
            {
                amount = Mathf.Max(0f, amount - 0.1f);
                image.materialForRendering.SetFloat("_FillAmount", amount);
            }
        }
    }
}