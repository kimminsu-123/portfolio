using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ComponentParentTest : MonoBehaviour
{
    public void Print()
    {
        Debug.Log(gameObject.name);
    }
}
