﻿using System;
using DeDucking.Utilities;
using UnityEngine;

namespace _2.Scripts.Test
{
    public class SoundAttributeTest : MonoBehaviour
    {
        [SoundElement] public int soundElement1;
        [SerializeField, SoundElement] private int soundElement2;
    }
}