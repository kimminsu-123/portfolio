using System;
using System.Collections;
using System.Collections.Generic;
using DeDucking.Utilities;
using Spine;
using Spine.Unity;
using UnityEngine;
using UnityEngine.PlayerLoop;

public class SpineTest : MonoBehaviour
{
    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            GetComponent<SkeletonAnimation>().CrossFade(0, "BS_idle", () =>
            {
                Debug.Log("Space BS_idle");
                GetComponent<SkeletonAnimation>().QueuedCrossFade(0, "BS_roar", TestFunc1);
                GetComponent<SkeletonAnimation>().QueuedCrossFade(0, "BS_fall", TestFunc2);
            });
        }
        else if (Input.GetKeyDown(KeyCode.A))
        {
            GetComponent<SkeletonAnimation>().CrossFade(0, "BS_idle", false);
            GetComponent<SkeletonAnimation>().QueuedCrossFade(0, "BS_roar", TestFunc3);
            GetComponent<SkeletonAnimation>().QueuedCrossFade(0, "BS_fall", TestFunc4);
        }
    }

    private void TestFunc1(TrackEntry t)
    {
        Debug.Log("Space BS_roar");
        t.Complete -= TestFunc1;
    }

    private void TestFunc2(TrackEntry t)
    {
        Debug.Log("Space BS_fall");
        t.Complete -= TestFunc2;
    }
    
    private void TestFunc3(TrackEntry t)
    {
        Debug.Log("A BS_roar");
        t.Complete -= TestFunc3;
    }

    private void TestFunc4(TrackEntry t)
    {
        Debug.Log("A BS_fall");
        t.Complete -= TestFunc4;
    }
}