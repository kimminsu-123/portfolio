﻿using System;
using DeDucking.Utilities;
using Spine.Unity;
using UnityEngine;

public class UIAnimationTester : MonoBehaviour
{
    public SkeletonGraphic graphic;
    public AnimationReferenceAsset asset;

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            graphic.CrossFade(0, asset, false);
        }
    }
}