﻿using System;
using System.Linq;
using DeDucking.Utilities;
using Spine.Unity;
using UniRx;
using UnityEngine;

namespace DeDucking.Monster.Boss.Patterns
{
    [Serializable]
    public class BossPatternInfo : IWeightRandom
    {
        [SerializeField] private BossPattern pattern;
        [SerializeField] private int weight;
        [SerializeField] private float cooldown;

        public bool CanUse { get; set; } = true;

        public BossPattern Pattern => pattern;
        public int Weight => weight;
        public float Cooldown => cooldown;
    }

    public class BossPatternBehavior : MonoBehaviour
    {
        [SerializeField] private SkeletonAnimation animator;
        
        [Header("일반 공격 속성")] 
        [SerializeField] private BossPatternInfo[] attackPatterns;
        [SerializeField] private float useAttackCooldown;

        [Header("스킬 공격 속성")] 
        [SerializeField] private BossPatternInfo[] skillPatterns;
        [SerializeField] private float useSkillCooldown = 0.5f;

        public bool ReadyToAttack => !_lockedAttack && attackPatterns.Any(x => x.CanUse);
        public bool ReadyToSkill => !_lockedSkill && skillPatterns.Any(x => x.CanUse);

        private BossPatternInfo _currentPatternInfo;
        private bool _lockedAttack;
        private bool _lockedSkill;

        public void Initialize()
        {
            foreach (BossPatternInfo patternInfo in attackPatterns)
            {
                patternInfo.Pattern.Initialize(animator);
            }
            foreach (BossPatternInfo patternInfo in skillPatterns)
            {
                patternInfo.Pattern.Initialize(animator);
            }
        }
        
        public void ResetCooldown()
        {
            _lockedAttack = true;
            _lockedSkill = true;

            Observable.Timer(TimeSpan.FromSeconds(useAttackCooldown)).Subscribe(_ => _lockedAttack = false);
            Observable.Timer(TimeSpan.FromSeconds(useSkillCooldown)).Subscribe(_ => _lockedSkill = false);
        }

        public void UseRandomAttack(Action callback)
        {
            _lockedAttack = true;

            var canUsePatterns = attackPatterns.Where(p => p.CanUse);

            _currentPatternInfo = Util.WeightRandomize(canUsePatterns);
            _currentPatternInfo.CanUse = false;
            _currentPatternInfo.Pattern.Execute(() =>
            {
                callback?.Invoke();
                OnFinishedPattern(_currentPatternInfo);
            });

            Observable.Timer(TimeSpan.FromSeconds(useAttackCooldown))
                .Subscribe(_ => _lockedAttack = false);
        }

        public void UseRandomSkill(Action callback)
        {
            _lockedSkill = true;

            var canUsePatterns = skillPatterns.Where(p => p.CanUse);

            _currentPatternInfo = Util.WeightRandomize(canUsePatterns);
            _currentPatternInfo.CanUse = false;
            _currentPatternInfo.Pattern.Execute(() =>
            {
                callback?.Invoke();
                OnFinishedPattern(_currentPatternInfo);
            });

            Observable.Timer(TimeSpan.FromSeconds(useSkillCooldown))
                .Subscribe(_ => _lockedSkill = false);
        }

        public void ForceStop()
        {
            _currentPatternInfo?.Pattern.ForceStop();
        }

        private void OnFinishedPattern(BossPatternInfo info)
        {
            _currentPatternInfo = null;
            
            Observable.Timer(TimeSpan.FromSeconds(info.Cooldown))
                .Subscribe(_ => info.CanUse = true);
        }
    }
}