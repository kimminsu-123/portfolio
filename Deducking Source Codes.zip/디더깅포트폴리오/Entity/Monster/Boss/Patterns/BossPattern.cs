using System;
using System.Collections;
using System.ComponentModel;
using DeDucking.Entity;
using DeDucking.Utilities;
using Spine.Unity;
using UniRx;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.InputSystem.Layouts;

namespace DeDucking.Monster.Boss.Patterns
{
    public abstract class BossPattern : MonoBehaviour, IParryReceiver
    {
        [Header("공격 시작을 위한 속성들")]
        [Tooltip("준비 애니메이션"), SerializeField] protected AnimationReferenceAsset readyAnimation;
        [Tooltip("몇 초 뒤에 공격 감지 및 시전을 할 것 인가?"), SerializeField] protected float delay;
        [Tooltip("어떤 물리 레이어와 상호작용을 할 것인가?"), SerializeField] protected LayerMask layerMask;
        [Tooltip("패리 힌트 이펙트 풀"), SerializeField] protected ObjectPoolDataSO hintEffectPool;
        [Tooltip("패리 힌트 이펙트 위치"), SerializeField] protected Transform hintEffectPos;
        
        public bool IsRunning { get; protected set; }
        
        protected SkeletonAnimation CachedAnimator { get; private set; }
        protected Action Callback;

        public virtual void Initialize(SkeletonAnimation animator)
        {
            CachedAnimator = animator;
        }

        public void Execute(Action callback)
        {
            IsRunning = true;
            Callback = callback;

            var effect = hintEffectPool.GetQueue<ParryHintEffectPoolObj>(hintEffectPos);
            effect.SetOriginPool(hintEffectPool);
            effect.SetupAnimation(gameObject.layer);
            effect.Play();
            
            CachedAnimator.CrossFade(0, readyAnimation, ProcessPattern);
        }

        public virtual void ForceStop()
        {
            IsRunning = false;
        }

        protected abstract void ProcessPattern();
        public virtual void SuccessParry() { }
        public virtual void SuccessBlock() { /* 그냥 지 꼴리는대로 다함 */ }
    }
}