using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;
using Logger = DeDucking.Utilities.Logger;

namespace DeDucking.Entity.UI
{
    public class SliderHealthUI : HealthUI
    {
        [SerializeField] private Image sliderImage;
        
        protected override void Setup()
        {
            sliderImage.fillAmount = 1f;
        }

        protected override void OnDamaged(GameObject hitter)
        {
            int current = entity.CurrentHp;
            int max = entity.EntityData.MaxHp;

            sliderImage.fillAmount = (float)current / max;
        }
        
        protected override void OnHeal()
        {
            OnDamaged(null);
        }
    }   
}
