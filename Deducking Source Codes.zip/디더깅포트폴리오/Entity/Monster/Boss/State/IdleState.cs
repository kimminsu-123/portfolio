﻿using DeDucking.Utilities;
using Spine.Unity;
using Unity.VisualScripting;
using UnityEngine;

namespace DeDucking.Monster.Boss.State
{
    public class IdleState : BossState
    {
        private readonly SkeletonAnimation _animator;
        private readonly PlatformerChaser _chaser;
        
        public IdleState(GameObject go) : base(go)
        {
            _animator = CachedGo.GetComponentInChildren<SkeletonAnimation>();
            _chaser = CachedGo.GetComponent<PlatformerChaser>();
        }

        public override void EnterState()
        {
            Utilities.Logger.Log("Enter Scarecrow State", "Idle State", Color.red);
            
            _animator.CrossFade(0, BossAnimationName.Idle, true);

            _chaser.isRunning = true;
        }

        public override void ExitState()
        {
            _chaser.isRunning = false;
        }
    }
}