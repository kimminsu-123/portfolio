﻿using DeDucking.Monster.Boss.Patterns;
using DeDucking.Utilities;
using Spine.Unity;
using UnityEngine;
using Utilities.Handler;

namespace DeDucking.Monster.Boss.State
{
    public class DieState : BossState
    {
        private readonly SkeletonAnimation _animator;
        private readonly PlatformerChaser _chaser;
        private readonly BossPatternBehavior _behavior;

        public DieState(GameObject go) : base(go)
        {
            _animator = CachedGo.GetComponentInChildren<SkeletonAnimation>();
            _chaser = CachedGo.GetComponent<PlatformerChaser>();
            _behavior = CachedGo.GetComponentInChildren<BossPatternBehavior>();
        }

        public override void EnterState()
        {
            Utilities.Logger.Log("Enter Scarecrow State", "Die State", Color.red);

            _behavior.ForceStop();
            _chaser.isRunning = false;
            
            CameraHandler.Instance.EffectVignette(CameraEffectType.High);
            CameraHandler.Instance.EffectChromatic(CameraEffectType.High);
            
            _animator.CrossFade(0, BossAnimationName.Death, false);
        }
    }
}