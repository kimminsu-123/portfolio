﻿using DeDucking.Monster.Boss.Patterns;
using UnityEngine;

namespace DeDucking.Monster.Boss.State
{
    public class SkillState : BossState
    {
        private readonly BossPatternBehavior _behavior;
        
        public SkillState(GameObject go) : base(go)
        {
            _behavior = CachedGo.GetComponentInChildren<BossPatternBehavior>();
        }

        public override void EnterState()
        {
            IsCompleted = false;
            
            Utilities.Logger.Log("Enter Scarecrow State", "Skill State", Color.red);

            _behavior.UseRandomSkill(() => IsCompleted = true);
        }

        public override void ExitState()
        {
            // 사용이 끝나지 않았는데 상태를 벗어난 경우 강제 종료
            if (!IsCompleted)
            {
                _behavior.ForceStop();
            }
        }
    }
}