﻿using DeDucking.FSM;
using UnityEngine;

namespace DeDucking.Monster.Boss.State
{
    public struct BossAnimationName
    {
        public static readonly string Idle = "BS_idle";
        public static readonly string Death = "BS_fall";
        public static readonly string Move = "BS_walking";
    }
    
    public abstract class BossState : IState
    {
        public bool IsCompleted { get; protected set; }

        protected readonly GameObject CachedGo;

        protected BossState(GameObject go)
        {
            CachedGo = go;
        }
        
        public virtual void EnterState()
        {
        }

        public virtual void UpdateState()
        {
        }

        public virtual void FixedUpdateState()
        {
        }

        public virtual void ExitState()
        {
        }
    }
}