﻿using DeDucking.Monster.Boss.Patterns;
using Unity.VisualScripting;
using UnityEngine;

namespace DeDucking.Monster.Boss.State
{
    public class AttackState : BossState
    {
        private readonly BossPatternBehavior _behavior;
        
        public AttackState(GameObject go) : base(go)
        {
            _behavior = CachedGo.GetComponentInChildren<BossPatternBehavior>();
        }

        public override void EnterState()
        {
            IsCompleted = false;
            
            Utilities.Logger.Log("Enter Scarecrow State", "Attack State", Color.red);

            _behavior.UseRandomAttack(() => IsCompleted = true);
        }

        public override void ExitState()
        {
            // 사용이 끝나지 않았는데 상태를 벗어난 경우 강제 종료
            if (!IsCompleted)
            {
                _behavior.ForceStop();
            }
        }
    }
}