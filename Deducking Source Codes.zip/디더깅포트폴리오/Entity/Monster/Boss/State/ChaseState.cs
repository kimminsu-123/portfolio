﻿using DeDucking.Utilities;
using Spine.Unity;
using UnityEngine;
using Logger = DeDucking.Utilities.Logger;

namespace DeDucking.Monster.Boss.State
{
    public class ChaseState : BossState
    {
        private readonly SkeletonAnimation _animator;
        private readonly PlatformerChaser _chaser;
        
        public ChaseState(GameObject go) : base(go)
        {
            _animator = CachedGo.GetComponentInChildren<SkeletonAnimation>();
            _chaser = CachedGo.GetComponent<PlatformerChaser>();
        }

        public override void EnterState()
        {
            Logger.Log("Enter Scarecrow State", "Chase State", Color.red);
            
            _animator.CrossFade(0, BossAnimationName.Move, true);
            
            _chaser.isRunning = true;
        }

        public override void ExitState()
        {
            _chaser.isRunning = false;
        }
    }
}