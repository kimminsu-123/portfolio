using System.Linq;
using DeDucking.Managers;
using DeDucking.Utilities;
using UnityEngine;
using UnityEngine.Playables;
using EventType = DeDucking.Managers.EventType;

namespace DeDucking.Monster.Boss
{
    [RequireComponent(typeof(CutScenePlayer))]
    public class BossStage : MonoBehaviour
    {
        private enum Status
        {
            Intro,
            Begin,
            End
        }

        [SerializeField] private Status currentStatus;
        [SerializeField] private PlayableAsset introCutScene;
        [SerializeField] private GameObject nextPortal;

        private CutScenePlayer _cutScenePlayer;
        private IBoss[] _bosses;
        private bool IsClearStage => _bosses.All(x => x.IsClear);

        private void Awake()
        {
            _bosses = gameObject.GetComponentsInChildren<IBoss>();
            _cutScenePlayer = GetComponent<CutScenePlayer>();
        }

        private void Start()
        {
            EventManager.Instance.AddListener(EventType.OnSceneLoaded, OnSceneLoaded);
            EventManager.Instance.AddListener(EventType.OnPlayerDeath, OnPlayerDeath);
            
            nextPortal.SetActive(false);
        }

        private void OnSceneLoaded(EventType type, Component sender, params object[] args)
        {
            Intro();
        }
        
        private void OnPlayerDeath(EventType type, Component sender, params object[] args)
        {
            EndStage(false);
        }
        
        private void Intro()
        {
            currentStatus = Status.Intro;

            if (introCutScene != null)
            {
                bool success = _cutScenePlayer.Play(introCutScene, BeginStage);

                if (!success)
                {
                    Utilities.Logger.Log("CutScene Failed", "has already playing other timeline");
                }   
            }
            else
            {
                BeginStage();
            }
        }

        private void Update()
        {
            if (IsClearStage)
            {
                EndStage(true);
            }
        }

        private void BeginStage()
        {
            if (currentStatus == Status.Begin)
            {
                return;
            }
            
            currentStatus = Status.Begin;

            for (int i = 0; i < _bosses.Length; i++)
            {
                _bosses[i].Begin();
            }
        }

        private void EndStage(bool success)
        {
            if (currentStatus == Status.End)
            {
                return;
            }
            
            currentStatus = Status.End;
            
            if (success)
            {
                nextPortal.SetActive(true);
            }
            
            for (int i = 0; i < _bosses.Length; i++)
            {
                _bosses[i].End();
            }
        }

        private void OnDisable()
        {
            EventManager.Instance.RemoveListener(EventType.OnSceneLoaded, OnSceneLoaded);
            EventManager.Instance.RemoveListener(EventType.OnPlayerDeath, OnPlayerDeath);
        }
    }
}