﻿using UnityEngine;

namespace DeDucking.Monster.Boss
{
    public interface IBoss
    {
        bool IsClear { get; }
        
        public void Begin();
        public void End();
    }
}