﻿using DeDucking.Managers;
using DeDucking.Utilities;
using UnityEngine;
using UnityEngine.Serialization;

namespace DeDucking.Monster.Boss
{
    public class ScarecrowSpeakerPlayer : MonoBehaviour
    {
        [SerializeField] private SoundInfo walkingSound;
        [SerializeField] private SoundInfo moveSound;
        [SerializeField] private SoundInfo chatSound;
        [SerializeField] private SoundInfo pattern1Sound;
        [SerializeField] private SoundInfo pattern1StabSound;
        [SerializeField] private SoundInfo pattern2Sound;
        [SerializeField] private SoundInfo pattern2_1Sound;
        [SerializeField] private SoundInfo pattern3Sound;
        [SerializeField] private SoundInfo roarSound;
        [SerializeField] private SoundInfo fallSound;

        public void PlayWalkSound()
        {
            AudioManager.Instance.PlayOneShot(transform, walkingSound.Id, walkingSound.Volume);
        }
        
        public void PlayMoveSound()
        {
            AudioManager.Instance.PlayOneShot(transform, moveSound.Id, moveSound.Volume);
        }
        
        public void PlayChatSound()
        {
            AudioManager.Instance.PlayOneShot(transform, chatSound.Id, chatSound.Volume);
        }
        
        public void PlayPattern1Sound()
        {
            AudioManager.Instance.PlayOneShot(transform, pattern1Sound.Id, pattern1Sound.Volume);
        }
        
        public void PlayPattern1_3Sound()
        {
            AudioManager.Instance.PlayOneShot(transform, pattern1StabSound.Id, pattern1StabSound.Volume);
        }
        
        public void PlayPattern2Sound()
        {
            AudioManager.Instance.PlayOneShot(transform, pattern2Sound.Id, pattern2Sound.Volume);
        }
        
        public void PlayPattern2_1Sound()
        {
            AudioManager.Instance.PlayOneShot(transform, pattern2_1Sound.Id, pattern2_1Sound.Volume);
        }
        
        public void PlayPattern3Sound()
        {
            AudioManager.Instance.PlayOneShot(transform, pattern3Sound.Id, pattern3Sound.Volume);
        }
        
        public void PlayRoarSound()
        {
            AudioManager.Instance.PlayOneShot(transform, roarSound.Id, roarSound.Volume);
        }
        
        public void PlayFallSound()
        {
            AudioManager.Instance.PlayOneShot(transform, fallSound.Id, fallSound.Volume);
        }
    }
}