﻿using DeDucking.Entity;
using DeDucking.Monster.Boss.Patterns;
using DeDucking.Utilities;
using NaughtyAttributes;
using Spine;
using Spine.Unity;
using UnityEngine;

namespace DeDucking.Monster.Boss.Pattern
{
    public class ScarecrowSpinningSlash : BossPattern
    {
        [Tooltip("회전 애니메이션"), SerializeField] private AnimationReferenceAsset loopAnimation;
        [Tooltip("공격 이후에 Idle로 돌아가는 애니메이션"), SerializeField] private AnimationReferenceAsset endAnimation;
        [Tooltip("회전 지속 시간"), SerializeField] private float duration;
        [Tooltip("공격 중에 추격 속도 (기존 속도보다 곱해지는 계수)"), SerializeField] private float chaseSpeedMultiplier;
        [Tooltip("그로기 지속시간"), SerializeField] private float groggyDuration;
        [Tooltip("포효 애니메이션"), SerializeField] private AnimationReferenceAsset roarAnimation;
        [Tooltip("공격력"), SerializeField] private int damage;

        [Header("회전 공격 감지 영역 속성들")] 
        [SerializeField] private ObjectPoolDataSO boxColliderDetectPool;
        [SerializeField] private Vector2 size;
        [SerializeField] private Vector2 center;
        [SerializeField] private bool drawGizmos = true;
        [ShowIf("drawGizmos"), SerializeField] private Color gizmosColor = Color.red;
        
        private PlatformerChaser _chaser;
        private Rigidbody2D _cachedRg;
        private Detector _detector;
        private GroggyHandler _groggyHandler;

        private IDetectStrategy _detectStrategy;
        private float _prevMultiplier;
        private bool _isDetectPlayer;
        private Timer<float> _durationTimer;

        public override void Initialize(SkeletonAnimation animator)
        {
            base.Initialize(animator);

            _chaser = CachedAnimator.GetComponentInParent<PlatformerChaser>();
            _cachedRg = CachedAnimator.GetComponentInParent<Rigidbody2D>();
            _detector = CachedAnimator.transform.parent.GetComponentInChildren<Detector>(true);
            _groggyHandler = CachedAnimator.GetComponentInParent<GroggyHandler>();
            
            _detectStrategy = new BoxColliderDetectorStrategy(boxColliderDetectPool, transform, size, center, layerMask);
            _durationTimer = new CooldownTimer(duration);
            _durationTimer.OnStopped += OnEndSpin;
        }

        public override void ForceStop()
        {
            if(!IsRunning) return;
            
            base.ForceStop();

            _durationTimer?.Stop();
            _chaser.isRunning = false;
            _chaser.moveSpeedMultiplier = _prevMultiplier;
            _detector.UnRegister(DetectType.Physics, _detectStrategy, AttackPlayer);
            _cachedRg.velocity = Vector2.zero;
        }
        
        protected override void ProcessPattern()
        {
            if(!IsRunning) return;
            
            _chaser.isRunning = false;
            _isDetectPlayer = false;    
            _prevMultiplier = _chaser.moveSpeedMultiplier;
            _cachedRg.velocity = Vector2.zero;
            _detector.Register(DetectType.Physics, _detectStrategy, AttackPlayer);
            
            Spinning();
        }
        
        private void Spinning()
        {
            if(!IsRunning) return;
            
            _chaser.isRunning = true;
            _chaser.moveSpeedMultiplier = chaseSpeedMultiplier;
            _durationTimer.Start();
            CachedAnimator.CrossFade(0, loopAnimation, true);
            CachedAnimator.QueuedCrossFade(0, endAnimation, CheckGroggy, duration);
        }

        private void OnEndSpin()
        {
            if (!IsRunning) return;
            
            _chaser.isRunning = false;
            _chaser.moveSpeedMultiplier = _prevMultiplier;
            _detector.UnRegister(DetectType.Physics, _detectStrategy, AttackPlayer);
            _cachedRg.velocity = Vector2.zero;
        }

        private void CheckGroggy(TrackEntry entry)
        {
            entry.Complete -= CheckGroggy;
            
            if (_isDetectPlayer)
            {            
                IsRunning = false;
                Callback?.Invoke();
                _durationTimer?.Stop();
            }
            else
            {
                _groggyHandler.Groggy(groggyDuration, WakeUpFromGroggy);
            }
        }

        private void WakeUpFromGroggy()
        {
            CachedAnimator.CrossFade(0, roarAnimation, () =>
            {            
                _durationTimer?.Stop();
                IsRunning = false;
                Callback?.Invoke(); 
            });
        }

        private void Update()
        {
            _durationTimer?.Tick(Time.deltaTime);
        }

        private void OnDrawGizmos()
        {
            if (!drawGizmos) return;
            
            Gizmos.color = gizmosColor;
            Gizmos.matrix = transform.localToWorldMatrix;
            Gizmos.DrawWireCube(center, size);
        }

        private void AttackPlayer(Collider2D other)
        {
            if (other != null)
            {
                _isDetectPlayer = true;
                
                other.GetComponent<LivingEntity>()?.TakeDamage(damage, gameObject);
            }
        }
    }
}