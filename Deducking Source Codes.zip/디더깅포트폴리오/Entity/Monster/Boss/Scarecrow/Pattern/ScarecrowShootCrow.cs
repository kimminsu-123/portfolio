﻿using DeDucking.Entity;
using DeDucking.Monster.Boss.Patterns;
using DeDucking.Utilities;
using Spine.Unity;
using UnityEngine;

namespace DeDucking.Monster.Boss.Pattern
{
    public class ScarecrowShootCrow : BossPattern
    {
        [SerializeField] private ObjectPoolDataSO poolData;
        [SerializeField] private string targetTag = "Player";
        
        [Tooltip("발싸 애니메이션"), SerializeField] private AnimationReferenceAsset throwAnimation;
        [Tooltip("발싸 딜레이"), SerializeField] private float throwDelay;
        [Tooltip("투사체 속도"), SerializeField] private float shootForce;
        [Tooltip("투사체 공격력"), SerializeField] private int damage;
        [Tooltip("까마귀 발사 위치"), SerializeField] private Transform shootPos;

        private Transform _cachedTr;
        private Transform _targetTr;
        private PlatformerChaser _chaser;
        private Timer<float> _delayTimer;
        
        public override void Initialize(SkeletonAnimation animator)
        {
            base.Initialize(animator);

            _cachedTr = CachedAnimator.transform.parent;
            _targetTr = GameObject.FindGameObjectWithTag(targetTag).transform;
            _chaser = CachedAnimator.GetComponentInParent<PlatformerChaser>();

            _delayTimer = new CooldownTimer(throwDelay);
            _delayTimer.OnStopped += Shoot;
        }

        public override void ForceStop()
        {
            if(!IsRunning) return;
            
            base.ForceStop();
            _chaser.isRunning = true;
            _delayTimer?.Stop();
        }

        protected override void ProcessPattern()
        {
            if(!IsRunning) return;
            
            _chaser.isRunning = false;
            CachedAnimator.CrossFade(0, throwAnimation, () =>
            {
                if(!IsRunning) return;
                Callback?.Invoke();
                ForceStop();
            });
            
            _delayTimer?.Start();
        }

        private void Update()
        {
            if (!IsRunning) return;
            
            _cachedTr.FlipLookAtUsingRotation(_targetTr);
            _delayTimer.Tick(Time.deltaTime);
        }

        private void Shoot()
        {
            if (!IsRunning) return;
            
            Projectile projectile = poolData.GetQueue<Projectile>(shootPos);

            projectile.transform.parent = null;
            projectile.transform.LookAt2D(_targetTr.position, Vector3.zero, true);
            
            projectile.poolDataSo = poolData;
            projectile.hitLayer = layerMask;
            projectile.Setup(shootForce, damage);
        }
    }
}