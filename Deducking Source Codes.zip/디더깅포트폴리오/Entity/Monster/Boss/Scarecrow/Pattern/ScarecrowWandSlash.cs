﻿using DeDucking.Entity;
using DeDucking.Monster.Boss.Patterns;
using DeDucking.Utilities;
using NaughtyAttributes;
using Spine.Unity;
using UnityEngine;


namespace DeDucking.Monster.Boss.Pattern
{
    public class ScarecrowWandSlash : BossPattern
    {
        [Tooltip("공격 애니메이션"), SerializeField] private AnimationReferenceAsset attackAnimation;
        [Tooltip("공격 감지를 몇 프레임 이후에 작동할 것인가?"), SerializeField] private int delayFrame;
        [Tooltip("공격 감지를 몇 프레임동안 시속 시킬것인가?"), SerializeField] private int durationFrame;
        [Tooltip("공격 delay 이후에 앞으로 순간적으로 나가는 속도"), SerializeField] private float dashSpeed;
        [Tooltip("공격력"), SerializeField] private int damage;
        [Tooltip("그로기 지속 시간"), SerializeField] private float groggyDuration;
        
        [Header("지팡이 공격 감지 영역 속성들")] 
        [SerializeField] private ObjectPoolDataSO boxColliderDetectPool;
        [SerializeField] private Vector2 size;
        [SerializeField] private Vector2 center;
        [SerializeField] private bool drawGizmos = true;
        [ShowIf("drawGizmos"), SerializeField] private Color gizmosColor = Color.red;

        private PlatformerChaser _chaser;
        private Rigidbody2D _cachedRg;
        private Detector _detector;
        private GroggyHandler _groggyHandler;

        private IDetectStrategy _detectStrategy;
        private Timer<int> _delayFrameTimer;
        private Timer<int> _detectFrameTimer;
        private bool _successParry;

        public override void Initialize(SkeletonAnimation animator)
        {
            base.Initialize(animator);
            
            _chaser = CachedAnimator.GetComponentInParent<PlatformerChaser>();
            _cachedRg = CachedAnimator.GetComponentInParent<Rigidbody2D>();
            _detector = CachedAnimator.transform.parent.GetComponentInChildren<Detector>(true);
            _groggyHandler = CachedAnimator.GetComponentInParent<GroggyHandler>();

            _detectStrategy = new BoxColliderDetectorStrategy(boxColliderDetectPool, transform, size, center, layerMask);
            _delayFrameTimer = new FrameTimer(delayFrame);
            _detectFrameTimer = new FrameTimer(durationFrame);

            _delayFrameTimer.OnStopped += ActiveDetect;
            _detectFrameTimer.OnStopped += InactiveDetect;
            _successParry = false;
        }

        public override void ForceStop()
        {
            base.ForceStop();
            _chaser.isRunning = true;
            _delayFrameTimer?.Stop();
            _detectFrameTimer?.Stop();
            _cachedRg.velocity = Vector2.zero;
            _detector.UnRegister(DetectType.Physics, _detectStrategy, AttackPlayer);
        }

        private void ActiveDetect()
        {
            if (!IsRunning) return;
            
            _cachedRg.velocity = _cachedRg.transform.right * dashSpeed;
            _detector.Register(DetectType.Physics, _detectStrategy, AttackPlayer);
            
            _detectFrameTimer.Start();
        }

        private void InactiveDetect()
        {
            _detector.UnRegister(DetectType.Physics, _detectStrategy, AttackPlayer);

            if (IsRunning)
            {
                _cachedRg.velocity = Vector2.zero;
            }
        }
        
        protected override void ProcessPattern()
        {
            if(!IsRunning) return;

            _successParry = false;
            _chaser.isRunning = false;
            
            CachedAnimator.CrossFade(0, attackAnimation, CheckGroggy);
            
            _cachedRg.velocity = Vector2.zero;
            
            _delayFrameTimer?.Start();
        }

        private void FixedUpdate()
        {
            _delayFrameTimer?.Tick(1);
            _detectFrameTimer?.Tick(1);
        }

        private void CheckGroggy()
        {
            if (_successParry)
            {
                _groggyHandler.Groggy(groggyDuration, ExitPattern);
            }
            else
            {
                ExitPattern();
            }
        }

        private void ExitPattern()
        {
            Callback?.Invoke();
            
            ForceStop();
        }

        private void AttackPlayer(Collider2D player)
        {
            if (player == null)
            {
                return;
            }
            
            player.GetComponent<LivingEntity>()?.TakeDamage(damage, gameObject);
            InactiveDetect();
        }

        public override void SuccessParry()
        {
            InactiveDetect();
            _successParry = true;
        }

        public override void SuccessBlock()
        {
            InactiveDetect();
        }

        private void OnDrawGizmos()
        {
            if (!drawGizmos) return;

            Gizmos.color = gizmosColor;
            Gizmos.matrix = transform.localToWorldMatrix;
            Gizmos.DrawWireCube(center, size);
        }
    }
}