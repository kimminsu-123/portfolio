﻿using System;
using DeDucking.Entity;
using DeDucking.Monster.Boss.Patterns;
using DeDucking.Utilities;
using Spine.Unity;
using UnityEngine;

namespace DeDucking.Monster.Boss.Pattern
{
    public class ScarecrowComboAttacks : BossPattern
    {
        [Serializable]
        private class ScarecrowComboAttack
        {
            [Tooltip("공격 애니메이션")] public AnimationReferenceAsset attackAnimation;
            [Tooltip("공격력")] public int attackDamage;
            [Tooltip("공격 딜레이 프레임")] public int delayFrame;
            [Tooltip("공격 감지 프레임")] public int detectFrame;
            [Tooltip("공격 감지 박스 사이즈")] public Vector2 attackBoxSize;
            [Tooltip("공격 감지 박스 센터")] public Vector2 attackBoxOffset;
            [Tooltip("공격시에 앞으로 이동할 속도")] public float xSpeed;
            [Tooltip("해당 콤보가 실행 되기 전 대기 시간")] public float delay = 0.3f;
            
            [SerializeField, Tooltip("기즈모 그리기 여부")] private bool isDrawGizmos = true;
            [SerializeField, Tooltip("기즈모 색")] private Color gizmosColor = Color.white;

            public void DrawGizmos(Transform parentTransform)
            {
                if (!isDrawGizmos)
                {
                    return;
                }
                Gizmos.color = gizmosColor;
                Gizmos.matrix = parentTransform.localToWorldMatrix;
                Gizmos.DrawWireCube(attackBoxOffset, attackBoxSize);
            }
        }
        
        [Header("공격 속성들 (순서대로 값 할당 필요!)")]
        [SerializeField] private ScarecrowComboAttack[] scarecrowComboAttacks;
        [SerializeField] private ObjectPoolDataSO boxColliderDetectPool;
        [SerializeField] private float groggyDuration;
        
        private BoxColliderDetectorStrategy _boxColliderDetector;
        private Timer<int> _delayFrameTimer;
        private Timer<int> _detectFrameTimer;
        private Timer<float> _comboDelayTimer;
        private int _currentCombo;
        private int _currentParriedCount;

        private PlatformerChaser _chaser;
        private Rigidbody2D _cachedRg;
        private Detector _detector;
        private GroggyHandler _groggyHandler;

        public override void Initialize(SkeletonAnimation animator)
        {
            base.Initialize(animator);

            _chaser = CachedAnimator.GetComponentInParent<PlatformerChaser>();
            _cachedRg = CachedAnimator.GetComponentInParent<Rigidbody2D>();
            _detector = CachedAnimator.transform.parent.GetComponentInChildren<Detector>(true);
            _groggyHandler = CachedAnimator.GetComponentInParent<GroggyHandler>();
            
            _boxColliderDetector = new BoxColliderDetectorStrategy(boxColliderDetectPool, transform, Vector2.zero, Vector2.zero, 1);
            _delayFrameTimer = new FrameTimer();
            _detectFrameTimer = new FrameTimer();
            _comboDelayTimer = new CooldownTimer();
            _currentCombo = -1;
            _currentParriedCount = 0;
            
            _delayFrameTimer.OnStopped += ActiveDetect;
            _detectFrameTimer.OnStopped += InactiveDetect;
            _comboDelayTimer.OnStopped += MoveNextCombo;
        }

        protected override void ProcessPattern()
        {
            if(!IsRunning) return;

            _currentCombo = 0;
            _currentParriedCount = 0;
            _chaser.isRunning = false;
            
            _comboDelayTimer.SetTime(scarecrowComboAttacks[_currentCombo].delay);
            _comboDelayTimer.Start();
        }

        private void ActiveDetect()
        {
            if (!IsRunning) return;
            
            _cachedRg.velocity = Vector2.zero;
            _cachedRg.velocity = _cachedRg.transform.right * scarecrowComboAttacks[_currentCombo].xSpeed;
            _detector.Register(DetectType.Physics, _boxColliderDetector, AttackPlayer);

            _detectFrameTimer.SetTime(scarecrowComboAttacks[_currentCombo].detectFrame);
            _detectFrameTimer.Start();
        }

        private void InactiveDetect()
        {
            _detector.UnRegister(DetectType.Physics, _boxColliderDetector, AttackPlayer);
        }

        private void MoveNextCombo()
        {
            if (!IsRunning) return;
                        
            var currentAkt = scarecrowComboAttacks[_currentCombo];
            
            CachedAnimator.CrossFade(0, currentAkt.attackAnimation, () =>
            {
                if (_currentCombo >= scarecrowComboAttacks.Length - 1)
                {
                    CheckGroggy();
                    return;
                }

                var effect = hintEffectPool.GetQueue<ParryHintEffectPoolObj>(hintEffectPos);
                effect.SetOriginPool(hintEffectPool);
                effect.SetupAnimation(gameObject.layer);
                effect.Play();
                
                _comboDelayTimer.SetTime(scarecrowComboAttacks[++_currentCombo].delay);                
                _comboDelayTimer.Start();
            });

            _boxColliderDetector.Setup(currentAkt.attackBoxSize, currentAkt.attackBoxOffset, layerMask);

            _delayFrameTimer.SetTime(currentAkt.delayFrame);
            _delayFrameTimer.Start();
        }

        private void CheckGroggy()
        {
            if (_currentParriedCount >= scarecrowComboAttacks.Length)
            {
                // 모든 공격 패링 성공!
                _cachedRg.velocity = Vector2.zero;
                _groggyHandler.Groggy(groggyDuration, ExitPattern);
            }
            else
            {
                ExitPattern();
            }
        }

        private void ExitPattern()
        {
            Callback?.Invoke();
            ForceStop();
        }

        private void Update()
        {
            _comboDelayTimer?.Tick(Time.deltaTime);
        }

        private void FixedUpdate()
        {
            _delayFrameTimer?.Tick(1);
            _detectFrameTimer?.Tick(1);
        }

        private void AttackPlayer(Collider2D player)
        {
            if (player != null)
            {
                player.GetComponent<LivingEntity>()?.TakeDamage(scarecrowComboAttacks[_currentCombo].attackDamage, gameObject);
                InactiveDetect();
            }
        }

        public override void ForceStop()
        {
            base.ForceStop();
            _currentCombo = -1;
            _delayFrameTimer.Stop();
            _detectFrameTimer.Stop();
            _detector.UnRegister(DetectType.Update, _boxColliderDetector, AttackPlayer);
            _cachedRg.velocity = Vector2.zero;
            _chaser.isRunning = true;
        }

        public override void SuccessParry()
        {
            InactiveDetect();
            _currentParriedCount++;
        }
        
        public override void SuccessBlock()
        {
            InactiveDetect();
        }
        
        private void OnDrawGizmos()
        {
            foreach (var attack in scarecrowComboAttacks)
            {
                attack.DrawGizmos(transform);
            }
        }
    }
}