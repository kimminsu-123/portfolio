﻿using DeDucking.Entity;
using DeDucking.FSM;
using DeDucking.Managers;
using DeDucking.Monster.Boss.Patterns;
using DeDucking.Monster.Boss.State;
using DeDucking.Utilities;
using UnityEngine;
using EventType = DeDucking.Managers.EventType;

namespace DeDucking.Monster.Boss
{
    public class Scarecrow : MonoBehaviour, IBoss
    {
        [Header("추격 대상")] 
        [SerializeField] private string chaseTargetTag = "Player";

        [Header("일반 공격 김지 속성 (추격 -> 일반 공격) (Box 모양)")] 
        [SerializeField] private Transform detectAttackParent;
        [SerializeField] private ObjectPoolDataSO boxColliderDetectPool;
        [SerializeField] private Vector2 size;
        [SerializeField] private Vector2 center;
        [SerializeField] private LayerMask detectLayerMask;
        
        public bool IsClear => _isClear;

        private StateMachine _stateMachine;
        private LivingEntity _entity;
        private BossPatternBehavior _behavior;
        private Detector _detector;
        private PlatformerChaser _chaser;

        private bool _isClear;
        private bool _isDetectPlayer;
        private Transform _chaseTarget;
        private BossState _idleState;
        private BossState _chaseState;
        private BossState _attackState;
        private BossState _skillState;
        private BossState _dieState;

        private IDetectStrategy _chase2AttackDetectStrategy;

        private void Awake()
        {
            _stateMachine = GetComponent<StateMachine>();
            _entity = GetComponent<LivingEntity>();
            _behavior = GetComponentInChildren<BossPatternBehavior>(true);
            _detector = GetComponentInChildren<Detector>(true);
            _chaser = GetComponent<PlatformerChaser>();
        }

        private void Start()
        {
            EventManager.Instance.AddListener(EventType.OnSceneLoaded, OnSceneLoaded);
        }

        private void OnSceneLoaded(EventType type, Component sender, object[] args)
        {
            SetupStates();
            ConnectTransition();
            Initialize();
        }

        private void SetupStates()
        {
            _idleState = new IdleState(gameObject);
            _chaseState = new ChaseState(gameObject);
            _attackState = new AttackState(gameObject);
            _skillState = new SkillState(gameObject);
            _dieState = new DieState(gameObject);
        }
        
        private void ConnectTransition()
        {
            _stateMachine.AddTransition(_idleState, _chaseState, new FuncPredicate(() => !_chaser.CurrentVelocity.Equals(Vector2.zero)));
            _stateMachine.AddTransition(_idleState, _attackState, new FuncPredicate(() => _behavior.ReadyToAttack && _isDetectPlayer));
            _stateMachine.AddTransition(_idleState, _skillState, new FuncPredicate(() => _behavior.ReadyToSkill));
            
            _stateMachine.AddTransition(_chaseState, _idleState, new FuncPredicate(() => _chaser.CurrentVelocity.Equals(Vector2.zero)));
            _stateMachine.AddTransition(_chaseState, _attackState, new FuncPredicate(() => _behavior.ReadyToAttack && _isDetectPlayer));
            _stateMachine.AddTransition(_chaseState, _skillState, new FuncPredicate(() => _behavior.ReadyToSkill));
            
            _stateMachine.AddTransition(_attackState, _chaseState, new FuncPredicate(() => _attackState.IsCompleted));
            
            _stateMachine.AddTransition(_skillState, _chaseState, new FuncPredicate(() => _skillState.IsCompleted));

            _stateMachine.AddAnyTransition(_dieState, new FuncPredicate(() => _isClear));
        }

        private void Initialize()
        {
            _chaseTarget = GameObject.FindGameObjectWithTag(chaseTargetTag).transform;
            _chase2AttackDetectStrategy = new BoxColliderDetectorStrategy(boxColliderDetectPool, detectAttackParent, size, center, detectLayerMask);
            _isClear = false;
            _isDetectPlayer = false;
            
            _behavior.Initialize();
            _detector.Register(DetectType.Physics, _chase2AttackDetectStrategy, OnDetectPlayer);
            _entity.onDeathCallback.AddListener(OnDeath);

            _chaser.isRunning = false;
            _chaser.SetTarget(_chaseTarget);
        }

        public void Begin()
        {
            _behavior.ResetCooldown();
            
            _stateMachine.SetState(_idleState);
        }

        public void End()
        {
            _detector.UnRegister(DetectType.Physics, _chase2AttackDetectStrategy, OnDetectPlayer);
        }

        private void OnDeath()
        {
            _isClear = true;
        }

        private void OnDrawGizmos()
        {
            Gizmos.color = Color.blue;
            Gizmos.matrix = transform.localToWorldMatrix;
            Gizmos.DrawWireCube(center, size);
        }

        private void OnDetectPlayer(Collider2D player)
        {
            _isDetectPlayer = player != null;
        }

        private void OnDestroy()
        {
            EventManager.Instance.RemoveListener(EventType.OnSceneLoaded, OnSceneLoaded);
        }
    }
}