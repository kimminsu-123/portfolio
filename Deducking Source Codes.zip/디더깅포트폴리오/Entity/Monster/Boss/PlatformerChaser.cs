﻿using System;
using System.Numerics;
using DeDucking.Utilities;
using NaughtyAttributes;
using UnityEngine;
using Quaternion = UnityEngine.Quaternion;
using Vector2 = UnityEngine.Vector2;

namespace DeDucking.Monster.Boss
{
    [RequireComponent(typeof(Rigidbody2D))]
    public class PlatformerChaser : MonoBehaviour
    {
        public Vector2 CurrentVelocity { get; private set; }

        public bool isRunning;
        public float moveSpeedMultiplier = 1f;
        public float moveSpeed;
        
        [SerializeField] private bool allowFlipToTarget;
        [SerializeField] private float stoppingDistance;
        [MinMaxSlider(0f, 180f), SerializeField] private Vector2 lookAngleLimit = new(85f, 95f);

        private Rigidbody2D _cachedRg;
        private Transform _target;

        private void Awake()
        {
            _cachedRg = GetComponent<Rigidbody2D>();
        }

        private void FixedUpdate()
        {
            if (isRunning && _target != null)
            {
                Vector2 dir = _target.position - transform.position;
                dir.y = 0f;
                dir.Normalize();

                if (allowFlipToTarget)
                {
                    _cachedRg.isKinematic = true;
                    transform.FlipLookAtUsingRotation(_target);
                    _cachedRg.isKinematic = false;
                }
                
                Chase(dir);
            }
        }
        
        public void SetTarget(Transform target)
        {
            _target = target;
        }
        
        private void Chase(Vector2 dir)
        {
            Vector2 destVector = _target.position - transform.position;
            CurrentVelocity = dir * (moveSpeed * moveSpeedMultiplier);
            
            float sqrDist = Vector2.SqrMagnitude(destVector);
            float distance = sqrDist * sqrDist;

            if (distance <= stoppingDistance)
            {
                CurrentVelocity = Vector2.zero;
            }

            float angle = Util.GetAngle(transform.position, _target.position);
            if (lookAngleLimit.x <= angle && angle <= lookAngleLimit.y)
            {
                CurrentVelocity = Vector2.zero;
            }

            _cachedRg.velocity = CurrentVelocity;
        }
    }
}