﻿using DeDucking.Utilities;
using Entity.Monster;
using Spine.Unity;
using UnityEngine;
using Logger = DeDucking.Utilities.Logger;

namespace DeDucking.Monster.State.PumpkinMonster
{
    public class IdleState : MonsterState<Pumpkin>
    {
        private readonly Rigidbody2D _rigidbody;
        private readonly SkeletonAnimation _animator;
        private readonly CooldownTimer _durationTimer;
        
        public IdleState(Pumpkin entity) : base(entity)
        {
            _rigidbody = CachedEntity.Rigid2D;
            _animator = CachedEntity.Animator;
            
            _durationTimer = new CooldownTimer(CachedEntity.IdleDuration);
            _durationTimer.OnStopped += OnEndOfIdle;
        }

        public override void EnterState()
        {
            Logger.Log("Pumpkin State Enter", "Idle", Color.red);
            IsCompleted = false;
            
            _rigidbody.velocity = Vector2.zero;
            _animator.CrossFade(0, Pumpkin.AnimationName.Idle, true);
            
            _durationTimer.Start();
        }

        public override void UpdateState()
        {
            _durationTimer?.Tick(Time.deltaTime);
        }

        private void OnEndOfIdle()
        {
            IsCompleted = true;
        }
    }
}