﻿using DeDucking.Entity;
using DeDucking.Player.Handler;
using DeDucking.Utilities;
using Entity.Monster;
using Spine.Unity;
using UnityEngine;
using Logger = DeDucking.Utilities.Logger;

namespace DeDucking.Monster.State.PumpkinMonster
{
    public class PatrolState : MonsterState<Pumpkin>
    {
        private readonly Rigidbody2D _rigidbody;
        private readonly SkeletonAnimation _animator;
        private readonly SurfaceChecker _surfaceChecker;

        private float MoveSpeed => CachedEntity.PatrolMoveSpeed;
        
        public PatrolState(Pumpkin entity) : base(entity)
        {
            _rigidbody = CachedEntity.Rigid2D;
            _animator = CachedEntity.Animator;
            _surfaceChecker = CachedEntity.SurfaceChecker;
        }

        public override void EnterState()
        {
            Logger.Log("Pumpkin State Enter", "Patrol", Color.red);
            
            IsCompleted = false;
            _animator.CrossFade(0, Pumpkin.AnimationName.Move, true);
        }

        public override void FixedUpdateState()
        {
            MoveToCurrentPoint();
        }

        private void MoveToCurrentPoint()
        {
            Vector2 vel = _rigidbody.velocity;
            vel.x = CachedEntity.transform.right.x * MoveSpeed;
            _rigidbody.velocity = vel;
            
            if (!_surfaceChecker.IsGrounded || _surfaceChecker.IsOnWall)
            {
                CachedEntity.transform.FlipLookAtUsingRotation();
                IsCompleted = true;
            }
        }
    }
}