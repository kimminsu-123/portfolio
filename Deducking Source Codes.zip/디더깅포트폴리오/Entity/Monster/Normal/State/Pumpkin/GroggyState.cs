﻿using DeDucking.Entity;
using Entity.Monster;
using UnityEngine;
using Logger = DeDucking.Utilities.Logger;

namespace DeDucking.Monster.State.PumpkinMonster
{
    public class GroggyState : MonsterState<Pumpkin>
    {
        private readonly Rigidbody2D _rigidbody;
        private readonly GroggyHandler _groggyHandler;
        
        public GroggyState(Pumpkin entity) : base(entity)
        {
            _rigidbody = CachedEntity.Rigid2D;
            _groggyHandler = entity.GetComponent<GroggyHandler>();
        }

        public override void EnterState()
        {
            Logger.Log("Pumpkin State Enter", "Groggy", Color.red);
            
            IsCompleted = false;
            
            _rigidbody.velocity = Vector2.zero;
            _groggyHandler.Groggy(CachedEntity.GroggyDuration, OnGroggyEnd);
        }
        
        private void OnGroggyEnd()
        {
            IsCompleted = true;
        }
    }
}