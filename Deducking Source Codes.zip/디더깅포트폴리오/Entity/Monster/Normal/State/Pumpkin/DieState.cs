﻿using DeDucking.Entity.Monster;
using DeDucking.Utilities;
using Entity.Monster;
using Spine.Unity;

namespace DeDucking.Monster.State.PumpkinMonster
{
    public class DieState : MonsterState<Pumpkin>
    {
        private readonly SkeletonAnimation _animation;
        private readonly ObjectPoolDataSO _dieEffectPool;
        
        public DieState(Pumpkin entity, ObjectPoolDataSO dieEffectPool) : base(entity)
        {
            _animation = CachedEntity.Animator;
            _dieEffectPool = dieEffectPool;
        }

        public override void EnterState()
        {
            _animation.CrossFade(0, Pumpkin.AnimationName.Die, OnAnimationFinish);
        }

        private void OnAnimationFinish()
        {
            var effect = _dieEffectPool.GetQueue<ParticlePoolObjActivator>(CachedEntity.transform);
            effect.transform.parent = null;
            effect.SetOriginPool(_dieEffectPool);
            effect.Play();
            
            CachedEntity.gameObject.SetActive(false);
        }
    }
}