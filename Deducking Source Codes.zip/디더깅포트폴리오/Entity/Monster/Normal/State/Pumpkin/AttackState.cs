﻿using DeDucking.Entity;
using DeDucking.Utilities;
using Entity.Monster;
using Spine.Unity;
using UnityEngine;
using Logger = DeDucking.Utilities.Logger;

namespace DeDucking.Monster.State.PumpkinMonster
{
    public class AttackState : MonsterState<Pumpkin>
    {
        private readonly Rigidbody2D _rigidbody2D;
        private readonly SkeletonAnimation _animator;
        private readonly SurfaceChecker _surfaceChecker;
        private readonly Detector _detector;
        private readonly IDetectStrategy _attackDetectStrategy;

        private Vector2 _direction;

        private int AttackDamage => CachedEntity.AttackDamage;
        private float MoveSpeed => CachedEntity.AttackMoveSpeed;
        private float AnimationSpeedFactor => MoveSpeed / CachedEntity.PatrolMoveSpeed;
        private Transform TargetTransform => CachedEntity.PlayerTr;
        private Transform AttackAreaParent => CachedEntity.AttackAreaParent;
        private Rect AttackArea => CachedEntity.AttackArea;
        private ObjectPoolDataSO ParryHintPool => CachedEntity.ParryHintPool;
        private Transform ParryHintEffectParent => CachedEntity.ParryHintEffectParent;

        public AttackState(Pumpkin entity) : base(entity)
        {
            _rigidbody2D = CachedEntity.Rigid2D;
            _animator = CachedEntity.Animator;
            _surfaceChecker = CachedEntity.SurfaceChecker;
            _detector = CachedEntity.Detector;

            _attackDetectStrategy = new BoxColliderDetectorStrategy(CachedEntity.BoxColliderPool, AttackAreaParent,
                AttackArea.size, AttackArea.min, CachedEntity.DetectLayerMask);
        }

        public override void EnterState()
        {
            Logger.Log("Pumpkin State Enter", "Attack", Color.red);

            CachedEntity.HasBlocked = false;
            CachedEntity.SuccessAttack = false;
            CachedEntity.HasParried = false;
            IsCompleted = false;

            CachedEntity.transform.FlipLookAtUsingRotation(TargetTransform);

            _animator.CrossFade(0, Pumpkin.AnimationName.AttackPre, BeginAttack);
            _animator.QueuedCrossFade(0, Pumpkin.AnimationName.AttackRoll, true, 0f, AnimationSpeedFactor);
            
            _direction = (TargetTransform.position - CachedEntity.transform.position).normalized;
            _direction = _direction.x > 0f ? Vector2.right : Vector2.left;

            var effect = ParryHintPool.GetQueue<ParryHintEffectPoolObj>(ParryHintEffectParent);
            effect.SetOriginPool(ParryHintPool);
            effect.SetupAnimation(AttackAreaParent.gameObject.layer);
            effect.Play();
        }

        private void BeginAttack()
        {
            if (IsCompleted)
            {
                return;
            }
            
            _detector.Register(DetectType.Physics, _attackDetectStrategy, OnSuccessAttack);
        }

        public override void FixedUpdateState()
        {
            Vector2 vel = _rigidbody2D.velocity;
            vel.x = _direction.x * MoveSpeed;
            _rigidbody2D.velocity = vel;

            if (_surfaceChecker.IsOnWall || !_surfaceChecker.IsGrounded)
            {
                IsCompleted = true;
            }
        }

        public override void ExitState()
        {
            _detector.UnRegister(DetectType.Physics, _attackDetectStrategy, OnSuccessAttack);
        }
        
        private void OnSuccessAttack(Collider2D obj)
        {
            if (CachedEntity.HasBlocked || CachedEntity.HasParried)
            {
                return;
            }
            
            if (obj == null)
            {
                return;
            }
            obj.GetComponent<LivingEntity>()?.TakeDamage(AttackDamage, AttackAreaParent.gameObject);
            Logger.Log("ParryTest", "Success Attack", Color.green);
            CachedEntity.SuccessAttack = true;
            IsCompleted = true;
            _detector.UnRegister(DetectType.Physics, _attackDetectStrategy, OnSuccessAttack);
        }
    }
}