using DeDucking.Entity.Monster;
using DeDucking.FSM;

namespace DeDucking.Monster.State
{    
    public struct MonsterAnimationName
    {
        public static readonly string Idle = "FP_idle";
        public static readonly string Die = "Die";
        public static readonly string Chase = "Chase";
        public static readonly string Patrol = "Patrol";
        public static readonly string Attack = "ATTACK";
        public static readonly string Move = "move";
        public static readonly string Stun = "FP_stun";
        public static readonly string ThornsAttack = "attack_merged";
        public static readonly string PumpkinAttack = "FP_attack_roll";
        public static readonly string ThronsIdle = "idle";
    }
    
    public abstract class MonsterState<T> : IState where T : Enemy
    {
        public bool IsCompleted { get; protected set; }

        protected T CachedEntity { get; private set; }
        
        protected MonsterState(T entity)
        {
            CachedEntity = entity;
        }
        
        public virtual void EnterState()
        {
            
        }

        public virtual void UpdateState()
        {
            
        }

        public virtual void FixedUpdateState()
        {
            
        }

        public virtual void ExitState()
        {
            
        }
    }
}
