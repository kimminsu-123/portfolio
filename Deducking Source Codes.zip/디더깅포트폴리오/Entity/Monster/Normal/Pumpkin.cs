﻿using DeDucking.Entity;
using DeDucking.Entity.Monster;
using DeDucking.FSM;
using DeDucking.Monster.State;
using DeDucking.Monster.State.PumpkinMonster;
using DeDucking.Utilities;
using Spine.Unity;
using UnityEngine;

namespace Entity.Monster
{
    [RequireComponent(typeof(LivingEntity))]    
    public class Pumpkin : Enemy, IParryReceiver
    {
        public struct AnimationName
        {
            public static readonly string Idle = "FP_idle";
            public static readonly string AttackRoll = "FP_attack_roll";
            public static readonly string AttackPre = "FP_att pre";
            public static readonly string Die = "FP_crack";
            public static readonly string Move = "FP_idle2";
        }
        
        public override bool IsDead => _entity.IsDeath;

        public bool HasParried { get; set; }
        public bool HasBlocked { get; set; }
        public bool SuccessAttack { get; set; }

        public Rigidbody2D Rigid2D => _rigidbody2D;
        public SkeletonAnimation Animator => _animator;
        public Detector Detector => _detector;
        public SurfaceChecker SurfaceChecker => _surfaceChecker;
        
        public float IdleDuration => stayIdleDuration;
        public float PatrolMoveSpeed => patrolMoveSpeed;
        public float AttackMoveSpeed => attackMoveSpeed;
        public int AttackDamage => attackDamage;
        public Transform AttackAreaParent => attackAreaParent;
        public Rect AttackArea => attackArea;
        public ObjectPoolDataSO ParryHintPool => parryHintPool;
        public Transform ParryHintEffectParent => parryHintEffectParent;
        public ObjectPoolDataSO BoxColliderPool => boxColliderPool;
        public LayerMask DetectLayerMask => detectLayerMask;
        public float GroggyDuration => groggyDuration;
        
        public Transform PlayerTr => _playerTr;

        [SerializeField] private ObjectPoolDataSO deathEffectPool;
        [SerializeField] private bool usePatrol = true;
        
        [Header("호박 감지 영역 속성들")]
        [SerializeField] private ObjectPoolDataSO boxColliderPool;
        [SerializeField] private Transform detectAreaParent;
        [SerializeField] private Rect detectArea;
        [SerializeField] private LayerMask detectLayerMask;

        [Header("호박 Idle 속성들")] 
        [SerializeField] private float stayIdleDuration;
        
        [Header("호박 정찰 속성들")] 
        [SerializeField] private float patrolMoveSpeed;
        
        [Header("호박 공격 속성들")] 
        [SerializeField] private float attackMoveSpeed;
        [SerializeField] private int attackDamage;
        [SerializeField] private Transform attackAreaParent;
        [SerializeField] private Rect attackArea;
        [SerializeField] private ObjectPoolDataSO parryHintPool;
        [SerializeField] private Transform parryHintEffectParent;
        
        [Header("호박 그로기 속성들")] 
        [SerializeField] private float groggyDuration;
        
        private LivingEntity _entity;
        private Detector _detector;
        private StateMachine _stateMachine;
        private Rigidbody2D _rigidbody2D;
        private SkeletonAnimation _animator;
        private SurfaceChecker _surfaceChecker;

        private IDetectStrategy _detectPlayerStrategy;
        private MonsterState<Pumpkin> _idleState;
        private MonsterState<Pumpkin> _patrolState;
        private MonsterState<Pumpkin> _attackState;
        private MonsterState<Pumpkin> _groggyState;
        private MonsterState<Pumpkin> _dieState;
        private Transform _playerTr;
        
        protected override void OnAwake()
        {
            _entity = GetComponent<LivingEntity>();
            _detector = GetComponent<Detector>();
            _stateMachine = GetComponent<StateMachine>();
            _rigidbody2D = GetComponent<Rigidbody2D>();
            _animator = GetComponentInChildren<SkeletonAnimation>();
            _surfaceChecker = GetComponent<SurfaceChecker>();
            _detectPlayerStrategy = new BoxColliderDetectorStrategy(boxColliderPool, detectAreaParent, detectArea.size, detectArea.min, detectLayerMask);
        }

        private void Start()
        {
            SetupStates();
            ConnectTransition();
        }

        protected override void Initialize()
        {
            _detector.Register(DetectType.Physics, _detectPlayerStrategy, DetectPlayer);
            _stateMachine.SetState(_idleState);            
        }

        private void SetupStates()
        {
            _idleState = new IdleState(this);
            _patrolState = new PatrolState(this);
            _attackState = new AttackState(this);
            _groggyState = new GroggyState(this);
            _dieState = new DieState(this, deathEffectPool);
        }

        private void ConnectTransition()
        {
            _stateMachine.AddTransition(_idleState, _attackState, new FuncPredicate(() => _playerTr != null && _idleState.IsCompleted));
            _stateMachine.AddTransition(_attackState, _idleState, new FuncPredicate(() => (_attackState.IsCompleted && SuccessAttack) || HasBlocked));
            _stateMachine.AddTransition(_attackState, _groggyState, new FuncPredicate(() => (_attackState.IsCompleted && !SuccessAttack) || HasParried));
            _stateMachine.AddTransition(_groggyState, _attackState, new FuncPredicate(() => _groggyState.IsCompleted && _playerTr != null));
            _stateMachine.AddAnyTransition(_dieState, new FuncPredicate(() => IsDead));

            if (usePatrol)
            {
                _stateMachine.AddTransition(_idleState, _patrolState, new FuncPredicate(() => _playerTr == null && _idleState.IsCompleted));
                _stateMachine.AddTransition(_groggyState, _patrolState, new FuncPredicate(() => _groggyState.IsCompleted && _playerTr == null));
                
                _stateMachine.AddTransition(_patrolState, _idleState, new FuncPredicate(() => _patrolState.IsCompleted));
                _stateMachine.AddTransition(_patrolState, _attackState, new FuncPredicate(() => _playerTr != null));
            }
            else
            {
                _stateMachine.AddTransition(_groggyState, _idleState, new FuncPredicate(() => _groggyState.IsCompleted && _playerTr == null));
            }
        }
        
        private void DetectPlayer(Collider2D player)
        {
            _playerTr = player != null ? player.transform : null;
        }

        private void OnDisable()
        {
            _detector.UnRegister(DetectType.Physics, _detectPlayerStrategy, DetectPlayer);
        }

        private void OnDrawGizmos()
        {
            if (detectAreaParent != null)
            {
                Gizmos.color = Color.red;
                Gizmos.matrix = detectAreaParent.localToWorldMatrix;
                Gizmos.DrawWireCube(detectArea.min, detectArea.size);   
            }
            
            if (attackAreaParent != null)
            {
                Gizmos.color = Color.green;
                Gizmos.matrix = attackAreaParent.localToWorldMatrix;
                Gizmos.DrawWireCube(attackArea.min, attackArea.size);   
            }
        }

        public void SuccessParry()
        {
            HasParried = true;
        }

        public void SuccessBlock()
        {
            HasBlocked = true;
        }
    }
}