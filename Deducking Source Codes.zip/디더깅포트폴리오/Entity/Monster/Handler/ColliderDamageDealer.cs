using DeDucking.Entity;
using DeDucking.Utilities;
using UnityEngine;

namespace DeDucking.Monster.Handler
{
    public class ColliderDamageDealer : MonoBehaviour
    {
        [SerializeField] private LayerMask layerMask;
        [SerializeField] private int damage;

        public void OnCollisionEnter2D(Collision2D col)
        {
            int layer = col.gameObject.layer;

            if (layerMask.Contains(layer))
            {
                var entity = col.gameObject.GetComponent<LivingEntity>();

                if (entity != null)
                {
                    entity.TakeDamage(damage, gameObject);
                }
            }
        }
    }
}
