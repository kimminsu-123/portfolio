using System.Collections.Generic;
using DeDucking.Utilities;
using Spine.Unity;
using UnityEngine;
using UnityEngine.UI;

namespace DeDucking.Entity.UI
{
    public class ActivationHealthUI : HealthUI
    {
        [SerializeField] private GameObject hpPrefab;
        [SerializeField] private GameObject alterHpPrefab;

        [SerializeField] private RectTransform hpElementParent;
        [SerializeField] private RectTransform alterHpElementParent;

        private readonly List<HealthElement> _hpElements = new();
        private readonly List<HealthElement> _alterHpElements = new();

        private int _maxHp;
        private int _maxAlterHp;
        
        protected override void Setup()
        {
            _maxHp = entity.EntityData.MaxHp;
            _maxAlterHp = entity.EntityData.MaxAlterHp;

            for (int i = 0; i < _maxHp; i++)
            {
                var ele = Instantiate(hpPrefab, hpElementParent).GetComponent<HealthElement>();
                ele.Fill();
                _hpElements.Add(ele);
            }
            
            for (int i = 0; i < _maxAlterHp; i++)
            {
                var ele = Instantiate(alterHpPrefab, alterHpElementParent).GetComponent<HealthElement>();
                ele.Drain();
                _alterHpElements.Add(ele);
            }
        }

        protected override void OnDamaged(GameObject hitter)
        {
            UpdateHealth();
            UpdateAlterHealth();
        }
        
        protected override void OnHeal()
        {
            UpdateHealth();
            UpdateAlterHealth();
        }

        private void UpdateHealth()
        {
            int currentHp = entity.CurrentHp;

            for (int i = 0; i < _maxHp; i++)
            {
                if(i < currentHp) _hpElements[i].Fill();
                else _hpElements[i].Drain();
            }
            
            LayoutRebuilder.ForceRebuildLayoutImmediate(hpElementParent);
        }

        private void UpdateAlterHealth()
        {
            int currentAlterHp = entity.CurrentAlterHp;

            for (int i = 0; i < _maxAlterHp; i++)
            {
                if(i < currentAlterHp) _alterHpElements[i].Fill();
                else _alterHpElements[i].Drain();
            }
            
            LayoutRebuilder.ForceRebuildLayoutImmediate(alterHpElementParent);
        }
    }
}