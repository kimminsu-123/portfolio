using DeDucking.Utilities;
using NaughtyAttributes;
using Spine.Unity;
using UnityEngine;

namespace DeDucking.Entity.UI
{
    public enum ImageType
    {
        None,
        Animation,
    }
    
    public class HealthElement : MonoBehaviour
    {
        [SerializeField] private ImageType type = ImageType.None;
        [SerializeField, ShowIf("type", ImageType.None)] private GameObject fillImage;
        [SerializeField, ShowIf("type", ImageType.Animation)] private SkeletonGraphic fillAnimation;
        [SerializeField, ShowIf("type", ImageType.Animation)] private AnimationReferenceAsset fillAnimationAsset;

        private bool _hasFilled = false;
        
        public void Fill()
        {
            if (_hasFilled) return;
            
            _hasFilled = true;
            
            if (type == ImageType.None)
            {
                fillImage.SetActive(true);
            }
            else
            {
                fillAnimation.gameObject.SetActive(true);
                fillAnimation.CrossFade(0, fillAnimationAsset, false);
            }
        }

        public void Drain()
        {
            _hasFilled = false;
            
            if (type == ImageType.None)
            {
                fillImage.SetActive(false);
            }
            else
            {
                fillAnimation.gameObject.SetActive(false);
            }
        }
    }
}