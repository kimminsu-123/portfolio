using System;
using UnityEngine;

namespace DeDucking.Entity.UI
{
    public abstract class HealthUI : MonoBehaviour
    {
        [SerializeField] protected LivingEntity entity;

        private void Awake()
        {
            Initialize();
        }

        private void Initialize()
        {
            Setup();
            RegisterEvents();
        }

        protected virtual void RegisterEvents()
        {
            entity.onDamageCallback.AddListener(OnDamaged);
            entity.onHealCallback.AddListener(OnHeal);
        }

        protected virtual void OnDestroy()
        {
            entity.onDamageCallback.RemoveListener(OnDamaged);
            entity.onHealCallback.RemoveListener(OnHeal);
        }

        protected abstract void Setup();
        protected abstract void OnDamaged(GameObject hitter);
        protected abstract void OnHeal();
    }
}