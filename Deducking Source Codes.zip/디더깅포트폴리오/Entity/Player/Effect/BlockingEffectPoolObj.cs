﻿using DeDucking.Utilities;
using Spine.Unity;
using UnityEngine;

namespace DeDucking.Entity.Player
{
    public class BlockingEffectPoolObj : PoolObjMonoBehavior
    {
        public float ParryDuration => parryEffectAnimation.Animation.Duration;
        public float BlockDuration => blockEffectAnimation.Animation.Duration;
        
        public AnimationReferenceAsset parryEffectAnimation;
        public AnimationReferenceAsset blockEffectAnimation;

        private SkeletonAnimation _animation;
        
        private void Awake()
        {
            _animation = GetComponent<SkeletonAnimation>();
        }

        public void Play(bool isSuccessParry)
        {
            gameObject.SetActive(true);
            
            if (isSuccessParry)
            {
                _animation.CrossFade(0, parryEffectAnimation, SelfReturn);
            }
            else
            {
                _animation.CrossFade(0, blockEffectAnimation, SelfReturn);
            }
        }
    }
}