﻿/*using DeDucking.Entity;
using DeDucking.Managers;
using DeDucking.Player.Handler;
using DeDucking.Utilities;
using Spine.Unity;
using UnityEngine;
using Logger = DeDucking.Utilities.Logger;

namespace DeDucking.Player.State
{
    public class FlyState : PlayerState
    {
        private readonly Rigidbody2D _rigidbody2D;
        private readonly LivingEntity _entity;
        private readonly Transform _transform;
        private readonly ObjectPoolDataSO _eggPool;

        private readonly CooldownTimer _flyCooldownTimer;
        private readonly CooldownTimer _eggResetCooldownTimer;
        private readonly CooldownTimer _eggCooldownTimer;

        private PlayerMover _mover;

        public float EggDropCooldown => DatabaseManager.Instance.PlayerData.EggDropCooldown;
        public int CurrentEggCount => DatabaseManager.Instance.PlayerData.EggCurrentCount;
        public int EggDropDamage => DatabaseManager.Instance.PlayerData.EggDropDamage;
        public float EggDropSpeed => DatabaseManager.Instance.PlayerData.EggDropSpeed;

        private float _currentFlyTime;
        private float _flyMoveSpeed = DatabaseManager.Instance.PlayerData.MoveSpeed * 1.5f;
        
        public FlyState(GameObject go, SkeletonAnimation animation, ObjectPoolDataSO eggPool, CooldownTimer flyCooldownTimer, CooldownTimer eggResetTimer) : base(go, animation)
        {
            _rigidbody2D = CachedGo.GetComponent<Rigidbody2D>();
            _entity = CachedGo.GetComponent<LivingEntity>();
            _mover = CachedGo.GetComponent<PlayerMover>();
            _transform = go.transform;

            Logger.Assert(_rigidbody2D, "player state", "player is not attached rigidbody2d component!");
            Logger.Assert(_entity, "player state", "player is not attached living entity component!");

            _flyCooldownTimer = flyCooldownTimer;
            _eggResetCooldownTimer = eggResetTimer;
            _eggCooldownTimer = new CooldownTimer(EggDropCooldown);

            _eggPool = eggPool;
        }

        public override void EnterState()
        {
            _mover.SetMoveSpeed(_flyMoveSpeed);

            CachedAnimation.CrossFade(0, PlayerAnimationName.Fly, true);
            
            Logger.Log("Player State", "Enter Fly State");

            if (_flyCooldownTimer.IsRunning)
            {
                IsCompleted = true;
                return;
            }

            _flyCooldownTimer.Start();
            _currentFlyTime = 0f;
            _entity.onDamageCallback.AddListener(OnTakeDamage);
            
            IsCompleted = false;
        }

        private void OnTakeDamage()
        {
            _rigidbody2D.Fall();
            IsCompleted = true;
        }

        public override void UpdateState()
        {
            _eggCooldownTimer.Tick(Time.deltaTime);
            if (InputManager.Instance.IsAttackKeyDown)
            {
                EggAttack();
            }
        }

        public override void FixedUpdateState()
        {
            _currentFlyTime += Time.deltaTime;
            
            if (InputManager.Instance.IsJump && 
                _currentFlyTime < DatabaseManager.Instance.PlayerData.FlyDuration)
            {
                float flySpeed = DatabaseManager.Instance.PlayerData.FlySpeed;
                _rigidbody2D.AddForce(Vector2.up * flySpeed, ForceMode2D.Force);
                return;
            }

            if (_rigidbody2D.velocity.y <= 0.0f)
            {
                IsCompleted = true;
            }
        }

        public override void ExitState()
        {
            _eggCooldownTimer.Stop();
            _entity.onDamageCallback.RemoveListener(OnTakeDamage);
        }

        private void EggAttack()
        {
            _eggResetCooldownTimer.Pause();

            if (_eggCooldownTimer.IsRunning)
            {
                return;
            }

            if (CurrentEggCount < 1)
            {
                return;
            }

            Projectile projectile = _eggPool.GetQueue<Projectile>(_transform);
            projectile.transform.right = -_transform.up;
            projectile.transform.parent = null;
            projectile.poolDataSo = _eggPool;
            projectile.Setup(EggDropSpeed, EggDropDamage);

            DatabaseManager.Instance.PlayerData.FillEgg(-1);

            _eggCooldownTimer.Start();
        }
    }

}*/