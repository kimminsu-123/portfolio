﻿using DeDucking.Monster.Boss.State;
using DeDucking.Utilities;
using Spine.Unity;
using UnityEngine;

namespace DeDucking.Player.State
{
    public class IdleState : PlayerState
    {
        public IdleState(GameObject go, SkeletonAnimation animation) : base(go, animation)
        {
        }

        public override void EnterState()
        {
            Utilities.Logger.Log("Player State", "Enter Idle State");

            CachedAnimation.CrossFade(0, PlayerAnimationName.Idle, true);
        }
    }
}