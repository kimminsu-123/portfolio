﻿using DeDucking.Entity;
using DeDucking.Managers;
using DeDucking.Player.Handler;
using DeDucking.Utilities;
using Spine.Unity;
using Unity.VisualScripting;
using UnityEngine;

namespace DeDucking.Player.State
{
    public class JumpAttackState : PlayerState
    {
        public int JumpAttackDelayFrame => DatabaseManager.Instance.PlayerData.JumpAttackDelayFrame;
        public int JumpAttackDurationFrame => DatabaseManager.Instance.PlayerData.JumpAttackDurationFrame;
        public float HoldingInAirDuration => DatabaseManager.Instance.PlayerData.HoldingInAirDuration;
        public float HoldingInAirDurationOnSuccessAttack => DatabaseManager.Instance.PlayerData.HoldingInAirDurationOnSuccessAttack;
        public int JumpAttackDamage => DatabaseManager.Instance.PlayerData.JumpAttackDamage;
        
        private readonly Player _player;
        private readonly Rigidbody2D _rigidbody2D;
        private readonly PlayerMover _mover;
        private readonly AttackCollisionHandler _handler;
        private readonly AttackCheckCollider _attackCheckCollider;
        private readonly FrameTimer _delayFrameTimer;
        private readonly FrameTimer _durationFrameTimer;
        private readonly CooldownTimer _holdingTimer;

        public JumpAttackState(GameObject go, SkeletonAnimation animation, CooldownTimer holdingTimer, AttackCollisionHandler handler,
            AttackCheckCollider checkHandler, Transform colliderParent) : base(go, animation)
        {
            _player = CachedGo.GetComponent<Player>();
            _rigidbody2D = CachedGo.GetComponent<Rigidbody2D>();
            _mover = CachedGo.GetComponent<PlayerMover>();
            _attackCheckCollider = checkHandler;
            _handler = handler;
            _handler.onAttackSuccess.AddListener(OnSuccessAttack);

            _delayFrameTimer = new FrameTimer();
            _durationFrameTimer = new FrameTimer();
            _holdingTimer = holdingTimer;

            _delayFrameTimer.OnStopped += OnEndAttackDelay;
            _durationFrameTimer.OnStopped += OnEndAttackDuration;
        }

        public override void EnterState()
        {
            _attackCheckCollider.Active();

            IsCompleted = false;

            JumpAttack();
        }

        public override void FixedUpdateState()
        {
            _delayFrameTimer?.Tick(1);
            _durationFrameTimer?.Tick(1);
        }
        
        public override void ExitState()
        {
            _attackCheckCollider.InActive();
            _handler.InActive();
            _delayFrameTimer?.Stop();
            _durationFrameTimer?.Stop();
        }

        private void OnEndAttackDelay()
        {
            if (IsCompleted) return;
            
            _handler.Active(JumpAttackDamage);
            
            _durationFrameTimer?.SetTime(JumpAttackDurationFrame);
            _durationFrameTimer?.Start();
        }

        private void OnEndAttackDuration()
        {
            if (IsCompleted) return;
            
            _handler.InActive();
        }

        private void JumpAttack()
        {
            _rigidbody2D.Fall();
            
            CachedAnimation.CrossFade(0, PlayerAnimationName.JumpAttack, OnEndJumpAttack);

            _mover.CanHoldingInAir = true;

            if (!_holdingTimer.IsRunning)
            {
                _holdingTimer?.SetTime(HoldingInAirDuration);
                _holdingTimer?.Start();
            }
            _delayFrameTimer?.SetTime(JumpAttackDelayFrame);
            _delayFrameTimer?.Start();
        }

        private void OnEndJumpAttack()
        {
            IsCompleted = true;
        }

        private void OnSuccessAttack()
        {
            if (_player.CanHoldingInAirOnSuccessAttack)
            {
                _holdingTimer?.SetTime(HoldingInAirDurationOnSuccessAttack);
                _holdingTimer?.Start();
            }
            _player.BlockHoldingInAirOnSuccessAttack();
        }
    }
}