﻿using DeDucking.Managers;
using DeDucking.Player.Handler;
using DeDucking.Utilities;
using Spine;
using Spine.Unity;
using UnityEngine;

namespace DeDucking.Player.State
{
    public class DieState : PlayerState
    {
        private readonly Player _player;
        private readonly PlayerMover _mover;
        
        public DieState(GameObject go, SkeletonAnimation animation) : base(go, animation)
        {
            _player = go.GetComponent<Player>();
            _mover = go.GetComponent<PlayerMover>();
        }

        public override void EnterState()
        {
            _player.HasTakeDamage = false;
            _mover.CurrentStatus = PlayerMover.Status.Stopped;
            
            CachedAnimation.CrossFade(0, PlayerAnimationName.Death, () =>
            {
                EventManager.Instance.PostNotification(Managers.EventType.OnPlayerDeath, null);
            });
        }

        public override void ExitState()
        {
            _player.HasTakeDamage = false;
            _mover.CurrentStatus = PlayerMover.Status.Running;
        }
    }
}