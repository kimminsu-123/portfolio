using DeDucking.Entity;
using DeDucking.Managers;
using DeDucking.Utilities;
using Spine.Unity;
using UnityEngine;

namespace DeDucking.Player.State
{
    /// <summary>
    /// 날    짜 : 2024.10.29
    /// 작 업 자 : 김민수
    /// 작업내용 : 점프 로직 수정 -> 누르는 동안 계속 점프 (할로우나이트 점프 참고) 
    /// </summary>
    public class JumpState : PlayerState
    {
        private readonly Rigidbody2D _rigidbody2D;
        private readonly LivingEntity _entity;
        private readonly CooldownTimer _jumpDurationTimer;

        private float JumpSpeed => DatabaseManager.Instance.PlayerData.JumpSpeed;
        private float JumpDuration => DatabaseManager.Instance.PlayerData.JumpDuration;

        public JumpState(GameObject go, SkeletonAnimation animation) : base(go, animation)
        {
            _rigidbody2D = CachedGo.GetComponent<Rigidbody2D>();
            _entity = CachedGo.GetComponent<LivingEntity>();
            _jumpDurationTimer = new CooldownTimer(JumpDuration);
            _jumpDurationTimer.OnStopped += () => ExitJumpState(null);
        }
        
        public override void EnterState()
        {
            IsCompleted = false;
               
            Utilities.Logger.Log("Player State", "Enter Jump State");
            
            _entity.onDamageCallback.AddListener(ExitJumpState);
            CachedAnimation.CrossFade(0, PlayerAnimationName.Jump, false);
            CachedAnimation.QueuedCrossFade(0, PlayerAnimationName.InAir, true);
            
            _jumpDurationTimer?.SetTime(JumpDuration);
            _jumpDurationTimer?.Start();
        }
        
        public override void UpdateState()
        {
            if (IsCompleted)
            {
                return;
            }
            
            Jump();
            
            _jumpDurationTimer?.Tick(Time.deltaTime);
        }
        
        private void Jump()
        {
            Vector2 currentVel = _rigidbody2D.velocity;
            currentVel.y = JumpSpeed;
            _rigidbody2D.velocity = currentVel;
        }

        public override void ExitState()
        {
            _entity.onDamageCallback.RemoveListener(ExitJumpState);
            CachedAnimation.CrossFade(0, PlayerAnimationName.Highest, false);
            _rigidbody2D.Fall();
        }

        private void ExitJumpState(GameObject hitter)
        {
            IsCompleted = true;
        }
    }
}