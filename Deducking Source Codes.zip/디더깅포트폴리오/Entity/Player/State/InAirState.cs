﻿using DeDucking.Entity;
using DeDucking.Managers;
using DeDucking.Player.Handler;
using DeDucking.Utilities;
using Spine.Unity;
using UnityEngine;

namespace DeDucking.Player.State
{
    public class InAirState : PlayerState
    {
        private readonly Rigidbody2D _rigidbody2D;
        private readonly LivingEntity _entity;

        public InAirState(GameObject go, SkeletonAnimation animation) : base(go, animation)
        {
            _rigidbody2D = CachedGo.GetComponent<Rigidbody2D>();
            _entity = CachedGo.GetComponent<LivingEntity>();
        }

        public override void EnterState()
        {
            Utilities.Logger.Log("Player State", "Enter InAir State");
            _entity.onDamageCallback.AddListener(OnTakeDamage);
            CachedAnimation.QueuedCrossFade(0, PlayerAnimationName.Fall, true);
        }

        private void OnTakeDamage(GameObject hitter)
        {
            _rigidbody2D.Fall();
        }

        public override void ExitState()
        {            
            _entity.onDamageCallback.RemoveListener(OnTakeDamage);
        }
    }
}