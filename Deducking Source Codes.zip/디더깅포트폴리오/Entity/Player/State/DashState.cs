using System;
using DeDucking.Entity;
using UnityEngine;
using DeDucking.Managers;
using DeDucking.Player.Handler;
using DeDucking.Utilities;
using Spine.Unity;
using UniRx;
using Logger = DeDucking.Utilities.Logger;

namespace DeDucking.Player.State
{
    public class DashState : PlayerState
    {
        private readonly PlayerMover _mover;
        private readonly Rigidbody2D _rigidbody2D;
        private readonly SurfaceChecker _surfaceChecker;
        
        private readonly CooldownTimer _dashTimer;

        private const int MONSTER_LAYER = 8;
        private const int MONSTER_ATTACK_LAYER = 9;
        private const int MONSTER_ATTACK_PARRY_LAYER = 10;
        
        private float DashSpeed => DatabaseManager.Instance.PlayerData.DashSpeed;
        
        public DashState(GameObject go, SkeletonAnimation animation, CooldownTimer dashTimer) : base(go, animation)
        {
            _dashTimer = dashTimer;
            _mover = CachedGo.GetComponent<PlayerMover>();
            _rigidbody2D = CachedGo.GetComponent<Rigidbody2D>();
            _surfaceChecker = CachedGo.GetComponent<SurfaceChecker>();
        }

        private void Dash()
        {
            Physics2D.IgnoreLayerCollision(CachedGo.layer, MONSTER_LAYER, true);
            Physics2D.IgnoreLayerCollision(CachedGo.layer, MONSTER_ATTACK_LAYER, true);
            Physics2D.IgnoreLayerCollision(CachedGo.layer, MONSTER_ATTACK_PARRY_LAYER, true);

            Vector2 velocity = _rigidbody2D.velocity;
            if (_surfaceChecker.IsSlope)
            {
                velocity = _surfaceChecker.ProjectDirection * DashSpeed;
            }
            else
            {
                velocity = CachedGo.transform.right * DashSpeed;
            }
            _rigidbody2D.velocity = velocity;
        }

        private void OnEndDash()
        {
            Physics2D.IgnoreLayerCollision(CachedGo.layer, MONSTER_LAYER, false);
            Physics2D.IgnoreLayerCollision(CachedGo.layer, MONSTER_ATTACK_LAYER, false);
            Physics2D.IgnoreLayerCollision(CachedGo.layer, MONSTER_ATTACK_PARRY_LAYER, false);
            _rigidbody2D.velocity = Vector2.zero;
            IsCompleted = true;
        }

        public override void EnterState()
        {
            Logger.Log("Player State", "Enter Dash State");

            _mover.CurrentStatus = PlayerMover.Status.Stopped;
            IsCompleted = false;    
            CachedAnimation.CrossFade(0, PlayerAnimationName.Dash, OnEndDash);
        }

        public override void FixedUpdateState()
        {
            Dash();
        }

        public override void ExitState()
        {
            _mover.CurrentStatus = PlayerMover.Status.Running;
            _dashTimer.Start();
        }
    }
}
