﻿using System.Transactions;
using DeDucking.Entity;
using DeDucking.Entity.Player;
using DeDucking.Entity.UI;
using DeDucking.Managers;
using DeDucking.Player.Handler;
using DeDucking.Player.SO;
using DeDucking.Player.UI;
using DeDucking.Utilities;
using Spine.Unity;
using Unity.VisualScripting;
using UnityEngine;
using Utilities.Handler;
using Logger = DeDucking.Utilities.Logger;

namespace DeDucking.Player.State
{
    public class BlockState : PlayerState
    {
        private readonly PlayerMover _mover;
        private readonly LivingEntity _entity;
        private readonly Detector _detector;
        private readonly IDetectStrategy _detectStrategy;
        private readonly Transform _blockingEffectParent;
        private readonly ParryGaugeUI _parryGaugeUI;
        private readonly LinesController _linesController;

        private bool _canParrying = false;
        private bool _successParrying = false;

        private readonly FrameTimer _delayTimer;
        private readonly FrameTimer _blockTimer;
        private readonly FrameTimer _parryTimer;

        private int DelayDuration => DatabaseManager.Instance.PlayerData.DelayDuration;
        private int BlockDuration => DatabaseManager.Instance.PlayerData.BlockDuration;
        private int ParryDuration => DatabaseManager.Instance.PlayerData.ParryDuration;
        private ObjectPoolDataSO BlockingEffectPool => DatabaseManager.Instance.PlayerData.BlockingEffectPool;
        private ObjectPoolDataSO ParryGaugeEffectPool => DatabaseManager.Instance.PlayerData.ParryGaugeEffectPool;
        private LineDataSO SuccessParryLines => DatabaseManager.Instance.PlayerData.SuccessParryLines;

        private float ParryGaugeIncrease => DatabaseManager.Instance.PlayerData.ParryGaugeIncrease;

        private float ParryGaugeCurrent => DatabaseManager.Instance.PlayerData.ParryGaugeCurrent;
        
        public BlockState(GameObject go, Transform blockingEffectParent, 
            SkeletonAnimation animation, Transform colliderParent) : base(go, animation)
        {
            _mover = CachedGo.GetComponent<PlayerMover>();
            _entity = CachedGo.GetComponent<LivingEntity>();
            _detector = CachedGo.GetComponent<Detector>();
            _linesController = CachedGo.GetComponentInChildren<LinesController>(true);
            Debug.Log(_linesController);
            _blockingEffectParent = blockingEffectParent;

            /*_detectStrategy = new BoxColliderDetectorStrategy(DatabaseManager.Instance.PlayerData.ParryColliderPool,
                colliderParent, DatabaseManager.Instance.PlayerData.ColliderSize,
                DatabaseManager.Instance.PlayerData.ColliderCenter, DatabaseManager.Instance.PlayerData.BlockLayer);*/
            _detectStrategy = new RectangleDetectStrategy(colliderParent, 
                DatabaseManager.Instance.PlayerData.ColliderSize, DatabaseManager.Instance.PlayerData.ColliderCenter,
                DatabaseManager.Instance.PlayerData.BlockLayer);

            _delayTimer = new FrameTimer(DelayDuration);
            _delayTimer.OnStopped += EndDelay;
            
            _parryTimer = new FrameTimer(ParryDuration);
            _parryTimer.OnStopped += EndParry;

            _blockTimer = new FrameTimer(BlockDuration);
            _blockTimer.OnStopped += EndBlock;
        }

        public override void EnterState()
        {
            IsCompleted = false;
            _canParrying = false;
            _successParrying = false;

            _detector.Register(DetectType.Update, _detectStrategy, OnDetectedAttack);
            _mover.StopForce();
            _mover.CurrentStatus = PlayerMover.Status.Stopped;
            _entity.DamageMode = DamageMode.Back;

            _delayTimer.Start();
            
            CachedAnimation.CrossFade(0, PlayerAnimationName.Parrying, false);
            
            Logger.Log("ParryTest", "Enter Block", Color.green);
        }

        public override void UpdateState()
        {
            if (InputManager.Instance.Move != Vector2.zero &&
                !IsCompleted &&
                !_delayTimer.IsRunning && 
                !_parryTimer.IsRunning)
            {
                IsCompleted = true;
                return;
            }

            if (IsCompleted)
            {
                return;
            }

            _delayTimer.Tick(1);
            _parryTimer.Tick(1);
            _blockTimer.Tick(1);
        }

        public override void ExitState()
        {
            _mover.CurrentStatus = PlayerMover.Status.Running;
            _detector.UnRegister(DetectType.Update, _detectStrategy, OnDetectedAttack);
            _delayTimer.Stop();
            _parryTimer.Stop();
            _blockTimer.Stop();
            _entity.DamageMode = DamageMode.Both;
            
            Logger.Log("ParryTest", "Exit Block", Color.green);
        }

        private void OnDetectedAttack(Collider2D other)
        {
            Logger.Log("ParryTest", $"Detect {other}", Color.green);

            if (other == null || _successParrying)
            {
                return;
            }
            
            Vector3 parentPos = other.transform.parent.position;
            Vector2 dir = (parentPos - CachedGo.transform.position).normalized;
            Vector2 right = CachedGo.transform.right.normalized;

            if (Vector2.Dot(right, dir) < 0f)
            {
                return;
            }

            if (_canParrying)
            {
                // 패링 처리
                HandleParry(other);
            }
            else
            {
                // 방어 처리
                HandleBlock(other);
            }
        }

        private void HandleBlock(Collider2D other)
        {
            var parryReceiver = other.GetComponentInParent<IParryReceiver>();

            if (parryReceiver != null)
            {
                parryReceiver.SuccessBlock();

                EffectBlock();
                EndBlock();
            }
        }

        private void HandleParry(Collider2D other)
        {
            var parryReceiver = other.GetComponentInParent<IParryReceiver>();
            
            if (parryReceiver != null)
            {
                parryReceiver.SuccessParry();
                EffectParry();
                _successParrying = true;
                
                AudioManager.Instance.PlayOneShot(CachedGo.transform, SuccessParryLines.GetRandomSound());
                _linesController.Show(SuccessParryLines.GetIcon(), SuccessParryLines.GetRandomLine());
                
                DatabaseManager.Instance.PlayerData.IncreaseParryGauge();
                Debug.Log($"Gauge incremented : {ParryGaugeCurrent}");
            }
        }
        
        private void EndDelay()
        {
            if (IsCompleted)
            {
                return;
            }
            
            _parryTimer.Start();
            _canParrying = true;
        }

        private void EndBlock()
        {
            IsCompleted = true;
        }

        private void EndParry()
        {
            if (IsCompleted)
            {
                return;
            }
            
            if (_successParrying)
            {
                IsCompleted = true;
                return;
            }

            _canParrying = false;
            _blockTimer.Start();
        }

        private void EffectParry()
        {
            /*var shockwave = ShockWaveEffectPool.GetQueue<ShaderLerpEffectPoolObj>(_shockWaveParent);
            shockwave.SetOriginPool(ShockWaveEffectPool);
            shockwave.duration = ShockWaveEffectDuration;
            shockwave.Play();*/

            var blockingVfx = BlockingEffectPool.GetQueue<BlockingEffectPoolObj>(_blockingEffectParent);
            blockingVfx.SetOriginPool(BlockingEffectPool);
            blockingVfx.SetParent(null);
            blockingVfx.Play(true);

            CameraHandler.Instance.Shake(CameraEffectType.High, blockingVfx.ParryDuration * 0.05f);
            CameraHandler.Instance.EffectCameraStop(CameraEffectType.High, blockingVfx.ParryDuration * 0.05f);
            AudioManager.Instance.PlayOneShot(CachedGo.transform, DatabaseManager.Instance.PlayerData.ParrySound.Id,
                DatabaseManager.Instance.PlayerData.ParrySound.Volume);
            CameraHandler.Instance.EffectDiffuse();
        }

        private void EffectBlock()
        {
            AudioManager.Instance.PlayOneShot(CachedGo.transform, DatabaseManager.Instance.PlayerData.BlockSound.Id,
                DatabaseManager.Instance.PlayerData.BlockSound.Volume);

            var blockingVfx = BlockingEffectPool.GetQueue<BlockingEffectPoolObj>(_blockingEffectParent);
            blockingVfx.SetOriginPool(BlockingEffectPool);
            blockingVfx.SetParent(null);
            blockingVfx.Play(false);

            CameraHandler.Instance.Shake(CameraEffectType.High);
        }
    }
}