﻿using DeDucking.FSM;
using Spine.Unity;
using UnityEngine;

namespace DeDucking.Player.State
{
    public struct PlayerAnimationName
    {
        public static readonly string Idle = "PC_idle";
        public static readonly string Death = "PC_dead";
        public static readonly string Jump = "PC_1 jump pre";
        public static readonly string InAir = "PC_2 jump looping";
        public static readonly string Highest = "PC_3 jump highest";
        public static readonly string Fall = "PC_4 fall looping";
        public static readonly string Land = "PC_5 land";
        public static readonly string Run = "PC_walking";
        public static readonly string Dash = "PC_dash";
        //eternal that will never die demage 근데 진짜 대단한 오타네요 근데 이거 언제 수정함?
        public static readonly string Hurt = "PC_demage";
        
        public static readonly string Attack1 = "PC_First_swing";
        public static readonly string Attack2 = "PC_Sec_swing";
        public static readonly string Attack3 = "PC_Third_swing";
        public static readonly string JumpAttack = "PC_First_swing";

        public static readonly string Parrying = "PC_Parrying";

        public static readonly string Heal = "PC_ParryingCharge";
        public static readonly string Healeff = "Parry Gauge PC eff";

        public static readonly string ParryGaugeEffect = "Parry Gauge eff";
    }

    public class PlayerState : IState
    {
        public bool IsCompleted { get; protected set; }
        
        protected readonly GameObject CachedGo;
        protected readonly StateMachine CachedStateMachine;
        protected readonly SkeletonAnimation CachedAnimation;
        
        protected PlayerState(GameObject go, SkeletonAnimation animation)
        {
            CachedGo = go;
            CachedAnimation = animation;
            CachedStateMachine = go.GetComponentInChildren<StateMachine>(true);
        }
        
        public virtual void EnterState()
        {
        }

        public virtual void UpdateState()
        {
        }

        public virtual void FixedUpdateState()
        {
        }

        public virtual void ExitState()
        {
        }
    }
}