using UnityEngine;
using DeDucking.Managers;
using DeDucking.Player.Handler;
using DeDucking.Utilities;
using Spine.Unity;

namespace DeDucking.Player.State
{
    public class MoveState : PlayerState
    {
        private readonly PlayerMover _mover;

        private float MoveSpeed => DatabaseManager.Instance.PlayerData.MoveSpeed;

        public MoveState(GameObject go, SkeletonAnimation animation) : base(go, animation)
        {
            _mover = CachedGo.GetComponent<PlayerMover>();
        }

        public override void EnterState()
        {
            Utilities.Logger.Log("Player State", "Enter Move State");
            
            CachedAnimation.CrossFade(0, PlayerAnimationName.Run, true);
            
            _mover.SetMoveSpeed(MoveSpeed);
        }
    }
}


