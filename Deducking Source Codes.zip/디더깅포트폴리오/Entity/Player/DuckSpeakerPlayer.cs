﻿using DeDucking.Managers;
using DeDucking.Utilities;
using UnityEngine;

namespace DeDucking.Entity.Player
{
    public class DuckSpeakerPlayer : MonoBehaviour
    {
        [SerializeField] private SoundInfo walkingSound;
        [SerializeField] private SoundInfo jumpSound;
        [SerializeField] private SoundInfo rollSound;
        [SerializeField] private SoundInfo wingSound;
        [SerializeField] private SoundInfo landSound;
        [SerializeField] private SoundInfo swingSound;
        [SerializeField] private SoundInfo swing3Sound;
        [SerializeField] private SoundInfo attackSound;
        [SerializeField] private SoundInfo damageSound;
        

        public void PlayWalkSound()
        {
            AudioManager.Instance.PlayOneShot(transform, walkingSound.Id, walkingSound.Volume);
        }
        
        public void PlayJumpSound()
        {
            AudioManager.Instance.PlayOneShot(transform, jumpSound.Id, jumpSound.Volume);
        }

        public void PlayRollSound()
        {
            AudioManager.Instance.PlayOneShot(transform, rollSound.Id, rollSound.Volume);
        }

        public void PlayWingSound()
        {
            AudioManager.Instance.PlayOneShot(transform, wingSound.Id, wingSound.Volume);
        }

        public void PlayLandSound()
        {
            AudioManager.Instance.PlayOneShot(transform, landSound.Id, landSound.Volume);
        }

        public void PlaySwingSound()
        {
            AudioManager.Instance.PlayOneShot(transform, swingSound.Id, swingSound.Volume);
        }

        public void PlaySwing3Sound()
        {
            AudioManager.Instance.PlayOneShot(transform, swing3Sound.Id, swing3Sound.Volume);
        }

        public void PlayAttackSound()
        {
            AudioManager.Instance.PlayOneShot(transform, attackSound.Id, attackSound.Volume);
        }

        public void PlayDamageSound()
        {
            AudioManager.Instance.PlayOneShot(transform, damageSound.Id, damageSound.Volume);
        }
    }
}