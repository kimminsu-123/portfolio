using DeDucking.Entity;
using DeDucking.Entity.Player;
using DeDucking.Managers;
using DeDucking.Player.Handler;
using DeDucking.Player.State;
using DeDucking.Utilities;
using Spine.Unity;
using UnityEngine;
using DieState = DeDucking.Player.State.DieState;
using IdleState = DeDucking.Player.State.IdleState;
using StateMachine = DeDucking.FSM.StateMachine;

namespace DeDucking.Player
{
    public class Player : MonoBehaviour
    {        
        public bool HasTakeDamage { get; set; }
        public bool CanHoldingInAirOnSuccessAttack { get; private set; }
        
        [SerializeField] private Transform blockParent;
        [SerializeField] private Transform blockingEffectParent;
        [SerializeField] private AttackCollisionHandler comboAttackCollisionHandler;
        [SerializeField] private AttackCheckCollider attackCheckCollisionHandler;
        [SerializeField] private AttackCollisionHandler jumpAttackCollisionHandler;
        [SerializeField] private SkeletonAnimation healEffectAnimation;
        [SerializeField] private SkeletonAnimation healSpreadEffectAnimation;
        
        private bool CanJump => InputManager.Instance.IsJump && _surfaceChecker.IsGrounded;

        private bool CanHeal => InputManager.Instance.IsHealKeyDown &&
                                DatabaseManager.Instance.PlayerData.CanUseHealSkill() &&
                                _entity.CurrentHp < _entity.EntityData.MaxHp;

        private SurfaceChecker _surfaceChecker;
        private SkeletonAnimation _cachedSkeleton;

        private StateMachine _stateMachine;
        private LivingEntity _entity;
        private PlayerMover _mover;

        private PlayerState _idleState;
        private PlayerState _jumpState;
        private PlayerState _jumpAttackState;
        private PlayerState _inAirState;
        private PlayerState _landState;
        private PlayerState _moveState;
        private PlayerState _dashState;
        private PlayerState _attackState;
        private PlayerState _dieState;
        private PlayerState _hurtState;
        private PlayerState _blockState;
        private PlayerState _healState;

        private CooldownTimer _dashCooldownTimer;
        private CooldownTimer _holdingInAirTimer;

        private void Awake()
        {
            _surfaceChecker = GetComponent<SurfaceChecker>();
            _stateMachine = gameObject.GetOrAddComponent<StateMachine>();
            _entity = GetComponent<LivingEntity>();
            _cachedSkeleton = GetComponentInChildren<SkeletonAnimation>(true);
            _mover = GetComponent<PlayerMover>();
        }

        private void Start()
        {
            SetupTimer();
            SetupStates();
            ConnectTransitions();
            ResetCanHoldingInAirOnSuccessAttack();

            _entity.onDamageCallback.AddListener(OnTakeDamage);
            _stateMachine.SetState(_idleState);
        }

        private void Update()
        {
            _dashCooldownTimer.Tick(Time.deltaTime);
            _holdingInAirTimer.Tick(Time.deltaTime);
        }

        private void SetupTimer()
        {
            _dashCooldownTimer = new CooldownTimer(DatabaseManager.Instance.PlayerData.DashCooldown);
            _holdingInAirTimer = new CooldownTimer();
            _holdingInAirTimer.OnStopped += OnEndHoldingTimer;
        }
        
        private void SetupStates()
        {
            _idleState = new IdleState(gameObject, _cachedSkeleton);
            _jumpState = new JumpState(gameObject, _cachedSkeleton);
            _jumpAttackState = new JumpAttackState(gameObject, _cachedSkeleton, _holdingInAirTimer, jumpAttackCollisionHandler, attackCheckCollisionHandler, blockParent);
            _inAirState = new InAirState(gameObject, _cachedSkeleton);
            _landState = new LandState(gameObject, _cachedSkeleton);
            _moveState = new MoveState(gameObject, _cachedSkeleton);
            _dashState = new DashState(gameObject, _cachedSkeleton, _dashCooldownTimer);
            _attackState = new AttackState(gameObject, _cachedSkeleton, comboAttackCollisionHandler, attackCheckCollisionHandler, blockParent);
            _dieState = new DieState(gameObject, _cachedSkeleton);
            _hurtState = new HurtState(gameObject, _cachedSkeleton);
            _blockState = new BlockState(gameObject, blockingEffectParent, _cachedSkeleton, blockParent);
            _healState = new HealState(gameObject, _cachedSkeleton, healEffectAnimation, healSpreadEffectAnimation);
        }

        private void ConnectTransitions()
        {
            // idle to
            _stateMachine.AddTransition(_idleState, _jumpState, new FuncPredicate(() => CanJump));
            _stateMachine.AddTransition(_idleState, _attackState, new FuncPredicate(() => InputManager.Instance.IsAttackKeyDown));
            _stateMachine.AddTransition(_idleState, _moveState, new FuncPredicate(() => InputManager.Instance.Move != Vector2.zero));
            _stateMachine.AddTransition(_idleState, _inAirState, new FuncPredicate(() => !_surfaceChecker.IsGrounded));
            _stateMachine.AddTransition(_idleState, _blockState, new FuncPredicate(() => InputManager.Instance.IsBlockKeyDown));
            _stateMachine.AddTransition(_idleState, _dashState, new FuncPredicate(() => InputManager.Instance.IsDash && !_dashCooldownTimer.IsRunning));
            _stateMachine.AddTransition(_idleState, _healState, new FuncPredicate(() => CanHeal));
            
            // move to
            _stateMachine.AddTransition(_moveState, _idleState, new FuncPredicate(() => InputManager.Instance.Move == Vector2.zero));
            _stateMachine.AddTransition(_moveState, _dashState, new FuncPredicate(() => InputManager.Instance.IsDash && !_dashCooldownTimer.IsRunning));
            _stateMachine.AddTransition(_moveState, _jumpState, new FuncPredicate(() => CanJump));
            _stateMachine.AddTransition(_moveState, _inAirState, new FuncPredicate(() => !_surfaceChecker.IsGrounded));
            _stateMachine.AddTransition(_moveState, _blockState, new FuncPredicate(() => InputManager.Instance.IsBlockKeyDown));
            _stateMachine.AddTransition(_moveState, _attackState, new FuncPredicate(() => InputManager.Instance.IsAttackKeyDown));
            _stateMachine.AddTransition(_moveState, _healState, new FuncPredicate(() => CanHeal));

            // dash to
            _stateMachine.AddTransition(_dashState, _moveState, new FuncPredicate(() => _dashState.IsCompleted));
            _stateMachine.AddTransition(_dashState, _jumpState, new FuncPredicate(() => CanJump));
            
            // jump to
            _stateMachine.AddTransition(_jumpState, _jumpAttackState, new FuncPredicate(() => InputManager.Instance.IsAttackKeyDown));
            _stateMachine.AddTransition(_jumpState, _inAirState, new FuncPredicate(() => _jumpState.IsCompleted || InputManager.Instance.IsJumpKeyUp));
                
            // jump attack to
            _stateMachine.AddTransition(_jumpAttackState, _inAirState, new FuncPredicate(() => _jumpAttackState.IsCompleted));
            _stateMachine.AddTransition(_jumpAttackState, _landState, new FuncPredicate(() => _surfaceChecker.IsGrounded));

            // in air to
            _stateMachine.AddTransition(_inAirState, _landState, new FuncPredicate(() => _surfaceChecker.IsGrounded));
            _stateMachine.AddTransition(_inAirState, _jumpAttackState, new FuncPredicate(() => InputManager.Instance.IsAttackKeyDown));
            
            // land to
            _stateMachine.AddTransition(_landState, _idleState, new FuncPredicate(() => _landState.IsCompleted));
            _stateMachine.AddTransition(_landState, _blockState, new FuncPredicate(() => InputManager.Instance.IsBlockKeyDown));
            _stateMachine.AddTransition(_landState, _healState, new FuncPredicate(() => CanHeal));

            // _attack to
            _stateMachine.AddTransition(_attackState, _idleState, new FuncPredicate(() => _attackState.IsCompleted));
            _stateMachine.AddTransition(_attackState, _blockState, new FuncPredicate(() => InputManager.Instance.IsBlockKeyDown));
            
            // die to
            _stateMachine.AddAnyTransition(_dieState, new FuncPredicate(() => _entity.IsDeath));
            _stateMachine.AddTransition(_dieState, _idleState, new FuncPredicate(() => !_entity.IsDeath));
            
            // hurt to
            _stateMachine.AddAnyTransition(_hurtState, new FuncPredicate(() => HasTakeDamage));
            _stateMachine.AddTransition(_hurtState, _inAirState, new FuncPredicate(() => _hurtState.IsCompleted && !_surfaceChecker.IsGrounded));
            _stateMachine.AddTransition(_hurtState, _idleState, new FuncPredicate(() => _hurtState.IsCompleted && _surfaceChecker.IsGrounded));
            _stateMachine.AddTransition(_hurtState, _blockState, new FuncPredicate(() => InputManager.Instance.IsBlockKeyDown && _surfaceChecker.IsGrounded));
            
            // block to
            _stateMachine.AddTransition(_blockState, _idleState, new FuncPredicate(() => _blockState.IsCompleted));
            
            // heal to
            _stateMachine.AddTransition(_healState, _idleState, new FuncPredicate(() => _healState.IsCompleted || InputManager.Instance.IsHealKeyUp));
            _stateMachine.AddTransition(_healState, _moveState, new FuncPredicate(() => _healState.IsCompleted && InputManager.Instance.Move != Vector2.zero));
            _stateMachine.AddTransition(_healState, _jumpState, new FuncPredicate(() => _healState.IsCompleted && CanJump));
            _stateMachine.AddTransition(_healState, _attackState, new FuncPredicate(() => _healState.IsCompleted && InputManager.Instance.IsAttackKeyDown));
            _stateMachine.AddTransition(_healState, _blockState, new FuncPredicate(() => _healState.IsCompleted && InputManager.Instance.IsBlockKeyDown));
        }

        private void OnEndHoldingTimer()
        {
            _mover.CanHoldingInAir = false;
        }
        
        public void ResetCanHoldingInAirOnSuccessAttack()
        {
            CanHoldingInAirOnSuccessAttack = true;
        }

        public void BlockHoldingInAirOnSuccessAttack()
        {
            CanHoldingInAirOnSuccessAttack = false;
        }

        private void OnTakeDamage(GameObject hitter)
        {
            HasTakeDamage = true;
        }
    }
}