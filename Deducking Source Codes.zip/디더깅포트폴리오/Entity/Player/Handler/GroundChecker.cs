﻿using System;
using UnityEngine;
using UnityEngine.Serialization;

namespace DeDucking.Player.Handler
{
    [Obsolete("SurfaceChecker 를 사용하세요 (해당 컴포넌트는 사용하지 않습니다)", true)]
    public class GroundChecker : MonoBehaviour
    {
        [SerializeField] private float radius;
        [SerializeField] private Vector2 center;
        [SerializeField] private LayerMask groundLayerMask;

        public bool IsGrounded { get; private set; }
        public bool IsSlope { get; private set; } = false;

        [SerializeField] private float slopeRayLen = 1f;
        [SerializeField] private float slopeLimit = 80f;

        //public float slopeAngle;    //UI확인용 변수. 나중에 삭제

        public Vector2 Dir { get; private set; }
        private Vector2 _checkDirection;

        private readonly Collider2D[] _colliders = new Collider2D[2];
        private ContactPoint2D[] _contactPoints = new ContactPoint2D[2];

        private void FixedUpdate()
        {
            float xFactor = 1f;
            _checkDirection = Vector2.right;
            if (transform.rotation.y != 0f)
            {
                _checkDirection = Vector2.left;
                xFactor = -1f;
            }

            Vector3 dirCenter = center;
            dirCenter.x *= xFactor;
            
            int count = Physics2D.OverlapCircleNonAlloc(transform.position + dirCenter, radius, _colliders, groundLayerMask);

            IsGrounded = count > 0;

            if (!IsGrounded)
                IsSlope = false;
        }

        public void CheckSlope()
        {
            if (_colliders[0] != null)
            {
                var hit = Physics2D.Raycast(transform.position, Vector2.down, slopeRayLen, LayerMask.GetMask("Ground"));
                if (hit.collider != null)
                {
                    float angle = Vector2.Angle(Vector2.up, hit.normal);
                    if (30f <= angle && angle <= slopeLimit)
                    {
                        //slopeAngle = angle;
                        IsSlope = true;
                        Vector3 dir = Vector3.ProjectOnPlane(_checkDirection, hit.normal);
                        Dir = dir.normalized;
                        return;
                    }
                }
            }
            IsSlope = false;
        }

        private void OnDrawGizmos()
        {
            Gizmos.matrix = transform.localToWorldMatrix;
            Gizmos.color = Color.red;
            Gizmos.DrawWireSphere(center, radius);
            
            Gizmos.matrix = transform.localToWorldMatrix;
            Gizmos.color = Color.red;
            Gizmos.DrawLine(Vector3.zero, Vector3.down * slopeRayLen);
        }
    }
}