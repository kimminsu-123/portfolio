using System;
using DeDucking.Player.Handler;
using UnityEngine;

[Obsolete("SurfaceChecker 를 사용하세요 (해당 컴포넌트는 사용하지 않습니다)", true)]
public class WallChecker : MonoBehaviour
{
    public ContactFilter2D _castFilter;
    private RaycastHit2D[] _wallHits = new RaycastHit2D[2];
    public float _wallRaycastDistance;

    public bool IsWall { get; private set; }

    private Vector2 _checkDirection;

    private Collider2D _playerCollider;
    private Rigidbody2D _playerRigidBody;
    private GroundChecker _groundChecker;

    #region 테스트 UI
    //public TextMeshProUGUI isWallTxt;
    //public TextMeshProUGUI isSlopeTxt;
    //public TextMeshProUGUI wallAngleTxt;
    //public TextMeshProUGUI slopAngleTxt;
    //public TextMeshProUGUI isGroundTxt;
    //public TextMeshProUGUI vectorTxt;
    //public TextMeshProUGUI moveStateTxt;
    //string moveState;
    #endregion

    private void Awake()
    {
        _playerCollider = GetComponent<Collider2D>();
        _playerRigidBody = GetComponent<Rigidbody2D>();
        _groundChecker = GetComponent<GroundChecker>();
    }

    private void FixedUpdate()
    {
        _checkDirection = transform.rotation.y == 0 ? Vector2.right : Vector2.left;

        #region Test UI
        //isWallTxt.text = "IsWall : " + IsWall.ToString();
        //isSlopeTxt.text = "IsSlope : " + _groundChecker.IsSlope.ToString();
        //isGroundTxt.text = "IsGround : " + _groundChecker.IsGrounded.ToString();
        //vectorTxt.text = $"{_groundChecker.Dir.x:F2}, {_groundChecker.Dir.y:F2}" +
        //    $" = {_groundChecker.Dir.x * _groundChecker.Dir.x + _groundChecker.Dir.y * _groundChecker.Dir.y}";
        //slopAngleTxt.text = "SlopeAngle : " + _groundChecker.slopeAngle.ToString();
        //moveStateTxt.text = "Move : " + moveState;

        //if (_groundChecker.IsSlope)
        //    moveState = "Dir";
        //else
        //    moveState = "normal";
        #endregion

        CheckWall();

        if (!IsWall && _groundChecker != null)
            _groundChecker.CheckSlope();
    }

    private void CheckWall()
    {
        int hitCount = _playerCollider.Cast(_checkDirection, _castFilter, _wallHits, _wallRaycastDistance);

        if (hitCount > 0)
        {
            //각도 구해서
            float angle = Vector2.Dot(_wallHits[0].normal, Vector2.up);
            angle = Mathf.Acos(angle);
            angle = angle * Mathf.Rad2Deg;

            //wallAngleTxt.text = "WallAngle : " + angle.ToString();
            //Debug.Log($"angle : {angle}");

            //벽으로 판정
            if (angle > 80)
            {
                IsWall = true;
                return;
            }
        }

        IsWall = false;
    }

    //private void CheckSlope()
    //{
    //    Vector2 checkDirection = transform.rotation.y == 0 ? Vector2.right : Vector2.left;

    //    RaycastHit2D hitSlope1 = Physics2D.Raycast((Vector2)transform.position , Vector2.down, _slopeCheckDistance, _layerMask);
    //    RaycastHit2D hitSlope2 = Physics2D.Raycast((Vector2)transform.position + checkDirection * dir2, Vector2.down, _slopeCheckDistance, _layerMask);


    //    Debug.Log($"{checkDirection}");

    //    if (hitSlope1 != null)
    //    {
    //        float angle = Vector2.Dot(hitSlope1.normal, Vector2.up);
    //        angle = Mathf.Acos(angle);
    //        angle = angle * Mathf.Rad2Deg;

    //        angleTxt.text = "Angle : " + angle.ToString();

    //        if (angle > 10 && angle < 80)
    //        {
    //            //경사면 각도의 벡터 구하기
    //            Vector2 slopeNormal = hitSlope1.normal;
    //            Vector2 slopeDirection = Vector2.Perpendicular(slopeNormal);
    //            Dir = Vector2.Dot(checkDirection, slopeDirection) * slopeDirection;
    //            Dir = Dir.normalized;

    //            if (_groundChecker.IsGrounded)
    //            {
    //                IsSlope = true;

    //                vectorTxt.text = $"{Dir.x}, {Dir.y} = {Dir.x * Dir.x + Dir.y * Dir.y}";
    //                //Debug.Log($"{Dir.x}, {Dir.y} = {Dir.x * Dir.x + Dir.y * Dir.y}");
    //            }
    //        }
    //    }


    //    if (hitSlope2 != null)
    //    {
    //        float angle = Vector2.Dot(hitSlope2.normal, Vector2.up);
    //        angle = Mathf.Acos(angle);
    //        angle = angle * Mathf.Rad2Deg;

    //        angleTxt.text = "Angle : " + angle.ToString();

    //        if (angle > 10 && angle < 80)
    //        {
    //            //경사면 각도의 벡터 구하기
    //            Vector2 slopeNormal = hitSlope2.normal;
    //            Vector2 slopeDirection = Vector2.Perpendicular(slopeNormal);
    //            Dir2 = Vector2.Dot(checkDirection, slopeDirection) * slopeDirection;
    //            Dir2 = Dir2.normalized;

    //            if (_groundChecker.IsGrounded)
    //            {
    //                IsSlope = true;

    //                vectorTxt.text = $"{Dir2.x}, {Dir2.y} = {Dir2.x * Dir2.x + Dir2.y * Dir2.y}";
    //                //Debug.Log($"{Dir.x}, {Dir.y} = {Dir.x * Dir.x + Dir.y * Dir.y}");
    //            }
    //        }
    //    }

    //    if (Dir != Dir2)
    //    {
    //        _playerRigidBody.velocity = Vector2.zero;
    //        Dir = Dir2;
    //    }
    //}
}
