using DeDucking.Entity;
using DeDucking.Utilities;
using UnityEngine;
using Logger = DeDucking.Utilities.Logger;

namespace DeDucking.Player.SO
{
    [CreateAssetMenu(fileName = "LineData", menuName = "Assets/SO/LineData", order = 6)]
    public class LineDataSO : ScriptableObject
    {
        [SerializeField] private Sprite profileIcon;
        [SerializeField, TextArea] private string[] lines;
        [SerializeField, SoundElement] private int[] sounds;

        public Sprite GetIcon() => profileIcon;
        public int Length => lines.Length;
        
        public string GetRandomLine()
        {
            int rand = Random.Range(0, lines.Length);

            return lines[rand];
        }

        public string GetLine(int idx)
        {
            if (idx < 0 || lines.Length <= idx)
            {
                Logger.Assert(false, "LineDataSO", "get line out of range index");
            }

            return lines[idx];
        }
        
        public int GetSound(int idx)
        {
            if (idx < 0 || sounds.Length <= idx)
            {
                Logger.Assert(false, "LineDataSO", "get sound out of range index");
            }

            return sounds[idx];
        }

        public int GetRandomSound()
        {
            int rand = Random.Range(0, sounds.Length);

            return sounds[rand];
        }
    }
}