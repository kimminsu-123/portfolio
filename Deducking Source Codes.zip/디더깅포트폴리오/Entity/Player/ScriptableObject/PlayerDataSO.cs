﻿using System;
using DeDucking.Utilities;
using Spine.Unity;
using UnityEngine;
using UnityEngine.Events;

namespace DeDucking.Player.SO
{
    [CreateAssetMenu(fileName = "PlayerData", menuName = "Assets/SO/Player Data", order = 0)]

    [Serializable]
    public class PlayerAttackInfo
    {
        public int delayFrame;
        public int attackFrame;
        public int damage;
        public float dashSpeed;
        public AnimationReferenceAsset anim;
    }


    public class PlayerDataSO : ScriptableObject
    {
        [SerializeField] private PlayerAttackInfo[] attackInfo;

        [Header("점프 및 하강 세팅 값")]
        [SerializeField] private float jumpSpeed;
        [SerializeField] private float jumpDuration;
        [SerializeField] private float gravityScale = 1f;
        /*[SerializeField] private float flyDuration;
        [SerializeField] private float flySpeed;
        [SerializeField] private float flyCooltime;*/

        [Header("점프 공격 세팅 값")]
        [SerializeField] private int jumpAttackDelayFrame;
        [SerializeField] private int jumpAttackDurationFrame;
        [SerializeField] private float holdingInAirDuration;
        [SerializeField] private float holdingInAirDurationOnSuccessAttack;
        [SerializeField] private int jumpAttackDamage;
        
        [Header("이동 및 대시 세팅 값")]
        [SerializeField] private float moveSpeed;
        [SerializeField] private float dashSpeed;
        [SerializeField] private float dashCooldown;

        [Header("넉백 힘 및 시간 세팅 값")]
        [SerializeField] private float knockbackForce;
        [SerializeField] private float knockbackDuration;

        [Header("콤보 공격 (일반 공격) 세팅 값")]
        [SerializeField] private float attackDuration;
        [SerializeField] private float attackCooldown;
        [SerializeField] private int normalAttackDamage;
        [SerializeField] private float comboResetTime;
        [SerializeField] private int comboMax;

        // [Header("차징 공격 세팅 값")]
        // [SerializeField] private int chargingAttackDamage;
        // [SerializeField] private float chargingTime;

        /*[Header("날기 공격 세팅 값")]
        [SerializeField] private int eggDropDamage;
        [SerializeField] private float eggDropCooldown;
        [SerializeField] private float eggResetCooldown;
        [SerializeField] private float eggDropSpeed;
        [SerializeField] private int eggMax;*/

        [Header("방어 (패링) 세팅 값")] 
        [SerializeField] private int delayDuration;
        [SerializeField] private int blockDuration;
        [SerializeField] private int parryDuration;
        [SerializeField] private ObjectPoolDataSO parryColliderPool;
        [SerializeField] private Vector2 colliderCenter;
        [SerializeField] private Vector2 colliderSize;
        [SerializeField] private LayerMask blockLayer;
        [SerializeField] private SoundInfo parrySound;
        [SerializeField] private SoundInfo blockSound;

        [Header("방패 몬스터 인지 세팅 값")]
        [SerializeField] private Vector2 colliderCenterToDetectShieldMonster;
        [SerializeField] private Vector2 colliderSizeToDetectShieldMonster;
        [SerializeField] private LayerMask monsterLayer;
        [SerializeField, SoundElement] private int attackShieldSound;


        [Header("이펙트 세팅 값")] 
        [SerializeField] private ObjectPoolDataSO blockingEffectPool;
        
        [Header("패링 게이지 세팅 값")]
        [SerializeField] private float parryGauge;
        [SerializeField] private float parryGaugeIncrease;
        [SerializeField] private float parryGaugeReduction;
        [SerializeField] private SoundInfo parryGaugeSound;

        [Header("스킬 세팅 값")] 
        [SerializeField] private float parryGaugeCost;
        [SerializeField] private int healAmount;

        [Header("대사 세팅 값")] 
        [SerializeField] private LineDataSO successParryLines;

        public UnityEvent<float> onParryGaugeUpdated;
        
        public PlayerAttackInfo[] AttackInfo => attackInfo;

        public float JumpSpeed => jumpSpeed;
        public float JumpDuration => jumpDuration;
        public float GravityScale => gravityScale;
        /*public float FlyDuration => flyDuration;
        public float FlySpeed => flySpeed;
        public float FlyCoolTime => flyCooltime;*/

        public int JumpAttackDelayFrame => jumpAttackDelayFrame;
        public int JumpAttackDurationFrame => jumpAttackDurationFrame;
        public float HoldingInAirDuration => holdingInAirDuration;
        public float HoldingInAirDurationOnSuccessAttack => holdingInAirDurationOnSuccessAttack;
        public int JumpAttackDamage => jumpAttackDamage;
        
        public float MoveSpeed => moveSpeed;
        public float DashSpeed => dashSpeed;
        public float DashCooldown => dashCooldown;

        public float KnockbackDuration => knockbackDuration;
        public float KnockbackForce => knockbackForce;

        public float AttackDuration => attackDuration;
        public float AttackCooldown => attackCooldown;
        public int NormalAttackDamage => normalAttackDamage;
        public float ComboResetTime => comboResetTime;
        public int ComboMax => comboMax;

        public int DelayDuration => delayDuration;
        public int BlockDuration => blockDuration;
        public int ParryDuration => parryDuration;
        public ObjectPoolDataSO ParryColliderPool => parryColliderPool;
        public Vector2 ColliderCenter => colliderCenter;
        public Vector2 ColliderSize => colliderSize;
        public LayerMask BlockLayer => blockLayer;


        public Vector2 ColliderCenterToDetectShieldMonster => colliderCenterToDetectShieldMonster;
        public Vector2 ColliderSizeToDetectShieldMonster => colliderSizeToDetectShieldMonster;
        public LayerMask MonsterLayer => monsterLayer;
        public int AttackShieldSound => attackShieldSound;


        public SoundInfo ParrySound => parrySound;
        public SoundInfo BlockSound => blockSound;
        public ObjectPoolDataSO BlockingEffectPool => blockingEffectPool;
        public ObjectPoolDataSO ParryGaugeEffectPool => ParryGaugeEffectPool;

        public float ParryGauge => parryGauge;
        public float ParryGaugeIncrease => parryGaugeIncrease;
        public float ParryGaugeReduction => parryGaugeReduction;
        public SoundInfo ParryGaugeSound => parryGaugeSound;
        public float ParryGaugeCurrent { get; private set; }

        public float ParryGaugeCost => parryGaugeCost;
        public int HealAmount => healAmount;
        public bool CanUseHealSkill() => ParryGaugeCurrent >= parryGaugeCost;
        
        public LineDataSO SuccessParryLines => successParryLines;

        // 리팩토링 해주세요
        public void IncreaseParryGauge()
        {
            ParryGaugeCurrent = Mathf.Clamp(ParryGaugeCurrent + parryGaugeIncrease, 0, parryGauge);
            onParryGaugeUpdated?.Invoke(ParryGaugeCurrent);
        }

        public void ReduceParryGauge()
        {
            ParryGaugeCurrent = Mathf.Clamp(ParryGaugeCurrent - parryGaugeReduction, 0, parryGauge);
            onParryGaugeUpdated?.Invoke(ParryGaugeCurrent);
        }

        public void ResetGauge()
        {
            ParryGaugeCurrent = 0;
            onParryGaugeUpdated?.Invoke(ParryGaugeCurrent);
        }

        public bool TryConsumeGaugeForHeal()
        {
            if (CanUseHealSkill())
            {
                ParryGaugeCurrent -= parryGaugeCost;
                onParryGaugeUpdated?.Invoke(ParryGaugeCurrent);
                return true;
            }

            return false;
        }
    }
}