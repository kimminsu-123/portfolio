using UnityEngine;

namespace DeDucking.Entity
{
    public interface IAttackReceiver
    {
        public void FrontAttack();
        public void BehindAttack();
        public void NotAttack();

    }
}
