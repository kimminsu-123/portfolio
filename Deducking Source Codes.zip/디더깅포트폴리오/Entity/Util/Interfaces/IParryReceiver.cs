﻿namespace DeDucking.Entity
{
    public interface IParryReceiver
    {
        public void SuccessParry();
        public void SuccessBlock();
    }
}