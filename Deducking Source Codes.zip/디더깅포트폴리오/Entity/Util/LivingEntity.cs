using DeDucking.Entity.UI;
using DeDucking.Managers;
using DeDucking.Utilities;
using DeDucking.Utilities.SO;
using UnityEngine;
using UnityEngine.Events;
using Utilities.Handler;

namespace DeDucking.Entity
{
    public enum DamageMode
    {
        None,
        Front,
        Back,
        Both,
    }
    
    public class LivingEntity : MonoBehaviour
    {   
        public UnityEvent onDeathCallback;
        public UnityEvent<GameObject> onDamageCallback;
        public UnityEvent onHealCallback;

        [SerializeField] private DamageMode damageMode = DamageMode.Both;
        [SerializeField] private LivingEntityDataSO livingEntityData;
        [SerializeField] private float invisibleTime = 0.5f;

        private ParryGaugeUI _parryGaugeUI;
        
        public DamageMode DamageMode
        {
            get => damageMode;
            set => damageMode = value;
        }
        public bool IsDeath { get; private set; }
        public int CurrentHp { get; private set; }
        public int CurrentAlterHp { get; private set; }
        public bool IsHit { get; private set; }
        public GameObject Hitter { get; private set; }
        public Vector3 HitterPosition { get; private set; }
        public LivingEntityDataSO EntityData => livingEntityData;
        
        private float ParryGaugeReduction => DatabaseManager.Instance.PlayerData.ParryGaugeReduction;

        private float ParryGaugeCurrent => DatabaseManager.Instance.PlayerData.ParryGaugeCurrent;

        private void Awake()
        {
            if (CompareTag("Player"))
            {
                _parryGaugeUI = GetComponent<ParryGaugeUI>();
            }
            
            ResetEntity();
        }

        public void TakeDamage(int damage, GameObject hitter)
        {
            if (hitter.layer != 9 && gameObject.layer == 7 || hitter.layer == 11 && gameObject.layer == 8) // 하드코딩 -> Parrying 불가이면 그냥 무시 무조건 공격 받음
            {
                if (!ValidateDamageMode(hitter.transform))
                {
                    return;
                }   
            }
            
            if (IsHit)
            {
                return;
            }

            //if (CompareTag("Player"))
            //{
            //    DatabaseManager.Instance.PlayerData.ReduceParryGauge();
            //}
            
            CameraHandler.Instance.Shake(CameraEffectType.Middle);

            IsHit = true;
            Hitter = hitter;
            HitterPosition = hitter.transform.position;
            // 무적이면  return

            int hpDamage = Mathf.Max(0, damage - CurrentAlterHp);
            int alterHpDamage = Mathf.Max(0, damage - hpDamage);

            CurrentAlterHp -= alterHpDamage; 
            CurrentHp -= hpDamage;
            
            Utilities.Logger.Log("공격 받음 (추가체력)", $"{alterHpDamage}", Color.red);
            Utilities.Logger.Log("공격 받음", $"{damage}", Color.red);
            Utilities.Logger.Log("현재 추가 체력", $"{CurrentAlterHp}", Color.red);
            Utilities.Logger.Log("현재 체력", $"{CurrentHp}", Color.red);

            onDamageCallback?.Invoke(hitter);

            Invoke(nameof(ResetHitState), invisibleTime);
            
            if (CurrentHp <= 0)
            {
                CurrentHp = 0;
                IsDeath = true;
                onDeathCallback?.Invoke();
            }
        }

        private void ResetHitState()
        {
            IsHit = false;
            Hitter = null;
            HitterPosition = Vector2.zero;
        }

        public void Heal(int amount)
        {
            CurrentHp = Mathf.Min(CurrentHp + amount, livingEntityData.MaxHp);
            onHealCallback?.Invoke();
        }

        public void AddAlterHealth(int amount)
        {
            CurrentAlterHp = Mathf.Min(CurrentAlterHp + amount, livingEntityData.MaxAlterHp);
            onHealCallback?.Invoke();
        }

        public void ResetEntity()
        {
            CurrentHp = livingEntityData.MaxHp;
            //CurrentAlterHp = livingEntityData.MaxAlterHp;
            
            IsDeath = false;
            IsHit = false;
            onHealCallback?.Invoke();
        }

        public void SetHp(int hp)
        {
            CurrentHp = hp;
            if (CurrentHp <= 0)
            {
                CurrentHp = 0;
                IsDeath = true;
                onDeathCallback?.Invoke();
            }
            onHealCallback?.Invoke();
        }

        private bool ValidateDamageMode(Transform hitter)
        {
            

            Vector2 dir = (hitter.position - transform.position).normalized;
            Vector2 right = transform.right.normalized;

            float dot = Vector2.Dot(right, dir);
            
            bool ret = true;
            switch (DamageMode)
            {
                case DamageMode.None:
                    ret = false;
                    break;
                case DamageMode.Front:
                    ret = dot > 0f; 
                    break;
                case DamageMode.Back:
                    ret = dot < 0f;
                    break;
            }
            return ret;
        }
    }
}