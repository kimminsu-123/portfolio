using DeDucking.Utilities;

namespace DeDucking.FSM
{
    public interface IState
    {
        public void EnterState();
        public void UpdateState();
        public void FixedUpdateState();
        public void ExitState();
    }
    
    public interface ITransition
    {
        public IState To { get; }
        public IPredicate Condition { get; }
    }
}