using System;
using System.Collections.Generic;
using DeDucking.Utilities;
using UnityEngine;

namespace DeDucking.FSM
{
    public class StateMachine : MonoBehaviour
    {
        private StateNode CurrentState { get; set; }
        private Dictionary<Type, StateNode> _nodes = new();
        private HashSet<ITransition> _anyTransitions = new();

        private void Update()
        {
            var transition = GetTransition();
            if (transition != null)
                ChangeState(transition.To);

            if (CurrentState != null)
            {
                CurrentState.State?.UpdateState();
            }
        }

        private void FixedUpdate()
        {
            var transition = GetTransition();
            if (transition != null)
                ChangeState(transition.To);

            if (CurrentState != null)
            {
                CurrentState.State?.FixedUpdateState();
            }
        }

        public void SetState(IState state)
        {
            CurrentState = _nodes[state.GetType()];
            CurrentState.State?.EnterState();
        }

        public IState GetState()
        {
            return CurrentState.State;
        }

        public void ChangeState(IState newState)
        {
            if (newState == CurrentState?.State) return;

            IState previousState = CurrentState?.State;
            IState nextState = _nodes[newState.GetType()].State;

            CurrentState = _nodes[newState.GetType()];

            previousState?.ExitState();
            nextState?.EnterState();
        }

        private ITransition GetTransition()
        {
            foreach (var transition in _anyTransitions)
                if (transition.Condition.Evaluate())
                    return transition;

            if (CurrentState != null)
            {
                foreach (var transition in CurrentState.Transitions)
                    if (transition.Condition.Evaluate())
                        return transition;   
            }

            return null;
        }

        public void AddTransition(IState from, IState to, FuncPredicate condition) =>
            GetOrAddNode(from).AddTransition(GetOrAddNode(to).State, condition);

        public void AddAnyTransition(IState to, IPredicate condition) =>
            _anyTransitions.Add(new Transition(GetOrAddNode(to).State, condition));

        public void RemoveTransition(IState from, IState to)
        {
            if (!_nodes.ContainsKey(from.GetType())) return;

            _nodes[from.GetType()].RemoveTransition(to);
        }

        public void RemoveAnyTransition(IState to) => _anyTransitions.RemoveWhere(x => x.To.Equals(to));

        public void RemoveAllTransitions()
        {
            _nodes = null;
            _nodes = new Dictionary<Type, StateNode>();
        }

        public void RemoveAllAnyTransitions()
        {
            _anyTransitions = null;
            _anyTransitions = new HashSet<ITransition>();
        }

        private StateNode GetOrAddNode(IState state)
        {
            StateNode node = _nodes.GetValueOrDefault(state.GetType());

            if (node == null)
            {
                node = new StateNode(state);
                _nodes.Add(state.GetType(), node);
            }

            return node;
        }

        private class StateNode
        {
            public IState State { get; }
            public HashSet<ITransition> Transitions { get; }

            public StateNode(IState state)
            {
                State = state;
                Transitions = new HashSet<ITransition>();
            }

            public void AddTransition(IState to, IPredicate condition)
            {
                Transitions.Add(new Transition(to, condition));
            }

            public void RemoveTransition(IState to)
            {
                Transitions.RemoveWhere(x => x.To.Equals(to));
            }
        }
    }
}