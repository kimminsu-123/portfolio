﻿using System;
using DeDucking.Utilities;
using Spine;
using Spine.Unity;
using UnityEngine;

namespace DeDucking.Entity
{
    public class GroggyHandler : MonoBehaviour
    {
        [SerializeField] private SkeletonAnimation spineAnimation;
        [SerializeField] private AnimationReferenceAsset beginGroggyAnimation;
        [SerializeField] private AnimationReferenceAsset loopGroggyAnimation;
        [SerializeField] private AnimationReferenceAsset endGroggyAnimation;

        private Action _callback;

        public void Groggy(float duration, Action callback, float timeScale = 1f)
        {
            _callback = callback;
            
            spineAnimation.CrossFade(0, beginGroggyAnimation, false, timeScale);
            spineAnimation.QueuedCrossFade(0, loopGroggyAnimation, true, 0f, timeScale);
            spineAnimation.QueuedCrossFade(0, endGroggyAnimation, OnEndGroggy, duration, timeScale);
        }

        private void OnEndGroggy(TrackEntry entry)
        {
            if (entry != null)
            {
                entry.Complete -= OnEndGroggy;
            }
            _callback?.Invoke();
        }
    }
}