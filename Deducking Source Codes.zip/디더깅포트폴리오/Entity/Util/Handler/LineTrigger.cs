using DeDucking.Player.SO;
using DeDucking.Player.UI;
using UnityEngine;

namespace DeDucking.Entity
{
    public class LineTrigger : MonoBehaviour
    {
        public LineDataSO data;
        public bool useRandom;

        private int _seq;

        private void OnTriggerEnter2D(Collider2D other)
        {
            var controller = other.GetComponentInChildren<LinesController>(true);

            if (!controller)
            {
                return;
            }
            
            if (useRandom)
            {
                controller.Show(data.GetIcon(), data.GetRandomLine());
            }
            else
            {
                controller.Show(data.GetIcon(), data.GetLine(_seq));
                _seq = (_seq + 1) % data.Length;
            }
        }
    }
}