﻿using System;
using UnityEngine;

namespace DeDucking.Entity
{
    [RequireComponent(typeof(LivingEntity))]
    public class DisablePhysicsOnDeath : MonoBehaviour
    {
        private LivingEntity _entity;
        private Rigidbody2D _rb2d;
        private Collider2D _col2d;

        private void Awake()
        {
            _entity = GetComponent<LivingEntity>();
            _rb2d = GetComponent<Rigidbody2D>();
            _col2d = GetComponent<Collider2D>();
            
            _entity.onDeathCallback.AddListener(OnDeath);
        }

        private void OnEnable()
        {
            if (_rb2d != null)
            {
                _rb2d.isKinematic = false;
            }
            if (_col2d != null)
            {
                _col2d.enabled = true;
            }
        }

        private void OnDeath()
        {
            if (_rb2d != null)
            {
                _rb2d.isKinematic = false;
                _rb2d.velocity = Vector2.zero;
                _rb2d.isKinematic = true;
            }
            if (_col2d != null)
            {
                _col2d.enabled = false;
            }
        }
    }
}