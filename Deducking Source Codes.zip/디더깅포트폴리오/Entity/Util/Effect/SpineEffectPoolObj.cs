﻿using System;
using DeDucking.Utilities;
using Spine.Unity;
using UnityEngine;

namespace DeDucking.Entity
{
    [RequireComponent(typeof(SkeletonAnimation))]
    public class SpineEffectPoolObj : PoolObjMonoBehavior
    {
        [SerializeField] protected AnimationReferenceAsset animationReference;
        
        private SkeletonAnimation _animation;

        protected override void OnAwake()
        {
            _animation = GetComponent<SkeletonAnimation>();
        }

        public virtual void Play()
        {
            _animation.CrossFade(0, animationReference, OnEnd);
        }

        protected virtual void OnEnd()
        {
            _animation.AnimationState.ClearTracks();
            _animation.ClearState();
            SelfReturn();
        }
    }
}