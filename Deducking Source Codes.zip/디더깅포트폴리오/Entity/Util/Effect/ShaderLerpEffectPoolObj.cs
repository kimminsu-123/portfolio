﻿using DeDucking.Utilities;
using DG.Tweening;
using UnityEngine;

namespace DeDucking.Entity
{
    public class ShaderLerpEffectPoolObj : PoolObjMonoBehavior
    {
        public string variableName;
        public float duration;
        public Vector2 fromToRange;
        
        private Renderer _renderer;
        private MaterialPropertyBlock _materialPropertyBlock;

        protected override void OnAwake()
        {
            _renderer = GetComponent<Renderer>();
            _materialPropertyBlock = new MaterialPropertyBlock();
        }

        public void Play()
        {
            DOTween.To(
                () => fromToRange.x,
                x =>
                {
                    _materialPropertyBlock.SetFloat(variableName, x);
                    _renderer.SetPropertyBlock(_materialPropertyBlock);   
                }, 
                fromToRange.y, 
                duration).OnComplete(SelfReturn).Play();
        }

        public override void OnGet()
        {
            _materialPropertyBlock.SetFloat(variableName, fromToRange.x);
            _renderer.SetPropertyBlock(_materialPropertyBlock);   
        }
    }
}