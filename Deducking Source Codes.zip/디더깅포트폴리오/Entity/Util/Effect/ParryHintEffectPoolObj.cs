using DeDucking.Managers;
using DeDucking.Utilities;
using Spine.Unity;
using UnityEngine;

namespace DeDucking.Entity
{
    public class ParryHintEffectPoolObj : SpineEffectPoolObj
    {
        [SerializeField] private AnimationReferenceAsset unavailableParryAnimation;
        [SerializeField] private AnimationReferenceAsset availableParryAnimation;

        [SerializeField] private SoundInfo unavailableParrySound;
        [SerializeField] private SoundInfo availableParrySound;

        private SoundInfo _currentSoundInfo;
        
        private const int UNAVAILABLE_PARRY_LAYER = 9;
        private const int AVAILABLE_PARRY_LAYER = 10;

        public void SetupAnimation(int layer)
        {
            switch (layer)
            {
                case UNAVAILABLE_PARRY_LAYER:
                    animationReference = unavailableParryAnimation;
                    _currentSoundInfo = unavailableParrySound;
                    break;
                case AVAILABLE_PARRY_LAYER:
                    animationReference = availableParryAnimation;
                    _currentSoundInfo = availableParrySound;
                    break;
            }
        }

        public override void Play()
        {
            base.Play();

            if (_currentSoundInfo != null)
            {
                AudioManager.Instance.PlayOneShot(transform, _currentSoundInfo.Id, _currentSoundInfo.Volume);
                _currentSoundInfo = null;   
            }
        }
    }
}