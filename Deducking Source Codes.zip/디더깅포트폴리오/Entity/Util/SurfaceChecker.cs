﻿using System;
using NaughtyAttributes;
using UnityEngine;

namespace DeDucking.Entity
{
    public class SurfaceChecker : MonoBehaviour
    {
        public bool IsGrounded { get; private set; } = false;
        public bool IsSlope { get; private set; } = false;
        public Vector2 ProjectDirection { get; private set; } = Vector2.zero;
        public bool IsOnWall { get; private set; } = false;

        [SerializeField] private bool useGroundChecker = true;
        [SerializeField] private bool useSlopeChecker = true;
        [SerializeField] private bool useWallChecker = true;
        [SerializeField] public ContactFilter2D castFilter;

        [Header("Ground Check Settings")] 
        [SerializeField, ShowIf("useGroundChecker")] private float groundCheckRadius;
        [SerializeField, ShowIf("useGroundChecker")] private Vector2 groundCheckOffset;

        [Header("Slope Check Settings")] 
        [SerializeField, ShowIf(EConditionOperator.And, "useGroundChecker", "useSlopeChecker")] private float slopeCheckLength = 1f;
        [SerializeField, ShowIf(EConditionOperator.And, "useGroundChecker", "useSlopeChecker")] private float slopeMaxAngle = 80f;

        [Header("Wall Check Settings")]
        [SerializeField, ShowIf("useWallChecker")] private float wallCheckLength = 0.2f;

        private readonly Collider2D[] _colliders = new Collider2D[2];
        private readonly RaycastHit2D[] _wallHits = new RaycastHit2D[2];
        
        private Collider2D _collider2D;
        private Vector2 _currentDirection;

        private void Awake()
        {
            _collider2D = GetComponent<Collider2D>();
        }

        private void FixedUpdate()
        {
            CalcDirection();

            if (useGroundChecker)
            {
                CheckGround();

                if (useSlopeChecker)
                {
                    CheckSlope();
                }
            }

            if (useWallChecker)
            {
                CheckWall();
            }
        }

        private void CalcDirection()
        {
            _currentDirection = Vector2.right;
            
            if (transform.right.x < 0f)
            {
                _currentDirection = Vector2.left;
            }
        }

        private void CheckGround()
        {
            Vector3 offset = _currentDirection;
            offset.x *= groundCheckOffset.x;
            offset.y += groundCheckOffset.y;
            
            int count = Physics2D.OverlapCircleNonAlloc(transform.position + offset, groundCheckRadius, _colliders, castFilter.layerMask);

            IsGrounded = count > 0;
        }

        public void CheckSlope()
        {
            if (!IsGrounded)
            {
                IsSlope = false;
                return;
            }

            if (_colliders[0] == null)
            {
                IsSlope = false;
                return;
            }
            
            RaycastHit2D hit = Physics2D.Raycast(transform.position, Vector2.down, slopeCheckLength, castFilter.layerMask);
            if (hit.collider == null)
            {
                IsSlope = false;
                return;
            }
            
            float angle = Vector2.Angle(Vector2.up, hit.normal);
            if (10f <= angle && angle < slopeMaxAngle)
            {
                IsSlope = true;
                ProjectDirection = Vector3.ProjectOnPlane(_currentDirection, hit.normal).normalized;
            }
            else
            {
                IsSlope = false;
                ProjectDirection = Vector2.zero;
            }
        }

        private void CheckWall()
        {
            int hitCount = _collider2D.Cast(_currentDirection, castFilter, _wallHits, wallCheckLength);

            if (hitCount <= 0)
            {
                IsOnWall = false;
                return;
            }
            
            float angle = Vector2.Angle(Vector2.up, _wallHits[0].normal);
            IsOnWall = angle > slopeMaxAngle;
        }

        #region Gizmos

        private void OnDrawGizmos()
        {
            if (useGroundChecker)
            {
                DrawGroundChecker();

                if (useSlopeChecker)
                {
                    DrawSlopeChecker();
                }
            }
        }

        private void DrawGroundChecker()
        {
            Gizmos.matrix = transform.localToWorldMatrix;
            Gizmos.color = Color.red;
            Gizmos.DrawWireSphere(groundCheckOffset, groundCheckRadius);
        }

        private void DrawSlopeChecker()
        {
            Gizmos.matrix = transform.localToWorldMatrix;
            Gizmos.color = Color.blue;
            Gizmos.DrawLine(Vector3.zero, Vector3.down * slopeCheckLength);
        }

        #endregion
    }
}