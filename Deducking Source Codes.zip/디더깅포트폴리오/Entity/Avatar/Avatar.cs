using DeDucking.Player.SO;
using DeDucking.Utilities;
using UnityEngine;
using IState = DeDucking.FSM.IState;
using StateMachine = DeDucking.FSM.StateMachine;

namespace DeDucking.Entity.Avatar
{
    [RequireComponent(typeof(StateMachine))]
    public class Avatar : MonoBehaviour
    {
        [SerializeField] private UpDownMoveBehavior idleMoveBehavior;
        [SerializeField] private FollowTargetMoveBehavior chaseMoveBehavior;
        
        [SerializeField] private PlayerDataSO playerData;
        
        [Header("Idle Properties")]
        [SerializeField] private float upDownSpeed;
        [SerializeField] private float yDistance = 0.5f;
        [SerializeField] private float xDistance = 0.001f;

        [Header("Chase Properties")] 
        [SerializeField] private string chaseTargetTag = "AvatarPos";

        private bool HasChase
        {
            get
            {
                Vector3 dir = chaseTarget.position - transform.position;

                float x = Mathf.Abs(dir.x);
                float y = Mathf.Abs(dir.y);
                
                return xDistance < x || yDistance < y;
            }
        }
        private float ChaseSpeed => playerData.MoveSpeed;

        private Transform chaseTarget;
        private StateMachine _stateMachine;
        private AvatarState _idleState;
        private AvatarState _chaseState;

        private void Awake()
        {
            _stateMachine = GetComponent<StateMachine>();
        }
        
        private void Start()
        {            
            chaseTarget = GameObject.FindGameObjectWithTag(chaseTargetTag).transform;

            SetupState();
            SetupTransitions();
            Initialize();
        }

        private void SetupState()
        {
            _idleState = new IdleState(transform, chaseTarget.parent, idleMoveBehavior);
            _chaseState = new ChaseState(chaseMoveBehavior, transform, chaseTarget);
        }

        private void SetupTransitions()
        {
            _stateMachine.AddTransition(_idleState, _chaseState, new FuncPredicate(() => HasChase ));
            _stateMachine.AddTransition(_chaseState, _idleState, new FuncPredicate(() => _chaseState.IsCompleted ));
        }

        private void Initialize()
        {
            idleMoveBehavior.SetMoveSpeed(upDownSpeed);
            idleMoveBehavior.SetYDistance(yDistance);
            
            chaseMoveBehavior.SetTarget(chaseTarget);
            chaseMoveBehavior.SetMoveSpeed(ChaseSpeed);
            
            _stateMachine.SetState(_idleState);
        }
    }
}