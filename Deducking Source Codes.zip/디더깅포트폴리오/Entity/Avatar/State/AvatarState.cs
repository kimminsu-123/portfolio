﻿using DeDucking.FSM;

namespace DeDucking.Entity
{
    public class AvatarState : IState
    {
        public bool IsCompleted { get; protected set; }
        
        protected readonly IMoveBehavior MoveBehavior;
        
        protected AvatarState(IMoveBehavior moveBehavior)
        {
            MoveBehavior = moveBehavior;
        }
        
        public virtual void EnterState() { }
        public virtual void UpdateState() { }
        public virtual void FixedUpdateState() { }
        public virtual void ExitState() { }
    }
}