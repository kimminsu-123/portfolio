﻿using DeDucking.Utilities;
using Unity.VisualScripting;
using UnityEngine;
using IState = DeDucking.FSM.IState;
using Logger = DeDucking.Utilities.Logger;

namespace DeDucking.Entity.Avatar
{
    public class ChaseState : AvatarState
    {
        private readonly Transform _cachedTr;
        private readonly Transform _targetTr;
        
        private bool HasReached => Util.GetDistance(_cachedTr.position, _targetTr.position) <= 0.000001f;
        
        public ChaseState(IMoveBehavior moveBehavior, Transform cachedTr, Transform targetTr) : base(moveBehavior)
        {
            _cachedTr = cachedTr;
            _targetTr = targetTr;
        }
        
        public override void EnterState()
        {
            IsCompleted = false;
            
            MoveBehavior.Run();
        }

        public override void UpdateState()
        {
            if (HasReached)
            {
                _cachedTr.position = _targetTr.position;
                
                IsCompleted = true;
            }
        }

        public override void ExitState()
        {
            MoveBehavior.Stop();
        }
    }
}