﻿using DeDucking.FSM;
using DeDucking.Utilities;
using UnityEngine;
using UnityEngine.PlayerLoop;
using Logger = DeDucking.Utilities.Logger;

namespace DeDucking.Entity.Avatar
{
    public class IdleState : AvatarState
    {
        private readonly Transform _cachedTr;
        private readonly Transform _playerTr;
        
        public IdleState(Transform cachedTr, Transform playerTr, IMoveBehavior moveBehavior) : base(moveBehavior)
        {
            _cachedTr = cachedTr;
            _playerTr = playerTr;
        }
        
        public override void EnterState()
        {
            MoveBehavior.Run();
        }

        public override void UpdateState()
        {
            _cachedTr.FlipLookAtUsingRotation(_playerTr);
        }

        public override void ExitState()
        {
            MoveBehavior.Stop();
        }
    }
}