﻿using DeDucking.Utilities;
using UnityEngine;

namespace DeDucking.Entity.Avatar
{
    public class FollowTargetMoveBehavior : MonoBehaviour, IMoveBehavior
    {
        [SerializeField] private float moveSpeed;
        [SerializeField] private Transform target;

        public bool IsRunning => true;
        private bool _isRunning = true;

        private void FixedUpdate()
        {
            if (_isRunning && target != null)
            {
                Move();
            }
        }

        public void SetMoveSpeed(float speed)
        {
            moveSpeed = speed;
        }

        public void SetTarget(Transform targetTr)
        {
            target = targetTr;
        }

        public void Run()
        {
            _isRunning = true;
        }

        public void Move()
        {
            transform.FlipLookAtUsingRotation(target);
            transform.position = Vector3.Lerp(transform.position, target.position, moveSpeed * Time.deltaTime);
        }

        public void Stop()
        {
            _isRunning = false;
        }
    }
}