﻿using System;
using Unity.VisualScripting;
using UnityEngine;

namespace DeDucking.Entity.Avatar
{
    public class UpDownMoveBehavior : MonoBehaviour, IMoveBehavior
    {
        [SerializeField] private float moveSpeed;
        [SerializeField] private float yDistance;
        
        public bool IsRunning => _isRunning;
        private bool _isRunning = true;
        private float _delta = 0f;
        private Vector3 _startPosition;

        private void OnEnable()
        {
            Run();
        }

        private void Update()
        {
            if (_isRunning)
            {
                Move();
            }
        }

        public void SetMoveSpeed(float speed)
        {
            moveSpeed = speed;
        }

        public void SetYDistance(float dist)
        {
            yDistance = dist;
        }

        public void Run()
        {
            _startPosition = transform.position;
            _delta = 0f;
            _isRunning = true;
        }

        public void Move()
        {
            _delta += Time.deltaTime * moveSpeed;

            Vector3 pos = transform.position;
            pos.y = _startPosition.y + (Mathf.Sin(_delta) * yDistance);
            transform.position = pos;
        }

        public void Stop()
        {   
            _isRunning = false;
        }
    }
}