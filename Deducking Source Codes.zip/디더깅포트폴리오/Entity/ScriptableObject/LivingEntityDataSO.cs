using UnityEngine;

namespace DeDucking.Utilities.SO
{
    [CreateAssetMenu(fileName = "LivingEntityData", menuName = "Assets/SO/Living Entity Data", order = 1)]
    public class LivingEntityDataSO : ScriptableObject
    {
        [SerializeField] private int maxHp;
        [SerializeField] private int maxAlterHp;

        public int MaxHp => maxHp;
        public int MaxAlterHp => maxAlterHp;
    }
}