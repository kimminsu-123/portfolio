using DeDucking.Utilities;
using UnityEngine;
using UnityEngine.InputSystem;

namespace DeDucking.Managers
{
    public class InputManager : SingletonMonoBehavior<InputManager>
    {
        private const string INPUT_NAME_MOVE = "Move";
        private const string INPUT_NAME_JUMP = "Jump";
        private const string INPUT_NAME_ATTACK = "Attack";
        private const string INPUT_NAME_DASH = "Dash";
        private const string INPUT_NAME_DROP_THROUGH = "DropThrough";
        private const string INPUT_NAME_BLOCK = "Block";
        private const string INPUT_NAME_HEAL = "Heal";

        private PlayerInput _playerInput;

        private InputAction _moveAction;
        private InputAction _jumpAction;
        private InputAction _attackAction;
        private InputAction _comboAttackAction;
        private InputAction _dashAction;
        private InputAction _dropThroughAction;
        private InputAction _blockAction;
        private InputAction _healAction;

        public bool HasAnyKeyInput => Move != Vector2.zero || IsJump || IsDash || IsAttack || IsBlock;
        public Vector2 Move { get; private set; }
        public bool IsMoveDown => _moveAction.WasPressedThisFrame();
        public bool IsJump { get; private set; }
        public bool IsJumpKeyDown => _jumpAction.WasPressedThisFrame();
        public bool IsJumpKeyUp => _jumpAction.WasReleasedThisFrame();
        public bool IsDash { get; private set; }
        public bool IsDashDown => _dashAction.WasPressedThisFrame();
        public bool IsAttack { get; private set; }
        public bool IsComboAttack { get; set; }
        public bool IsAttackKeyDown => _attackAction.WasPressedThisFrame();
        public bool IsComboAttackKeyUp => _comboAttackAction.WasReleasedThisFrame();
        public bool IsDropThrough => _dropThroughAction.WasPressedThisFrame();
        public bool IsBlock { get; set; }
        public bool IsBlockKeyDown => _blockAction.WasPerformedThisFrame();
        public bool IsBlockKeyUp => _blockAction.WasReleasedThisFrame();
        
        public bool IsHealKeyDown => _healAction.WasPerformedThisFrame();
        public bool IsHealKeyUp => _healAction.WasReleasedThisFrame();

        protected override void Initialize()
        {
            _playerInput = gameObject.GetOrAddComponent<PlayerInput>();

            _moveAction = _playerInput.actions[INPUT_NAME_MOVE];
            _jumpAction = _playerInput.actions[INPUT_NAME_JUMP];
            _attackAction = _playerInput.actions[INPUT_NAME_ATTACK];
            _comboAttackAction = _playerInput.actions[INPUT_NAME_ATTACK];
            _dashAction = _playerInput.actions[INPUT_NAME_DASH];
            _dropThroughAction = _playerInput.actions[INPUT_NAME_DROP_THROUGH];
            _blockAction = _playerInput.actions[INPUT_NAME_BLOCK];
            _healAction = _playerInput.actions[INPUT_NAME_HEAL];
            
            EventManager.Instance.AddListener(EventType.OnBeginCutScene, OnCutScene);
            EventManager.Instance.AddListener(EventType.OnEndCutScene, OnCutScene);

            BindButtonActions();
        }

        protected override void OnDestroy()
        {
            base.OnDestroy();

            EventManager.Instance.RemoveListener(EventType.OnBeginCutScene, OnCutScene);
            EventManager.Instance.RemoveListener(EventType.OnEndCutScene, OnCutScene);
        }

        private void OnCutScene(EventType type, Component sender, object[] args)
        {
            if (type == EventType.OnBeginCutScene)
            {
                DisableInput();
            }
            else
            {
                EnableInput();
            }
        }

        private void BindButtonActions()
        {
            _jumpAction.started += context => IsJump = true;
            _jumpAction.canceled += context => IsJump = false;

            _attackAction.started += context => IsAttack = true;
            _attackAction.canceled += context => IsAttack = false;

            _comboAttackAction.started += context => IsComboAttack = true;
            _comboAttackAction.canceled += context => IsComboAttack = false;

            _dashAction.started += context => IsDash = true;
            _dashAction.canceled += context => IsDash = false;

            _blockAction.started += context => IsBlock = true;
            _blockAction.canceled += context => IsBlock = false;

            // _dropThroughAction.started += context => IsDropThrough = true;
            // _dropThroughAction.canceled += context => IsDropThrough = false;
        }

        public void OnMove(InputValue value)
        {
            Move = value.Get<Vector2>();
        }

        public void EnableInput()
        {
            _playerInput.currentActionMap.Enable();
        }

        public void DisableInput()
        {
            _playerInput.currentActionMap.Disable();
        }
    }
}