﻿using DeDucking.Player.SO;
using DeDucking.Utilities;
using UnityEngine;

namespace DeDucking.Managers
{
    public class DatabaseManager : SingletonMonoBehavior<DatabaseManager>
    {
        [SerializeField] private PlayerDataSO playerData;
        public PlayerDataSO PlayerData => playerData;
        
        private const string STAGE_SAVE_PATH = "Stage";
        private const string HP_SAVE_PATH = "PlayerHp";
        private const string ALTER_HP_SAVE_PATH = "PlayerAlterHp";
        
        protected override void Initialize()
        {
        }

        public void SaveCurrentStage(string currentScenePath)
        {
            PlayerPrefs.SetString(STAGE_SAVE_PATH, currentScenePath);
        }

        public void SaveCurrentHp(int currentHp)
        {
            PlayerPrefs.SetInt(HP_SAVE_PATH, currentHp);
        }
        
        public void SaveCurrentAlterHp(int alterHp)
        {
            PlayerPrefs.SetInt(ALTER_HP_SAVE_PATH, alterHp);
        }
        
        public string GetSavedStage() => PlayerPrefs.GetString(STAGE_SAVE_PATH);
        public int GetSavedHp() => PlayerPrefs.GetInt(HP_SAVE_PATH);
        public int GetSavedAlterHp() => PlayerPrefs.GetInt(ALTER_HP_SAVE_PATH);
    }
}