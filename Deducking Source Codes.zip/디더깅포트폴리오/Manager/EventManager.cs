using System.Collections.Generic;
using UnityEngine;

namespace DeDucking.Managers
{
    public enum EventType
    {
        OnBeginSceneLoad,
        OnSceneLoadedBefore,
        OnSceneLoaded,
        OnPlayerDeath,
        OnBeginCutScene,
        OnEndCutScene,
    }
    
    public class EventManager : SingletonMonoBehavior<EventManager>
    {
        public delegate void OnEvent(EventType type, Component sender, params object[] args);

        private readonly Dictionary<EventType, List<OnEvent>> _listeners = new();

        protected override void Initialize()
        {
            
        }
        
        public void AddListener(EventType type, OnEvent onEvent)
        {
            if (!_listeners.ContainsKey(type))
            {
                _listeners.Add(type, new List<OnEvent>());
            }
            
            _listeners[type].Add(onEvent);
        }

        public void RemoveListener(EventType type, OnEvent onEvent)
        {
            if (!_listeners.ContainsKey(type))
            {
                return;
            }

            _listeners[type].Remove(onEvent);
        }

        public void PostNotification(EventType type, Component sender, params object[] args)
        {
            if (!_listeners.ContainsKey(type))
            {
                return;
            }

            foreach (var callback in _listeners[type])
            {
                callback?.Invoke(type, sender, args);
            }
        }
    }
}