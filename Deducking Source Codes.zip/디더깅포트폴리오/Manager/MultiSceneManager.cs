﻿using System;
using System.Collections;
using DeDucking.Interactables.Common;
using DeDucking.UI.Canvas;
using DeDucking.Utilities;
using Unity.Mathematics;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace DeDucking.Managers
{
    public class MultiSceneManager : SingletonMonoBehavior<MultiSceneManager>
    {
        [SerializeField] private GameObject cameras;
        [SerializeField] private GameObject dontDestroyOnLoadObj;
        [SerializeField] private SceneLoader initSceneLoader;
        
        public bool IsLoading { get; private set; }

        private string _currentScene;
        private LoadingCanvas _loadingCanvas;

        private const string STAGE_PREFIX = "Stage";
        
        protected override void Initialize()
        {
            _loadingCanvas = FindObjectOfType<LoadingCanvas>(true);
            
            IsLoading = false;
        }

        private void Start()
        {
            GoToMain();
        }

        public void GoToMain()
        {
            initSceneLoader?.Interact(gameObject);
        }
        
        public bool LoadSceneAdditive(SceneReference scene)
        {
            return LoadSceneAdditive(scene.ScenePath);
        }

        public bool LoadSceneAdditive(string scenePath)
        {
            if (IsLoading)
            {
                return false;
            }
            
            IsLoading = true;
            
            dontDestroyOnLoadObj.SetActive(false);
            _loadingCanvas.SetCompleteFadeInCallback(() => StartCoroutine(LoadSceneAdditiveCoroutine(scenePath)));
            _loadingCanvas.Show();
            
            return true;
        }

        private IEnumerator LoadSceneAdditiveCoroutine(string scenePath)
        {
            EventManager.Instance.PostNotification(EventType.OnBeginSceneLoad, this);
            
            RepositioningPlayer(true);
            
            yield return StartCoroutine(UnloadPrevScene());

            yield return StartCoroutine(LoadNextScene(scenePath));
            
            CompleteLoadScene(scenePath);
        }

        private IEnumerator UnloadPrevScene()
        {
            SceneManager.SetActiveScene(SceneManager.GetSceneAt(0));

            if (_currentScene != null)
            {
                yield return SceneManager.UnloadSceneAsync(_currentScene);
            }
            
            yield return null;
        }

        private IEnumerator LoadNextScene(string scenePath)
        {
            AsyncOperation operation = SceneManager.LoadSceneAsync(scenePath, LoadSceneMode.Additive);
            operation.allowSceneActivation = false;

            while (!operation.isDone)
            {
                if (operation.progress >= 0.9f)
                {
                    operation.allowSceneActivation = true;
                }
                
                yield return null;
            }
        }

        private void CompleteLoadScene(string scenePath)
        {
            if (scenePath.Contains(STAGE_PREFIX))
            {
                InputManager.Instance.EnableInput();
                DatabaseManager.Instance.SaveCurrentStage(scenePath);
                DatabaseManager.Instance.SaveCurrentHp(GameManager.Instance.Player.CurrentHp);
                DatabaseManager.Instance.SaveCurrentAlterHp(GameManager.Instance.Player.CurrentAlterHp);
            }
            else
            {
                GC.Collect(2, GCCollectionMode.Forced, false);
                InputManager.Instance.DisableInput();   
            }
            
            SceneManager.SetActiveScene(SceneManager.GetSceneByPath(scenePath));
            _currentScene = scenePath;

            RepositioningPlayer(false);

            EventManager.Instance.PostNotification(EventType.OnSceneLoadedBefore, this);
            
            _loadingCanvas.SetCompleteFadeOutCallback(() =>
            {
                EventManager.Instance.PostNotification(EventType.OnSceneLoaded, this);
                IsLoading = false;
            });
            _loadingCanvas.Hide();
        }

        private void RepositioningPlayer(bool isThis)
        {
            dontDestroyOnLoadObj.gameObject.SetActive(!isThis);
            foreach (Transform child in dontDestroyOnLoadObj.transform)
            {
                child.transform.localPosition = Vector3.zero;
                child.transform.localRotation = quaternion.identity;
            }
            
            var parent = transform;
            if (!isThis)
            {
                parent = Util.FindSpawnPoint();
                if (parent == null)
                {
                    return;
                }
            }
            
            dontDestroyOnLoadObj.transform.parent = parent;
            dontDestroyOnLoadObj.transform.localPosition = Vector3.zero;
            dontDestroyOnLoadObj.transform.localRotation = Quaternion.identity;

            cameras.transform.parent = parent;
            cameras.transform.localPosition = Vector3.zero;
            cameras.transform.localRotation = Quaternion.identity;
        }
    }
}