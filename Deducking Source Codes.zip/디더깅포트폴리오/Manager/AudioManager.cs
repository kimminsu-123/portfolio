﻿using DeDucking.Utilities;
using UnityEngine;
using Logger = DeDucking.Utilities.Logger;

namespace DeDucking.Managers
{
    public class AudioManager : SingletonMonoBehavior<AudioManager>
    {
        [SerializeField] private ObjectPoolDataSO speakerPool;
        [SerializeField] private SoundTableSO[] tables;

        protected override void Initialize()
        {
            for (int i = 0; i < tables.Length; i++)
            {
                tables[i].Initialize();
            }
        }

        public void PlayLoop(Transform parent, int id, float volume = 1f)
        {
            AudioClip clip = GetSound(id);
            if (clip != null)
            {
                Speaker speaker = speakerPool.GetQueue<Speaker>(parent);
                speaker.originPool = speakerPool;
                speaker.PlayLoop(clip, volume);
            }
        }

        public void PlayOneShot(Transform parent, int id, float volume = 1f)
        {
            AudioClip clip = GetSound(id);
            if (clip != null)
            {
                Speaker speaker = speakerPool.GetQueue<Speaker>(parent);
                speaker.originPool = speakerPool;
                speaker.PlayOneShot(clip, volume);
            }
        }

        private AudioClip GetSound(int id)
        {
            AudioClip clip = null;

            for (int i = 0; i < tables.Length && clip == null; i++)
            {
                clip = tables[i].GetAudio(id);
            }

            if (clip == null)
            {
                Logger.LogWarning("AudioManager", $"Audio clip not found {id}");
            }
            
            return clip;
        }
    }
}