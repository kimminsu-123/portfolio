using DeDucking.Entity;
using DeDucking.Interactables.Common;
using DeDucking.Managers;
using UnityEngine;
using EventType = DeDucking.Managers.EventType;

#if UNITY_EDITOR
using UnityEditor;
#endif

[RequireComponent(typeof(SceneLoader))]
public class GameManager : SingletonMonoBehavior<GameManager>
{
    private SceneLoader _beginnerSceneLoader;
    public LivingEntity Player { get; private set; }
    
    protected override void Initialize()
    {
        _beginnerSceneLoader = GetComponent<SceneLoader>();
        Player = GameObject.FindGameObjectWithTag("Player").GetComponent<LivingEntity>();
        
        EventManager.Instance.AddListener(EventType.OnPlayerDeath, OnPlayerDeath);
        
        QualitySettings.vSyncCount = 0;
        Application.targetFrameRate = 60;
    }

    public void StartNewGame()
    {
        Player.ResetEntity();
        _beginnerSceneLoader.Interact(gameObject);
    }

    public void ContinueGame()
    {
        string s = DatabaseManager.Instance.GetSavedStage();

        if (string.IsNullOrEmpty(s))
        {
            // 저장된 씬이 없음
            return;
        }

        Player.ResetEntity();

        /* 20241202 회의를 통해서 없애기로함 
        int lastHp = DatabaseManager.Instance.GetSavedHp();
        if (lastHp > 0)
        {
            Player.SetHp(lastHp);
        }*/
        
        int lastAlterHp = DatabaseManager.Instance.GetSavedAlterHp();
        if (lastAlterHp > 0)
        {
            Player.AddAlterHealth(lastAlterHp);
        }

        MultiSceneManager.Instance.LoadSceneAdditive(s);
    }

    public void ExitGame()
    {
        #if UNITY_EDITOR
            EditorApplication.isPlaying = false;
        #else
            Application.Quit();
        #endif
    }

    private void OnPlayerDeath(EventType type, Component sender, object[] args)
    {
        MultiSceneManager.Instance.GoToMain();
    }

    protected override void OnDestroy()
    {
        base.OnDestroy();

        EventManager.Instance.RemoveListener(EventType.OnPlayerDeath, OnPlayerDeath);
    }
}
