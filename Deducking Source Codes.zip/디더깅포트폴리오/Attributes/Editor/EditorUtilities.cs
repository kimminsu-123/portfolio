﻿using System.Linq;
using System.Reflection;
using UnityEditor;
using UnityEngine;

namespace DeDucking.Editor
{
    public static class EditorUtilities
    {
        public static T[] FindAllAssetsOfTypeScriptableObjects<T>() where T : ScriptableObject
        {
            string[] guids = AssetDatabase.FindAssets($"t:{typeof(T)}");
            T[] result = new T[guids.Length];

            for (int i = 0; i < guids.Length; i++)
            {
                string path = AssetDatabase.GUIDToAssetPath(guids[i]);
                result[i] = AssetDatabase.LoadAssetAtPath<T>(path);
            }

            return result;
        }
        
        public static void PlayClip(AudioClip clip, int startSample = 0, bool loop = false)
        {
            if (clip == null)
            {
                return;
            }
            
            Assembly unityEditorAssembly = typeof(AudioImporter).Assembly;
            System.Type audioUtilClass = unityEditorAssembly.GetType("UnityEditor.AudioUtil");
            var method = audioUtilClass.GetMethod(
                "PlayPreviewClip",
                BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic,
                null,
                new[] { typeof(AudioClip), typeof(int), typeof(bool) },
                null
            );
            method?.Invoke(
                null,
                new object[] { clip, startSample, loop }
            );
        }
    }
}