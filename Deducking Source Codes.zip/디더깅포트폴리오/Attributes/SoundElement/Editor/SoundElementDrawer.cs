﻿using System.Collections.Generic;
using System.Linq;
using DeDucking.Editor;
using DeDucking.Utilities;
using UnityEditor;
using UnityEngine;

namespace DeDucking.SoundElement.Editor
{
    [CustomPropertyDrawer (typeof(SoundElementAttribute))]
    public class SoundElementDrawer : PropertyDrawer
    {
        private bool _isInitialize = false;
        private SoundTableSO[] _soundTables;
        private List<string> _keys;
        
        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            if (!_isInitialize)
            {
                Initialize();
            }
            
            EditorGUILayout.BeginHorizontal();
            EditorGUI.LabelField(position, label);

            int currentID = property.intValue;

            int selected = 0;
            for (int i = 0; i < _keys.Count; i++)
            {
                string[] split1 = _keys[i].Split("/");
                string[] split2 = split1.Last().Split("_");
                if (int.Parse(split2.First()) == currentID)
                {
                    selected = i;
                    break;
                }
            }
            Rect popupRect = new Rect(position.x + 100, position.y, position.width - 300, EditorGUIUtility.singleLineHeight);
            selected = EditorGUI.Popup(popupRect, selected, _keys.ToArray());
            EditorGUILayout.EndHorizontal();

            string[] splitSelected = _keys[selected].Split("/");
            string[] splitDetails = splitSelected.Last().Split("_");

            string tableName = splitSelected.First();
            int selectedID = int.Parse(splitDetails.First());
            
            Rect buttonRect = new Rect(popupRect.width + popupRect.position.x + 10, position.y, 200, EditorGUIUtility.singleLineHeight);
            if (GUI.Button(buttonRect, "Play", EditorStyles.miniButton))
            {
                var soundTable = _soundTables.FirstOrDefault(x => x.name.Equals(tableName));
                if (soundTable != null)
                {
                    var clip = soundTable.AudioClips.First(x => x.ID == selectedID).Clip;
                    EditorUtilities.PlayClip(clip);
                }
            }
            
            property.intValue = selectedID;

            property.serializedObject.ApplyModifiedProperties();
        }

        private void Initialize()
        {
            _isInitialize = true;
            
            _soundTables = EditorUtilities.FindAllAssetsOfTypeScriptableObjects<SoundTableSO>();
            _keys = new List<string>();

            for (var i = 0; i < _soundTables.Length; i++)
            {
                var soundTable = _soundTables[i];
                for (int j = 0; j < soundTable.AudioClips.Length; j++)
                {
                    _keys.Add($"{soundTable.name}/{soundTable.AudioClips[j].ID}_{soundTable.AudioClips[j].Description}");
                }
            }
        }
    }
}