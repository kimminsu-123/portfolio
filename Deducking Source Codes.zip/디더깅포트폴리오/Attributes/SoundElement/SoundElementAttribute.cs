using System;
using UnityEditor;
using UnityEngine;

[AttributeUsage(AttributeTargets.Field, AllowMultiple = true)]
public class SoundElementAttribute : PropertyAttribute
{
}

