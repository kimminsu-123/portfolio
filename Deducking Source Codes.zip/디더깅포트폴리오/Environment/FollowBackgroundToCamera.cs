using DeDucking.Managers;
using NaughtyAttributes;
using UnityEngine;
using Utilities.Handler;

namespace DeDucking.Environment
{
    public enum FollowMode
    {
        None,
        Soft,
        Hard
    }

    public class FollowBackgroundToCamera : MonoBehaviour
    {
        [SerializeField] private FollowMode followMode;
        [SerializeField, ShowIf("followMode", FollowMode.Soft)] public Vector2 smoothLerpSpeed;
        [SerializeField, ShowIf("followMode", FollowMode.Hard)] private bool _matchCameraSize = false;

        private SpriteRenderer _spriteRenderer;
        private Camera _mainCam;

        private Transform _mainCamTr;
        private Vector3 _offset;

        private void Start()
        {
            EventManager.Instance.AddListener(Managers.EventType.OnSceneLoadedBefore, OnSceneLoaded);
        }

        private void OnSceneLoaded(Managers.EventType type, Component sender, object[] args)
        {
            _mainCamTr = CameraHandler.Instance.MainCamera.transform;

            _offset = transform.position - _mainCamTr.position;

            if (_matchCameraSize)
            {
                _spriteRenderer = GetComponent<SpriteRenderer>();
                _mainCam = _mainCamTr.gameObject.GetComponent<Camera>();
                ResizeBackgroundToCamera();
            }
        }

        private void FixedUpdate()
        {
            if (_mainCamTr == null)
            {
                return;
            }

            switch (followMode)
            {
                case FollowMode.None:
                    // nothing
                    break;
                case FollowMode.Soft:
                    FollowSoft();
                    break;
                case FollowMode.Hard:
                    FollowHard();
                    break;
            }
        }
        private void FollowSoft()
        {
            Vector3 curPos = transform.position;
            Vector3 targetPos = _mainCamTr.position + _offset;

            curPos.x = Mathf.Lerp(curPos.x, targetPos.x, Time.deltaTime * smoothLerpSpeed.x);
            curPos.y = Mathf.Lerp(curPos.y, targetPos.y, Time.deltaTime * smoothLerpSpeed.y);

            transform.position = curPos;
        }
        private void FollowHard()
        {
            if (_matchCameraSize)
            {
                Vector3 pos = new Vector3(_mainCamTr.position.x, _mainCamTr.position.y, 0);
                transform.position = pos;
                return;
            }

            transform.position = _mainCamTr.position + _offset;
        }

        private void OnDestroy()
        {
            EventManager.Instance.RemoveListener(Managers.EventType.OnSceneLoadedBefore, OnSceneLoaded);
        }

        private void ResizeBackgroundToCamera()
        {
            if (_mainCam == null || _spriteRenderer == null)
                return;

            float cameraDistance = Mathf.Abs(_mainCam.transform.position.z);
            float fov = _mainCam.fieldOfView;
            float aspect = _mainCam.aspect;

            float cameraHeight = 2f * Mathf.Tan(fov * 0.5f * Mathf.Deg2Rad) * cameraDistance;

            float cameraWidth = cameraHeight * aspect;

            Vector2 spriteSize = _spriteRenderer.size;

            float scaleX = (cameraWidth / spriteSize.x) * 3;
            float scaleY = cameraHeight / spriteSize.y;

            transform.localScale = new Vector3(scaleX, scaleY, 1);
        }
    }
}