using DeDucking.Managers;
using DeDucking.Player;
using UnityEngine;
using EventType = DeDucking.Managers.EventType;

public class ParallaxEffect : MonoBehaviour
{
    private Camera cam;
    private Transform followTarget;

    private Vector2 _startingPosition;

    private float _startingZ;

    private Vector2 CamMoveSinceStart => (Vector2)cam.transform.position - _startingPosition;

    private float ZDistanceFromTarget => transform.position.z - followTarget.transform.position.z;

    private float ClippingPlane =>
        (cam.transform.position.z + (ZDistanceFromTarget > 0 ? cam.farClipPlane : cam.nearClipPlane));

    private float ParallaxFactor => Mathf.Abs(ZDistanceFromTarget) / ClippingPlane;

    // Start is called before the first frame update
    void Start()
    {
        EventManager.Instance.AddListener(EventType.OnSceneLoadedBefore, OnSceneLoaded);
    }

    private void OnSceneLoaded(EventType type, Component sender, object[] args)
    {
        cam = Camera.main;
        followTarget = FindObjectOfType<Player>().transform;
        
        _startingPosition = transform.position;
        _startingZ = transform.position.z;
    }

    // Update is called once per frame
    void LateUpdate()
    {
        if (followTarget != null && cam != null)
        {
            Vector2 newPosition = new Vector2(_startingPosition.x + CamMoveSinceStart.x * ParallaxFactor, _startingPosition.y); 
            transform.position = new Vector3(newPosition.x, newPosition.y, _startingZ);    
        }
    }

    private void OnDestroy()
    {
        EventManager.Instance.RemoveListener(EventType.OnSceneLoadedBefore, OnSceneLoaded);
    }
}