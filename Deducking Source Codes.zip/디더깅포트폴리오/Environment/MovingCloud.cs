﻿using UnityEngine;

namespace DeDucking.Environment
{
    public class MovingCloud : MonoBehaviour
    {
        
    }
}