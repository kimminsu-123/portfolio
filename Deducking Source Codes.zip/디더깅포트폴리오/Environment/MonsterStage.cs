﻿using System.Linq;
using DeDucking.Entity.Monster;
using UnityEngine;
using UnityEngine.Serialization;

namespace DeDucking.Environment
{
    public enum StageStatus
    {
        None = 0,
        Initialized,
        Cleared
    }
    
    public class MonsterStage : MonoBehaviour
    {
        [SerializeField] private GameObject portal;
        [SerializeField] private bool openPortalImmediately;

        public int TotalMonster => _monsters.Length;
        public int CurrentLiveMonster => _monsters.Count(x => !x.IsDead);
        
        private bool IsDeadAllMonsterInStage => _monsters.All(x => x.IsDead);
        private Enemy[] _monsters;
        private StageStatus _currentStatus = StageStatus.None;
        
        private void Start()
        {
            _monsters = GetComponentsInChildren<Enemy>(true);
            portal.SetActive(openPortalImmediately);
            _currentStatus = openPortalImmediately ? StageStatus.Cleared : StageStatus.Initialized;
        }

        private void Update()
        {
            if (openPortalImmediately)
            {
                return;
            }

            if (_currentStatus != StageStatus.Initialized)
            {
                return;
            }
            
            if (_currentStatus == StageStatus.Cleared)
            {
                return;
            }

            if (IsDeadAllMonsterInStage)
            {
                portal.SetActive(true);
                _currentStatus = StageStatus.Cleared;
            }
        }
    }
}