﻿using System;
using DeDucking.Managers;
using DeDucking.Utilities;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement;
using EventType = DeDucking.Managers.EventType;

namespace DeDucking.Environment
{
    public class BGMPlayer : MonoBehaviour
    {
        [SerializeField] private SoundInfo[] soundInfos;
        
        private bool _isPlaying = false;

        private void OnEnable()
        {
            EventManager.Instance.AddListener(EventType.OnSceneLoaded, OnSceneLoaded);
        }

        private void OnSceneLoaded(EventType type, Component sender, object[] args)
        {
            if (_isPlaying) return;

            _isPlaying = true;
            
            for (int i = 0; i < soundInfos.Length; i++)
            {
                AudioManager.Instance.PlayLoop(transform, soundInfos[i].Id, soundInfos[i].Volume);
            }
        }

        private void OnDisable()
        {
            _isPlaying = false;

            EventManager.Instance.RemoveListener(EventType.OnSceneLoaded, OnSceneLoaded);
        }
    }
}