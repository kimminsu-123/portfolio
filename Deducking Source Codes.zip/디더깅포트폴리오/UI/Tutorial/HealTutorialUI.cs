﻿using DeDucking.Entity;
using DeDucking.Managers;
using DeDucking.Player.UI;
using UnityEngine;
using EventType = DeDucking.Managers.EventType;

namespace DeDucking.UI.Tutorial
{
    public class HealTutorialUI : MonoBehaviour
    {
        [SerializeField] private GameObject uiElement;
        private bool isPlayerInRange = false;
        
        private Player.Player _player;
        private LivingEntity _livingEntity;
        private LinesController _linesController;

        private void Start()
        {
            EventManager.Instance.AddListener(EventType.OnSceneLoaded, OnSceneLoaded);
        }

        private void OnSceneLoaded(EventType type, Component sender, object[] args)
        {
            _player = FindObjectOfType<Player.Player>(true);
            _livingEntity = _player.GetComponentInChildren<LivingEntity>(true);
            _linesController = _player.GetComponentInChildren<LinesController>(true);

            _linesController.active = false;
        }

        private void OnDestroy()
        {
            EventManager.Instance.RemoveListener(EventType.OnSceneLoaded, OnSceneLoaded);
            
            _linesController.active = true;
        }

        private void OnTriggerEnter2D(Collider2D other)
        {
            if (other.CompareTag("Player"))
            {
                ShowUI();
            }
        }

        private void OnTriggerExit2D(Collider2D other)
        {
            if (other.CompareTag("Player"))
            {
                HideUI();
            }
        }
        
        private void ShowUI()
        {
            if (_livingEntity.CurrentHp == _livingEntity.EntityData.MaxHp)
            {
                _livingEntity.SetHp(_livingEntity.CurrentHp - 1);
            }

            if (DatabaseManager.Instance.PlayerData.ParryGaugeCurrent <
                DatabaseManager.Instance.PlayerData.ParryGaugeReduction)
            {
                DatabaseManager.Instance.PlayerData.IncreaseParryGauge();
            }
            
            uiElement.SetActive(true);
            isPlayerInRange = true;
        }

        private void HideUI()
        {
            uiElement.SetActive(false);
            isPlayerInRange = false;
        }
    }
}