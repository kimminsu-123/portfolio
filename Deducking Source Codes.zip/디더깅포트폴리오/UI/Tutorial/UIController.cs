using System;
using DeDucking.Managers;
using NaughtyAttributes;
using UnityEditor;
using UnityEngine;
using TMPro;

namespace DeDucking.UI.Tutorial
{
    public enum InputFlag
    {
        Move,
        Jump,
        Attack,
        Dash,
        DropThrough,
        Block,
        Heal,
    }

    public class UIController : MonoBehaviour
    {
        [SerializeField] private InputFlag inputFlag;
        [SerializeField] private GameObject uiElement;
        [SerializeField] private TMP_Text inputStatusText;
        [SerializeField] private Collider2D boundaryCollider2D;

        private int inputCount = 0;
        private const int RequiredInputs = 3;
        private bool isPlayerInRange = false;
        private bool tutorialCompleted = false;

        private void OnTriggerEnter2D(Collider2D other)
        {
            if (other.CompareTag("Player") && !tutorialCompleted)
            {
                ShowTutorialUI();
            }
        }

        private void Update()
        {
            if (isPlayerInRange && !tutorialCompleted)
            {
                if (CheckInput())
                {
                    inputCount++;
                    UpdateInputStatus();

                    if (inputCount >= RequiredInputs)
                    {
                        CompleteTutorial();
                    }
                }
            }
        }

        private bool CheckInput()
        {
            switch (inputFlag)
            {
                case InputFlag.Move:
                    return InputManager.Instance.IsMoveDown;
                case InputFlag.Jump:
                    return InputManager.Instance.IsJumpKeyDown;
                case InputFlag.Attack:
                    return InputManager.Instance.IsAttackKeyDown;
                case InputFlag.Dash:
                    return InputManager.Instance.IsDashDown;
                case InputFlag.Block:
                    return InputManager.Instance.IsBlockKeyDown;
                case InputFlag.Heal:
                    return InputManager.Instance.IsHealKeyDown;
            }

            return false;
        }

        private void ShowTutorialUI()
        {
            uiElement.SetActive(true);
            isPlayerInRange = true;
            inputCount = 0;
            UpdateInputStatus();
            boundaryCollider2D.enabled = true;
        }

        private void CompleteTutorial()
        {
            tutorialCompleted = true;
            HideTutorialUI();
        }
        
        private void HideTutorialUI()
        {
            uiElement.SetActive(false);
            isPlayerInRange = false;
            boundaryCollider2D.enabled = false;
        }

        private void UpdateInputStatus()
        {
            if (inputStatusText != null)
            {
                inputStatusText.text = $"{inputCount}/{RequiredInputs}";
            }
        }
    }
}
