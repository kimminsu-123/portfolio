﻿using System;
using System.Collections;
using DeDucking.UI.Interfaces;
using DeDucking.Utilities;
using DG.Tweening;
using UnityEngine;

namespace DeDucking.UI.Canvas
{
    [RequireComponent(typeof(LoadingCanvas))]
    public class LoadingCanvas : MonoBehaviour, ICanvas
    {
        [SerializeField] private float fadeDuration = 0.2f;
        [SerializeField] private CanvasGroup canvasGroup;

        private Action _onFadeInCompleted;
        private Action _onFadeOutCompleted;

        public void SetCompleteFadeInCallback(Action callback)
        {
            _onFadeInCompleted = Enable;
            _onFadeInCompleted += callback;
        }

        public void SetCompleteFadeOutCallback(Action callback)
        {
            _onFadeOutCompleted = callback;
            _onFadeOutCompleted += Disable;
        }

        public void Show()
        {
            Fade(1f, _onFadeInCompleted);
        }

        public void Hide()
        {
            Fade(0f, _onFadeOutCompleted);
        }
        
        private void Fade(float to, Action callback)
        {
            canvasGroup
                .DOFade(to, fadeDuration)
                .OnComplete(callback.Invoke)
                .SetAutoKill(true)
                .Play();
        }

        private void Enable()
        {
            gameObject.SetActive(true);
        }
        
        private void Disable()
        {
            gameObject.SetActive(false);
        }
    }
}