using DeDucking.Managers;
using DeDucking.Utilities;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using Logger = DeDucking.Utilities.Logger;

namespace DeDucking.UI
{
    public class HighlightButton : Button
    {
        [SerializeField] private GameObject selectedObj;

        [SerializeField] private SoundInfo selectedSound;
        [SerializeField] private TMP_Text targetText;
        [SerializeField] private Color selectedColor;
        [SerializeField] private Color deselectedColor;

        public override void OnSelect(BaseEventData eventData)
        {
            Logger.Log("Highlight Button", $"Selected {name}", Color.green);
            base.OnSelect(eventData);
            UpdateHighlight();
        }

        public override void OnDeselect(BaseEventData eventData)
        {
            Logger.Log("Highlight Button", $"DeSelected {name}", Color.green);
            base.OnDeselect(eventData);
            UpdateHighlight();
        }

        private void UpdateHighlight()
        {
            Logger.Log("Highlight Button", $"Update {name} - {currentSelectionState}", Color.green);
            bool selectedActivation = currentSelectionState == SelectionState.Selected;
            
            selectedObj.SetActive(selectedActivation);
            targetText.faceColor = selectedActivation ? selectedColor : deselectedColor;
            
            if (selectedActivation)
            {
                AudioManager.Instance.PlayOneShot(gameObject.transform, selectedSound.Id, selectedSound.Volume);
            }
        }
    }
}