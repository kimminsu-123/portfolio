using Cinemachine;
using UnityEngine;

public class MinimapCam : MonoBehaviour
{
    private GameObject _followCam;
    private Camera _cam;

    private CinemachineConfiner2D _confiner;
    private Collider2D _limitCollider;

    Bounds bounds;

    private float _limitLeft, _limitRight;
    private float _limitTop, _limitBottom;

    private float _camLeftBoundary, _camRightBoundary;
    private float _camTopBoundary, _camBottomBoundary;

    private float _camX;
    private float _camY;



    void Start()
    {
        _followCam = GameObject.Find("FollowCamera");
        _confiner = _followCam.GetComponent<CinemachineConfiner2D>();
        _cam = gameObject.GetComponent<Camera>();
    }

    void Update()
    {
        SetMinimapCamPos();
    }

    private void SetMinimapCamPos()
    {
        _camLeftBoundary = transform.position.x - (_cam.orthographicSize * _cam.aspect);
        _camRightBoundary = transform.position.x + (_cam.orthographicSize * _cam.aspect);
        _camTopBoundary = transform.position.y + _cam.orthographicSize;
        _camBottomBoundary = transform.position.y - _cam.orthographicSize;

        if (_limitCollider == null)
        {
            _limitCollider = _confiner.m_BoundingShape2D;
            if (_limitCollider != null)
            {
                bounds = _limitCollider.bounds;

                _limitLeft = bounds.min.x;
                _limitRight = bounds.max.x;
                _limitTop = bounds.max.y;
                _limitBottom = bounds.min.y;
            }
        }
        else
        {
            _camX = _followCam.transform.position.x;
            _camY = _followCam.transform.position.y;

            if (_camX - (_cam.orthographicSize * _cam.aspect) < _limitLeft)
                _camX = _limitLeft + (_cam.orthographicSize * _cam.aspect);
            if (_camX + (_cam.orthographicSize * _cam.aspect) > _limitRight)
                _camX = _limitRight - (_cam.orthographicSize * _cam.aspect);

            if (_camY + _cam.orthographicSize > _limitTop)
                _camY = _limitTop - _cam.orthographicSize;
            if (_camY - _cam.orthographicSize < _limitBottom)
                _camY = _limitBottom + _cam.orthographicSize;

            transform.position = new Vector3(_camX, _camY, -15);
        }
    }



    private void OnDrawGizmos()
    {
        Gizmos.color = Color.green;
        Gizmos.DrawLine(new Vector3(_camLeftBoundary, _camTopBoundary), new Vector3(_camRightBoundary, _camTopBoundary));
        Gizmos.DrawLine(new Vector3(_camLeftBoundary, _camBottomBoundary), new Vector3(_camRightBoundary, _camBottomBoundary));
        Gizmos.DrawLine(new Vector3(_camLeftBoundary, _camTopBoundary), new Vector3(_camLeftBoundary, _camBottomBoundary));
        Gizmos.DrawLine(new Vector3(_camRightBoundary, _camTopBoundary), new Vector3(_camRightBoundary, _camBottomBoundary));


        Gizmos.color = Color.red;
        Gizmos.DrawLine(new Vector3(_limitLeft, _limitTop), new Vector3(_limitRight, _limitTop));
        Gizmos.DrawLine(new Vector3(_limitLeft, _limitBottom), new Vector3(_limitRight, _limitBottom));
        Gizmos.DrawLine(new Vector3(_limitLeft, _limitTop), new Vector3(_limitLeft, _limitBottom));
        Gizmos.DrawLine(new Vector3(_limitRight, _limitTop), new Vector3(_limitRight, _limitBottom));
    }
}
