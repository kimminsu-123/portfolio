﻿namespace DeDucking.UI.Interfaces
{
    public interface ICanvas
    {
        public void Show();
        public void Hide();
    }
}