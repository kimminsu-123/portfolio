﻿using System;
using DeDucking.Managers;
using UnityEngine;
using UnityEngine.UI;
using EventType = DeDucking.Managers.EventType;
using Logger = DeDucking.Utilities.Logger;

namespace DeDucking.UI
{
    public class MainCanvas : MonoBehaviour
    {
        [SerializeField] private Button newGameButton;
        [SerializeField] private Button continueButton;
        [SerializeField] private Button exitButton;

        private void Start()
        {
            EventManager.Instance.AddListener(EventType.OnSceneLoadedBefore, OnSceneLoadedBefore);
            
            newGameButton.onClick.AddListener(GameManager.Instance.StartNewGame);
            continueButton.onClick.AddListener(GameManager.Instance.ContinueGame);
            exitButton.onClick.AddListener(GameManager.Instance.ExitGame);
        }

        private void OnSceneLoadedBefore(EventType type, Component sender, object[] args)
        {
            UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(newGameButton.gameObject);
            Logger.Log("MainCanvas Init", $"Start", Color.green);
        }

        private void OnDestroy()
        {
            EventManager.Instance.RemoveListener(EventType.OnSceneLoadedBefore, OnSceneLoadedBefore);
        }
    }
}