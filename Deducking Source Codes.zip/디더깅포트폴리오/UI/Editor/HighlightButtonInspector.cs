using System;
using UnityEditor;

namespace DeDucking.UI
{
    [CanEditMultipleObjects]
    [CustomEditor(typeof(HighlightButton))]
    public class HighlightButtonInspector : UnityEditor.Editor
    {
        private SerializedProperty _hoverObjProperty;
        private SerializedProperty _unHoverObjProperty;
        
        private void OnEnable()
        {
            _hoverObjProperty = serializedObject.FindProperty("hoverObj");
            _unHoverObjProperty = serializedObject.FindProperty("unHoverObj");
        }

        public override void OnInspectorGUI()
        {
            base.OnInspectorGUI();
        }
    }
}